/* ============================================================
   牛逼清恒 — App core
   - Hash router
   - localStorage state
   - SRS (Leitner 5 boxes)
   - Helpers for views
   ============================================================ */
(function () {
  'use strict';

  const STORAGE_KEY = 'xq_state_v1';
  const TODAY_OVERRIDE_KEY = 'xq_today_override'; // for testing — yyyy-mm-dd
  const START_DATE = new Date(2026, 4, 28); // 28/5/2026
  const TOTAL_DAYS = 32;

  // ====== Store ======
  let state = loadState();

  function defaultState() {
    return {
      lessons: {}, // lessonId -> { vocab: {wordIdx: {box, due, seen}}, tabsDone: {vocab,dialog,notes,exercises}, score: {correct,total}, completed: false }
      stats: { lastVisited: null, lastLessonId: null, lastTab: null, streak: 0, lastStudyDate: null },
      settings: { pinyinAlwaysOn: false }
    };
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultState();
      const parsed = JSON.parse(raw);
      // Migrations
      if (!parsed.lessons) parsed.lessons = {};
      if (!parsed.stats) parsed.stats = { lastVisited: null, lastLessonId: null, lastTab: null, streak: 0, lastStudyDate: null };
      if (!parsed.settings) parsed.settings = { pinyinAlwaysOn: false };
      return parsed;
    } catch (e) {
      return defaultState();
    }
  }

  function saveState() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
    catch (e) { console.warn('storage failed', e); }
  }

  function lessonState(id) {
    if (!state.lessons[id]) {
      state.lessons[id] = {
        vocab: {},        // wordIdx -> { box: 0-4, due: epochDay, lastSeen: epochDay }
        tabsDone: {},     // 'vocab'|'dialogue'|'notes'|'exercises' -> true
        score: null,      // { correct, total, when }
        exerciseAnswers: {}, // qNum -> userAnswer (for resume)
        completed: false,
        startedAt: null
      };
    }
    return state.lessons[id];
  }

  // ====== Dates ======
  function today() {
    const override = localStorage.getItem(TODAY_OVERRIDE_KEY);
    if (override) return new Date(override + 'T00:00:00');
    return new Date();
  }

  function epochDay(d) {
    // days since some fixed epoch; 0-based int
    const ms = (d || today()).getTime();
    const offset = (d || today()).getTimezoneOffset() * 60000;
    return Math.floor((ms - offset) / 86400000);
  }

  // Lesson "scheduled day" — how many days from START_DATE this lesson is meant for.
  function lessonScheduledDay(num) {
    return num - 1; // bài 1 is day 0
  }

  function todayLessonNum() {
    const t = today();
    const diff = Math.floor((t - START_DATE) / 86400000);
    if (diff < 0) return 1;
    if (diff >= TOTAL_DAYS) return TOTAL_DAYS;
    return diff + 1;
  }

  function isInFuture(num) {
    return num > todayLessonNum();
  }

  // Pretty date short form
  function fmtDate(dateStr) {
    return dateStr; // already like "28/5"
  }

  // ====== SRS (Leitner 5 boxes) ======
  // Boxes 0..4. Intervals in days: 0->1, 1->2, 2->4, 3->7, 4->14
  const SRS_INTERVALS = [1, 2, 4, 7, 14];

  function srsReviewWord(wordKey /* `${lessonId}-${idx}` */, quality /* 'again'|'good'|'easy' */) {
    const [lid, idx] = wordKey.split('-');
    const ls = lessonState(+lid);
    const v = ls.vocab[idx] || { box: 0, due: 0, lastSeen: 0 };
    const ed = epochDay();
    if (quality === 'again') {
      v.box = 0;
    } else if (quality === 'good') {
      v.box = Math.min(4, v.box + 1);
    } else if (quality === 'easy') {
      v.box = Math.min(4, v.box + 2);
    }
    v.lastSeen = ed;
    v.due = ed + SRS_INTERVALS[v.box];
    ls.vocab[idx] = v;
    saveState();
  }

  function dueVocab() {
    // Collect due words across all lessons
    const ed = epochDay();
    const due = [];
    for (const [lid, ls] of Object.entries(state.lessons)) {
      const L = LESSONS.find(x => x.num === +lid);
      if (!L) continue;
      for (const [idx, v] of Object.entries(ls.vocab)) {
        if (v.due <= ed) {
          const word = L.vocab[+idx];
          if (word) due.push({ lessonId: +lid, idx: +idx, word, v });
        }
      }
    }
    return due;
  }

  function vocabStats() {
    // Total vocab words across lessons with content
    let total = 0, learned = 0, mastered = 0;
    for (const L of LESSONS) {
      total += L.vocab.length;
      const ls = state.lessons[L.num];
      if (!ls) continue;
      for (const [idx, v] of Object.entries(ls.vocab)) {
        if (idx >= L.vocab.length) continue;
        learned++;
        if (v.box >= 3) mastered++;
      }
    }
    return { total, learned, mastered };
  }

  function lessonsStats() {
    let total = CURRICULUM.length;
    let completed = 0, started = 0;
    for (const c of CURRICULUM) {
      const ls = state.lessons[c.num];
      if (!ls) continue;
      started++;
      if (ls.completed) completed++;
    }
    return { total, started, completed };
  }

  function avgScore() {
    let sum = 0, n = 0;
    for (const c of CURRICULUM) {
      const ls = state.lessons[c.num];
      if (!ls || !ls.score) continue;
      sum += ls.score.correct / ls.score.total;
      n++;
    }
    return n === 0 ? null : sum / n;
  }

  // ====== Router ======
  const routes = {
    dashboard: { match: (h) => h === '' || h === '/' || h === '/dashboard', render: () => XQ.views.dashboard() },
    lesson:    { match: (h) => h.startsWith('/lesson/'),  render: (h) => {
      const parts = h.slice(8).split('/');
      const num = +parts[0];
      const tab = parts[1] || 'vocab';
      XQ.views.lesson(num, tab);
    }},
    roadmap:   { match: (h) => h === '/roadmap', render: () => XQ.views.roadmap() },
    review:    { match: (h) => h === '/review' || h.startsWith('/review/'), render: () => XQ.views.review() },
    exam:      { match: (h) => h === '/exam', render: () => XQ.views.exam() },
  };

  function navTo(hash) {
    if (location.hash === '#' + hash) {
      route();
    } else {
      location.hash = hash;
    }
  }

  function route() {
    const h = location.hash.replace(/^#/, '') || '/';
    let routeName = 'dashboard';
    for (const [name, r] of Object.entries(routes)) {
      if (r.match(h)) { routeName = name; break; }
    }
    // Update active nav
    document.querySelectorAll('#topnav a').forEach(a => {
      a.classList.toggle('active', a.getAttribute('data-route') === routeName);
    });
    // Scroll to top on route change
    window.scrollTo(0, 0);
    routes[routeName].render(h);
  }

  // ====== DOM helpers ======
  function el(tag, attrs, ...children) {
    const e = document.createElement(tag);
    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (k === 'class') e.className = v;
        else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
        else if (k === 'html') e.innerHTML = v;
        else if (k === 'text') e.textContent = v;
        else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k === 'data') for (const [dk, dv] of Object.entries(v)) e.dataset[dk] = dv;
        else if (v === true) e.setAttribute(k, '');
        else if (v !== false && v != null) e.setAttribute(k, v);
      }
    }
    for (const c of children.flat()) {
      if (c == null || c === false) continue;
      if (typeof c === 'string' || typeof c === 'number') e.appendChild(document.createTextNode(c));
      else e.appendChild(c);
    }
    return e;
  }

  function render(node) {
    const v = document.getElementById('view');
    v.innerHTML = '';
    v.appendChild(node);
  }

  // Shuffle helper
  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  // String normalize for forgiving comparison in fill-blank answers
  function normalizeStr(s) {
    return (s || '').toString().trim().toLowerCase().replace(/[\s.,!?，。！？]/g, '');
  }

  // Sleep
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ====== Boot ======
  function boot() {
    window.addEventListener('hashchange', route);
    route();
  }

  // Expose
  window.XQ = {
    boot, navTo, route,
    state, saveState, lessonState,
    today, epochDay, todayLessonNum, isInFuture,
    srsReviewWord, dueVocab, vocabStats, lessonsStats, avgScore, SRS_INTERVALS,
    el, render, shuffle, normalizeStr, sleep,
    START_DATE, TOTAL_DAYS,
    views: {} // filled in by view modules
  };
})();
