window.CURRICULUM = [
  {
    "num": 1,
    "date": "28/5",
    "phase": 1,
    "title": "Chào hỏi & Giới thiệu trong môi trường B2B"
  },
  {
    "num": 2,
    "date": "29/5",
    "phase": 1,
    "title": "Hỏi giá & Báo giá"
  },
  {
    "num": 3,
    "date": "30/5",
    "phase": 1,
    "title": "Số lượng & Điều kiện đặt hàng"
  },
  {
    "num": 4,
    "date": "31/5",
    "phase": 1,
    "title": "Thanh toán quốc tế"
  },
  {
    "num": 5,
    "date": "1/6",
    "phase": 1,
    "title": "Chuỗi cung ứng & Tình trạng hàng hóa"
  },
  {
    "num": 6,
    "date": "2/6",
    "phase": 1,
    "title": "Giao hàng & Vận chuyển"
  },
  {
    "num": 7,
    "date": "3/6",
    "phase": 1,
    "title": "Chất lượng & Kiểm hàng"
  },
  {
    "num": 8,
    "date": "4/6",
    "phase": 1,
    "title": "Khiếu nại & Xử lý tranh chấp"
  },
  {
    "num": 9,
    "date": "5/6",
    "phase": 1,
    "title": "Hợp đồng & Điều khoản pháp lý"
  },
  {
    "num": 10,
    "date": "6/6",
    "phase": 1,
    "title": "Chứng từ xuất nhập khẩu"
  },
  {
    "num": 11,
    "date": "7/6",
    "phase": 1,
    "title": "Đàm phán giá & Thương lượng"
  },
  {
    "num": 12,
    "date": "8/6",
    "phase": 1,
    "title": "Hội chợ triển lãm — Ngôn ngữ tổng quát"
  },
  {
    "num": 13,
    "date": "9/6",
    "phase": 2,
    "title": "OEM/ODM — Khái niệm & Quy trình"
  },
  {
    "num": 14,
    "date": "10/6",
    "phase": 2,
    "title": "Nội thất — Vật liệu & Sản phẩm"
  },
  {
    "num": 15,
    "date": "11/6",
    "phase": 2,
    "title": "Nội thất — Tiêu chuẩn xuất Mỹ"
  },
  {
    "num": 16,
    "date": "12/6",
    "phase": 2,
    "title": "Mỹ phẩm — Thành phần & Sản phẩm"
  },
  {
    "num": 17,
    "date": "13/6",
    "phase": 2,
    "title": "Mỹ phẩm — Chứng nhận FDA & Quy định"
  },
  {
    "num": 18,
    "date": "14/6",
    "phase": 2,
    "title": "Thời trang — Chất liệu & Sản phẩm"
  },
  {
    "num": 19,
    "date": "15/6",
    "phase": 2,
    "title": "Thời trang — Sản xuất & Kiểm hàng"
  },
  {
    "num": 20,
    "date": "16/6",
    "phase": 2,
    "title": "Hội thoại tổng hợp — Hàng tiêu dùng B2B"
  },
  {
    "num": 21,
    "date": "17/6",
    "phase": 3,
    "title": "Sản phẩm điện tử & Thông số kỹ thuật"
  },
  {
    "num": 22,
    "date": "18/6",
    "phase": 3,
    "title": "Chứng nhận FCC/CE/RoHS cho điện tử"
  },
  {
    "num": 23,
    "date": "19/6",
    "phase": 3,
    "title": "Linh kiện điện tử & BOM"
  },
  {
    "num": 24,
    "date": "20/6",
    "phase": 3,
    "title": "Sản xuất & Kiểm soát chất lượng điện tử"
  },
  {
    "num": 25,
    "date": "21/6",
    "phase": 3,
    "title": "Phát triển sản phẩm ODM điện tử"
  },
  {
    "num": 26,
    "date": "22/6",
    "phase": 3,
    "title": "Hội thoại tổng hợp — Hội chợ điện tử"
  },
  {
    "num": 27,
    "date": "23/6",
    "phase": 4,
    "title": "Năng lượng tái tạo — Sản phẩm & Công nghệ"
  },
  {
    "num": 28,
    "date": "24/6",
    "phase": 4,
    "title": "Pin & Xe điện"
  },
  {
    "num": 29,
    "date": "25/6",
    "phase": 4,
    "title": "Khoáng sản chiến lược"
  },
  {
    "num": 30,
    "date": "26/6",
    "phase": 4,
    "title": "Đầu tư FDI & Hợp tác doanh nghiệp"
  },
  {
    "num": 31,
    "date": "27/6",
    "phase": 4,
    "title": "Hội thoại tổng hợp — Đầu tư năng lượng xanh"
  },
  {
    "num": 32,
    "date": "28/6",
    "phase": 5,
    "title": "Thực chiến — Kiểm tra tổng hợp"
  }
];
window.PHASES = [
  {
    "id": 1,
    "name": "Từ vựng & Hội thoại nền tảng",
    "range": "28/5 – 8/6",
    "zh": "基础阶段"
  },
  {
    "id": 2,
    "name": "Hàng tiêu dùng OEM/ODM",
    "range": "9/6 – 16/6",
    "zh": "消费品阶段"
  },
  {
    "id": 3,
    "name": "Điện tử & Công nghệ cao",
    "range": "17/6 – 22/6",
    "zh": "电子阶段"
  },
  {
    "id": 4,
    "name": "Năng lượng xanh & Khoáng sản",
    "range": "23/6 – 27/6",
    "zh": "绿能阶段"
  },
  {
    "id": 5,
    "name": "Thực chiến",
    "range": "28/6",
    "zh": "实战"
  }
];
