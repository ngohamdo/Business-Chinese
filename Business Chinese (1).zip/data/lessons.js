// Auto-generated from giaotrinh_tiengtrung_thuongmai_bai1-27.txt
window.LESSONS = [
  {
    "num": 1,
    "title": "CHÀO HỎI & GIỚI THIỆU TRONG MÔI TRƯỜNG B2B",
    "date": "28/5",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "贵公司",
        "pinyin": "guì gōngsī",
        "vi": "quý công ty",
        "explanation": "Cách gọi lịch sự chỉ công ty của đối phương. \"贵\" có nghĩa là \"quý/đáng kính\". Trong môi trường B2B Trung Quốc, luôn dùng 贵公司 khi nói về công ty đối tác, không bao giờ nói thẳng tên công ty họ trong câu vì nghe thiếu tôn trọng. Ngược lại, khi nói về công ty mình thì dùng 我们公司 hoặc 我方.",
        "example": {
          "zh": "贵公司主要做哪些产品？",
          "vi": "Quý công ty chủ yếu làm những sản phẩm gì?"
        }
      },
      {
        "num": 2,
        "hanzi": "我方",
        "pinyin": "wǒ fāng",
        "vi": "phía chúng tôi / bên chúng tôi",
        "explanation": "Cách nói trang trọng hơn 我们 khi đề cập đến phía mình trong đàm phán hoặc hợp đồng. 方 có nghĩa là \"bên/phía\". Trong hợp đồng viết thường thấy 甲方 (bên A) và 乙方 (bên B). Trong cuộc họp, dùng 我方 thay vì 我们 để thể hiện sự chuyên nghiệp.",
        "example": {
          "zh": "我方对这次合作非常重视。",
          "vi": "Phía chúng tôi rất coi trọng lần hợp tác này."
        }
      },
      {
        "num": 3,
        "hanzi": "贵方",
        "pinyin": "guì fāng",
        "vi": "phía quý vị / bên quý vị",
        "explanation": "Tương đương 贵公司 nhưng dùng trong văn viết hoặc khi muốn nói ngắn hơn. Hay xuất hiện trong email, hợp đồng, và các văn bản chính thức. Cặp đôi 我方/贵方 thường xuất hiện song song trong một đoạn văn đàm phán.",
        "example": {
          "zh": "贵方是否同意这个条款？",
          "vi": "Phía quý vị có đồng ý điều khoản này không?"
        }
      },
      {
        "num": 4,
        "hanzi": "初次见面",
        "pinyin": "chūcì jiànmiàn",
        "vi": "lần đầu gặp mặt",
        "explanation": "Cụm từ dùng để mở đầu khi gặp ai đó lần đầu tiên trong môi trường kinh doanh. Thường đi kèm với 请多关照 (xin nhiều chỉ giáo / mong được hợp tác). Đây là nghi thức xã giao quan trọng trong văn hóa kinh doanh TQ — bỏ qua bước này có thể bị xem là thiếu lịch sự.",
        "example": {
          "zh": "初次见面，请多关照。",
          "vi": "Lần đầu gặp mặt, xin nhiều chỉ giáo."
        }
      },
      {
        "num": 5,
        "hanzi": "久仰大名",
        "pinyin": "jiǔ yǎng dàmíng",
        "vi": "nghe danh đã lâu",
        "explanation": "Cụm từ lịch sự dùng khi gặp người mà mình đã biết tiếng từ trước — qua giới thiệu, qua internet, hoặc qua danh tiếng ngành. Không nhất thiết phải biết thật — đây là nghi thức xã giao để tạo thiện cảm ngay từ đầu. Tương đương \"Tôi đã nghe nhiều về anh/chị\" trong tiếng Việt.",
        "example": {
          "zh": "久仰大名，今日终于见到您了。",
          "vi": "Nghe danh đã lâu, hôm nay mới được gặp."
        }
      },
      {
        "num": 6,
        "hanzi": "合作愉快",
        "pinyin": "hézuò yúkuài",
        "vi": "hợp tác vui vẻ / chúc hợp tác tốt đẹp",
        "explanation": "Câu chúc thường nói vào cuối buổi gặp mặt hoặc sau khi ký hợp đồng, tương đương \"chúc hợp tác thành công\". Có thể nói đơn giản là 合作愉快! như một lời chào kết thúc. Người TQ rất hay dùng câu này và kỳ vọng bạn đáp lại — nếu im lặng sẽ tạo cảm giác lạnh nhạt.",
        "example": {
          "zh": "希望我们合作愉快！",
          "vi": "Hy vọng chúng ta hợp tác vui vẻ!"
        }
      },
      {
        "num": 7,
        "hanzi": "请多关照",
        "pinyin": "qǐng duō guānzhào",
        "vi": "xin nhiều chỉ giáo / nhờ nhiều quan tâm",
        "explanation": "Câu nói khiêm tốn khi mới làm quen, ý muốn nói \"mong anh/chị chỉ dạy và hỗ trợ\". Trong văn hóa TQ, câu này thể hiện sự khiêm tốn và thiện chí. Không cần dịch từng chữ — khi phiên dịch, bạn có thể dịch ý là \"mong được hợp tác tốt đẹp\".",
        "example": {
          "zh": "以后还请多关照。",
          "vi": "Sau này còn nhờ nhiều chỉ giáo."
        }
      },
      {
        "num": 8,
        "hanzi": "名片",
        "pinyin": "míngpiàn",
        "vi": "danh thiếp",
        "explanation": "Card visit. Trong văn hóa kinh doanh TQ, việc trao và nhận danh thiếp có nghi thức riêng: dùng hai tay để đưa và nhận, nhận xong phải nhìn vào đọc một chút trước khi cất — không được nhét vào túi ngay. Đây là điều bạn cần biết khi phiên dịch vì bạn sẽ thường đứng cạnh và quan sát những khoảnh khắc này.",
        "example": {
          "zh": "这是我的名片，请多指教。",
          "vi": "Đây là danh thiếp của tôi, mong được chỉ giáo."
        }
      },
      {
        "num": 9,
        "hanzi": "互相介绍",
        "pinyin": "hùxiāng jièshào",
        "vi": "giới thiệu lẫn nhau",
        "explanation": "Bước đầu tiên trong mọi cuộc gặp B2B. Phiên dịch viên thường phải dẫn dắt bước này — giới thiệu từng người một cho cả hai bên hiểu. Quan trọng là dịch đúng chức danh (职位) vì người TQ rất coi trọng thứ bậc.",
        "example": {
          "zh": "我来给大家互相介绍一下。",
          "vi": "Để tôi giới thiệu mọi người cho nhau."
        }
      },
      {
        "num": 10,
        "hanzi": "此次拜访的目的",
        "pinyin": "cǐcì bàifǎng de mùdì",
        "vi": "mục đích của chuyến thăm lần này",
        "explanation": "Cụm từ dùng khi mở đầu nội dung chính của cuộc gặp, sau phần chào hỏi xã giao. Thường do trưởng đoàn phía khách nói trước để định hướng cuộc họp. Phiên dịch cần dịch chính xác cụm này vì nó đặt tone cho toàn bộ buổi gặp.",
        "example": {
          "zh": "此次拜访的目的主要是了解贵公司的产品。",
          "vi": "Mục đích chuyến thăm lần này chủ yếu là tìm hiểu sản phẩm của quý công ty."
        }
      }
    ],
    "dialogue": {
      "context": "Đoàn mua hàng Việt Nam 3 người đến thăm nhà máy tại Quảng Châu lần đầu. Bạn là phiên dịch đi cùng đoàn.",
      "characters": [
        {
          "name": "李总 (Lǐ zǒng)",
          "role": "Giám đốc nhà máy TQ"
        },
        {
          "name": "Anh Hùng",
          "role": "Trưởng đoàn phía Việt Nam"
        }
      ],
      "lines": [
        {
          "speaker": "李总",
          "zh": "欢迎欢迎！一路辛苦了，请进请进。",
          "vi": "Chào mừng chào mừng! Đường xa vất vả, mời vào mời vào."
        },
        {
          "speaker": "李总",
          "zh": "这是我们公司的销售总监王经理，这是技术部的张工。",
          "vi": "Đây là Giám đốc kinh doanh của chúng tôi, anh Wang, và đây là kỹ sư phòng kỹ thuật, anh Zhang."
        },
        {
          "speaker": "Anh Hùng",
          "zh": "您好，李总。久仰大名，今日终于见到您了。这是我们公司的采购总监陈先生，这是我的助理小林。",
          "vi": "Xin chào, anh Lý. Nghe danh đã lâu, hôm nay mới được gặp. Đây là Trưởng phòng thu mua của chúng tôi, anh Trần, và đây là trợ lý của tôi, chị Lâm."
        },
        {
          "speaker": "李总",
          "zh": "初次见面，请多关照。来，大家先坐下喝杯茶。",
          "vi": "Lần đầu gặp mặt, xin nhiều chỉ giáo. Nào, mọi người ngồi xuống uống trà đã."
        },
        {
          "speaker": "Anh Hùng",
          "zh": "谢谢。李总，这是我的名片，请多指教。",
          "vi": "Cảm ơn. Anh Lý, đây là danh thiếp của tôi, mong được chỉ giáo."
        },
        {
          "speaker": "李总",
          "zh": "谢谢，这是我的。我们工厂做外贸已经十二年了，主要出口欧美市场，很高兴认识贵公司。",
          "vi": "Cảm ơn, đây là của tôi. Nhà máy chúng tôi làm ngoại thương đã 12 năm, chủ yếu xuất sang thị trường Âu Mỹ, rất vui được làm quen với quý công ty."
        },
        {
          "speaker": "Anh Hùng",
          "zh": "我们公司专门做越南到美国的出口贸易。此次拜访的目的，主要是想了解贵公司的产品和合作可能性。",
          "vi": "Công ty chúng tôi chuyên làm thương mại xuất khẩu từ Việt Nam sang Mỹ. Mục đích chuyến thăm lần này chủ yếu là muốn tìm hiểu sản phẩm của quý công ty và khả năng hợp tác."
        },
        {
          "speaker": "李总",
          "zh": "太好了，我们也一直希望开拓越南市场。今天先参观一下我们的展厅，然后我们再详细洽谈，您看怎么样？",
          "vi": "Tuyệt quá, chúng tôi cũng luôn muốn mở rộng thị trường Việt Nam. Hôm nay trước tiên tham quan phòng trưng bày của chúng tôi, sau đó chúng ta sẽ bàn chi tiết hơn, anh thấy thế nào?"
        },
        {
          "speaker": "Anh Hùng",
          "zh": "非常好，一切听李总安排。",
          "vi": "Rất tốt, mọi việc nghe anh Lý sắp xếp."
        },
        {
          "speaker": "李总",
          "zh": "好，那我们开始吧。希望今天我们合作愉快！",
          "vi": "Tốt, vậy chúng ta bắt đầu nhé. Chúc hôm nay hợp tác vui vẻ!"
        }
      ]
    },
    "notes": [
      {
        "title": "Thứ tự ưu tiên trong giới thiệu",
        "body": "Người TQ giới thiệu theo thứ bậc từ cao xuống thấp. Người chức vụ cao nhất được giới thiệu trước. Khi bạn làm phiên dịch và phải dẫn dắt phần này, hãy hỏi trước về chức danh của từng người trong đoàn để giới thiệu đúng thứ tự — sai thứ tự có thể gây khó xử cho cả hai bên."
      },
      {
        "title": "Nghi thức danh thiếp",
        "body": "Khi đưa và nhận danh thiếp, người TQ dùng hai tay. Nhận xong phải nhìn vào đọc ít nhất 3–5 giây rồi mới cất. Đặt danh thiếp lên bàn trước mặt trong suốt cuộc họp cũng là cách thể hiện tôn trọng. Trong vai trò phiên dịch, bạn cũng sẽ được trao danh thiếp — hãy thực hiện đúng nghi thức này."
      },
      {
        "title": "Giai đoạn xã giao không thể bỏ qua",
        "body": "Người TQ không vào thẳng nội dung kinh doanh ngay. Họ luôn có 10–20 phút xã giao (uống trà, hỏi thăm đường xa, khen thành phố...) trước khi vào việc. Đây không phải thời gian lãng phí mà là bước xây dựng quan hệ (关系 guānxi) — rất quan trọng trong văn hóa kinh doanh TQ. Phiên dịch cần dịch cả phần này, không được bỏ qua."
      },
      {
        "title": "张工 là gì",
        "body": "工 (gōng) là cách gọi tắt của 工程师 (kỹ sư). 张工 = kỹ sư Zhang. Trong nhà máy sản xuất, bạn sẽ gặp cách gọi này rất thường xuyên. Tương tự: 王经理 = Giám đốc/Quản lý Wang, 李总 = Giám đốc Lý, 陈主任 = Trưởng phòng Trần."
      },
      {
        "title": "Đừng dịch quá sát 请多关照",
        "body": "Nếu dịch từng chữ sẽ thành \"xin nhiều quan chiếu\" — nghe rất lạ trong tiếng Việt. Tùy ngữ cảnh bạn có thể dịch là \"mong được hợp tác tốt đẹp\", \"nhờ anh/chị nhiều\", hoặc đơn giản là \"rất vui được làm quen\". Phiên dịch giỏi là dịch ý, không dịch chữ."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "贵公司 được dùng để chỉ ai?",
          "options": {
            "A": "Công ty của mình",
            "B": "Công ty của đối tác / người đang nói chuyện cùng",
            "C": "Công ty lớn nhất trong ngành",
            "D": "Công ty nước ngoài"
          }
        },
        {
          "num": 2,
          "q": "Khi nhận danh thiếp từ đối tác TQ, bạn nên làm gì?",
          "options": {
            "A": "Cất ngay vào túi để thể hiện sự gọn gàng",
            "B": "Nhận bằng một tay và đặt sang bên",
            "C": "Nhận bằng hai tay, đọc qua, có thể đặt trên bàn trước mặt",
            "D": "Chụp ảnh ngay lập tức"
          }
        },
        {
          "num": 3,
          "q": "久仰大名 phù hợp dùng trong tình huống nào?",
          "options": {
            "A": "Gặp lại người quen sau nhiều năm",
            "B": "Gặp lần đầu người mà bạn đã biết tiếng từ trước",
            "C": "Khi muốn khen ngợi sản phẩm của đối tác",
            "D": "Khi kết thúc cuộc họp"
          }
        },
        {
          "num": 4,
          "q": "Trong hợp đồng tiếng Trung, 甲方 và 乙方 có nghĩa là gì?",
          "options": {
            "A": "Người mua và người bán",
            "B": "Công ty lớn và công ty nhỏ",
            "C": "Bên A và bên B",
            "D": "Bên xuất khẩu và bên nhập khẩu"
          }
        },
        {
          "num": 5,
          "q": "Người TQ thường bắt đầu cuộc họp kinh doanh như thế nào?",
          "options": {
            "A": "Vào thẳng nội dung chính ngay",
            "B": "Có 10–20 phút xã giao trước khi vào việc",
            "C": "Yêu cầu xem catalog sản phẩm trước",
            "D": "Đề nghị ký NDA trước"
          }
        },
        {
          "num": 6,
          "q": "张工 trong ngữ cảnh nhà máy có nghĩa là gì?",
          "options": {
            "A": "Giám đốc Zhang",
            "B": "Kỹ sư Zhang",
            "C": "Công nhân Zhang",
            "D": "Trưởng phòng Zhang"
          }
        },
        {
          "num": 7,
          "q": "Câu nào phù hợp để nói khi kết thúc buổi gặp mặt lần đầu?",
          "options": {
            "A": "再见，下次不用再来了",
            "B": "希望我们合作愉快！",
            "C": "你们的产品太贵了",
            "D": "我们需要考虑一下"
          }
        },
        {
          "num": 8,
          "q": "我方 khác 我们 ở điểm nào?",
          "options": {
            "A": "我方 chỉ dùng trong văn nói",
            "B": "我方 mang tính trang trọng hơn, thường dùng trong đàm phán và hợp đồng",
            "C": "我方 chỉ dùng khi nói với người nước ngoài",
            "D": "Hai từ hoàn toàn giống nhau"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "贵方 và 贵公司 có thể dùng thay thế cho nhau trong hầu hết trường hợp."
        },
        {
          "num": 10,
          "q": "Trong văn hóa kinh doanh TQ, giai đoạn xã giao trước cuộc họp là không cần thiết và có thể bỏ qua để tiết kiệm thời gian."
        },
        {
          "num": 11,
          "q": "Phiên dịch viên không cần dịch phần chào hỏi xã giao, chỉ cần dịch phần nội dung kinh doanh."
        },
        {
          "num": 12,
          "q": "初次见面 thường đi kèm với 请多关照."
        },
        {
          "num": 13,
          "q": "Người TQ giới thiệu thành viên trong đoàn theo thứ tự từ chức vụ thấp đến cao."
        },
        {
          "num": 14,
          "q": "合作愉快 là câu thường nói vào cuối buổi gặp hoặc sau khi ký hợp đồng."
        }
      ],
      "fillblank": {
        "wordbank": [
          "贵公司",
          "我方",
          "初次见面",
          "久仰大名",
          "名片",
          "合作愉快"
        ],
        "items": [
          {
            "num": 15,
            "q": "____，请多关照，希望以后多多合作。"
          },
          {
            "num": 16,
            "q": "____，今日终于见到您了，非常高兴。"
          },
          {
            "num": 17,
            "q": "这是我的____，请多指教。"
          },
          {
            "num": 18,
            "q": "____对这次合作非常重视，希望双方都能获益。"
          },
          {
            "num": 19,
            "q": "____主要做哪些产品？主要出口哪些市场？"
          },
          {
            "num": 20,
            "q": "签完合同后，双方都说了声：\"____！\""
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "此次拜访的目的，主要是了解贵公司的产品和生产能力。"
        },
        {
          "num": 22,
          "q": "我方对东南亚市场非常感兴趣，希望能与贵方建立长期合作关系。"
        },
        {
          "num": 23,
          "q": "初次见面，请多关照，以后还请贵方多多支持。"
        },
        {
          "num": 24,
          "q": "我来给大家互相介绍一下，这位是我们公司的采购总监。"
        },
        {
          "num": 25,
          "q": "贵公司在行业内久负盛名，我们早就希望有机会合作。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Nghe danh anh Lý đã lâu, hôm nay mới được gặp, rất vui."
        },
        {
          "num": 27,
          "q": "Đây là danh thiếp của tôi, mong được nhiều chỉ giáo."
        },
        {
          "num": 28,
          "q": "Mục đích chuyến thăm lần này là muốn tìm hiểu khả năng hợp tác giữa hai bên."
        },
        {
          "num": 29,
          "q": "Phía chúng tôi chuyên xuất khẩu hàng tiêu dùng sang thị trường Mỹ, đã hoạt động được 8 năm."
        },
        {
          "num": 30,
          "q": "Hy vọng hai bên hợp tác vui vẻ, cùng có lợi!"
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "C",
        "3": "B",
        "4": "C",
        "5": "B",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": false,
        "11": false,
        "12": true,
        "13": false,
        "14": true
      },
      "fillblank": {
        "15": "初次见面",
        "16": "久仰大名",
        "17": "名片",
        "18": "我方",
        "19": "贵公司",
        "20": "合作愉快"
      },
      "zh2vi": {
        "21": "Mục đích chuyến thăm lần này chủ yếu là tìm hiểu sản phẩm và năng lực sản xuất của quý công ty.",
        "22": "Phía chúng tôi rất quan tâm đến thị trường Đông Nam Á, hy vọng có thể thiết lập quan hệ hợp tác lâu dài với quý vị.",
        "23": "Lần đầu gặp mặt, xin nhiều chỉ giáo, sau này còn nhờ quý vị nhiều.",
        "24": "Để tôi giới thiệu mọi người cho nhau, đây là Trưởng phòng thu mua của công ty chúng tôi.",
        "25": "Quý công ty có tiếng tăm lâu năm trong ngành, chúng tôi từ lâu đã mong có cơ hội hợp tác."
      },
      "vi2zh": {
        "26": "久仰李总大名，今日终于见到您了，非常高兴。",
        "27": "这是我的名片，请多指教。",
        "28": "此次拜访的目的，主要是想了解双方合作的可能性。",
        "29": "我方专门从事越南到美国市场的消费品出口，已经经营了八年。",
        "30": "希望双方合作愉快，互利共赢！"
      }
    }
  },
  {
    "num": 2,
    "title": "HỎI GIÁ & BÁO GIÁ",
    "date": "29/5",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "报价",
        "pinyin": "bàojià",
        "vi": "báo giá",
        "explanation": "Hành động nhà cung cấp đưa ra mức giá cho sản phẩm/dịch vụ. Có thể là động từ (报价给我 = báo giá cho tôi) hoặc danh từ (报价单 = bảng báo giá). Trong thực tế, 报价 thường chỉ là giá sơ bộ để bắt đầu đàm phán, chưa phải giá cuối cùng.",
        "example": {
          "zh": "请给我们报价。",
          "vi": "Vui lòng báo giá cho chúng tôi."
        }
      },
      {
        "num": 2,
        "hanzi": "单价",
        "pinyin": "dānjià",
        "vi": "đơn giá",
        "explanation": "Giá của một đơn vị sản phẩm. Phân biệt với 总价 (tổng giá) và 批量价 (giá theo lô). Khi đàm phán, 单价 luôn được đề cập trước, sau đó mới tính ra 总价 dựa trên số lượng.",
        "example": {
          "zh": "这个产品的单价是多少？",
          "vi": "Đơn giá của sản phẩm này là bao nhiêu?"
        }
      },
      {
        "num": 3,
        "hanzi": "含税价",
        "pinyin": "hán shuì jià",
        "vi": "giá đã bao gồm thuế",
        "explanation": "Giá đã tính thuế VAT (增值税) vào trong. Ở Trung Quốc thuế VAT thông thường là 13% cho hàng hóa. Khi so sánh giá giữa các nhà cung cấp, phải hỏi rõ là 含税 hay 不含税 vì khác nhau đến 13%.",
        "example": {
          "zh": "这个价格是含税价还是不含税价？",
          "vi": "Giá này là giá đã bao gồm thuế hay chưa?"
        }
      },
      {
        "num": 4,
        "hanzi": "不含税",
        "pinyin": "bù hán shuì",
        "vi": "giá chưa bao gồm thuế (giá trước thuế)",
        "explanation": "Giá chưa tính thuế VAT. Nhiều nhà máy TQ báo giá không bao gồm thuế để con số trông nhỏ hơn. Người mua cần chủ động hỏi để so sánh đúng. Trong xuất khẩu, hàng thường được hoàn thuế VAT (出口退税) nên giá xuất khẩu thường thấp hơn giá nội địa.",
        "example": {
          "zh": "我们的出口报价是不含税的。",
          "vi": "Báo giá xuất khẩu của chúng tôi là chưa bao gồm thuế."
        }
      },
      {
        "num": 5,
        "hanzi": "FOB价",
        "pinyin": "FOB jià",
        "vi": "giá FOB",
        "explanation": "Free On Board — giá đã bao gồm chi phí đến khi hàng qua lan can tàu tại cảng xuất khẩu. Người mua chịu toàn bộ chi phí vận chuyển và bảo hiểm từ cảng TQ trở đi. Đây là điều kiện giá phổ biến nhất trong giao dịch xuất nhập khẩu TQ–VN–Mỹ.",
        "example": {
          "zh": "我们的报价是FOB广州港。",
          "vi": "Báo giá của chúng tôi là FOB cảng Quảng Châu."
        }
      },
      {
        "num": 6,
        "hanzi": "CIF价",
        "pinyin": "CIF jià",
        "vi": "giá CIF",
        "explanation": "Cost + Insurance + Freight — giá bao gồm chi phí hàng hóa, bảo hiểm và cước vận chuyển đến cảng đích. Người bán chịu trách nhiệm thuê tàu và mua bảo hiểm. Thường cao hơn FOB nhưng người mua ít phải lo hơn. Khi bán vào Mỹ qua Amazon, người bán thường báo giá FOB còn logistics từ cảng Mỹ do bên mua hoặc forwarder lo.",
        "example": {
          "zh": "如果要CIF洛杉矶港，价格会高一些。",
          "vi": "Nếu muốn CIF cảng Los Angeles thì giá sẽ cao hơn một chút."
        }
      },
      {
        "num": 7,
        "hanzi": "报价单",
        "pinyin": "bàojià dān",
        "vi": "bảng báo giá",
        "explanation": "Văn bản chính thức liệt kê giá cả, điều kiện, thời hạn hiệu lực. Khác với báo giá miệng — 报价单 có giá trị tham chiếu và thường là bước trước khi ký hợp đồng. Một bảng báo giá chuẩn bao gồm: tên sản phẩm, thông số, đơn giá, điều kiện giao hàng, điều kiện thanh toán, thời hạn hiệu lực.",
        "example": {
          "zh": "请发一份正式的报价单给我们。",
          "vi": "Vui lòng gửi một bảng báo giá chính thức cho chúng tôi."
        }
      },
      {
        "num": 8,
        "hanzi": "有效期",
        "pinyin": "yǒuxiào qī",
        "vi": "thời hạn hiệu lực",
        "explanation": "Khoảng thời gian mà mức giá trong báo giá còn hiệu lực. Thường là 30 ngày hoặc 60 ngày. Sau thời hạn này, nhà cung cấp có quyền thay đổi giá. Quan trọng khi thị trường nguyên liệu biến động — hãy để ý 有效期 trước khi quyết định.",
        "example": {
          "zh": "这份报价单的有效期是30天。",
          "vi": "Bảng báo giá này có hiệu lực 30 ngày."
        }
      },
      {
        "num": 9,
        "hanzi": "含运费",
        "pinyin": "hán yùnfèi",
        "vi": "đã bao gồm cước vận chuyển",
        "explanation": "Giá đã tính phí vận chuyển vào trong. Khi so sánh báo giá giữa các nhà cung cấp ở các thành phố khác nhau, phải hỏi rõ có 含运费 không — vì nhà máy ở Thâm Quyến gần cảng hơn nhà máy ở Thành Đô, chi phí vận chuyển nội địa sẽ khác nhau đáng kể.",
        "example": {
          "zh": "这个价格含运费到深圳港吗？",
          "vi": "Giá này đã bao gồm cước vận chuyển đến cảng Thâm Quyến chưa?"
        }
      },
      {
        "num": 10,
        "hanzi": "最新报价",
        "pinyin": "zuìxīn bàojià",
        "vi": "báo giá mới nhất",
        "explanation": "Báo giá cập nhật nhất — quan trọng vì giá nguyên vật liệu thay đổi thường xuyên. Khi liên hệ lại với nhà cung cấp sau 1–2 tháng, luôn hỏi 最新报价 thay vì dùng báo giá cũ.",
        "example": {
          "zh": "请给我们发一下最新报价。",
          "vi": "Vui lòng gửi cho chúng tôi báo giá mới nhất."
        }
      }
    ],
    "dialogue": {
      "context": "Email trao đổi và cuộc gọi video đầu tiên. Công ty VN đang tìm nhà cung cấp ghế văn phòng để xuất sang Mỹ. Bạn là phiên dịch hỗ trợ cuộc gọi video.",
      "characters": [
        {
          "name": "销售小赵 (Xiǎo Zhào)",
          "role": "Nhân viên kinh doanh nhà máy TQ"
        },
        {
          "name": "Chị Mai",
          "role": "Nhân viên thu mua phía VN"
        }
      ],
      "lines": [
        {
          "speaker": "小赵",
          "zh": "您好，我是佳美家具的销售赵晓，请问您是越南那边的采购吗？",
          "vi": "Xin chào, tôi là Zhao Xiao, nhân viên kinh doanh của Jiamei Furniture, xin hỏi bạn có phải là bộ phận thu mua bên Việt Nam không?"
        },
        {
          "speaker": "Chị Mai",
          "zh": "对的，您好赵先生。我是越南公司的采购员，我们公司专门做出口美国的家具贸易，想了解一下你们的办公椅产品。",
          "vi": "Đúng vậy, xin chào anh Zhao. Tôi là nhân viên thu mua của công ty Việt Nam, công ty chúng tôi chuyên làm thương mại xuất khẩu nội thất sang Mỹ, muốn tìm hiểu về sản phẩm ghế văn phòng của các anh."
        },
        {
          "speaker": "小赵",
          "zh": "好的，没问题。请问您对哪个型号感兴趣？我们有三个系列，从经济型到高端型都有。",
          "vi": "Được, không vấn đề. Chị quan tâm đến mẫu nào? Chúng tôi có ba dòng sản phẩm, từ phổ thông đến cao cấp đều có."
        },
        {
          "speaker": "Chị Mai",
          "zh": "我们主要做中端产品，目标是在亚马逊上销售。能先给我们一个大概的价格范围吗？",
          "vi": "Chúng tôi chủ yếu làm sản phẩm tầm trung, mục tiêu bán trên Amazon. Anh có thể cho chúng tôi một khoảng giá tham khảo trước không?"
        },
        {
          "speaker": "小赵",
          "zh": "好的。我们中端办公椅，FOB深圳港的单价大概在45到65美元之间，具体价格要看配置和订单量。请问您大概需要多少数量？",
          "vi": "Được. Ghế văn phòng tầm trung của chúng tôi, đơn giá FOB cảng Thâm Quyến khoảng 45 đến 65 đô Mỹ, giá cụ thể tùy cấu hình và số lượng đặt hàng. Chị dự kiến cần khoảng bao nhiêu số lượng?"
        },
        {
          "speaker": "Chị Mai",
          "zh": "第一批可能是500到1000把。这个价格是含税价还是不含税？",
          "vi": "Đợt đầu có thể là 500 đến 1000 cái. Giá này là giá đã bao gồm thuế hay chưa?"
        },
        {
          "speaker": "小赵",
          "zh": "这是不含税的出口报价，含税要加13%。另外这个报价有效期是30天，因为最近原材料价格有波动。",
          "vi": "Đây là giá báo xuất khẩu chưa bao gồm thuế, bao gồm thuế phải cộng thêm 13%. Ngoài ra báo giá này có hiệu lực 30 ngày vì gần đây giá nguyên liệu có biến động."
        },
        {
          "speaker": "Chị Mai",
          "zh": "明白了。能请您发一份正式的报价单给我们吗？包括产品规格、单价、交期还有付款条件。",
          "vi": "Hiểu rồi. Anh có thể gửi cho chúng tôi một bảng báo giá chính thức không? Bao gồm thông số sản phẩm, đơn giá, thời gian giao hàng và điều kiện thanh toán."
        },
        {
          "speaker": "小赵",
          "zh": "没问题，今天下班前我发给您。请问您的邮箱是？",
          "vi": "Không vấn đề, trước khi tan làm hôm nay tôi sẽ gửi cho chị. Xin hỏi email của chị là gì?"
        },
        {
          "speaker": "Chị Mai",
          "zh": "谢谢，我的邮箱等一下我发给您。另外请问运费是怎么计算的？",
          "vi": "Cảm ơn, email tôi lát gửi cho anh. Ngoài ra cước vận chuyển được tính như thế nào?"
        },
        {
          "speaker": "小赵",
          "zh": "我们报的是FOB深圳港价格，不含运费。如果您需要，我们也可以报CIF价格，把运费和保险一起算进去，您来美国哪个港口？",
          "vi": "Giá chúng tôi báo là FOB cảng Thâm Quyến, chưa bao gồm cước vận chuyển. Nếu cần, chúng tôi cũng có thể báo giá CIF, tính cả cước và bảo hiểm vào, chị về cảng Mỹ nào?"
        },
        {
          "speaker": "Chị Mai",
          "zh": "洛杉矶港。好的，那麻烦您把FOB和CIF洛杉矶港两个价格都报给我们，方便我们比较。",
          "vi": "Cảng Los Angeles. Được, vậy phiền anh báo cả hai mức giá FOB và CIF cảng Los Angeles cho chúng tôi, tiện để so sánh."
        },
        {
          "speaker": "小赵",
          "zh": "没问题，我这边安排好了就发给您，最迟明天上午您就能收到最新报价单。",
          "vi": "Không vấn đề, tôi sắp xếp xong sẽ gửi ngay, chậm nhất sáng mai chị sẽ nhận được bảng báo giá mới nhất."
        }
      ]
    },
    "notes": [
      {
        "title": "FOB và CIF: cái nào có lợi hơn?",
        "body": "Không có câu trả lời tuyệt đối. Người mua ít kinh nghiệm thường thích CIF vì \"trọn gói\". Nhưng người mua có kinh nghiệm thường chọn FOB vì tự chủ được freight forwarder, tự chọn hãng tàu rẻ hơn, và tự mua bảo hiểm. Khi phiên dịch cuộc thảo luận về điều kiện này, bạn cần hiểu cả hai để dịch chính xác lý lẽ của mỗi bên."
      },
      {
        "title": "Giá báo miệng vs báo giá chính thức",
        "body": "Giá nói trong cuộc gặp hoặc qua điện thoại không có giá trị ràng buộc. Chỉ khi có 报价单 bằng văn bản mới là cơ sở đàm phán thực sự. Khi phiên dịch, nếu thấy một bên đang báo giá miệng và bên kia đang ghi chép, hãy nhắc nhở khéo léo rằng nên xin bảng báo giá chính thức."
      },
      {
        "title": "Thuế VAT 13% và xuất khẩu",
        "body": "Hàng xuất khẩu từ TQ được hoàn thuế VAT (出口退税). Điều này có nghĩa là giá xuất khẩu thường thấp hơn giá bán nội địa. Tuy nhiên không phải mặt hàng nào cũng được hoàn thuế 100% — tỷ lệ hoàn thuế tùy từng ngành. Khi khách hỏi tại sao giá xuất khẩu rẻ hơn giá trong nước TQ, đây là lý do."
      },
      {
        "title": "有效期 30 ngày: đừng bỏ qua",
        "body": "Giá nguyên liệu (đặc biệt kim loại, vải, nhựa) biến động liên tục. Nếu bạn nhận báo giá hôm nay nhưng 2 tháng sau mới đặt hàng, nhà cung cấp có quyền báo giá mới. Luôn hỏi 有效期 là bao lâu và đặt hàng trong thời hạn đó nếu đã quyết định."
      },
      {
        "title": "Khi nghe \"大概\" (dàgài)",
        "body": "大概 = khoảng / tầm. Khi nhà cung cấp dùng 大概, nghĩa là giá chưa chính xác — đây là ước tính sơ bộ. Giá chính xác (准确价格) sẽ có sau khi xác nhận thêm thông số và số lượng. Dịch 大概 thành \"chính xác\" là sai hoàn toàn và có thể gây tranh cãi sau này."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "含税价 có nghĩa là gì?",
          "options": {
            "A": "Giá đã bao gồm cước vận chuyển",
            "B": "Giá đã bao gồm thuế VAT",
            "C": "Giá đã bao gồm bảo hiểm",
            "D": "Giá bán lẻ cuối cùng"
          }
        },
        {
          "num": 2,
          "q": "Điều kiện giá FOB có nghĩa là gì?",
          "options": {
            "A": "Người bán chịu mọi chi phí đến tận kho người mua",
            "B": "Người bán chịu chi phí đến khi hàng qua lan can tàu tại cảng xuất",
            "C": "Người bán chịu thêm cả cước tàu và bảo hiểm",
            "D": "Người mua đến nhà máy lấy hàng"
          }
        },
        {
          "num": 3,
          "q": "报价单 khác với báo giá miệng ở điểm nào?",
          "options": {
            "A": "报价单 luôn rẻ hơn",
            "B": "报价单 là văn bản chính thức có giá trị tham chiếu",
            "C": "报价单 chỉ dùng trong nước",
            "D": "报价单 không có thời hạn hiệu lực"
          }
        },
        {
          "num": 4,
          "q": "Nếu báo giá có 有效期 30 ngày, điều đó có nghĩa là gì?",
          "options": {
            "A": "Hàng sẽ được giao trong 30 ngày",
            "B": "Mức giá này chỉ có hiệu lực trong 30 ngày",
            "C": "Thanh toán phải hoàn tất trong 30 ngày",
            "D": "Hợp đồng phải ký trong 30 ngày"
          }
        },
        {
          "num": 5,
          "q": "CIF khác FOB ở điểm nào?",
          "options": {
            "A": "CIF bao gồm thêm cước vận chuyển và bảo hiểm đến cảng đích",
            "B": "CIF rẻ hơn FOB",
            "C": "CIF chỉ dùng cho vận chuyển đường bộ",
            "D": "CIF và FOB giống nhau hoàn toàn"
          }
        },
        {
          "num": 6,
          "q": "Thuế VAT xuất khẩu ở Trung Quốc thông thường là bao nhiêu?",
          "options": {
            "A": "5%",
            "B": "9%",
            "C": "13%",
            "D": "17%"
          }
        },
        {
          "num": 7,
          "q": "Khi nhà cung cấp dùng từ 大概 trong báo giá, điều đó có nghĩa là?",
          "options": {
            "A": "Giá chính xác và có thể ký hợp đồng ngay",
            "B": "Giá ước tính sơ bộ, chưa chính xác",
            "C": "Giá đã bao gồm mọi chi phí",
            "D": "Giá không thể thương lượng"
          }
        },
        {
          "num": 8,
          "q": "Vì sao giá xuất khẩu TQ thường thấp hơn giá bán nội địa TQ?",
          "options": {
            "A": "Vì hàng xuất khẩu chất lượng kém hơn",
            "B": "Vì hàng xuất khẩu được hoàn thuế VAT",
            "C": "Vì nhà máy muốn bán nhanh",
            "D": "Vì chi phí vận chuyển xuất khẩu thấp hơn"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "FOB và CIF là hai điều kiện giá phổ biến nhất trong giao dịch xuất nhập khẩu."
        },
        {
          "num": 10,
          "q": "Giá báo miệng trong cuộc gặp có giá trị pháp lý tương đương bảng báo giá bằng văn bản."
        },
        {
          "num": 11,
          "q": "单价 là giá của toàn bộ lô hàng."
        },
        {
          "num": 12,
          "q": "Nếu nhà cung cấp báo giá 不含税, người mua cần cộng thêm 13% để có giá thực tế."
        },
        {
          "num": 13,
          "q": "Người mua kinh nghiệm thường thích điều kiện FOB hơn CIF vì có thể tự chủ chọn công ty vận chuyển."
        },
        {
          "num": 14,
          "q": "最新报价 quan trọng vì giá nguyên liệu thay đổi thường xuyên."
        }
      ],
      "fillblank": {
        "wordbank": [
          "报价单",
          "单价",
          "FOB价",
          "有效期",
          "含税价",
          "最新报价"
        ],
        "items": [
          {
            "num": 15,
            "q": "这份____是30天，请尽快确认。"
          },
          {
            "num": 16,
            "q": "我们的____是不含税的，如果需要含税价请告知。"
          },
          {
            "num": 17,
            "q": "请问这个产品的____是多少？500个起订的话有优惠吗？"
          },
          {
            "num": 18,
            "q": "请发一份正式的____给我们，包括规格和付款条件。"
          },
          {
            "num": 19,
            "q": "我们报的是____深圳港，不包含运费和保险。"
          },
          {
            "num": 20,
            "q": "由于原材料最近涨价，请给我们发一下____。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "我们的中端产品FOB深圳港单价是52美元，不含税，有效期30天。"
        },
        {
          "num": 22,
          "q": "如果订单量超过2000个，我们可以在单价上给予5%的折扣。"
        },
        {
          "num": 23,
          "q": "请问你们需要FOB价还是CIF洛杉矶港的价格？"
        },
        {
          "num": 24,
          "q": "这个报价是含运费到深圳港的，从深圳港到美国的运费需要另外计算。"
        },
        {
          "num": 25,
          "q": "最近原材料价格波动较大，我们的报价有效期只有15天。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Vui lòng gửi cho chúng tôi bảng báo giá chính thức, bao gồm đơn giá, điều kiện giao hàng và điều kiện thanh toán."
        },
        {
          "num": 27,
          "q": "Giá này là giá đã bao gồm thuế hay chưa? Điều kiện giao hàng là FOB hay CIF?"
        },
        {
          "num": 28,
          "q": "Chúng tôi dự kiến đặt 1000 cái, nếu tăng lên 2000 cái thì đơn giá có thể giảm không?"
        },
        {
          "num": 29,
          "q": "Bảng báo giá này có hiệu lực đến bao giờ? Chúng tôi cần khoảng 2 tuần để xét duyệt nội bộ."
        },
        {
          "num": 30,
          "q": "Anh có thể báo cả giá FOB và CIF cảng Los Angeles không? Để chúng tôi so sánh và quyết định."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "A",
        "6": "C",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": false,
        "11": false,
        "12": true,
        "13": true,
        "14": true
      },
      "fillblank": {
        "15": "有效期",
        "16": "报价",
        "17": "单价",
        "18": "报价单",
        "19": "FOB价",
        "20": "最新报价"
      },
      "zh2vi": {
        "21": "Đơn giá sản phẩm tầm trung FOB cảng Thâm Quyến của chúng tôi là 52 đô, chưa bao gồm thuế, hiệu lực 30 ngày.",
        "22": "Nếu số lượng đặt hàng vượt 2000 cái, chúng tôi có thể giảm 5% đơn giá.",
        "23": "Anh/chị cần giá FOB hay CIF cảng Los Angeles?",
        "24": "Báo giá này đã bao gồm cước đến cảng Thâm Quyến, từ Thâm Quyến sang Mỹ cần tính thêm.",
        "25": "Gần đây giá nguyên liệu biến động lớn, báo giá của chúng tôi chỉ có hiệu lực 15 ngày."
      },
      "vi2zh": {
        "26": "请发一份正式报价单给我们，包括单价、交货条件和付款条件。",
        "27": "这个价格是含税还是不含税？交货条件是FOB还是CIF？",
        "28": "我们预计订购1000个，如果增加到2000个，单价可以降低吗？",
        "29": "这份报价单有效期到什么时候？我们需要大约两周进行内部审批。",
        "30": "您能同时报FOB价和CIF洛杉矶港的价格吗？方便我们比较后做决定。"
      }
    }
  },
  {
    "num": 3,
    "title": "SỐ LƯỢNG & ĐIỀU KIỆN ĐẶT HÀNG",
    "date": "30/5",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "最低起订量(MOQ)",
        "pinyin": "zuìdī qǐdìng liàng",
        "vi": "số lượng đặt hàng tối thiểu",
        "explanation": "Minimum Order Quantity — số lượng ít nhất mà nhà máy chấp nhận sản xuất cho một đơn hàng. Dưới mức này nhà máy không nhận vì không đủ bù chi phí setup máy móc và nguyên liệu. MOQ cao thường đi kèm đơn giá thấp hơn. MOQ là điểm đàm phán quan trọng nhất với người mua nhỏ hoặc đặt hàng thử lần đầu.",
        "example": {
          "zh": "我们的MOQ是500个。",
          "vi": "MOQ của chúng tôi là 500 cái."
        }
      },
      {
        "num": 2,
        "hanzi": "订单量",
        "pinyin": "dìngdān liàng",
        "vi": "số lượng đặt hàng",
        "explanation": "Tổng số lượng trong một đơn hàng cụ thể. Khác với MOQ (là ngưỡng tối thiểu), 订单量 là con số thực tế khách hàng đặt. 订单量 càng lớn thì thường đàm phán được giá tốt hơn.",
        "example": {
          "zh": "这次的订单量是1000个。",
          "vi": "Số lượng đơn hàng lần này là 1000 cái."
        }
      },
      {
        "num": 3,
        "hanzi": "批次",
        "pinyin": "pīcì",
        "vi": "lô / đợt",
        "explanation": "Một lần giao hàng hoặc một lần sản xuất. Đơn hàng lớn có thể chia thành nhiều 批次 để giao dần. Ví dụ: tổng đơn hàng 3000 cái nhưng chia 3 đợt, mỗi đợt 1000 cái. Kiểm soát 批次 giúp người mua quản lý dòng tiền và kho hàng tốt hơn.",
        "example": {
          "zh": "这批货我们分两个批次发货。",
          "vi": "Lô hàng này chúng tôi sẽ giao làm hai đợt."
        }
      },
      {
        "num": 4,
        "hanzi": "试单",
        "pinyin": "shìdān",
        "vi": "đơn thử / đơn hàng thử nghiệm",
        "explanation": "Đơn hàng nhỏ đặt lần đầu để kiểm tra chất lượng nhà cung cấp trước khi đặt số lượng lớn. Thường có số lượng nhỏ hơn MOQ bình thường và đơn giá cao hơn. Đây là bước bảo vệ rủi ro quan trọng cho người mua — không nên bỏ qua dù nhà cung cấp có vẻ uy tín.",
        "example": {
          "zh": "我们想先下一个试单，看看质量再说。",
          "vi": "Chúng tôi muốn đặt thử một đơn trước, xem chất lượng rồi mới bàn tiếp."
        }
      },
      {
        "num": 5,
        "hanzi": "样品",
        "pinyin": "yàngpǐn",
        "vi": "mẫu sản phẩm",
        "explanation": "Sản phẩm mẫu để khách hàng kiểm tra trước khi đặt hàng đại trà. Có hai loại: 现有样品 (mẫu có sẵn trong kho) và 定制样品 (mẫu làm theo yêu cầu riêng). Xác nhận mẫu (确认样) là bước bắt buộc trước khi sản xuất đại trà. Nếu bỏ qua bước này, rủi ro hàng không đúng ý rất cao.",
        "example": {
          "zh": "能先寄样品给我们确认吗？",
          "vi": "Có thể gửi mẫu cho chúng tôi xác nhận trước không?"
        }
      },
      {
        "num": 6,
        "hanzi": "打样费",
        "pinyin": "dǎyàng fèi",
        "vi": "phí làm mẫu",
        "explanation": "Chi phí nhà máy thu để làm mẫu theo yêu cầu riêng của khách. Thường tính riêng và không hoàn lại, nhưng nhiều nhà máy sẽ khấu trừ 打样费 vào đơn hàng chính thức nếu khách đặt hàng. Mức phí từ vài trăm đến vài nghìn nhân dân tệ tùy độ phức tạp.",
        "example": {
          "zh": "打样费是多少？下单后能退吗？",
          "vi": "Phí làm mẫu là bao nhiêu? Sau khi đặt hàng có được hoàn không?"
        }
      },
      {
        "num": 7,
        "hanzi": "模具费",
        "pinyin": "mújù fèi",
        "vi": "phí khuôn",
        "explanation": "Chi phí chế tạo khuôn đúc/khuôn ép cho sản phẩm mới hoặc sản phẩm tùy chỉnh. Đây thường là chi phí lớn nhất khi phát triển sản phẩm mới — có thể từ vài nghìn đến vài trăm nghìn nhân dân tệ tùy độ phức tạp. Khuôn thường thuộc sở hữu của nhà máy trừ khi khách hàng trả tiền mua khuôn về.",
        "example": {
          "zh": "这个产品需要开模，模具费大概是8000元。",
          "vi": "Sản phẩm này cần làm khuôn, phí khuôn khoảng 8000 tệ."
        }
      },
      {
        "num": 8,
        "hanzi": "起批",
        "pinyin": "qǐ pī",
        "vi": "bắt đầu đặt từ / tối thiểu",
        "explanation": "Từ thông tục chỉ mức tối thiểu để bắt đầu sản xuất hoặc cung cấp. Thường dùng trong câu như 500个起批 (bắt đầu từ 500 cái). Khác với MOQ ở chỗ 起批 mang tính thông báo hơn là điều kiện chính thức.",
        "example": {
          "zh": "我们这款产品500个起批。",
          "vi": "Sản phẩm này của chúng tôi bắt đầu từ 500 cái."
        }
      },
      {
        "num": 9,
        "hanzi": "加急费",
        "pinyin": "jiājí fèi",
        "vi": "phí giao hàng nhanh / phí đơn hàng khẩn",
        "explanation": "Phụ phí phát sinh khi khách yêu cầu thời gian giao hàng ngắn hơn bình thường, buộc nhà máy phải tăng ca hoặc ưu tiên đơn hàng. Thường từ 10–30% giá trị đơn hàng. Trong mùa cao điểm (trước lễ Tết, Black Friday) hầu như đơn nào cũng bị tính 加急费.",
        "example": {
          "zh": "如果需要提前两周交货，需要加收加急费。",
          "vi": "Nếu cần giao hàng sớm hơn hai tuần, sẽ phải tính thêm phí khẩn."
        }
      },
      {
        "num": 10,
        "hanzi": "确认样",
        "pinyin": "quèrèn yàng",
        "vi": "mẫu xác nhận",
        "explanation": "Mẫu sản phẩm cuối cùng được khách hàng ký duyệt, trở thành tiêu chuẩn cho toàn bộ lô hàng đại trà. Sau khi 确认样 được duyệt, nhà máy mới bắt đầu sản xuất đại trà. Đây là văn bản bảo vệ quyền lợi của người mua — nếu hàng thực tế khác 确认样, có cơ sở để khiếu nại.",
        "example": {
          "zh": "确认样通过后，我们才会正式开始生产。",
          "vi": "Sau khi mẫu xác nhận được duyệt, chúng tôi mới chính thức bắt đầu sản xuất."
        }
      }
    ],
    "dialogue": {
      "context": "Cuộc gọi video giữa buyer Việt Nam và nhà cung cấp TQ. Đây là lần liên hệ thứ hai sau khi đã nhận báo giá. Bạn là phiên dịch.",
      "characters": [
        {
          "name": "王经理 (Wáng jīnglǐ)",
          "role": "Quản lý kinh doanh nhà máy TQ"
        },
        {
          "name": "Anh Tuấn",
          "role": "Nhân viên thu mua VN"
        }
      ],
      "lines": [
        {
          "speaker": "王经理",
          "zh": "您好，上次发的报价单您收到了吗？有什么问题吗？",
          "vi": "Xin chào, bảng báo giá lần trước gửi anh có nhận được không? Có vấn đề gì không?"
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "收到了，谢谢。我们对产品挺感兴趣的，但是有几个问题想跟您确认一下。首先，你们的MOQ是500个，我们第一次合作，能不能先下一个试单，数量少一点？",
          "vi": "Nhận được rồi, cảm ơn. Chúng tôi khá quan tâm đến sản phẩm, nhưng có một số điểm muốn xác nhận với anh. Trước tiên, MOQ của anh là 500 cái, đây là lần đầu hợp tác, có thể đặt đơn thử trước với số lượng ít hơn không?"
        },
        {
          "speaker": "王经理",
          "zh": "可以理解。试单的话，我们最少可以做100个，但是单价会比正常的高大概15%，因为批量小，成本相对高一些。",
          "vi": "Hoàn toàn có thể hiểu được. Đơn thử thì ít nhất chúng tôi có thể làm 100 cái, nhưng đơn giá sẽ cao hơn bình thường khoảng 15%, vì số lượng nhỏ nên chi phí tương đối cao hơn."
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "明白。那样品的话怎么处理？我们需要先看到实物才能确认。",
          "vi": "Hiểu rồi. Vậy về mẫu sản phẩm thì xử lý thế nào? Chúng tôi cần xem hàng thực tế mới có thể xác nhận được."
        },
        {
          "speaker": "王经理",
          "zh": "没问题，我们有现成的样品可以寄给您，快递费您这边承担。如果您需要定制颜色或者logo，需要收打样费，大概800元人民币。",
          "vi": "Không vấn đề, chúng tôi có mẫu sẵn có thể gửi cho anh, phí chuyển phát nhanh phía anh chịu. Nếu cần tùy chỉnh màu sắc hoặc logo, sẽ tính phí làm mẫu, khoảng 800 nhân dân tệ."
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "好的。如果打样满意，正式下单的时候，打样费能从货款里扣掉吗？",
          "vi": "Được. Nếu mẫu ổn, khi đặt hàng chính thức, phí làm mẫu có thể khấu trừ vào tiền hàng không?"
        },
        {
          "speaker": "王经理",
          "zh": "可以的，如果正式订单量达到500个以上，打样费可以全额抵扣。",
          "vi": "Được chứ, nếu đơn hàng chính thức đạt từ 500 cái trở lên, phí làm mẫu có thể khấu trừ toàn bộ."
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "那如果我们想在产品上加我们公司的logo，需要开模吗？",
          "vi": "Vậy nếu chúng tôi muốn in logo công ty lên sản phẩm, có cần làm khuôn không?"
        },
        {
          "speaker": "王经理",
          "zh": "如果只是印刷logo，不需要开模，费用很低。如果是要改变产品形状或者做专属配件，才需要开模，费用根据复杂程度在3000到15000元不等。",
          "vi": "Nếu chỉ in logo thì không cần làm khuôn, chi phí rất thấp. Nếu muốn thay đổi hình dạng sản phẩm hoặc làm phụ kiện riêng, mới cần làm khuôn, chi phí tùy độ phức tạp từ 3000 đến 15000 tệ."
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "明白了。我们先看样品，如果满意的话，我们会先下一个100个的试单，然后根据市场反应再决定后续订单量。",
          "vi": "Hiểu rồi. Chúng tôi xem mẫu trước, nếu ổn sẽ đặt thử 100 cái, sau đó tùy phản ứng thị trường mới quyết định số lượng tiếp theo."
        },
        {
          "speaker": "王经理",
          "zh": "好的，没问题。请您确认一下收货地址，我们今天安排寄样。另外，确认样通过后，您这边多久能正式下单？",
          "vi": "Được, không vấn đề. Nhờ anh xác nhận địa chỉ nhận hàng, hôm nay chúng tôi sắp xếp gửi mẫu. Ngoài ra, sau khi mẫu xác nhận được duyệt, phía anh mất bao lâu để đặt hàng chính thức?"
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "样品确认大概需要一周，如果没问题，一周内我们会正式下试单。",
          "vi": "Xác nhận mẫu khoảng một tuần, nếu không có vấn đề gì, trong một tuần chúng tôi sẽ đặt đơn thử chính thức."
        },
        {
          "speaker": "王经理",
          "zh": "好的，我们等您的消息。有任何问题随时联系我。",
          "vi": "Tốt, chúng tôi chờ tin anh. Có bất kỳ câu hỏi gì cứ liên hệ tôi bất cứ lúc nào."
        }
      ]
    },
    "notes": [
      {
        "title": "Tại sao 试单 quan trọng hơn người ta nghĩ",
        "body": "Dù nhà cung cấp có catalog đẹp, website chuyên nghiệp, hay được giới thiệu bởi người quen, mẫu và đơn thử vẫn là bước bắt buộc. Trong thực tế rất phổ biến trường hợp mẫu đẹp nhưng hàng đại trà kém chất lượng hơn. Đơn thử nhỏ tốn tiền ít hơn rủi ro mất cả container hàng sau này."
      },
      {
        "title": "Phí làm mẫu và phí khuôn: hai khoản hay bị nhầm",
        "body": "打样费 (phí làm mẫu) = chi phí nhà máy bỏ công sức làm sản phẩm mẫu theo yêu cầu, thường vài trăm đến vài nghìn tệ. 模具费 (phí khuôn) = chi phí chế tạo khuôn kim loại để ép/đúc hàng loạt, thường vài nghìn đến hàng chục nghìn tệ. Hai khoản này hoàn toàn khác nhau và có thể phát sinh cùng lúc."
      },
      {
        "title": "Sở hữu khuôn: điểm cần đàm phán rõ",
        "body": "Nếu bạn trả phí khuôn, hãy làm rõ khuôn đó thuộc sở hữu của ai. Nhiều nhà máy TQ mặc định khuôn là của họ dù khách trả tiền. Nếu sau này chuyển sang nhà máy khác, bạn sẽ phải làm khuôn mới từ đầu. Hãy đưa điều khoản sở hữu khuôn vào hợp đồng ngay từ đầu."
      },
      {
        "title": "确认样 phải lưu giữ cẩn thận",
        "body": "Sau khi mẫu xác nhận được duyệt, hãy chụp ảnh chi tiết, ghi chép thông số và lưu lại. Khi hàng về, đối chiếu với 确认样 để phát hiện sai lệch. Đây là bằng chứng quan trọng nhất nếu có tranh chấp về chất lượng sau này."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "MOQ là viết tắt của gì và có nghĩa là gì?",
          "options": {
            "A": "Maximum Order Quantity — số lượng đặt hàng tối đa",
            "B": "Minimum Order Quantity — số lượng đặt hàng tối thiểu",
            "C": "Monthly Order Quantity — số lượng đặt hàng hàng tháng",
            "D": "Multiple Order Quantity — bội số số lượng đặt hàng"
          }
        },
        {
          "num": 2,
          "q": "试单 thường có đặc điểm gì so với đơn hàng bình thường?",
          "options": {
            "A": "Số lượng nhiều hơn và giá rẻ hơn",
            "B": "Số lượng ít hơn và đơn giá cao hơn",
            "C": "Số lượng và giá giống hệt đơn bình thường",
            "D": "Không cần mẫu xác nhận"
          }
        },
        {
          "num": 3,
          "q": "打样费 và 模具费 khác nhau thế nào?",
          "options": {
            "A": "Hoàn toàn giống nhau",
            "B": "打样费 là phí làm mẫu, 模具费 là phí chế tạo khuôn sản xuất",
            "C": "打样费 chỉ dùng cho sản phẩm nhựa",
            "D": "模具费 rẻ hơn 打样费"
          }
        },
        {
          "num": 4,
          "q": "确认样 có vai trò gì?",
          "options": {
            "A": "Là mẫu trưng bày tại hội chợ",
            "B": "Là tiêu chuẩn chất lượng cho toàn bộ lô hàng đại trà",
            "C": "Là mẫu gửi cho khách hàng cuối",
            "D": "Là mẫu để xin chứng nhận chất lượng"
          }
        },
        {
          "num": 5,
          "q": "Khi nào nhà máy sẽ tính 加急费?",
          "options": {
            "A": "Khi đơn hàng quá lớn",
            "B": "Khi khách yêu cầu giao hàng nhanh hơn thời gian bình thường",
            "C": "Khi khách thanh toán chậm",
            "D": "Khi nguyên liệu tăng giá"
          }
        },
        {
          "num": 6,
          "q": "批次 trong đơn hàng có nghĩa là gì?",
          "options": {
            "A": "Chất lượng lô hàng",
            "B": "Giá của từng lô",
            "C": "Lần giao hàng / đợt sản xuất",
            "D": "Nhà kho chứa hàng"
          }
        },
        {
          "num": 7,
          "q": "Tại sao đặt 试单 trước khi đặt số lượng lớn là quan trọng?",
          "options": {
            "A": "Vì nhà máy yêu cầu bắt buộc",
            "B": "Để kiểm tra chất lượng thực tế trước khi rủi ro lớn",
            "C": "Vì giá thử đơn rẻ hơn",
            "D": "Vì quy định hải quan"
          }
        },
        {
          "num": 8,
          "q": "Nếu khách hàng trả phí khuôn, điều quan trọng cần làm rõ trong hợp đồng là gì?",
          "options": {
            "A": "Thời gian giao hàng",
            "B": "Sở hữu khuôn thuộc về ai",
            "C": "Màu sắc của khuôn",
            "D": "Trọng lượng khuôn"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "MOQ là số lượng tối đa nhà máy có thể sản xuất trong một đơn hàng."
        },
        {
          "num": 10,
          "q": "Đơn thử (试单) luôn có giá thấp hơn đơn hàng bình thường vì số lượng ít."
        },
        {
          "num": 11,
          "q": "确认样 được duyệt là bước bắt buộc trước khi sản xuất đại trà."
        },
        {
          "num": 12,
          "q": "Nếu chỉ muốn in logo lên sản phẩm có sẵn, thường không cần làm khuôn mới."
        },
        {
          "num": 13,
          "q": "打样费 luôn được hoàn lại đầy đủ khi khách đặt hàng chính thức."
        },
        {
          "num": 14,
          "q": "订单量 là số lượng thực tế khách đặt, còn MOQ là ngưỡng tối thiểu nhà máy chấp nhận."
        }
      ],
      "fillblank": {
        "wordbank": [
          "试单",
          "样品",
          "打样费",
          "MOQ",
          "确认样",
          "批次"
        ],
        "items": [
          {
            "num": 15,
            "q": "我们想先下一个____，100个，看看质量再决定后续。"
          },
          {
            "num": 16,
            "q": "能先寄____给我们看看吗？我们需要确认实物质量。"
          },
          {
            "num": 17,
            "q": "这次订单我们分三个____发货，每批1000个。"
          },
          {
            "num": 18,
            "q": "我们的____是500个，低于这个数量我们无法接受。"
          },
          {
            "num": 19,
            "q": "定制产品需要收____，800元，下正式订单后可以抵扣。"
          },
          {
            "num": 20,
            "q": "____通过后，我们才会安排正式生产，请务必仔细检查。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "我们的MOQ是500个，但如果是第一次合作，可以接受100个的试单，单价会高15%。"
        },
        {
          "num": 22,
          "q": "定制LOGO不需要开模，只需要收取少量的丝印费用。"
        },
        {
          "num": 23,
          "q": "确认样通过后，请在三个工作日内正式下单，我们好安排生产计划。"
        },
        {
          "num": 24,
          "q": "如果需要修改产品设计，可能需要重新打样，会再收一次打样费。"
        },
        {
          "num": 25,
          "q": "这个模具费是8000元，如果您以后转到其他工厂，模具归我们所有。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Đây là lần đầu hợp tác, chúng tôi muốn đặt đơn thử 200 cái trước để kiểm tra chất lượng."
        },
        {
          "num": 27,
          "q": "Phí làm mẫu có thể khấu trừ vào đơn hàng chính thức không? Chúng tôi dự kiến đặt 1000 cái."
        },
        {
          "num": 28,
          "q": "Mẫu xác nhận chúng tôi đã duyệt rồi, bây giờ có thể bắt đầu sản xuất chưa?"
        },
        {
          "num": 29,
          "q": "Chúng tôi muốn chia đơn hàng thành 2 đợt, mỗi đợt 500 cái, giao cách nhau 4 tuần."
        },
        {
          "num": 30,
          "q": "Nếu cần giao hàng trong 3 tuần thay vì 6 tuần, phí khẩn là bao nhiêu?"
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "C",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": false,
        "10": false,
        "11": true,
        "12": true,
        "13": false,
        "14": true
      },
      "fillblank": {
        "15": "试单",
        "16": "样品",
        "17": "批次",
        "18": "MOQ",
        "19": "打样费",
        "20": "确认样"
      },
      "zh2vi": {
        "21": "MOQ của chúng tôi là 500 cái, nhưng nếu là lần đầu hợp tác, có thể chấp nhận đơn thử 100 cái, đơn giá cao hơn 15%.",
        "22": "Tùy chỉnh logo không cần làm khuôn, chỉ tính phí in lụa nhỏ.",
        "23": "Sau khi mẫu xác nhận được duyệt, nhờ đặt hàng chính thức trong 3 ngày làm việc để chúng tôi sắp xếp kế hoạch sản xuất.",
        "24": "Nếu cần chỉnh sửa thiết kế sản phẩm, có thể cần làm mẫu lại và sẽ tính thêm phí làm mẫu một lần nữa.",
        "25": "Phí khuôn là 8000 tệ, nếu anh chuyển sang nhà máy khác sau này, khuôn thuộc về chúng tôi."
      },
      "vi2zh": {
        "26": "这是我们第一次合作，我们想先下200个的试单，检验一下质量。",
        "27": "打样费可以从正式订单里抵扣吗？我们预计下1000个的订单。",
        "28": "确认样我们已经通过了，现在可以开始生产吗？",
        "29": "我们想把订单分成两批，每批500个，间隔四周发货。",
        "30": "如果需要在三周内交货，而不是六周，加急费是多少？"
      }
    }
  },
  {
    "num": 4,
    "title": "THANH TOÁN QUỐC TẾ",
    "date": "31/5",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "定金",
        "pinyin": "dìngjīn",
        "vi": "tiền đặt cọc / tiền cọc",
        "explanation": "Khoản tiền người mua trả trước để xác nhận đơn hàng, thường là 30% tổng giá trị. Khác với 订金 (cũng đọc là dìngjīn) — 定金 có tính ràng buộc pháp lý cao hơn: nếu người mua hủy, mất cọc; nếu người bán hủy, phải hoàn gấp đôi. Trong thực tế xuất nhập khẩu, hai từ này thường dùng lẫn nhau.",
        "example": {
          "zh": "我们需要先收30%的定金才能安排生产。",
          "vi": "Chúng tôi cần nhận 30% tiền cọc trước mới sắp xếp sản xuất."
        }
      },
      {
        "num": 2,
        "hanzi": "尾款",
        "pinyin": "wěikuǎn",
        "vi": "tiền còn lại / thanh toán phần còn lại",
        "explanation": "Phần thanh toán còn lại sau khi đã trả cọc. Ví dụ: tổng đơn hàng 100 triệu, đã trả cọc 30 triệu, thì 尾款 là 70 triệu còn lại. Thường được trả trước khi giao hàng hoặc sau khi hàng đến cảng đích tùy điều kiện đàm phán.",
        "example": {
          "zh": "尾款在出货前付清。",
          "vi": "Tiền còn lại thanh toán trước khi xuất hàng."
        }
      },
      {
        "num": 3,
        "hanzi": "电汇 (T/T)",
        "pinyin": "diànhuì",
        "vi": "chuyển khoản ngân hàng quốc tế (Telegraphic Transfer)",
        "explanation": "Phương thức thanh toán phổ biến nhất trong giao dịch xuất nhập khẩu SME — người mua chuyển tiền trực tiếp qua ngân hàng đến tài khoản người bán. Ưu điểm: đơn giản, nhanh. Nhược điểm: rủi ro cao cho người mua vì tiền đã chuyển trước khi nhận hàng. Công thức phổ biến nhất: 30% T/T khi đặt hàng, 70% T/T trước khi xuất.",
        "example": {
          "zh": "我们接受T/T付款，30%定金，70%出货前付清。",
          "vi": "Chúng tôi chấp nhận thanh toán T/T, 30% cọc, 70% thanh toán trước khi xuất hàng."
        }
      },
      {
        "num": 4,
        "hanzi": "信用证 (L/C)",
        "pinyin": "xìnyòngzhèng",
        "vi": "thư tín dụng (Letter of Credit)",
        "explanation": "Công cụ thanh toán do ngân hàng của người mua phát hành, cam kết trả tiền cho người bán khi xuất trình đủ bộ chứng từ hợp lệ. Bảo vệ cả hai bên: người bán chắc chắn được trả tiền nếu giao hàng đúng, người mua chỉ trả tiền khi có bằng chứng hàng đã giao. Phức tạp hơn T/T nhưng an toàn hơn nhiều cho đơn hàng lớn.",
        "example": {
          "zh": "订单金额较大，我们希望用信用证付款。",
          "vi": "Giá trị đơn hàng lớn, chúng tôi muốn thanh toán bằng thư tín dụng."
        }
      },
      {
        "num": 5,
        "hanzi": "账期",
        "pinyin": "zhàngqī",
        "vi": "kỳ hạn thanh toán / thời hạn nợ",
        "explanation": "Khoảng thời gian người mua được phép chậm thanh toán sau khi nhận hàng. Ví dụ: 账期30天 nghĩa là nhận hàng xong, trong vòng 30 ngày phải thanh toán. Thường chỉ nhà máy TQ mới cho 账期 với khách hàng lâu năm và uy tín — khách hàng mới hầu như không được hưởng.",
        "example": {
          "zh": "新客户我们不提供账期，需要全款预付。",
          "vi": "Khách hàng mới chúng tôi không cung cấp kỳ hạn thanh toán, cần thanh toán toàn bộ trước."
        }
      },
      {
        "num": 6,
        "hanzi": "预付款",
        "pinyin": "yùfùkuǎn",
        "vi": "thanh toán trước / tiền ứng trước",
        "explanation": "Toàn bộ hoặc một phần tiền được trả trước khi sản xuất hoặc giao hàng. Nhà máy TQ thường yêu cầu 预付款 với khách mới để đảm bảo khách không hủy đơn sau khi đã mua nguyên liệu. Tỷ lệ 预付款 phản ánh mức độ tin tưởng giữa hai bên.",
        "example": {
          "zh": "第一次合作，我们需要100%预付款。",
          "vi": "Lần đầu hợp tác, chúng tôi yêu cầu thanh toán trước 100%."
        }
      },
      {
        "num": 7,
        "hanzi": "结汇",
        "pinyin": "jiéhuì",
        "vi": "kết hối / quy đổi ngoại tệ",
        "explanation": "Quá trình nhà xuất khẩu TQ đổi ngoại tệ (USD, EUR...) nhận được về nhân dân tệ (CNY) qua ngân hàng. Đây là bước bắt buộc sau khi nhận thanh toán quốc tế. Tỷ giá hối đoái tại thời điểm kết hối ảnh hưởng đến lợi nhuận thực tế của nhà máy — đây là lý do họ hay quan tâm đến biến động tỷ giá.",
        "example": {
          "zh": "我们收到货款后会及时结汇。",
          "vi": "Sau khi nhận tiền hàng chúng tôi sẽ kết hối kịp thời."
        }
      },
      {
        "num": 8,
        "hanzi": "到付",
        "pinyin": "dào fù",
        "vi": "thanh toán khi nhận hàng (COD)",
        "explanation": "Cash on Delivery — trả tiền khi nhận hàng. Trong xuất nhập khẩu B2B, COD rất hiếm gặp vì rủi ro cao cho người bán. Chủ yếu dùng trong thương mại nội địa hoặc giao dịch nhỏ. Nếu nhà cung cấp TQ đề nghị 到付, thường nghĩa là họ không tin tưởng người mua.",
        "example": {
          "zh": "我们不接受到付，所有订单需要预付定金。",
          "vi": "Chúng tôi không chấp nhận COD, mọi đơn hàng cần đặt cọc trước."
        }
      },
      {
        "num": 9,
        "hanzi": "汇率",
        "pinyin": "huìlǜ",
        "vi": "tỷ giá hối đoái",
        "explanation": "Tỷ lệ quy đổi giữa hai đồng tiền. Trong giao dịch TQ–VN–Mỹ, tỷ giá USD/CNY và USD/VND đều quan trọng. Biến động tỷ giá ảnh hưởng đến lợi nhuận thực tế — người bán TQ thường báo giá USD nhưng thực thu CNY, nên lo ngại CNY tăng giá so với USD.",
        "example": {
          "zh": "最近汇率波动比较大，我们的报价可能会有调整。",
          "vi": "Gần đây tỷ giá biến động lớn, báo giá của chúng tôi có thể sẽ điều chỉnh."
        }
      },
      {
        "num": 10,
        "hanzi": "付款凭证",
        "pinyin": "fùkuǎn píngzhèng",
        "vi": "chứng từ thanh toán / bằng chứng chuyển tiền",
        "explanation": "Tài liệu chứng minh đã thực hiện thanh toán — thường là screenshot hoặc PDF xác nhận chuyển tiền từ ngân hàng (bank slip / SWIFT confirmation). Nhà máy TQ yêu cầu 付款凭证 trước khi bắt đầu sản xuất hoặc trước khi xuất hàng. Đây là tài liệu quan trọng cần lưu giữ cho cả hai bên.",
        "example": {
          "zh": "收到定金后，请把付款凭证发给我们，我们才能安排生产。",
          "vi": "Sau khi trả cọc, vui lòng gửi chứng từ thanh toán cho chúng tôi, chúng tôi mới sắp xếp sản xuất."
        }
      }
    ],
    "dialogue": {
      "context": "Cuộc họp cuối để chốt điều kiện thanh toán trước khi ký hợp đồng. Hai bên đã thống nhất về sản phẩm và giá. Bạn là phiên dịch.",
      "characters": [
        {
          "name": "刘总 (Liú zǒng)",
          "role": "Giám đốc nhà máy TQ"
        },
        {
          "name": "Chị Hoa",
          "role": "Giám đốc thu mua công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "刘总",
          "zh": "产品和价格我们都谈好了，现在来确认一下付款条件。我们通常要求T/T付款，30%定金，70%出货前付清，您看可以吗？",
          "vi": "Sản phẩm và giá chúng ta đã bàn xong, bây giờ xác nhận điều kiện thanh toán. Chúng tôi thường yêu cầu thanh toán T/T, 30% đặt cọc, 70% thanh toán trước khi xuất hàng, anh/chị thấy được không?"
        },
        {
          "speaker": "Chị Hoa",
          "zh": "这个条件对我们来说压力比较大。我们能不能做30%定金，70%见提单付款？",
          "vi": "Điều kiện này áp lực hơi lớn với phía chúng tôi. Có thể làm 30% cọc, 70% thanh toán khi có vận đơn không?"
        },
        {
          "speaker": "刘总",
          "zh": "提单付款的话，我们这边风险比较高，因为货已经出了。这样吧，30%定金，60%出货前，10%收到货物验收无误后付清，您觉得怎么样？",
          "vi": "Thanh toán khi có vận đơn thì rủi ro phía chúng tôi cao hơn vì hàng đã xuất rồi. Thế này nhé, 30% cọc, 60% trước khi xuất, 10% sau khi nhận hàng kiểm tra không có vấn đề thì thanh toán, chị thấy thế nào?"
        },
        {
          "speaker": "Chị Hoa",
          "zh": "这个方案基本可以接受，但是10%的尾款，我们需要在验货后15个工作日内付清，可以吗？",
          "vi": "Phương án này về cơ bản có thể chấp nhận, nhưng 10% tiền cuối, chúng tôi cần 15 ngày làm việc sau khi kiểm hàng mới thanh toán được, có được không?"
        },
        {
          "speaker": "刘总",
          "zh": "15个工作日有点长，能不能缩短到7个工作日？",
          "vi": "15 ngày làm việc hơi dài, có thể rút xuống 7 ngày làm việc không?"
        },
        {
          "speaker": "Chị Hoa",
          "zh": "好的，7个工作日可以接受。另外，付款方式是T/T，请问你们的账户信息是？",
          "vi": "Được, 7 ngày làm việc chấp nhận được. Ngoài ra thanh toán T/T, thông tin tài khoản của anh là gì?"
        },
        {
          "speaker": "刘总",
          "zh": "我一会儿发给您。还有，第一次合作，我们需要收到定金的付款凭证之后，才能开始安排生产，请您理解。",
          "vi": "Tôi sẽ gửi cho chị lát nữa. Ngoài ra, lần đầu hợp tác, chúng tôi cần nhận được chứng từ thanh toán tiền cọc mới sắp xếp sản xuất, mong chị thông cảm."
        },
        {
          "speaker": "Chị Hoa",
          "zh": "没问题，我们理解。那如果以后合作顺畅，能否给我们一定的账期？",
          "vi": "Không vấn đề, chúng tôi hiểu. Vậy nếu sau này hợp tác thuận lợi, có thể cho chúng tôi kỳ hạn thanh toán không?"
        },
        {
          "speaker": "刘总",
          "zh": "可以考虑。一般合作一年以上，有稳定订单量的客户，我们可以给30天账期。但这个要等我们建立了信任之后再谈。",
          "vi": "Có thể xem xét. Thường khách hàng hợp tác trên 1 năm, có đơn hàng ổn định, chúng tôi có thể cho kỳ hạn 30 ngày. Nhưng cái này phải chờ khi hai bên đã xây dựng được lòng tin rồi mới bàn."
        },
        {
          "speaker": "Chị Hoa",
          "zh": "完全理解。那我们先按这次的付款条件来，30%定金，60%出货前，10%验货后7个工作日内付清，对吗？",
          "vi": "Hoàn toàn hiểu. Vậy lần này chúng ta theo điều kiện thanh toán: 30% cọc, 60% trước khi xuất, 10% trong 7 ngày làm việc sau kiểm hàng, đúng không?"
        },
        {
          "speaker": "刘总",
          "zh": "对，就这样定了。我来安排起草合同，合同里会把这些付款条件都写清楚。",
          "vi": "Đúng, thống nhất như vậy. Tôi sẽ sắp xếp soạn hợp đồng, trong hợp đồng sẽ ghi rõ tất cả các điều kiện thanh toán này."
        }
      ]
    },
    "notes": [
      {
        "title": "Công thức T/T phổ biến nhất",
        "body": "30/70 (30% cọc, 70% trước khi xuất) là công thức chuẩn cho khách mới. Khách lâu năm uy tín có thể đàm phán xuống 30/70 với 70% khi có vận đơn, hoặc thậm chí 0/100 nếu có 账期. Khi phiên dịch cuộc thảo luận này, cần dịch chính xác từng tỷ lệ và thời điểm thanh toán."
      },
      {
        "title": "L/C phức tạp hơn T/T rất nhiều",
        "body": "L/C cần có ngân hàng của cả hai bên tham gia, bộ chứng từ phải hoàn toàn khớp với điều kiện L/C (chỉ cần sai một ký tự cũng có thể bị từ chối thanh toán). Chi phí mở L/C thường từ 0.1–0.5% giá trị. Thường chỉ dùng cho đơn hàng lớn trên 50.000–100.000 USD. Với đơn hàng nhỏ, T/T đơn giản và rẻ hơn nhiều."
      },
      {
        "title": "Chứng từ thanh toán: gửi ngay, đừng để nhà máy chờ",
        "body": "Sau khi chuyển tiền, gửi 付款凭证 cho nhà máy ngay trong ngày. Nhà máy không thể xác nhận tiền có vào hay chưa ngay lập tức (có thể mất 1–3 ngày làm việc tùy ngân hàng), nhưng chứng từ giúp họ yên tâm sắp xếp kế hoạch sản xuất trước. Trễ gửi chứng từ = trễ cả tiến độ sản xuất."
      },
      {
        "title": "账期: đặc quyền của khách hàng lâu năm",
        "body": "Đừng kỳ vọng có 账期 ngay từ lần đầu hợp tác. Đây là đặc quyền phải xây dựng qua thời gian. Nếu nhà cung cấp chủ động đề nghị 账期 ngay từ đầu, hãy cẩn thận — đôi khi là dấu hiệu họ đang cần tiền hoặc muốn ràng buộc khách hàng bằng điều kiện tốt."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "T/T trong thanh toán quốc tế là viết tắt của gì?",
          "options": {
            "A": "Trade Transfer",
            "B": "Telegraphic Transfer — chuyển khoản ngân hàng quốc tế",
            "C": "Total Transaction",
            "D": "Tax Transfer"
          }
        },
        {
          "num": 2,
          "q": "Công thức T/T phổ biến nhất với khách hàng mới là gì?",
          "options": {
            "A": "50% cọc, 50% sau khi nhận hàng",
            "B": "100% thanh toán trước",
            "C": "30% cọc, 70% trước khi xuất hàng",
            "D": "0% cọc, 100% sau khi nhận hàng"
          }
        },
        {
          "num": 3,
          "q": "L/C (信用证) phù hợp nhất với loại giao dịch nào?",
          "options": {
            "A": "Đơn hàng nhỏ dưới 5000 USD",
            "B": "Đơn hàng lớn cần sự bảo đảm từ ngân hàng cả hai bên",
            "C": "Thanh toán trong ngày",
            "D": "Giao dịch nội địa"
          }
        },
        {
          "num": 4,
          "q": "账期30天 có nghĩa là gì?",
          "options": {
            "A": "Phải thanh toán trong 30 ngày trước khi nhận hàng",
            "B": "Sau khi nhận hàng, có 30 ngày để thanh toán",
            "C": "Hợp đồng có hiệu lực 30 ngày",
            "D": "Giao hàng trong 30 ngày"
          }
        },
        {
          "num": 5,
          "q": "Sau khi chuyển tiền cọc, việc gì cần làm ngay lập tức?",
          "options": {
            "A": "Chờ nhà máy xác nhận",
            "B": "Gửi chứng từ thanh toán (付款凭证) cho nhà máy",
            "C": "Ký hợp đồng",
            "D": "Đặt lịch kiểm hàng"
          }
        },
        {
          "num": 6,
          "q": "尾款 là gì?",
          "options": {
            "A": "Toàn bộ tiền đơn hàng",
            "B": "Tiền đặt cọc ban đầu",
            "C": "Phần tiền còn lại chưa thanh toán",
            "D": "Phí vận chuyển"
          }
        },
        {
          "num": 7,
          "q": "Tại sao nhà máy TQ thường yêu cầu thanh toán trước một phần với khách mới?",
          "options": {
            "A": "Vì quy định của chính phủ TQ",
            "B": "Để đảm bảo khách không hủy đơn sau khi đã mua nguyên liệu",
            "C": "Vì chi phí sản xuất quá cao",
            "D": "Vì tỷ giá biến động"
          }
        },
        {
          "num": 8,
          "q": "Khi nào 账期 thường được nhà máy cung cấp?",
          "options": {
            "A": "Ngay từ lần đầu hợp tác",
            "B": "Sau khi hợp tác lâu dài và ổn định, thường trên 1 năm",
            "C": "Khi đơn hàng trên 10.000 USD",
            "D": "Khi khách hàng là công ty lớn"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "L/C đơn giản và rẻ hơn T/T nên phù hợp cho mọi loại đơn hàng."
        },
        {
          "num": 10,
          "q": "付款凭证 cần gửi cho nhà máy càng sớm càng tốt sau khi chuyển tiền."
        },
        {
          "num": 11,
          "q": "定金 và 订金 có cùng cách phát âm và thường dùng thay thế nhau trong thực tế."
        },
        {
          "num": 12,
          "q": "Khách hàng mới thường được hưởng kỳ hạn thanh toán ngay từ đơn hàng đầu tiên."
        },
        {
          "num": 13,
          "q": "汇率 biến động có thể ảnh hưởng đến lợi nhuận thực tế của nhà máy dù giá USD không đổi."
        },
        {
          "num": 14,
          "q": "预付款 100% nghĩa là toàn bộ tiền phải trả trước khi sản xuất hoặc giao hàng."
        }
      ],
      "fillblank": {
        "wordbank": [
          "定金",
          "尾款",
          "T",
          "T",
          "信用证",
          "账期",
          "付款凭证"
        ],
        "items": [
          {
            "num": 15,
            "q": "我们接受____付款，30%____，70%出货前付清。"
          },
          {
            "num": 16,
            "q": "订单金额超过10万美元，建议使用____付款，更安全。"
          },
          {
            "num": 17,
            "q": "货物验收通过后，____请在7个工作日内付清。"
          },
          {
            "num": 18,
            "q": "合作一年后，我们可以给您30天的____。"
          },
          {
            "num": 19,
            "q": "转账后请把____发给我，我们好安排生产计划。"
          },
          {
            "num": 20,
            "q": "第一次合作，我们需要100%____，请理解。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "我们的付款条件是T/T，30%定金，60%见提单，10%验货后7天内付清。"
        },
        {
          "num": 22,
          "q": "新客户需要全款预付，合作稳定后我们可以考虑提供账期。"
        },
        {
          "num": 23,
          "q": "由于最近汇率波动，我们的报价已经调整，请以最新报价单为准。"
        },
        {
          "num": 24,
          "q": "收到付款凭证后，我们会在24小时内确认收款并安排排产。"
        },
        {
          "num": 25,
          "q": "信用证付款比T/T复杂，但对双方都更有保障，特别是大金额订单。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Điều kiện thanh toán của chúng tôi là 30% cọc, 70% trước khi xuất hàng. Chấp nhận không?"
        },
        {
          "num": 27,
          "q": "Sau khi chuyển cọc, tôi sẽ gửi chứng từ thanh toán cho anh ngay trong ngày hôm nay."
        },
        {
          "num": 28,
          "q": "Nếu sau này đơn hàng ổn định, anh có thể cho chúng tôi kỳ hạn thanh toán 30 ngày không?"
        },
        {
          "num": 29,
          "q": "Giá trị đơn hàng lần này là 80.000 USD, chúng tôi muốn thanh toán bằng thư tín dụng."
        },
        {
          "num": 30,
          "q": "Tiền còn lại 70% chúng tôi sẽ thanh toán trước khi xuất hàng, anh có thể gửi thông tin tài khoản ngân hàng không?"
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "C",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "C",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": false,
        "10": true,
        "11": true,
        "12": false,
        "13": true,
        "14": true
      },
      "fillblank": {
        "15": "T",
        "16": "信用证",
        "17": "尾款",
        "18": "账期",
        "19": "付款凭证",
        "20": "预付款"
      },
      "zh2vi": {
        "21": "Điều kiện thanh toán của chúng tôi là T/T, 30% cọc, 60% khi có vận đơn, 10% trong 7 ngày sau kiểm hàng.",
        "22": "Khách mới cần thanh toán toàn bộ trước, sau khi hợp tác ổn định chúng tôi có thể xem xét cung cấp kỳ hạn.",
        "23": "Do tỷ giá gần đây biến động, báo giá của chúng tôi đã điều chỉnh, vui lòng lấy bảng báo giá mới nhất làm chuẩn.",
        "24": "Sau khi nhận được chứng từ thanh toán, chúng tôi sẽ xác nhận trong 24 giờ và sắp xếp lịch sản xuất.",
        "25": "Thanh toán L/C phức tạp hơn T/T nhưng bảo đảm hơn cho cả hai bên, đặc biệt đơn hàng giá trị lớn."
      },
      "vi2zh": {
        "26": "我们的付款条件是30%定金，70%出货前付清，可以接受吗？",
        "27": "转完定金后，我今天就把付款凭证发给您。",
        "28": "如果以后订单稳定，您能给我们30天账期吗？",
        "29": "这次订单金额是8万美元，我们希望用信用证付款。",
        "30": "70%的尾款我们会在出货前付清，您能把银行账户信息发给我吗？"
      }
    }
  },
  {
    "num": 5,
    "title": "CHUỖI CUNG ỨNG & TÌNH TRẠNG HÀNG HÓA",
    "date": "1/6",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "供应链",
        "pinyin": "gōngyìng liàn",
        "vi": "chuỗi cung ứng",
        "explanation": "Toàn bộ hệ thống từ khai thác nguyên liệu thô → sản xuất linh kiện → lắp ráp thành phẩm → vận chuyển → phân phối đến tay người tiêu dùng. Khi 供应链 bị gián đoạn ở bất kỳ khâu nào (thiếu nguyên liệu, tắc cảng, đứt vận chuyển), toàn bộ chuỗi bị ảnh hưởng. COVID-19 năm 2020–2021 là ví dụ điển hình về khủng hoảng 供应链 toàn cầu.",
        "example": {
          "zh": "最近供应链很不稳定，导致很多产品交期延误。",
          "vi": "Gần đây chuỗi cung ứng rất không ổn định, dẫn đến nhiều sản phẩm bị chậm giao hàng."
        }
      },
      {
        "num": 2,
        "hanzi": "缺货",
        "pinyin": "quē huò",
        "vi": "thiếu hàng / hết hàng",
        "explanation": "Tình trạng sản phẩm hoặc nguyên liệu không đủ số lượng để đáp ứng nhu cầu. Có thể xảy ra ở bất kỳ khâu nào trong chuỗi cung ứng. Khi nhà cung cấp báo 缺货, người mua cần hỏi ngay: bao lâu có hàng lại, có hàng thay thế không, và có thể giao một phần trước không.",
        "example": {
          "zh": "这个型号目前严重缺货，至少要等6周。",
          "vi": "Mẫu này hiện đang thiếu hàng nghiêm trọng, ít nhất phải chờ 6 tuần."
        }
      },
      {
        "num": 3,
        "hanzi": "断货",
        "pinyin": "duàn huò",
        "vi": "đứt hàng / ngừng cung cấp",
        "explanation": "Tình trạng nghiêm trọng hơn 缺货 — hàng bị ngừng cung cấp hoàn toàn trong một khoảng thời gian, thường do nhà cung cấp đầu nguồn ngừng sản xuất hoặc xuất khẩu. 断货 ảnh hưởng đến toàn bộ kế hoạch sản xuất và giao hàng.",
        "example": {
          "zh": "上游原材料断货，我们被迫停产两周。",
          "vi": "Nguyên liệu đầu nguồn bị đứt hàng, chúng tôi buộc phải ngừng sản xuất 2 tuần."
        }
      },
      {
        "num": 4,
        "hanzi": "备货",
        "pinyin": "bèi huò",
        "vi": "dự trữ hàng / chuẩn bị hàng sẵn",
        "explanation": "Chủ động tích trữ hàng hóa hoặc nguyên liệu trước để đề phòng thiếu hụt hoặc đáp ứng đơn hàng lớn đột xuất. Trong mùa cao điểm (trước Black Friday, Tết...), nhà máy và khách hàng đều 备货 để tránh rủi ro thiếu hàng.",
        "example": {
          "zh": "旺季前我们会提前备货三个月。",
          "vi": "Trước mùa cao điểm chúng tôi sẽ dự trữ hàng trước 3 tháng."
        }
      },
      {
        "num": 5,
        "hanzi": "库存",
        "pinyin": "kùcún",
        "vi": "tồn kho",
        "explanation": "Lượng hàng hóa hoặc nguyên liệu đang được lưu trữ trong kho tại một thời điểm. Quản lý 库存 là bài toán cân bằng: quá nhiều thì đọng vốn, quá ít thì không đáp ứng được đơn hàng. Amazon rất quan tâm đến 库存 của seller — nếu 库存 về 0, listing sẽ mất thứ hạng.",
        "example": {
          "zh": "目前我们的库存只够生产两周，需要尽快补货。",
          "vi": "Hiện tồn kho của chúng tôi chỉ đủ sản xuất 2 tuần, cần bổ sung hàng gấp."
        }
      },
      {
        "num": 6,
        "hanzi": "上游供应商",
        "pinyin": "shàngyóu gōngyìng shāng",
        "vi": "nhà cung cấp đầu nguồn",
        "explanation": "Các công ty cung cấp nguyên liệu thô hoặc linh kiện cho nhà sản xuất của bạn. Ví dụ: nhà máy may mặc có 上游供应商 là nhà cung cấp vải; nhà máy điện tử có 上游供应商 là nhà cung cấp chip. Vấn đề ở 上游 sẽ lan xuống toàn bộ chuỗi.",
        "example": {
          "zh": "我们的上游供应商出了问题，导致我们这边也受到影响。",
          "vi": "Nhà cung cấp đầu nguồn của chúng tôi có vấn đề, dẫn đến phía chúng tôi cũng bị ảnh hưởng."
        }
      },
      {
        "num": 7,
        "hanzi": "采购周期",
        "pinyin": "cǎigòu zhōuqī",
        "vi": "chu kỳ thu mua",
        "explanation": "Khoảng thời gian từ khi đặt mua nguyên liệu/linh kiện đến khi nhận được hàng. Chu kỳ này ảnh hưởng trực tiếp đến 生产周期 (chu kỳ sản xuất) và 交货期 (thời gian giao hàng). Khi 采购周期 kéo dài (do thiếu hàng, vận chuyển chậm), toàn bộ kế hoạch bị đẩy lùi.",
        "example": {
          "zh": "这个芯片的采购周期现在要12周，比以前长了很多。",
          "vi": "Chu kỳ thu mua chip này hiện cần 12 tuần, dài hơn trước rất nhiều."
        }
      },
      {
        "num": 8,
        "hanzi": "交期延误",
        "pinyin": "jiāoqī yánwù",
        "vi": "chậm giao hàng / trễ hẹn giao hàng",
        "explanation": "Tình trạng hàng không được giao đúng thời hạn đã cam kết trong hợp đồng. Đây là vấn đề phổ biến và nghiêm trọng trong thương mại quốc tế — ảnh hưởng đến kế hoạch bán hàng của khách và có thể dẫn đến phạt vi phạm hợp đồng. Khi xảy ra, nhà máy cần thông báo sớm và đề xuất giải pháp thay vì chờ đến hạn mới báo.",
        "example": {
          "zh": "非常抱歉，由于供应链问题，这次交期要延误两周。",
          "vi": "Rất xin lỗi, do vấn đề chuỗi cung ứng, lần này giao hàng sẽ trễ 2 tuần."
        }
      },
      {
        "num": 9,
        "hanzi": "替代料",
        "pinyin": "tìdài liào",
        "vi": "nguyên liệu / linh kiện thay thế",
        "explanation": "Nguyên liệu hoặc linh kiện có thể dùng thay thế cho nguyên liệu gốc khi nguyên liệu gốc bị thiếu hoặc quá đắt. Việc dùng 替代料 cần được khách hàng chấp thuận trước — không được tự ý thay thế vì có thể ảnh hưởng đến chất lượng hoặc chứng nhận sản phẩm.",
        "example": {
          "zh": "原来的料缺货，我们可以用替代料吗？需要先得到您的确认。",
          "vi": "Nguyên liệu gốc hết hàng, chúng tôi có thể dùng nguyên liệu thay thế không? Cần xác nhận từ phía anh/chị trước."
        }
      },
      {
        "num": 10,
        "hanzi": "补货",
        "pinyin": "bǔ huò",
        "vi": "bổ sung hàng / nhập thêm hàng",
        "explanation": "Hành động đặt thêm hàng hoặc nguyên liệu để bù đắp lượng đã bán hoặc đã dùng, nhằm duy trì mức tồn kho tối thiểu. Quan trọng với người bán hàng Amazon — phải 补货 trước khi 库存 về 0 vì sau khi hết hàng, listing mất thứ hạng và mất doanh thu trong thời gian chờ hàng về.",
        "example": {
          "zh": "我们的亚马逊库存快见底了，需要尽快安排补货。",
          "vi": "Tồn kho Amazon của chúng tôi sắp hết, cần sắp xếp bổ sung hàng gấp."
        }
      }
    ],
    "dialogue": {
      "context": "Nhà máy TQ gọi điện khẩn cho khách hàng VN để thông báo vấn đề chuỗi cung ứng ảnh hưởng đến đơn hàng đang sản xuất. Bạn là phiên dịch.",
      "characters": [
        {
          "name": "生产主管老陈 (Lǎo Chén)",
          "role": "Trưởng sản xuất nhà máy TQ"
        },
        {
          "name": "Anh Khoa",
          "role": "Trưởng phòng thu mua VN"
        }
      ],
      "lines": [
        {
          "speaker": "老陈",
          "zh": "喂，您好，我是工厂生产主管老陈。有个紧急情况需要跟您说明一下。",
          "vi": "Alo, xin chào, tôi là lão Trần, trưởng sản xuất nhà máy. Có tình huống khẩn cần báo anh."
        },
        {
          "speaker": "Anh Khoa",
          "zh": "老陈你好，什么情况？",
          "vi": "Lão Trần xin chào, có chuyện gì vậy?"
        },
        {
          "speaker": "老陈",
          "zh": "是这样的，您上次的订单，我们本来计划这周五出货，但是出了点问题。我们的上游供应商通知我们，有一个关键零件现在严重缺货，他们的采购周期要延长到8周。",
          "vi": "Là thế này, đơn hàng lần trước của anh, chúng tôi vốn kế hoạch xuất hàng thứ Sáu tuần này, nhưng có vấn đề phát sinh. Nhà cung cấp đầu nguồn của chúng tôi thông báo có một linh kiện quan trọng hiện đang thiếu hàng nghiêm trọng, chu kỳ thu mua của họ phải kéo dài đến 8 tuần."
        },
        {
          "speaker": "Anh Khoa",
          "zh": "什么？8周？那我们的订单怎么办？",
          "vi": "Gì? 8 tuần? Vậy đơn hàng của chúng tôi tính sao?"
        },
        {
          "speaker": "老陈",
          "zh": "我们目前的库存只够完成您订单的60%，剩下的40%要等新的料到了才能继续生产。我们非常抱歉造成这个麻烦。",
          "vi": "Tồn kho hiện tại của chúng tôi chỉ đủ hoàn thành 60% đơn hàng của anh, 40% còn lại phải chờ nguyên liệu mới về mới tiếp tục sản xuất được. Chúng tôi rất xin lỗi vì đã gây ra phiền toái này."
        },
        {
          "speaker": "Anh Khoa",
          "zh": "这个影响很大，我们在亚马逊上的库存快见底了，等不起8周。有没有替代料可以用？",
          "vi": "Cái này ảnh hưởng lớn lắm, tồn kho Amazon của chúng tôi sắp hết rồi, không chờ được 8 tuần. Có nguyên liệu thay thế nào dùng được không?"
        },
        {
          "speaker": "老陈",
          "zh": "我们也在想这个方案。有一种替代料可以考虑，功能基本一样，但是规格稍微有点不同。需要您这边技术部门确认一下是否可以接受。",
          "vi": "Chúng tôi cũng đang nghĩ đến phương án đó. Có một loại nguyên liệu thay thế có thể xem xét, chức năng cơ bản giống nhau nhưng thông số hơi khác một chút. Cần bộ phận kỹ thuật phía anh xác nhận có chấp nhận được không."
        },
        {
          "speaker": "Anh Khoa",
          "zh": "好，你把替代料的规格参数发给我，我们内部确认一下。如果可以，能多快开始生产？",
          "vi": "Được, anh gửi thông số kỹ thuật của nguyên liệu thay thế cho tôi, chúng tôi xác nhận nội bộ. Nếu được, nhanh nhất bao lâu có thể bắt đầu sản xuất?"
        },
        {
          "speaker": "老陈",
          "zh": "如果您这边确认没问题，我们现在有备货，可以立刻安排生产，大概3到4天就可以完成剩余部分。",
          "vi": "Nếu phía anh xác nhận không vấn đề, chúng tôi hiện có sẵn hàng dự trữ, có thể sắp xếp sản xuất ngay lập tức, khoảng 3 đến 4 ngày là hoàn thành phần còn lại."
        },
        {
          "speaker": "Anh Khoa",
          "zh": "3到4天可以接受。另外，先发已经完成的60%给我们吗？",
          "vi": "3 đến 4 ngày chấp nhận được. Ngoài ra, có thể xuất 60% đã hoàn thành cho chúng tôi trước không?"
        },
        {
          "speaker": "老陈",
          "zh": "可以，我们可以先发60%，剩下的等确认替代料之后，最快4天后发出。这样您的亚马逊库存就不会断货了。",
          "vi": "Được, chúng tôi có thể xuất 60% trước, phần còn lại sau khi xác nhận nguyên liệu thay thế, nhanh nhất 4 ngày sau sẽ xuất. Như vậy tồn kho Amazon của anh sẽ không bị đứt hàng."
        },
        {
          "speaker": "Anh Khoa",
          "zh": "好，就这样安排。替代料规格你今天发给我，我明天给你答复。还有，这次延误有没有影响运费方面的安排？",
          "vi": "Tốt, sắp xếp như vậy đi. Thông số nguyên liệu thay thế anh gửi hôm nay cho tôi, ngày mai tôi trả lời. Ngoài ra, lần trễ hàng này có ảnh hưởng gì đến việc thu xếp cước vận chuyển không?"
        },
        {
          "speaker": "老陈",
          "zh": "运费方面我来跟货代重新协调，如果有额外费用我们这边承担，不会转嫁给您。再次为这次的供应链问题道歉。",
          "vi": "Phần cước vận chuyển tôi sẽ phối hợp lại với công ty freight forwarder, nếu có chi phí phát sinh phía chúng tôi chịu, không chuyển sang cho anh. Một lần nữa xin lỗi vì vấn đề chuỗi cung ứng lần này."
        }
      ]
    },
    "notes": [
      {
        "title": "Thông báo sớm khi có vấn đề: nguyên tắc vàng",
        "body": "Nhà máy tốt sẽ thông báo vấn đề ngay khi biết, không chờ đến hạn giao hàng. Trong hội thoại này, nhà máy thông báo trước nhiều tuần và đề xuất giải pháp — đây là hành vi chuyên nghiệp. Khi phiên dịch tình huống này, cần dịch sát cả phần giải thích nguyên nhân lẫn phần đề xuất giải pháp vì cả hai đều quan trọng cho quyết định của khách hàng."
      },
      {
        "title": "Phân biệt 缺货 và 断货",
        "body": "缺货 = thiếu, còn hàng nhưng không đủ. 断货 = đứt hoàn toàn, không có hàng. Hai từ này nghe giống nhau trong hội thoại nhanh nhưng mức độ nghiêm trọng khác nhau. Dịch sai sẽ khiến khách hàng đánh giá sai mức độ vấn đề."
      },
      {
        "title": "Amazon 库存 và tầm quan trọng của 补货 timing",
        "body": "Với người bán Amazon, 库存 về 0 là thảm họa — listing mất thứ hạng, mất Buy Box, mất doanh thu. Quy tắc thực tế: khi còn 30–45 ngày tồn kho, phải đặt hàng bổ sung ngay. Nếu bạn làm phiên dịch cho công ty bán Amazon, bạn sẽ nghe cụm từ 亚马逊库存 rất thường xuyên."
      },
      {
        "title": "Khi dùng 替代料 phải có văn bản xác nhận",
        "body": "Dù cấp bách đến đâu, việc dùng nguyên liệu thay thế cần được xác nhận bằng văn bản (email hoặc WeChat). Nếu sau này có vấn đề chất lượng liên quan đến nguyên liệu thay thế, cần có bằng chứng khách hàng đã đồng ý. Đây là điểm bảo vệ cả hai bên."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "供应链 mô tả điều gì?",
          "options": {
            "A": "Danh sách nhà cung cấp của một công ty",
            "B": "Toàn bộ hệ thống từ nguyên liệu thô đến tay người tiêu dùng",
            "C": "Hợp đồng giữa nhà máy và khách hàng",
            "D": "Hệ thống kho bãi của nhà máy"
          }
        },
        {
          "num": 2,
          "q": "断货 khác 缺货 ở điểm nào?",
          "options": {
            "A": "Hoàn toàn giống nhau",
            "B": "断货 nghiêm trọng hơn — hàng ngừng cung cấp hoàn toàn",
            "C": "缺货 nghiêm trọng hơn 断货",
            "D": "断货 chỉ dùng cho nguyên liệu, 缺货 cho thành phẩm"
          }
        },
        {
          "num": 3,
          "q": "Khi Amazon 库存 về 0, điều gì xảy ra với listing sản phẩm?",
          "options": {
            "A": "Listing bị xóa vĩnh viễn",
            "B": "Listing mất thứ hạng, mất Buy Box, mất doanh thu trong thời gian chờ hàng về",
            "C": "Listing vẫn hoạt động bình thường",
            "D": "Amazon tự động đặt hàng thay cho seller"
          }
        },
        {
          "num": 4,
          "q": "Khi muốn dùng 替代料, điều bắt buộc phải làm là gì?",
          "options": {
            "A": "Thông báo sau khi đã sản xuất xong",
            "B": "Được khách hàng xác nhận trước khi sản xuất",
            "C": "Chỉ cần báo cáo trong hóa đơn",
            "D": "Không cần làm gì thêm"
          }
        },
        {
          "num": 5,
          "q": "采购周期 ảnh hưởng đến điều gì?",
          "options": {
            "A": "Giá sản phẩm",
            "B": "Chất lượng sản phẩm",
            "C": "Thời gian giao hàng tổng thể",
            "D": "Điều kiện thanh toán"
          }
        },
        {
          "num": 6,
          "q": "备货 là gì?",
          "options": {
            "A": "Kiểm tra hàng trước khi xuất kho",
            "B": "Chủ động tích trữ hàng/nguyên liệu để đề phòng thiếu hụt",
            "C": "Trả lại hàng lỗi cho nhà máy",
            "D": "Đóng gói hàng để giao"
          }
        },
        {
          "num": 7,
          "q": "Nhà máy chuyên nghiệp nên thông báo 交期延误 khi nào?",
          "options": {
            "A": "Đúng ngày hẹn giao hàng",
            "B": "Ngay khi biết có vấn đề, càng sớm càng tốt",
            "C": "Sau khi hàng đã được xuất",
            "D": "Chỉ khi khách hàng hỏi"
          }
        },
        {
          "num": 8,
          "q": "上游供应商 là ai trong chuỗi cung ứng?",
          "options": {
            "A": "Khách hàng mua hàng từ nhà máy",
            "B": "Công ty vận chuyển hàng hóa",
            "C": "Nhà cung cấp nguyên liệu hoặc linh kiện cho nhà máy",
            "D": "Công ty kiểm định chất lượng"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "缺货 và 断货 có mức độ nghiêm trọng như nhau."
        },
        {
          "num": 10,
          "q": "Nhà máy có thể tự ý dùng 替代料 mà không cần hỏi khách hàng nếu chất lượng tương đương."
        },
        {
          "num": 11,
          "q": "Người bán Amazon nên đặt 补货 khi tồn kho còn khoảng 30–45 ngày để tránh 断货."
        },
        {
          "num": 12,
          "q": "采购周期 là thời gian từ khi đặt mua nguyên liệu đến khi nhận được hàng."
        },
        {
          "num": 13,
          "q": "Khi xảy ra 交期延误, nhà máy tốt sẽ chờ đến hạn giao hàng mới thông báo cho khách."
        },
        {
          "num": 14,
          "q": "库存 quá nhiều cũng là vấn đề vì đọng vốn."
        }
      ],
      "fillblank": {
        "wordbank": [
          "供应链",
          "缺货",
          "备货",
          "库存",
          "交期延误",
          "替代料"
        ],
        "items": [
          {
            "num": 15,
            "q": "最近____很不稳定，很多工厂都出现了____问题。"
          },
          {
            "num": 16,
            "q": "我们目前的____只够两周生产，需要尽快安排____。"
          },
          {
            "num": 17,
            "q": "由于原材料____，这次我们的____了三周，非常抱歉。"
          },
          {
            "num": 18,
            "q": "原来的零件没有货，我们找到了一种____，功能一样，请问您能接受吗？"
          },
          {
            "num": 19,
            "q": "旺季前我们提前____了三个月的原材料，以防____。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 20,
          "q": "由于上游供应商突然断货，我们不得不暂停生产，预计影响交期两到三周。"
        },
        {
          "num": 21,
          "q": "我们的库存还够生产500个，剩下的500个要等新原材料到了才能安排。"
        },
        {
          "num": 22,
          "q": "如果使用替代料，需要您技术部门确认规格参数是否符合要求。"
        },
        {
          "num": 23,
          "q": "旺季马上要到了，建议您提前备货，避免因为我们这边生产周期长而断货。"
        },
        {
          "num": 24,
          "q": "非常抱歉，这次交期延误完全是因为供应链的问题，额外产生的运费我们承担。"
        }
      ],
      "vi2zh": [
        {
          "num": 25,
          "q": "Tồn kho Amazon của chúng tôi chỉ còn đủ cho 3 tuần, cần xuất hàng gấp."
        },
        {
          "num": 26,
          "q": "Chuỗi cung ứng gần đây không ổn định, anh có thể xác nhận thời gian giao hàng vẫn đúng hạn không?"
        },
        {
          "num": 27,
          "q": "Nếu nguyên liệu gốc hết hàng, vui lòng thông báo cho chúng tôi ngay và đề xuất nguyên liệu thay thế."
        },
        {
          "num": 28,
          "q": "Chu kỳ thu mua linh kiện này là bao lâu? Có ảnh hưởng đến thời gian giao hàng của chúng tôi không?"
        },
        {
          "num": 29,
          "q": "Chúng tôi muốn dự trữ hàng trước 2 tháng, anh có thể nhận đơn với số lượng lớn hơn bình thường không?"
        },
        {
          "num": 30,
          "q": "Lần trễ hàng này ảnh hưởng rất lớn đến kế hoạch bán hàng của chúng tôi, mong anh ưu tiên xử lý."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "C",
        "6": "B",
        "7": "B",
        "8": "C"
      },
      "tf": {
        "9": false,
        "10": false,
        "11": true,
        "12": true,
        "13": false,
        "14": true
      },
      "fillblank": {
        "15": [
          "供应链",
          "缺货"
        ],
        "16": [
          "库存",
          "备货"
        ],
        "17": [
          "缺货",
          "交期延误"
        ],
        "18": "替代料",
        "19": [
          "备货",
          "缺货"
        ]
      },
      "zh2vi": {
        "20": "Do nhà cung cấp đầu nguồn đột ngột đứt hàng, chúng tôi buộc phải tạm dừng sản xuất, dự kiến ảnh hưởng đến thời gian giao hàng 2 đến 3 tuần.",
        "21": "Tồn kho của chúng tôi còn đủ sản xuất 500 cái, 500 cái còn lại phải chờ nguyên liệu mới về mới sắp xếp được.",
        "22": "Nếu dùng nguyên liệu thay thế, cần bộ phận kỹ thuật phía anh xác nhận thông số có đáp ứng yêu cầu không.",
        "23": "Mùa cao điểm sắp đến rồi, khuyến nghị anh dự trữ hàng trước để tránh đứt hàng do chu kỳ sản xuất bên chúng tôi dài.",
        "24": "Rất xin lỗi, lần trễ giao hàng này hoàn toàn do vấn đề chuỗi cung ứng, phần cước phát sinh thêm chúng tôi chịu."
      },
      "vi2zh": {
        "25": "我们的亚马逊库存只够三周了，需要尽快发货。",
        "26": "最近供应链不稳定，您能确认交货时间还是按时吗？",
        "27": "如果原来的原材料缺货，请立即通知我们并提出替代料方案。",
        "28": "这个零件的采购周期是多长？会不会影响我们的交货时间？",
        "29": "我们想提前备两个月的货，您能接受比平时更大的订单量吗？",
        "30": "这次延误对我们的销售计划影响很大，希望您能优先处理。"
      }
    }
  },
  {
    "num": 6,
    "title": "GIAO HÀNG & VẬN CHUYỂN",
    "date": "2/6",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "交货期",
        "pinyin": "jiāohuò qī",
        "vi": "thời hạn giao hàng",
        "explanation": "Ngày hoặc khoảng thời gian hàng hóa phải được giao theo hợp đồng. Đây là một trong những điều khoản quan trọng nhất — vi phạm 交货期 có thể dẫn đến phạt vi phạm hợp đồng hoặc hủy đơn. Cần phân biệt: 交货期 là ngày xuất hàng khỏi nhà máy hay ngày hàng đến cảng hay ngày đến tay khách.",
        "example": {
          "zh": "合同规定的交货期是6月30日，请务必按时出货。",
          "vi": "Thời hạn giao hàng trong hợp đồng là 30/6, nhất định phải xuất hàng đúng hạn."
        }
      },
      {
        "num": 2,
        "hanzi": "生产周期",
        "pinyin": "shēngchǎn zhōuqī",
        "vi": "chu kỳ sản xuất / thời gian sản xuất",
        "explanation": "Khoảng thời gian từ khi bắt đầu sản xuất đến khi hoàn thành sản phẩm, chưa tính thời gian vận chuyển. Ví dụ: 生产周期 30 ngày + vận chuyển biển 20 ngày = tổng thời gian từ đặt hàng đến nhận hàng là 50 ngày. Hiểu được 生产周期 giúp lên kế hoạch đặt hàng chính xác.",
        "example": {
          "zh": "这款产品的生产周期是25到30天。",
          "vi": "Chu kỳ sản xuất của sản phẩm này là 25 đến 30 ngày."
        }
      },
      {
        "num": 3,
        "hanzi": "装柜",
        "pinyin": "zhuāng guì",
        "vi": "đóng container / xếp hàng vào container",
        "explanation": "Quá trình đưa hàng thành phẩm vào container để vận chuyển. Đây là bước cuối cùng trước khi hàng rời nhà máy. 装柜 thường diễn ra tại cảng hoặc tại nhà máy (nếu là container FCL). Trong thực tế, buyer hay hỏi 什么时候装柜 để biết chính xác tiến độ.",
        "example": {
          "zh": "货物已经准备好了，明天安排装柜。",
          "vi": "Hàng hóa đã chuẩn bị xong, ngày mai sắp xếp đóng container."
        }
      },
      {
        "num": 4,
        "hanzi": "出货",
        "pinyin": "chū huò",
        "vi": "xuất hàng / giao hàng đi",
        "explanation": "Thời điểm hàng rời khỏi nhà máy hoặc kho để đến cảng xuất khẩu. 出货 là mốc quan trọng trong quy trình — sau khi 出货, nhà máy sẽ cấp bộ chứng từ xuất khẩu. Trong nhắn tin hàng ngày, cụm 货出了吗？ (hàng xuất chưa?) là câu hỏi phổ biến nhất của buyer.",
        "example": {
          "zh": "订单已经生产完毕，明天可以出货。",
          "vi": "Đơn hàng đã sản xuất xong, ngày mai có thể xuất hàng."
        }
      },
      {
        "num": 5,
        "hanzi": "整柜 (FCL)",
        "pinyin": "zhěng guì",
        "vi": "nguyên container (Full Container Load)",
        "explanation": "Thuê nguyên một container chỉ chở hàng của một chủ hàng. Container 20 feet chứa khoảng 25–28 CBM, container 40 feet chứa khoảng 55–58 CBM. FCL rẻ hơn theo CBM so với LCL, nhưng cần lượng hàng đủ lớn để lấp đầy container. Thường dùng khi đơn hàng trên 15 CBM.",
        "example": {
          "zh": "这批货我们走整柜，一个40尺柜。",
          "vi": "Lô hàng này chúng tôi sẽ dùng nguyên container, một container 40 feet."
        }
      },
      {
        "num": 6,
        "hanzi": "拼柜 (LCL)",
        "pinyin": "pīn guì",
        "vi": "ghép container (Less than Container Load)",
        "explanation": "Gộp hàng của nhiều chủ hàng vào chung một container. Phù hợp khi lượng hàng nhỏ, không đủ lấp đầy một container. LCL đắt hơn FCL theo CBM nhưng linh hoạt hơn cho đơn hàng nhỏ. Nhược điểm: thời gian giao hàng chậm hơn và rủi ro hư hỏng hàng cao hơn vì xếp dỡ nhiều lần hơn.",
        "example": {
          "zh": "货量不够一个整柜，我们走拼柜吧。",
          "vi": "Lượng hàng không đủ một nguyên container, chúng ta đi ghép container nhé."
        }
      },
      {
        "num": 7,
        "hanzi": "货代",
        "pinyin": "huò dài",
        "vi": "công ty freight forwarder / đại lý vận chuyển",
        "explanation": "Công ty trung gian lo toàn bộ thủ tục vận chuyển quốc tế: đặt chỗ tàu, làm thủ tục hải quan, cấp vận đơn, theo dõi hành trình hàng hóa. Trong thực tế, hầu hết nhà máy và buyer đều làm việc qua 货代 thay vì trực tiếp với hãng tàu. Tìm được 货代 tốt là lợi thế cạnh tranh quan trọng.",
        "example": {
          "zh": "我们的货代会安排订舱，你们这边有指定货代吗？",
          "vi": "Công ty forwarder của chúng tôi sẽ đặt chỗ tàu, phía anh có công ty forwarder chỉ định không?"
        }
      },
      {
        "num": 8,
        "hanzi": "提货",
        "pinyin": "tí huò",
        "vi": "nhận hàng / lấy hàng",
        "explanation": "Hành động người nhận hàng đến cảng đích hoặc kho để lấy hàng sau khi hải quan thông quan. Để 提货, cần có vận đơn gốc (B/L) hoặc điện giải phóng hàng (Telex Release). Thiếu chứng từ = không thể 提货.",
        "example": {
          "zh": "货到港了，准备好提单了吗？可以去提货了。",
          "vi": "Hàng đến cảng rồi, chuẩn bị sẵn vận đơn chưa? Có thể đi lấy hàng rồi."
        }
      },
      {
        "num": 9,
        "hanzi": "预计到港时间 (ETA)",
        "pinyin": "yùjì dào gǎng shíjiān",
        "vi": "thời gian dự kiến đến cảng",
        "explanation": "Estimated Time of Arrival — ngày tàu dự kiến cập cảng đích. ETA có thể thay đổi do điều kiện thời tiết, tắc nghẽn cảng, hoặc lịch tàu thay đổi. Người nhận hàng cần theo dõi ETA để chuẩn bị thủ tục hải quan và kho bãi kịp thời.",
        "example": {
          "zh": "这批货的ETA是7月15日，请提前准备清关文件。",
          "vi": "ETA của lô hàng này là 15/7, vui lòng chuẩn bị trước chứng từ thông quan."
        }
      },
      {
        "num": 10,
        "hanzi": "运费",
        "pinyin": "yùnfèi",
        "vi": "cước vận chuyển",
        "explanation": "Phí trả cho hãng tàu hoặc hãng hàng không để vận chuyển hàng hóa. 运费 biến động theo mùa, tuyến đường và cung cầu thị trường. Năm 2021–2022, 运费 từ TQ sang Mỹ tăng gấp 10 lần so với bình thường do khủng hoảng chuỗi cung ứng — đây là bài học về tầm quan trọng của việc theo dõi 运费.",
        "example": {
          "zh": "最近运费涨了很多，从深圳到洛杉矶现在要多少？",
          "vi": "Gần đây cước vận chuyển tăng nhiều, từ Thâm Quyến đến Los Angeles hiện là bao nhiêu?"
        }
      }
    ],
    "dialogue": {
      "context": "Cuộc gọi xác nhận logistics sau khi đơn hàng đã sản xuất xong. Nhà máy và buyer thống nhất kế hoạch xuất hàng. Bạn là phiên dịch.",
      "characters": [
        {
          "name": "跟单员小李 (Xiǎo Lǐ)",
          "role": "Nhân viên theo dõi đơn hàng của nhà máy TQ"
        },
        {
          "name": "Anh Nam",
          "role": "Nhân viên logistics công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "小李",
          "zh": "您好，您的订单已经生产完毕了，质检也通过了，可以安排出货了。请问你们这边有指定货代吗？",
          "vi": "Xin chào, đơn hàng của anh đã sản xuất xong rồi, kiểm tra chất lượng cũng đã qua, có thể sắp xếp xuất hàng rồi. Cho hỏi phía anh có công ty forwarder chỉ định không?"
        },
        {
          "speaker": "Anh Nam",
          "zh": "我们有合作的货代，叫东方物流，深圳那边你们认识他们吗？",
          "vi": "Chúng tôi có forwarder hợp tác, tên là Đông Phương Logistics, bên Thâm Quyến các anh có quen không?"
        },
        {
          "speaker": "小李",
          "zh": "知道，我们之前也跟他们合作过。那订舱的事情我这边通知他们来安排吗？还是你们自己联系？",
          "vi": "Biết chứ, trước đây chúng tôi cũng đã hợp tác với họ rồi. Vậy việc đặt chỗ tàu phía tôi thông báo họ sắp xếp luôn hay anh tự liên hệ?"
        },
        {
          "speaker": "Anh Nam",
          "zh": "麻烦你通知他们，顺便告诉他们货量是多少，几个CBM？",
          "vi": "Phiền anh thông báo họ, tiện thể cho họ biết lượng hàng là bao nhiêu, mấy CBM?"
        },
        {
          "speaker": "小李",
          "zh": "这批货总共是12个CBM，重量大约是3.8吨。走拼柜的话比较合适，整柜的话有点浪费。",
          "vi": "Lô hàng này tổng cộng 12 CBM, trọng lượng khoảng 3,8 tấn. Đi ghép container là phù hợp hơn, nguyên container thì hơi lãng phí."
        },
        {
          "speaker": "Anh Nam",
          "zh": "好的，走拼柜吧。这批货的交货期是6月20日，来得及吗？",
          "vi": "Được, đi ghép container nhé. Thời hạn giao hàng lô này là 20/6, kịp không?"
        },
        {
          "speaker": "小李",
          "zh": "完全没问题，我们这周四就可以出货，拼柜的船期大概周五出发，ETA洛杉矶是7月18日左右。",
          "vi": "Hoàn toàn không vấn đề, tuần này thứ Năm chúng tôi có thể xuất hàng, chuyến tàu ghép container khoảng thứ Sáu khởi hành, ETA cảng Los Angeles khoảng 18/7."
        },
        {
          "speaker": "Anh Nam",
          "zh": "好，7月18日可以接受。出货之后能不能马上把提单和装箱单发给我？我们要提前准备清关。",
          "vi": "Tốt, 18/7 chấp nhận được. Sau khi xuất hàng có thể gửi ngay vận đơn và packing list cho tôi không? Chúng tôi cần chuẩn bị thông quan trước."
        },
        {
          "speaker": "小李",
          "zh": "当然，货出了之后我们会在24小时内把全套单据发给您，包括商业发票、装箱单还有提单。",
          "vi": "Tất nhiên, sau khi hàng xuất chúng tôi sẽ gửi toàn bộ chứng từ cho anh trong 24 giờ, bao gồm commercial invoice, packing list và vận đơn."
        },
        {
          "speaker": "Anh Nam",
          "zh": "好的。还有，这次运费是怎么算的？我们之前谈的是FOB深圳港，运费我们自己承担。",
          "vi": "Tốt. Ngoài ra, cước vận chuyển lần này tính như thế nào? Trước đây chúng ta đã thỏa thuận giá FOB cảng Thâm Quyến, cước phía chúng tôi tự chịu."
        },
        {
          "speaker": "小李",
          "zh": "对，你们是FOB价格，运费由你们的货代来安排付款，我们这边只负责把货送到深圳港就好了。",
          "vi": "Đúng, anh dùng giá FOB, cước vận chuyển do forwarder của anh thanh toán, phía chúng tôi chỉ chịu trách nhiệm đưa hàng đến cảng Thâm Quyến là xong."
        },
        {
          "speaker": "Anh Nam",
          "zh": "明白了，那我现在就联系东方物流让他们订舱，你把货的具体尺寸和重量发给我，我转给他们。",
          "vi": "Hiểu rồi, vậy tôi liên hệ Đông Phương Logistics ngay để họ đặt chỗ tàu, anh gửi kích thước và trọng lượng hàng chi tiết cho tôi, tôi chuyển cho họ."
        },
        {
          "speaker": "小李",
          "zh": "好的，我马上发给您，还有出货通知我也同步发给您和你们的货代。",
          "vi": "Được, tôi gửi ngay cho anh, thông báo xuất hàng tôi cũng gửi đồng thời cho anh và forwarder của anh."
        }
      ]
    },
    "notes": [
      {
        "title": "FCL hay LCL: quyết định bằng thể tích",
        "body": "Quy tắc thực tế: dưới 15 CBM thì đi LCL (ghép container), trên 15 CBM nên cân nhắc FCL (nguyên container). LCL đắt hơn theo CBM nhưng không cần đủ hàng để lấp container. FCL rẻ hơn theo CBM nhưng cần có đủ lượng hàng."
      },
      {
        "title": "ETA là ước tính, không phải cam kết",
        "body": "ETA thường bị thay đổi — tàu delay, cảng tắc nghẽn, thời tiết xấu. Khi lên kế hoạch bán hàng, nên cộng thêm buffer 5–7 ngày so với ETA. Theo dõi ETA trên website của hãng tàu hoặc qua forwarder thường xuyên, đừng chỉ tin vào con số ban đầu."
      },
      {
        "title": "Bộ chứng từ xuất khẩu: 3 tài liệu cốt lõi",
        "body": "Commercial Invoice (商业发票), Packing List (装箱单), Bill of Lading (提单) là bộ ba bắt buộc. Thiếu một trong ba sẽ không thể thông quan. Trong thực tế còn có thể cần thêm: Certificate of Origin (原产地证), chứng nhận kiểm tra (检验证书), và các chứng nhận chuyên ngành."
      },
      {
        "title": "货代 tốt là tài sản",
        "body": "Một forwarder có kinh nghiệm trên tuyến TQ–Mỹ biết cách xử lý vấn đề, có quan hệ với hãng tàu và hải quan, và thường có thể giải quyết vấn đề phát sinh nhanh hơn. Đừng chỉ chọn forwarder rẻ nhất — giá rẻ đôi khi trả giá bằng hàng bị kẹt ở cảng."
      },
      {
        "title": "装柜 và 出货 không phải cùng một thời điểm",
        "body": "Đôi khi hàng được đóng container (装柜) tại kho nhà máy, sau đó container mới được kéo ra cảng. Thời điểm 出货 là khi container rời nhà máy, không phải khi tàu khởi hành (出发). Cần hỏi rõ để tránh nhầm lẫn khi theo dõi tiến độ."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "FCL và LCL khác nhau như thế nào?",
          "options": {
            "A": "FCL là vận chuyển đường hàng không, LCL là đường biển",
            "B": "FCL là nguyên container một chủ hàng, LCL là ghép nhiều chủ hàng",
            "C": "FCL nhanh hơn LCL",
            "D": "FCL chỉ dùng cho hàng nguy hiểm"
          }
        },
        {
          "num": 2,
          "q": "Khi nào nên dùng LCL thay vì FCL?",
          "options": {
            "A": "Khi hàng nặng hơn 5 tấn",
            "B": "Khi lượng hàng nhỏ, không đủ lấp đầy một container",
            "C": "Khi cần giao hàng nhanh",
            "D": "Khi hàng cần bảo quản lạnh"
          }
        },
        {
          "num": 3,
          "q": "货代 (freight forwarder) làm gì?",
          "options": {
            "A": "Sản xuất hàng hóa",
            "B": "Lo thủ tục vận chuyển quốc tế, đặt chỗ tàu, làm hải quan",
            "C": "Kiểm tra chất lượng hàng",
            "D": "Bảo hiểm hàng hóa"
          }
        },
        {
          "num": 4,
          "q": "ETA là gì?",
          "options": {
            "A": "Ngày xuất hàng khỏi nhà máy",
            "B": "Ngày tàu dự kiến cập cảng đích",
            "C": "Ngày hợp đồng có hiệu lực",
            "D": "Ngày thanh toán cuối cùng"
          }
        },
        {
          "num": 5,
          "q": "Để 提货 (lấy hàng) tại cảng, cần có gì?",
          "options": {
            "A": "Hóa đơn mua hàng",
            "B": "Vận đơn gốc (B/L) hoặc điện giải phóng hàng",
            "C": "Hộ chiếu của giám đốc",
            "D": "Hợp đồng mua bán"
          }
        },
        {
          "num": 6,
          "q": "Bộ 3 chứng từ xuất khẩu bắt buộc là gì?",
          "options": {
            "A": "Hợp đồng, báo giá, đơn đặt hàng",
            "B": "Commercial Invoice, Packing List, Bill of Lading",
            "C": "Certificate of Origin, Insurance, Bill of Lading",
            "D": "Purchase Order, Invoice, Bank receipt"
          }
        },
        {
          "num": 7,
          "q": "生产周期 30 ngày + vận chuyển biển 20 ngày = tổng thời gian từ đặt hàng đến nhận hàng là bao nhiêu?",
          "options": {
            "A": "30 ngày",
            "B": "20 ngày",
            "C": "50 ngày",
            "D": "10 ngày"
          }
        },
        {
          "num": 8,
          "q": "Tại sao không nên chỉ chọn forwarder rẻ nhất?",
          "options": {
            "A": "Forwarder rẻ thường là lừa đảo",
            "B": "Giá rẻ có thể đi kèm thiếu kinh nghiệm, quan hệ kém, xử lý vấn đề chậm",
            "C": "Forwarder rẻ không có giấy phép",
            "D": "Forwarder rẻ không chấp nhận hàng nhỏ"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "FCL luôn rẻ hơn LCL trong mọi trường hợp."
        },
        {
          "num": 10,
          "q": "ETA là ngày chắc chắn tàu sẽ cập cảng, không thay đổi."
        },
        {
          "num": 11,
          "q": "Khi dùng điều kiện giá FOB, người mua chịu cước vận chuyển từ cảng xuất khẩu trở đi."
        },
        {
          "num": 12,
          "q": "装柜 và 出货 luôn xảy ra cùng một thời điểm."
        },
        {
          "num": 13,
          "q": "Thiếu một trong ba chứng từ cốt lõi (Invoice, Packing List, B/L) có thể khiến hàng không thông quan được."
        },
        {
          "num": 14,
          "q": "生产周期 đã bao gồm cả thời gian vận chuyển đến cảng đích."
        }
      ],
      "fillblank": {
        "wordbank": [
          "整柜",
          "拼柜",
          "货代",
          "ETA",
          "出货",
          "运费"
        ],
        "items": [
          {
            "num": 15,
            "q": "这批货只有8个CBM，走____比较合适。"
          },
          {
            "num": 16,
            "q": "你们有指定的____吗？我们可以推荐几家。"
          },
          {
            "num": 17,
            "q": "这批货的____洛杉矶港是8月5日，请提前准备清关手续。"
          },
          {
            "num": 18,
            "q": "货物生产完毕，明天可以安排____了。"
          },
          {
            "num": 19,
            "q": "这次走____，一个40尺柜刚好装满。"
          },
          {
            "num": 20,
            "q": "FOB价格不含____，从出发港到目的港的费用由买方承担。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "货已经生产完了，明天装柜，预计后天可以出货，ETA洛杉矶是7月20日。"
        },
        {
          "num": 22,
          "q": "这批货12个CBM，走拼柜，货代已经帮我们订好舱位了。"
        },
        {
          "num": 23,
          "q": "出货后24小时内，我们会把商业发票、装箱单和提单全部发给您。"
        },
        {
          "num": 24,
          "q": "FOB深圳港价格不含运费，从深圳到目的港的运费和保险由买方负责。"
        },
        {
          "num": 25,
          "q": "最近运费涨了不少，建议您尽快确认订单，锁定目前的运费价格。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Hàng đã sản xuất xong chưa? Thời hạn giao hàng trong hợp đồng là 30/6, còn kịp không?"
        },
        {
          "num": 27,
          "q": "Lô hàng này khoảng 18 CBM, có nên đi nguyên container hay ghép container?"
        },
        {
          "num": 28,
          "q": "Sau khi xuất hàng, nhớ gửi toàn bộ chứng từ cho forwarder của chúng tôi và cho tôi."
        },
        {
          "num": 29,
          "q": "ETA của lô hàng này là bao giờ? Chúng tôi cần biết để chuẩn bị kho."
        },
        {
          "num": 30,
          "q": "Gần đây cước vận chuyển từ Thâm Quyến đến Los Angeles là bao nhiêu cho một container 40 feet?"
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "C",
        "8": "B"
      },
      "tf": {
        "9": false,
        "10": false,
        "11": true,
        "12": false,
        "13": true,
        "14": false
      },
      "fillblank": {
        "15": "拼柜",
        "16": "货代",
        "17": "ETA",
        "18": "出货",
        "19": "整柜",
        "20": "运费"
      },
      "zh2vi": {
        "21": "Hàng đã sản xuất xong rồi, ngày mai đóng container, dự kiến ngày kia có thể xuất hàng, ETA Los Angeles là 20/7.",
        "22": "Lô hàng này 12 CBM, đi ghép container, forwarder đã đặt chỗ tàu cho chúng tôi rồi.",
        "23": "Sau khi xuất hàng 24 giờ, chúng tôi sẽ gửi toàn bộ commercial invoice, packing list và vận đơn cho anh.",
        "24": "Giá FOB cảng Thâm Quyến không bao gồm cước, cước và bảo hiểm từ Thâm Quyến đến cảng đích do bên mua chịu.",
        "25": "Gần đây cước vận chuyển tăng nhiều, khuyến nghị anh xác nhận đơn hàng sớm để chốt mức cước hiện tại."
      },
      "vi2zh": {
        "26": "货生产好了吗？合同规定的交货期是6月30日，来得及吗？",
        "27": "这批货大约18个CBM，走整柜还是拼柜好？",
        "28": "出货后记得把全套单据发给我们的货代和我。",
        "29": "这批货的ETA是什么时候？我们需要知道以便准备仓库。",
        "30": "最近从深圳到洛杉矶的运费是多少，一个40尺柜？"
      }
    }
  },
  {
    "num": 7,
    "title": "CHẤT LƯỢNG & KIỂM HÀNG",
    "date": "3/6",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "质量标准",
        "pinyin": "zhìliàng biāozhǔn",
        "vi": "tiêu chuẩn chất lượng",
        "explanation": "Bộ tiêu chí cụ thể về kích thước, vật liệu, màu sắc, chức năng mà sản phẩm phải đáp ứng. Tiêu chuẩn chất lượng nên được ghi rõ trong hợp đồng để tránh tranh cãi. Không có tiêu chuẩn rõ ràng = không có cơ sở để khiếu nại khi hàng kém chất lượng.",
        "example": {
          "zh": "请把你们的质量标准发给我们，我们按照这个标准生产。",
          "vi": "Vui lòng gửi tiêu chuẩn chất lượng của anh cho chúng tôi, chúng tôi sản xuất theo tiêu chuẩn đó."
        }
      },
      {
        "num": 2,
        "hanzi": "验货",
        "pinyin": "yàn huò",
        "vi": "kiểm tra hàng hóa",
        "explanation": "Quá trình kiểm tra hàng thành phẩm trước khi xuất kho, đảm bảo đáp ứng tiêu chuẩn chất lượng. Có thể do nhà máy tự kiểm (内部验货), khách hàng cử người đến kiểm (驻厂验货), hoặc thuê bên thứ ba kiểm (第三方验货).",
        "example": {
          "zh": "出货前我们需要派人去工厂验货。",
          "vi": "Trước khi xuất hàng chúng tôi cần cử người đến nhà máy kiểm hàng."
        }
      },
      {
        "num": 3,
        "hanzi": "第三方检测",
        "pinyin": "dìsānfāng jiǎncè",
        "vi": "kiểm định bên thứ ba",
        "explanation": "Dịch vụ kiểm tra chất lượng độc lập do công ty chuyên nghiệp thực hiện — phổ biến nhất là SGS, Bureau Veritas, Intertek. Chi phí thường từ 200–400 USD/ngày kiểm. Khuyến nghị bắt buộc cho đơn hàng lớn hoặc lần đầu hợp tác với nhà máy mới.",
        "example": {
          "zh": "我们要求用SGS做第三方检测，费用由买方承担。",
          "vi": "Chúng tôi yêu cầu dùng SGS làm kiểm định bên thứ ba, chi phí do bên mua chịu."
        }
      },
      {
        "num": 4,
        "hanzi": "不合格品",
        "pinyin": "bù hégé pǐn",
        "vi": "hàng không đạt tiêu chuẩn / hàng lỗi",
        "explanation": "Sản phẩm không đáp ứng tiêu chuẩn chất lượng đã thỏa thuận. Khi phát hiện 不合格品, cần xác định: tỷ lệ lỗi bao nhiêu (%), nguyên nhân là gì, và giải pháp xử lý (返工 làm lại / 换货 đổi hàng / 索赔 khiếu nại).",
        "example": {
          "zh": "这批货里有5%的不合格品，请尽快处理。",
          "vi": "Trong lô hàng này có 5% hàng lỗi, vui lòng xử lý sớm."
        }
      },
      {
        "num": 5,
        "hanzi": "返工",
        "pinyin": "fǎn gōng",
        "vi": "làm lại / sửa chữa hàng lỗi",
        "explanation": "Quá trình sửa lại hoặc làm lại những sản phẩm không đạt tiêu chuẩn. Tốn thêm thời gian và chi phí. Câu hỏi quan trọng: ai chịu chi phí 返工 — nhà máy nếu lỗi do sản xuất, khách hàng nếu lỗi do thiết kế.",
        "example": {
          "zh": "这批不合格品可以返工吗？返工费用谁来承担？",
          "vi": "Lô hàng lỗi này có thể làm lại không? Chi phí làm lại ai chịu?"
        }
      },
      {
        "num": 6,
        "hanzi": "良品率",
        "pinyin": "liángpǐn lǜ",
        "vi": "tỷ lệ hàng đạt tiêu chuẩn",
        "explanation": "Phần trăm sản phẩm đạt tiêu chuẩn trên tổng số sản xuất. Ví dụ: 良品率 95% nghĩa là trong 100 sản phẩm, 95 cái đạt, 5 cái lỗi. Nhà máy tốt thường có 良品率 trên 98%. 良品率 thấp = chi phí cao và rủi ro khiếu nại lớn.",
        "example": {
          "zh": "我们的良品率一直保持在98%以上。",
          "vi": "Tỷ lệ hàng đạt của chúng tôi luôn duy trì trên 98%."
        }
      },
      {
        "num": 7,
        "hanzi": "抽检",
        "pinyin": "chōu jiǎn",
        "vi": "kiểm tra ngẫu nhiên / lấy mẫu kiểm tra",
        "explanation": "Phương pháp kiểm tra lấy một số mẫu ngẫu nhiên trong lô hàng để đánh giá chất lượng toàn bộ lô. Tiêu chuẩn phổ biến nhất là AQL (Acceptable Quality Level) — thường dùng AQL 2.5 cho hàng tiêu dùng thông thường.",
        "example": {
          "zh": "我们按照AQL 2.5标准进行抽检。",
          "vi": "Chúng tôi kiểm tra theo tiêu chuẩn AQL 2.5."
        }
      },
      {
        "num": 8,
        "hanzi": "质检报告",
        "pinyin": "zhì jiǎn bàogào",
        "vi": "báo cáo kiểm định chất lượng",
        "explanation": "Tài liệu chính thức ghi lại kết quả kiểm tra chất lượng. Khi bán hàng trên Amazon hoặc vào các chuỗi bán lẻ lớn như Costco, Walmart, 质检报告 từ công ty kiểm định uy tín là tài liệu bắt buộc. Thiếu 质检报告 = không được bán hàng.",
        "example": {
          "zh": "亚马逊要求我们提供质检报告，请问贵工厂能提供吗？",
          "vi": "Amazon yêu cầu chúng tôi cung cấp báo cáo kiểm định, quý nhà máy có thể cung cấp không?"
        }
      },
      {
        "num": 9,
        "hanzi": "驻厂验货",
        "pinyin": "zhù chǎng yàn huò",
        "vi": "kiểm hàng tại nhà máy / cử người thường trú kiểm",
        "explanation": "Người mua cử nhân viên đến ở tại nhà máy trong suốt quá trình sản xuất để giám sát chất lượng trực tiếp. Đây là hình thức kiểm soát chất lượng chặt chẽ nhất nhưng cũng tốn kém nhất.",
        "example": {
          "zh": "这个订单比较重要，我们想安排驻厂验货，可以吗？",
          "vi": "Đơn hàng này khá quan trọng, chúng tôi muốn sắp xếp kiểm hàng tại nhà máy, được không?"
        }
      },
      {
        "num": 10,
        "hanzi": "瑕疵",
        "pinyin": "xiácī",
        "vi": "khuyết tật / lỗi sản phẩm",
        "explanation": "Lỗi hoặc khiếm khuyết trên bề mặt hoặc chức năng của sản phẩm. Có thể là 外观瑕疵 (lỗi bề mặt — trầy xước, màu không đều) hoặc 功能性瑕疵 (lỗi chức năng — không hoạt động đúng). Cần xác định loại và mức độ 瑕疵 để quyết định xử lý.",
        "example": {
          "zh": "收到的货物表面有明显瑕疵，请问如何处理？",
          "vi": "Hàng nhận được có khuyết tật rõ ràng trên bề mặt, xin hỏi xử lý như thế nào?"
        }
      }
    ],
    "dialogue": {
      "context": "Nhân viên kiểm hàng của bên thứ ba (SGS) đang báo cáo kết quả kiểm hàng cho cả hai bên trước khi quyết định xuất hàng. Bạn là phiên dịch.",
      "characters": [
        {
          "name": "SGS检验员老王 (Lǎo Wáng)",
          "role": "Kiểm định viên SGS"
        },
        {
          "name": "工厂品质主管小陈 (Xiǎo Chén)",
          "role": "Trưởng QC nhà máy"
        },
        {
          "name": "Chị Thu",
          "role": "Đại diện bên mua VN"
        }
      ],
      "lines": [
        {
          "speaker": "老王",
          "zh": "我们今天按照AQL 2.5标准对这批2000个产品进行了抽检，抽检了125个样品，发现了以下问题。",
          "vi": "Hôm nay chúng tôi đã kiểm tra ngẫu nhiên lô 2000 sản phẩm này theo tiêu chuẩn AQL 2.5, lấy 125 mẫu kiểm, phát hiện các vấn đề sau."
        },
        {
          "speaker": "小陈",
          "zh": "请说，具体是什么问题？",
          "vi": "Vui lòng nói, cụ thể là vấn đề gì?"
        },
        {
          "speaker": "老王",
          "zh": "首先，有8个产品表面有明显瑕疵，主要是涂装不均匀。第二，有3个产品尺寸偏差超出了合同规定的允许范围。第三，有2个产品功能测试不通过。总体不合格品是13个，不合格率是10.4%，超过了AQL 2.5的允许上限，这批货不建议通过验收。",
          "vi": "Thứ nhất, có 8 sản phẩm bề mặt có khuyết tật rõ ràng, chủ yếu là sơn không đều. Thứ hai, có 3 sản phẩm sai lệch kích thước vượt phạm vi cho phép theo hợp đồng. Thứ ba, có 2 sản phẩm không qua kiểm tra chức năng. Tổng hàng không đạt là 13 cái, tỷ lệ không đạt 10,4%, vượt ngưỡng cho phép của AQL 2.5, lô hàng này không khuyến nghị nghiệm thu."
        },
        {
          "speaker": "Chị Thu",
          "zh": "这个结果我们很不满意。工厂这边怎么说？",
          "vi": "Kết quả này chúng tôi rất không hài lòng. Nhà máy có ý kiến gì?"
        },
        {
          "speaker": "小陈",
          "zh": "我们承认确实存在问题，但是我们认为涂装的问题可以返工处理，不需要重新生产。返工大概需要3天时间。",
          "vi": "Chúng tôi thừa nhận đúng là có vấn đề, nhưng chúng tôi cho rằng vấn đề sơn có thể làm lại, không cần sản xuất lại từ đầu. Làm lại khoảng 3 ngày."
        },
        {
          "speaker": "Chị Thu",
          "zh": "3天可以，但是返工之后需要重新验货，验货通过了才能出货，同意吗？",
          "vi": "3 ngày được, nhưng sau khi làm lại cần kiểm tra lại, qua kiểm tra mới được xuất hàng, đồng ý không?"
        },
        {
          "speaker": "小陈",
          "zh": "同意，返工完成后我们通知SGS重新验货。",
          "vi": "Đồng ý, sau khi làm lại xong chúng tôi thông báo SGS kiểm tra lại."
        },
        {
          "speaker": "老王",
          "zh": "好的，返工后我们会重新按照AQL 2.5标准抽检。另外，那5个尺寸超标和功能不合格的产品需要报废或者重做，不能返工修复。",
          "vi": "Được, sau khi làm lại chúng tôi sẽ kiểm tra lại theo tiêu chuẩn AQL 2.5. Ngoài ra, 5 sản phẩm lỗi kích thước và lỗi chức năng cần hủy hoặc làm lại từ đầu, không thể sửa chữa."
        },
        {
          "speaker": "小陈",
          "zh": "明白，那5个我们安排重新生产，3天内可以完成。",
          "vi": "Hiểu rồi, 5 cái đó chúng tôi sắp xếp sản xuất lại, 3 ngày có thể hoàn thành."
        },
        {
          "speaker": "Chị Thu",
          "zh": "好，那就这样安排。返工和重新生产的费用由工厂承担，对吗？",
          "vi": "Tốt, sắp xếp như vậy đi. Chi phí làm lại và sản xuất lại do nhà máy chịu, đúng không?"
        },
        {
          "speaker": "小陈",
          "zh": "对，这是我们生产质量的问题，费用我们这边全部承担，不会向您收取任何额外费用。",
          "vi": "Đúng, đây là vấn đề chất lượng sản xuất của chúng tôi, chi phí phía chúng tôi toàn bộ chịu, sẽ không tính bất kỳ khoản phí thêm nào cho anh/chị."
        },
        {
          "speaker": "Chị Thu",
          "zh": "好的，谢谢。那我们等工厂处理好之后，再安排SGS复检，复检通过后再出货。",
          "vi": "Tốt, cảm ơn. Vậy chúng tôi chờ nhà máy xử lý xong, rồi sắp xếp SGS kiểm tra lại, kiểm tra lại qua mới xuất hàng."
        }
      ]
    },
    "notes": [
      {
        "title": "AQL là gì và tại sao quan trọng",
        "body": "AQL (Acceptable Quality Level) là tiêu chuẩn quốc tế xác định tỷ lệ lỗi tối đa có thể chấp nhận được trong một lô hàng. AQL 2.5 nghĩa là cho phép tối đa 2.5% sản phẩm lỗi. Amazon yêu cầu hàng hóa đạt AQL 2.5 hoặc tốt hơn. Khi phiên dịch báo cáo kiểm định, số liệu AQL rất quan trọng — dịch sai có thể dẫn đến quyết định sai."
      },
      {
        "title": "Phân biệt 返工 và 重新生产",
        "body": "返工 = sửa chữa lại sản phẩm đã có, nhanh hơn và rẻ hơn. 重新生产 = làm lại từ đầu, tốn thêm nguyên liệu và thời gian. Nhà máy thường đề xuất 返工 để giảm chi phí. Người mua cần đánh giá liệu sản phẩm sau 返工 có thực sự đạt tiêu chuẩn không."
      },
      {
        "title": "Kiểm hàng bên thứ ba: đầu tư xứng đáng",
        "body": "Chi phí thuê SGS kiểm hàng khoảng 300–500 USD/lần. So với giá trị một container hàng (có thể hàng chục nghìn đến hàng trăm nghìn USD), chi phí này rất nhỏ. Nếu không kiểm và hàng lỗi đến tay khách — đặc biệt trên Amazon — hậu quả là reviews xấu, returns cao, và có thể bị ban tài khoản."
      },
      {
        "title": "Lỗi nào do nhà máy, lỗi nào do thiết kế",
        "body": "Khi có 不合格品, câu hỏi đầu tiên là: lỗi do sản xuất (nhà máy chịu) hay lỗi do thiết kế/thông số kỹ thuật của khách hàng (khách hàng chịu một phần). Rõ ràng trách nhiệm này từ đầu sẽ tránh tranh cãi không cần thiết sau này."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "AQL 2.5 có nghĩa là gì?",
          "options": {
            "A": "Kiểm tra 2.5% số lượng hàng",
            "B": "Cho phép tối đa 2.5% sản phẩm lỗi trong lô hàng",
            "C": "Chi phí kiểm định là 2.5 USD/sản phẩm",
            "D": "Thời gian kiểm định là 2.5 ngày"
          }
        },
        {
          "num": 2,
          "q": "Phương pháp kiểm hàng nào nghiêm ngặt nhất?",
          "options": {
            "A": "抽检 (kiểm ngẫu nhiên)",
            "B": "内部验货 (nhà máy tự kiểm)",
            "C": "驻厂验货 (cử người thường trú tại nhà máy)",
            "D": "出货前抽检 (kiểm ngẫu nhiên trước khi xuất)"
          }
        },
        {
          "num": 3,
          "q": "良品率 98% có nghĩa là gì?",
          "options": {
            "A": "Trong 100 sản phẩm có 2 cái đạt tiêu chuẩn",
            "B": "Trong 100 sản phẩm có 98 cái đạt tiêu chuẩn",
            "C": "Chi phí sản xuất tăng 98%",
            "D": "Thời gian kiểm tra mất 98 phút"
          }
        },
        {
          "num": 4,
          "q": "返工 khác 重新生产 thế nào?",
          "options": {
            "A": "Giống nhau hoàn toàn",
            "B": "返工 là sửa chữa sản phẩm có sẵn, 重新生产 là làm lại từ đầu",
            "C": "返工 nhanh hơn và đắt hơn",
            "D": "重新生产 chỉ dùng cho hàng điện tử"
          }
        },
        {
          "num": 5,
          "q": "Khi bán hàng trên Amazon, tài liệu nào thường bắt buộc phải có?",
          "options": {
            "A": "Hợp đồng với nhà máy",
            "B": "Báo cáo kiểm định chất lượng từ công ty uy tín",
            "C": "Bản vẽ kỹ thuật sản phẩm",
            "D": "Lịch sử đơn hàng"
          }
        },
        {
          "num": 6,
          "q": "Công ty kiểm định bên thứ ba nào được nhắc đến trong bài?",
          "options": {
            "A": "Amazon",
            "B": "SGS",
            "C": "AQL",
            "D": "Costco"
          }
        },
        {
          "num": 7,
          "q": "瑕疵 ngoại quan (外观瑕疵) khác 瑕疵 chức năng (功能性瑕疵) thế nào?",
          "options": {
            "A": "Hoàn toàn giống nhau",
            "B": "Ngoại quan là lỗi bề mặt nhìn thấy được, chức năng là lỗi không hoạt động đúng",
            "C": "Lỗi chức năng nghiêm trọng hơn luôn",
            "D": "Lỗi ngoại quan không cần xử lý"
          }
        },
        {
          "num": 8,
          "q": "Ai thường chịu chi phí 返工 khi hàng lỗi do sản xuất?",
          "options": {
            "A": "Người mua chịu toàn bộ",
            "B": "Nhà máy chịu toàn bộ",
            "C": "Chia đôi hai bên",
            "D": "Công ty bảo hiểm chịu"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Không cần ghi tiêu chuẩn chất lượng vào hợp đồng vì nhà máy tốt tự biết sản xuất đúng."
        },
        {
          "num": 10,
          "q": "Chi phí thuê SGS kiểm hàng là khoản đầu tư đáng giá so với rủi ro nhận hàng lỗi."
        },
        {
          "num": 11,
          "q": "质检报告 từ bên thứ ba uy tín là tài liệu bắt buộc khi bán hàng trên Amazon."
        },
        {
          "num": 12,
          "q": "Sau khi 返工, không cần kiểm tra lại vì nhà máy đã khẳng định đạt tiêu chuẩn."
        },
        {
          "num": 13,
          "q": "良品率 cao đồng nghĩa với chi phí sản xuất thấp và ít rủi ro khiếu nại."
        },
        {
          "num": 14,
          "q": "Khi hàng lỗi do thiết kế của khách hàng, nhà máy phải toàn quyền chịu chi phí sửa chữa."
        }
      ],
      "fillblank": {
        "wordbank": [
          "验货",
          "第三方检测",
          "不合格品",
          "返工",
          "良品率",
          "质检报告"
        ],
        "items": [
          {
            "num": 15,
            "q": "出货前我们需要安排____，确认质量没有问题。"
          },
          {
            "num": 16,
            "q": "我们要求做____，费用由我方承担。"
          },
          {
            "num": 17,
            "q": "这批货里有3%的____，请尽快处理。"
          },
          {
            "num": 18,
            "q": "表面瑕疵可以____，但功能性问题需要重新生产。"
          },
          {
            "num": 19,
            "q": "我们的____保持在98.5%以上，请放心。"
          },
          {
            "num": 20,
            "q": "亚马逊平台要求提供产品的____，请问贵公司能出具吗？"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "我们按照AQL 2.5标准抽检了这批货，发现不合格率是8%，超过了允许上限，不建议通过验收。"
        },
        {
          "num": 22,
          "q": "工厂同意对不合格品进行返工，返工费用由工厂承担，3天内完成。"
        },
        {
          "num": 23,
          "q": "请提供第三方质检报告，我们的美国客户要求有SGS或Intertek的检测证书。"
        },
        {
          "num": 24,
          "q": "这批货的良品率是96%，低于我们要求的98%，请分析原因并提出改善方案。"
        },
        {
          "num": 25,
          "q": "驻厂验货发现有几个批次的产品颜色跟确认样不一致，需要重新处理。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Trước khi xuất hàng, chúng tôi muốn thuê SGS đến kiểm hàng theo tiêu chuẩn AQL 2.5."
        },
        {
          "num": 27,
          "q": "Lô hàng này có 5% hàng lỗi, vượt tiêu chuẩn cho phép, nhà máy cần xử lý trước khi xuất hàng."
        },
        {
          "num": 28,
          "q": "Sản phẩm sau khi làm lại có cần kiểm tra lại không? Chúng tôi cần đảm bảo đạt tiêu chuẩn."
        },
        {
          "num": 29,
          "q": "Tiêu chuẩn chất lượng của chúng tôi đã ghi rõ trong hợp đồng, vui lòng sản xuất theo đúng tiêu chuẩn đó."
        },
        {
          "num": 30,
          "q": "Khách hàng bên Mỹ yêu cầu báo cáo kiểm định từ Intertek, anh có thể sắp xếp kiểm định không?"
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "C",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": false,
        "10": true,
        "11": true,
        "12": false,
        "13": true,
        "14": false
      },
      "fillblank": {
        "15": "验货",
        "16": "第三方检测",
        "17": "不合格品",
        "18": "返工",
        "19": "良品率",
        "20": "质检报告"
      },
      "zh2vi": {
        "21": "Chúng tôi đã kiểm ngẫu nhiên lô hàng theo tiêu chuẩn AQL 2.5, tỷ lệ không đạt là 8%, vượt ngưỡng cho phép, không khuyến nghị nghiệm thu.",
        "22": "Nhà máy đồng ý làm lại hàng lỗi, chi phí làm lại nhà máy chịu, hoàn thành trong 3 ngày.",
        "23": "Vui lòng cung cấp báo cáo kiểm định bên thứ ba, khách hàng Mỹ của chúng tôi yêu cầu chứng nhận kiểm định từ SGS hoặc Intertek.",
        "24": "Tỷ lệ hàng đạt lô này là 96%, thấp hơn yêu cầu 98% của chúng tôi, vui lòng phân tích nguyên nhân và đề xuất giải pháp cải thiện.",
        "25": "Kiểm hàng tại nhà máy phát hiện màu sắc của một số lô sản phẩm không khớp với mẫu xác nhận, cần xử lý lại."
      },
      "vi2zh": {
        "26": "出货前我们想委托SGS按照AQL 2.5标准进行验货。",
        "27": "这批货有5%的不合格品，超过了允许标准，工厂需要处理好后才能出货。",
        "28": "返工后的产品需要重新验货吗？我们需要确保达到质量标准。",
        "29": "我们的质量标准在合同里已经写清楚了，请按照标准生产。",
        "30": "美国客户要求提供Intertek的检测报告，您能安排检测吗？"
      }
    }
  },
  {
    "num": 8,
    "title": "KHIẾU NẠI & XỬ LÝ TRANH CHẤP",
    "date": "4/6",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "索赔",
        "pinyin": "suǒ péi",
        "vi": "khiếu nại / yêu cầu bồi thường",
        "explanation": "Yêu cầu chính thức của một bên đối với bên kia đòi bồi thường thiệt hại do vi phạm hợp đồng hoặc giao hàng kém chất lượng. 索赔 phải có cơ sở (bằng chứng hàng lỗi, hợp đồng, chứng từ kiểm định) và được đưa ra trong thời hạn quy định.",
        "example": {
          "zh": "由于质量问题，我们正式提出索赔，要求赔偿损失。",
          "vi": "Do vấn đề chất lượng, chúng tôi chính thức khiếu nại, yêu cầu bồi thường thiệt hại."
        }
      },
      {
        "num": 2,
        "hanzi": "赔偿",
        "pinyin": "péicháng",
        "vi": "bồi thường",
        "explanation": "Khoản tiền hoặc hàng hóa mà bên vi phạm phải trả cho bên bị thiệt hại. Trong thương mại quốc tế, 赔偿 có thể là: hoàn tiền (退款), đổi hàng (换货), giảm giá (降价), hoặc phạt vi phạm hợp đồng (违约金).",
        "example": {
          "zh": "工厂同意赔偿我们10%的货款作为质量问题的补偿。",
          "vi": "Nhà máy đồng ý bồi thường 10% tiền hàng như khoản bù đắp vấn đề chất lượng."
        }
      },
      {
        "num": 3,
        "hanzi": "退货",
        "pinyin": "tuì huò",
        "vi": "trả hàng lại",
        "explanation": "Hành động trả lại hàng hóa cho người bán khi hàng không đạt tiêu chuẩn hoặc không đúng với đơn hàng. Trong thương mại quốc tế, 退货 rất tốn kém (chi phí vận chuyển ngược) và phức tạp, nên thường chỉ là biện pháp cuối cùng.",
        "example": {
          "zh": "如果协商不成，我们将考虑退货并要求全额退款。",
          "vi": "Nếu đàm phán không thành, chúng tôi sẽ xem xét trả hàng và yêu cầu hoàn tiền toàn bộ."
        }
      },
      {
        "num": 4,
        "hanzi": "换货",
        "pinyin": "huàn huò",
        "vi": "đổi hàng",
        "explanation": "Nhà cung cấp thay thế hàng lỗi bằng hàng mới đạt tiêu chuẩn. Thường được ưu tiên hơn 退货 vì giúp người mua nhận được hàng mà không phải chờ hoàn tiền và tìm nhà cung cấp mới.",
        "example": {
          "zh": "我们希望换货而不是退款，因为时间紧迫。",
          "vi": "Chúng tôi muốn đổi hàng thay vì hoàn tiền vì thời gian gấp."
        }
      },
      {
        "num": 5,
        "hanzi": "扣款",
        "pinyin": "kòu kuǎn",
        "vi": "khấu trừ tiền / giữ lại một phần tiền",
        "explanation": "Người mua giữ lại một phần tiền thanh toán như hình thức bồi thường cho hàng lỗi hoặc chậm giao. Thường là 扣除 một tỷ lệ phần trăm nhất định từ 尾款. Ví dụ: hàng lỗi 5% → khấu trừ 5% từ khoản thanh toán cuối.",
        "example": {
          "zh": "由于这批货有8%的不合格品，我们将在尾款中扣除相应金额。",
          "vi": "Do lô hàng này có 8% hàng lỗi, chúng tôi sẽ khấu trừ số tiền tương ứng từ khoản thanh toán cuối."
        }
      },
      {
        "num": 6,
        "hanzi": "责任方",
        "pinyin": "zérèn fāng",
        "vi": "bên có trách nhiệm / bên lỗi",
        "explanation": "Bên phải chịu trách nhiệm về vấn đề phát sinh. Xác định 责任方 là bước đầu tiên trong mọi tranh chấp. Nhà máy thường lập luận rằng vấn đề do thiết kế của khách, còn khách hàng lập luận do sản xuất của nhà máy — đây là điểm tranh cãi phổ biến nhất.",
        "example": {
          "zh": "首先我们需要确认这次质量问题的责任方是谁。",
          "vi": "Trước tiên chúng ta cần xác nhận bên có trách nhiệm về vấn đề chất lượng lần này là ai."
        }
      },
      {
        "num": 7,
        "hanzi": "证据",
        "pinyin": "zhèngjù",
        "vi": "bằng chứng",
        "explanation": "Tài liệu hoặc vật chứng chứng minh vấn đề hoặc vi phạm. Trong tranh chấp thương mại, 证据 thường bao gồm: ảnh/video hàng lỗi, báo cáo kiểm định, hợp đồng, email trao đổi, mẫu xác nhận. Không có 证据 = không có cơ sở 索赔.",
        "example": {
          "zh": "请提供具体的证据，包括照片和第三方检测报告。",
          "vi": "Vui lòng cung cấp bằng chứng cụ thể, bao gồm ảnh và báo cáo kiểm định bên thứ ba."
        }
      },
      {
        "num": 8,
        "hanzi": "协商解决",
        "pinyin": "xiéshāng jiějué",
        "vi": "giải quyết thông qua đàm phán",
        "explanation": "Cách xử lý tranh chấp ưu tiên trong thương mại — hai bên tự đàm phán để đạt thỏa thuận mà không cần đến trọng tài hoặc tòa án. Nhanh hơn, rẻ hơn, và giữ được quan hệ tốt hơn. Khoảng 95% tranh chấp thương mại được giải quyết bằng 协商.",
        "example": {
          "zh": "我们希望通过协商解决这个问题，避免走仲裁程序。",
          "vi": "Chúng tôi hy vọng giải quyết vấn đề này qua đàm phán, tránh phải đi vào trình tự trọng tài."
        }
      },
      {
        "num": 9,
        "hanzi": "违约金",
        "pinyin": "wéiyuē jīn",
        "vi": "phạt vi phạm hợp đồng",
        "explanation": "Khoản tiền phạt được quy định trong hợp đồng mà bên vi phạm phải trả. Ví dụ: chậm giao hàng 1 ngày phạt 0.1% giá trị hợp đồng. 违约金 cần được ghi rõ tỷ lệ và điều kiện trong hợp đồng — không có điều khoản này thì khó đòi được.",
        "example": {
          "zh": "合同里规定迟延交货每天罚款0.1%，请参考合同条款。",
          "vi": "Hợp đồng quy định chậm giao hàng mỗi ngày phạt 0.1%, vui lòng tham khảo điều khoản hợp đồng."
        }
      },
      {
        "num": 10,
        "hanzi": "仲裁",
        "pinyin": "zhòngcái",
        "vi": "trọng tài",
        "explanation": "Phương thức giải quyết tranh chấp thông qua một bên thứ ba độc lập (trọng tài viên), phán quyết có giá trị pháp lý. Nhanh hơn và rẻ hơn kiện tụng tòa án. Hợp đồng thương mại quốc tế thường chỉ định trọng tài CIETAC (TQ) hoặc ICC (quốc tế).",
        "example": {
          "zh": "如果协商不成，双方同意提交CIETAC仲裁解决。",
          "vi": "Nếu đàm phán không thành, hai bên đồng ý đưa ra trọng tài CIETAC giải quyết."
        }
      }
    ],
    "dialogue": {
      "context": "Cuộc gọi khẩn sau khi khách hàng Mỹ trả lại hàng trên Amazon vì chất lượng kém. Buyer VN đang khiếu nại nhà máy TQ. Bạn là phiên dịch.",
      "characters": [
        {
          "name": "工厂销售经理老张 (Lǎo Zhāng)",
          "role": "Giám đốc kinh doanh nhà máy TQ"
        },
        {
          "name": "Anh Bình",
          "role": "Giám đốc công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "Anh Bình",
          "zh": "张经理，我们有个严重的问题需要跟您谈。上个月收到的那批货，在亚马逊上已经产生了大量的差评，退货率高达15%，给我们造成了很大的损失。",
          "vi": "Giám đốc Trương, chúng tôi có vấn đề nghiêm trọng cần nói chuyện với anh. Lô hàng nhận tháng trước, trên Amazon đã phát sinh rất nhiều đánh giá xấu, tỷ lệ hoàn trả lên đến 15%, gây ra tổn thất lớn cho chúng tôi."
        },
        {
          "speaker": "老张",
          "zh": "我听说了，对此我们深感抱歉。能详细说一下主要是什么问题吗？",
          "vi": "Tôi có nghe, chúng tôi rất xin lỗi về điều này. Anh có thể nói chi tiết vấn đề chủ yếu là gì không?"
        },
        {
          "speaker": "Anh Bình",
          "zh": "客户反映产品收到后有明显瑕疵，主要是表面油漆脱落，还有一些产品尺寸跟亚马逊页面上的描述不符。我这边有照片和客户投诉记录可以作为证据。",
          "vi": "Khách hàng phản ánh nhận sản phẩm có khuyết tật rõ ràng, chủ yếu là bề mặt sơn bong tróc, và một số sản phẩm kích thước không khớp với mô tả trên trang Amazon. Phía tôi có ảnh và hồ sơ khiếu nại của khách hàng làm bằng chứng."
        },
        {
          "speaker": "老张",
          "zh": "照片能发给我看吗？我们这边先确认一下是什么原因导致的。",
          "vi": "Anh có thể gửi ảnh cho tôi xem không? Phía chúng tôi xác nhận trước nguyên nhân là gì."
        },
        {
          "speaker": "Anh Bình",
          "zh": "已经发到您邮箱了。但是我们现在已经很确定这是生产质量问题，不是我们的问题。我们正式提出索赔，要求赔偿我们的直接损失，包括退货运费和亚马逊扣除的费用，总计大概5000美元。",
          "vi": "Đã gửi vào email anh rồi. Nhưng hiện tại chúng tôi đã khá chắc chắn đây là vấn đề chất lượng sản xuất, không phải lỗi của chúng tôi. Chúng tôi chính thức khiếu nại, yêu cầu bồi thường thiệt hại trực tiếp, bao gồm phí hoàn hàng và khoản Amazon trừ, tổng cộng khoảng 5000 đô Mỹ."
        },
        {
          "speaker": "老张",
          "zh": "我理解您的情况，但5000美元我们需要先核实损失明细。能否提供一下亚马逊的退货数据和扣款记录？",
          "vi": "Tôi hiểu tình huống của anh, nhưng 5000 đô chúng tôi cần xác minh chi tiết thiệt hại trước. Anh có thể cung cấp dữ liệu hoàn hàng và hồ sơ trừ tiền từ Amazon không?"
        },
        {
          "speaker": "Anh Bình",
          "zh": "没问题，我把所有证据整理好发给您。但我希望您明白，我们在亚马逊上的排名也受到了影响，间接损失更大。我们希望通过协商解决，不想走仲裁。",
          "vi": "Không vấn đề, tôi sẽ tổng hợp toàn bộ bằng chứng gửi cho anh. Nhưng mong anh hiểu, thứ hạng của chúng tôi trên Amazon cũng bị ảnh hưởng, thiệt hại gián tiếp còn lớn hơn. Chúng tôi hy vọng giải quyết qua đàm phán, không muốn đi đến trọng tài."
        },
        {
          "speaker": "老张",
          "zh": "我们也不希望走到那一步，我们重视这段合作关系。这样吧，我们承认这批货存在质量问题，我们愿意赔偿直接损失。至于金额，等我收到所有证据之后，三个工作日内给您一个正式的赔偿方案。",
          "vi": "Chúng tôi cũng không muốn đến nước đó, chúng tôi coi trọng mối quan hệ hợp tác này. Thế này nhé, chúng tôi thừa nhận lô hàng này có vấn đề chất lượng, chúng tôi sẵn sàng bồi thường thiệt hại trực tiếp. Về số tiền cụ thể, chờ tôi nhận đầy đủ bằng chứng, trong 3 ngày làm việc sẽ đưa ra phương án bồi thường chính thức."
        },
        {
          "speaker": "Anh Bình",
          "zh": "好，我接受这个时间安排。另外，对于后续的订单，我们需要加强验货，避免再次出现这种情况。",
          "vi": "Tốt, tôi chấp nhận thời gian đó. Ngoài ra, với các đơn hàng tiếp theo, chúng tôi cần tăng cường kiểm hàng để tránh tình trạng này tái diễn."
        },
        {
          "speaker": "老张",
          "zh": "完全同意，我们会改进生产流程，并且支持您派员驻厂验货，确保以后的货物质量达到您的标准。",
          "vi": "Hoàn toàn đồng ý, chúng tôi sẽ cải thiện quy trình sản xuất, và hỗ trợ anh cử người kiểm hàng tại nhà máy, đảm bảo chất lượng hàng sau này đáp ứng tiêu chuẩn của anh."
        }
      ]
    },
    "notes": [
      {
        "title": "Tỷ lệ hoàn hàng Amazon cao: hậu quả nghiêm trọng",
        "body": "Tỷ lệ hoàn hàng (return rate) trên Amazon vượt 5–8% đã là dấu hiệu nghiêm trọng. Nếu vượt 10–15%, Amazon có thể tạm khóa listing hoặc tài khoản. Khi khiếu nại nhà máy về vấn đề liên quan đến Amazon, cần đưa ra dữ liệu cụ thể (return rate, số lượng review xấu, số tiền Amazon trừ) thay vì chỉ nói chung chung."
      },
      {
        "title": "Trình tự xử lý khiếu nại hiệu quả",
        "body": "Bước 1: Thu thập bằng chứng (ảnh, video, báo cáo kiểm định, dữ liệu return). Bước 2: Thông báo chính thức bằng văn bản (email với đầy đủ thông tin). Bước 3: Đàm phán trực tiếp. Bước 4: Nếu không thành — trọng tài hoặc tòa án. Đừng bỏ qua bước nào, đặc biệt bước 1 và 2 vì thiếu bằng chứng bằng văn bản sẽ mất lợi thế."
      },
      {
        "title": "Phân biệt thiệt hại trực tiếp và gián tiếp",
        "body": "直接损失 (thiệt hại trực tiếp): tiền đã mất cụ thể — phí hoàn hàng, khoản Amazon trừ, tiền hàng lỗi. Nhà máy thường đồng ý bồi thường phần này. 间接损失 (thiệt hại gián tiếp): mất doanh thu tương lai, ảnh hưởng thứ hạng, mất khách hàng. Rất khó đòi bồi thường phần này vì khó chứng minh."
      },
      {
        "title": "Giữ quan hệ khi khiếu nại",
        "body": "Trong hội thoại, cả hai bên đều thể hiện muốn giữ quan hệ hợp tác. Đây là cách tiếp cận đúng đắn — khiếu nại quyết liệt nhưng không đối đầu, luôn để ngỏ cửa đàm phán. Khi phiên dịch, cần dịch đúng cả phần cứng rắn lẫn phần mềm mỏng của từng bên."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "索赔 cần những gì để có hiệu lực?",
          "options": {
            "A": "Chỉ cần nói miệng với nhà cung cấp",
            "B": "Phải có cơ sở bằng chứng và trong thời hạn quy định",
            "C": "Chỉ cần có hợp đồng",
            "D": "Chỉ cần báo cáo kiểm định"
          }
        },
        {
          "num": 2,
          "q": "Phương án 赔偿 nào thường được người mua ưu tiên hơn khi thời gian gấp?",
          "options": {
            "A": "退款 (hoàn tiền)",
            "B": "换货 (đổi hàng mới)",
            "C": "仲裁 (trọng tài)",
            "D": "降价 (giảm giá đơn hàng tiếp)"
          }
        },
        {
          "num": 3,
          "q": "扣款 trong khiếu nại thương mại có nghĩa là gì?",
          "options": {
            "A": "Người mua từ chối thanh toán hoàn toàn",
            "B": "Người mua khấu trừ một phần tiền từ khoản thanh toán còn lại",
            "C": "Nhà máy giảm giá cho đơn hàng tiếp theo",
            "D": "Ngân hàng phong tỏa tài khoản"
          }
        },
        {
          "num": 4,
          "q": "Cách giải quyết tranh chấp nào được ưu tiên đầu tiên?",
          "options": {
            "A": "Kiện ra tòa án",
            "B": "Trọng tài CIETAC",
            "C": "Đàm phán trực tiếp (协商解决)",
            "D": "Thông báo trên mạng xã hội"
          }
        },
        {
          "num": 5,
          "q": "Trọng tài (仲裁) khác kiện tụng tòa án thế nào?",
          "options": {
            "A": "Trọng tài chậm hơn và đắt hơn",
            "B": "Trọng tài nhanh hơn, rẻ hơn, phán quyết vẫn có giá trị pháp lý",
            "C": "Trọng tài không có giá trị pháp lý",
            "D": "Trọng tài chỉ dùng cho tranh chấp nội địa"
          }
        },
        {
          "num": 6,
          "q": "违约金 được áp dụng khi nào?",
          "options": {
            "A": "Khi hàng hóa bị hư hỏng trong vận chuyển",
            "B": "Khi một bên vi phạm điều khoản hợp đồng đã thỏa thuận",
            "C": "Khi giá nguyên liệu tăng",
            "D": "Khi tỷ giá biến động"
          }
        },
        {
          "num": 7,
          "q": "Bằng chứng nào mạnh nhất khi khiếu nại về chất lượng?",
          "options": {
            "A": "Email phàn nàn từ khách hàng cuối",
            "B": "Ảnh hàng lỗi kèm báo cáo kiểm định bên thứ ba và hợp đồng",
            "C": "Tin nhắn WeChat",
            "D": "Lời khai miệng của nhân viên kho"
          }
        },
        {
          "num": 8,
          "q": "退货 trong thương mại quốc tế thường là biện pháp nào?",
          "options": {
            "A": "Biện pháp đầu tiên và ưu tiên nhất",
            "B": "Biện pháp cuối cùng vì tốn kém và phức tạp",
            "C": "Biện pháp duy nhất có giá trị pháp lý",
            "D": "Biện pháp không cần có hợp đồng"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "协商解决 là phương pháp xử lý tranh chấp được ưu tiên nhất trong thương mại quốc tế."
        },
        {
          "num": 10,
          "q": "Thiệt hại gián tiếp như mất thứ hạng Amazon dễ đòi bồi thường hơn thiệt hại trực tiếp."
        },
        {
          "num": 11,
          "q": "Không có bằng chứng bằng văn bản thì rất khó thắng trong tranh chấp thương mại."
        },
        {
          "num": 12,
          "q": "违约金 chỉ có hiệu lực nếu được ghi rõ tỷ lệ và điều kiện trong hợp đồng."
        },
        {
          "num": 13,
          "q": "Tỷ lệ hoàn hàng 15% trên Amazon là mức bình thường, không đáng lo."
        },
        {
          "num": 14,
          "q": "Khi khiếu nại, cần khởi kiện ngay lập tức để thể hiện sự nghiêm túc."
        }
      ],
      "fillblank": {
        "wordbank": [
          "索赔",
          "赔偿",
          "扣款",
          "违约金",
          "证据",
          "协商解决"
        ],
        "items": [
          {
            "num": 15,
            "q": "由于质量问题，我们正式提出____，要求____直接损失5000美元。"
          },
          {
            "num": 16,
            "q": "请提供具体的____，包括照片、检测报告和退货数据。"
          },
          {
            "num": 17,
            "q": "合同规定迟延交货每天____0.1%，请注意交货时间。"
          },
          {
            "num": 18,
            "q": "我们希望通过____处理这个问题，不想走仲裁程序。"
          },
          {
            "num": 19,
            "q": "这批货有10%不合格品，我们将在尾款中____相应金额。"
          },
          {
            "num": 20,
            "q": "工厂同意____我们的直接损失，具体金额三天内确认。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "由于这批货严重的质量问题，我们在亚马逊上的退货率高达12%，正式要求赔偿直接损失。"
        },
        {
          "num": 22,
          "q": "请在三个工作日内提供正式的赔偿方案，否则我们将考虑提交仲裁。"
        },
        {
          "num": 23,
          "q": "我们愿意协商解决，可以接受换货，但需要在两周内发出替换货物。"
        },
        {
          "num": 24,
          "q": "合同第8条规定，质量问题导致的损失由责任方全额赔偿，请参考合同条款。"
        },
        {
          "num": 25,
          "q": "我们重视双方的合作关系，这次愿意承担50%的损失，希望双方各退一步。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Chúng tôi có đầy đủ bằng chứng chứng minh lô hàng này có vấn đề chất lượng do sản xuất."
        },
        {
          "num": 27,
          "q": "Tổng thiệt hại trực tiếp của chúng tôi là 8000 đô, bao gồm phí hoàn hàng và khoản Amazon trừ."
        },
        {
          "num": 28,
          "q": "Nếu hai bên không thể đàm phán thành công, chúng tôi sẽ đệ trình lên trọng tài theo điều khoản hợp đồng."
        },
        {
          "num": 29,
          "q": "Chúng tôi muốn đổi hàng thay vì hoàn tiền, cần giao hàng mới trong vòng 3 tuần."
        },
        {
          "num": 30,
          "q": "Để tránh tái diễn vấn đề này, chúng tôi đề nghị tăng cường kiểm định chất lượng cho tất cả đơn hàng tiếp theo."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "C",
        "5": "B",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": false,
        "11": true,
        "12": true,
        "13": false,
        "14": false
      },
      "fillblank": {
        "15": [
          "索赔",
          "赔偿"
        ],
        "16": "证据",
        "17": "违约金",
        "18": "协商解决",
        "19": "扣款",
        "20": "赔偿"
      },
      "zh2vi": {
        "21": "Do vấn đề chất lượng nghiêm trọng của lô hàng này, tỷ lệ hoàn hàng của chúng tôi trên Amazon lên đến 12%, chính thức yêu cầu bồi thường thiệt hại trực tiếp.",
        "22": "Vui lòng đưa ra phương án bồi thường chính thức trong 3 ngày làm việc, nếu không chúng tôi sẽ xem xét đệ trình trọng tài.",
        "23": "Chúng tôi sẵn sàng đàm phán, có thể chấp nhận đổi hàng, nhưng cần giao hàng thay thế trong 2 tuần.",
        "24": "Điều 8 hợp đồng quy định thiệt hại do vấn đề chất lượng gây ra do bên có trách nhiệm bồi thường toàn bộ, vui lòng tham khảo điều khoản hợp đồng.",
        "25": "Chúng tôi coi trọng quan hệ hợp tác hai bên, lần này sẵn sàng chịu 50% thiệt hại, mong hai bên cùng nhượng bộ một bước."
      },
      "vi2zh": {
        "26": "我们有充分证据证明这批货存在生产质量问题。",
        "27": "我们的直接损失总计8000美元，包括退货运费和亚马逊扣除的费用。",
        "28": "如果双方无法通过谈判解决，我们将按合同条款提交仲裁。",
        "29": "我们希望换货而不是退款，需要在三周内发出新货。",
        "30": "为避免此类问题再次发生，我们建议对后续所有订单加强质量检验。"
      }
    }
  },
  {
    "num": 9,
    "title": "HỢP ĐỒNG & ĐIỀU KHOẢN PHÁP LÝ",
    "date": "5/6",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "合同",
        "pinyin": "hétong",
        "vi": "hợp đồng",
        "explanation": "Văn bản pháp lý ràng buộc giữa hai bên, ghi rõ quyền và nghĩa vụ của mỗi bên. Trong thương mại quốc tế, hợp đồng thường bằng tiếng Anh hoặc song ngữ Trung-Anh. Hợp đồng bằng miệng hoặc qua chat không có giá trị pháp lý đủ mạnh khi xảy ra tranh chấp.",
        "example": {
          "zh": "请起草一份采购合同，我们明天签字。",
          "vi": "Vui lòng soạn thảo một hợp đồng mua bán, ngày mai chúng ta ký."
        }
      },
      {
        "num": 2,
        "hanzi": "甲方 / 乙方",
        "pinyin": "jiǎ fāng / yǐ fāng",
        "vi": "bên A / bên B",
        "explanation": "Cách gọi hai bên trong hợp đồng TQ. 甲方 thường là bên mua hoặc bên thuê dịch vụ, 乙方 là bên bán hoặc bên cung cấp. Khi đọc hợp đồng TQ, phải xác định ngay mình là 甲方 hay 乙方 để hiểu đúng quyền và nghĩa vụ.",
        "example": {
          "zh": "甲方负责验货，乙方负责按时交货。",
          "vi": "Bên A chịu trách nhiệm kiểm hàng, bên B chịu trách nhiệm giao hàng đúng hạn."
        }
      },
      {
        "num": 3,
        "hanzi": "条款",
        "pinyin": "tiáokuǎn",
        "vi": "điều khoản",
        "explanation": "Từng mục cụ thể trong hợp đồng quy định quyền, nghĩa vụ, hoặc điều kiện. Hợp đồng thương mại quốc tế thường có các điều khoản về: sản phẩm, giá, thanh toán, giao hàng, chất lượng, bảo hành, vi phạm, và giải quyết tranh chấp.",
        "example": {
          "zh": "请仔细阅读合同第五条的条款，关于质量保证的规定。",
          "vi": "Vui lòng đọc kỹ điều khoản trong điều 5 hợp đồng, quy định về đảm bảo chất lượng."
        }
      },
      {
        "num": 4,
        "hanzi": "签订合同",
        "pinyin": "qiāndìng hétong",
        "vi": "ký kết hợp đồng",
        "explanation": "Hành động chính thức ký tên và đóng dấu vào hợp đồng để nó có hiệu lực pháp lý. Trong thực tế TQ, dấu công ty (公章) quan trọng không kém chữ ký — hợp đồng thiếu dấu công ty có thể bị tranh cãi về hiệu lực.",
        "example": {
          "zh": "双方确认条款无误后，明天正式签订合同。",
          "vi": "Hai bên xác nhận các điều khoản không có sai sót, ngày mai chính thức ký kết hợp đồng."
        }
      },
      {
        "num": 5,
        "hanzi": "有效期",
        "pinyin": "yǒuxiào qī",
        "vi": "thời hạn hiệu lực",
        "explanation": "Khoảng thời gian hợp đồng có giá trị ràng buộc pháp lý. Sau thời hạn này, hợp đồng hết hiệu lực trừ khi được gia hạn. Quan trọng cần theo dõi để gia hạn kịp thời với đối tác lâu dài.",
        "example": {
          "zh": "这份合同的有效期是一年，到期后自动续签。",
          "vi": "Hợp đồng này có thời hạn một năm, hết hạn tự động gia hạn."
        }
      },
      {
        "num": 6,
        "hanzi": "违约",
        "pinyin": "wéiyuē",
        "vi": "vi phạm hợp đồng",
        "explanation": "Hành động không thực hiện đúng hoặc không thực hiện các nghĩa vụ đã ký kết trong hợp đồng. Có thể là vi phạm về thời gian (chậm giao), chất lượng (hàng không đạt tiêu chuẩn), hoặc thanh toán (chậm trả). Hậu quả thường là phạt 违约金 hoặc bồi thường thiệt hại.",
        "example": {
          "zh": "如果一方违约，须承担合同规定的违约责任。",
          "vi": "Nếu một bên vi phạm hợp đồng, phải chịu trách nhiệm vi phạm theo quy định hợp đồng."
        }
      },
      {
        "num": 7,
        "hanzi": "不可抗力",
        "pinyin": "bùkě kànglì",
        "vi": "bất khả kháng (Force Majeure)",
        "explanation": "Những sự kiện nằm ngoài tầm kiểm soát của các bên — thiên tai, chiến tranh, dịch bệnh, lệnh cấm xuất khẩu của chính phủ. Khi xảy ra 不可抗力, bên bị ảnh hưởng có thể được miễn hoặc giảm trách nhiệm vi phạm hợp đồng. COVID-19 là ví dụ điển hình về 不可抗力 được viện dẫn rộng rãi.",
        "example": {
          "zh": "由于新冠疫情属于不可抗力，工厂申请延迟交货不承担违约责任。",
          "vi": "Do đại dịch COVID-19 thuộc trường hợp bất khả kháng, nhà máy xin phép trễ giao hàng không chịu trách nhiệm vi phạm."
        }
      },
      {
        "num": 8,
        "hanzi": "知识产权",
        "pinyin": "zhīshi chǎnquán",
        "vi": "sở hữu trí tuệ (IP)",
        "explanation": "Quyền sở hữu đối với thiết kế, thương hiệu, patent, bí quyết kỹ thuật. Khi làm OEM/ODM, điều khoản 知识产权 cực kỳ quan trọng — cần quy định rõ ai sở hữu thiết kế, nhà máy có được sản xuất cho bên khác không. Nhiều tranh chấp lớn trong ngành xuất phát từ thiếu điều khoản 知识产权.",
        "example": {
          "zh": "合同中需要明确知识产权归属，设计专属于我方，工厂不得向第三方提供。",
          "vi": "Trong hợp đồng cần ghi rõ quy thuộc sở hữu trí tuệ, thiết kế thuộc về chúng tôi, nhà máy không được cung cấp cho bên thứ ba."
        }
      },
      {
        "num": 9,
        "hanzi": "保密协议",
        "pinyin": "bǎomì xiéyì",
        "vi": "thỏa thuận bảo mật (NDA)",
        "explanation": "Non-Disclosure Agreement — hợp đồng cam kết bảo mật thông tin được chia sẻ giữa hai bên. Trong làm việc với nhà máy TQ, NDA quan trọng khi chia sẻ thiết kế sản phẩm, công thức, hoặc danh sách khách hàng. Tuy nhiên, thực thi NDA ở TQ có thể gặp khó khăn nếu xảy ra vi phạm.",
        "example": {
          "zh": "在分享产品设计之前，请先签署保密协议。",
          "vi": "Trước khi chia sẻ thiết kế sản phẩm, vui lòng ký thỏa thuận bảo mật trước."
        }
      },
      {
        "num": 10,
        "hanzi": "争议解决",
        "pinyin": "zhēngyì jiějué",
        "vi": "giải quyết tranh chấp",
        "explanation": "Điều khoản trong hợp đồng quy định phương thức xử lý khi có bất đồng: đàm phán, hòa giải, trọng tài, hoặc tòa án. Điều khoản này cũng quy định luật áp dụng (TQ, VN, hay quốc tế) và địa điểm giải quyết. Đây là điều khoản nhiều người bỏ qua nhưng cực kỳ quan trọng khi có tranh chấp thực sự.",
        "example": {
          "zh": "合同规定，争议提交中国国际经济贸易仲裁委员会（CIETAC）仲裁解决。",
          "vi": "Hợp đồng quy định tranh chấp đưa ra trọng tài CIETAC để giải quyết."
        }
      }
    ],
    "dialogue": {
      "context": "Hai bên đang xem xét bản thảo hợp đồng lần cuối trước khi ký. Luật sư hoặc người có kinh nghiệm pháp lý đại diện cho mỗi bên. Bạn là phiên dịch.",
      "characters": [
        {
          "name": "法务王律师 (Wáng lǜshī)",
          "role": "Cố vấn pháp lý nhà máy TQ"
        },
        {
          "name": "Anh Dũng",
          "role": "Giám đốc công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "王律师",
          "zh": "您好，我们已经把合同草案发给您了，请问您这边有什么需要修改的地方吗？",
          "vi": "Xin chào, chúng tôi đã gửi bản thảo hợp đồng cho anh rồi, phía anh có chỗ nào cần chỉnh sửa không?"
        },
        {
          "speaker": "Anh Dũng",
          "zh": "有几个地方我们想讨论一下。第一，关于知识产权的条款，合同里没有明确规定产品设计的归属，我们希望加上\"所有产品设计专属于甲方，乙方不得将设计提供给任何第三方\"。",
          "vi": "Có một vài điểm chúng tôi muốn bàn. Thứ nhất, về điều khoản sở hữu trí tuệ, hợp đồng chưa ghi rõ quy thuộc thiết kế sản phẩm, chúng tôi muốn thêm vào \"toàn bộ thiết kế sản phẩm thuộc độc quyền của bên A, bên B không được cung cấp thiết kế cho bất kỳ bên thứ ba nào\"."
        },
        {
          "speaker": "王律师",
          "zh": "这个没问题，我们可以加上这一条。有时候我们也会跟其他客户做类似产品，但如果是您的专有设计，我们同意保密。是否需要同时签一份独立的保密协议？",
          "vi": "Điểm này không vấn đề, chúng tôi có thể thêm vào. Đôi khi chúng tôi cũng làm sản phẩm tương tự cho khách hàng khác, nhưng nếu là thiết kế độc quyền của anh, chúng tôi đồng ý bảo mật. Có cần ký thêm một thỏa thuận bảo mật riêng không?"
        },
        {
          "speaker": "Anh Dũng",
          "zh": "是的，我们需要一份NDA，在分享最终设计方案之前签好。第二个问题，关于违约金的条款，目前合同写的是迟延交货每天罚款0.05%，我们希望提高到0.1%。",
          "vi": "Có, chúng tôi cần một NDA, ký trước khi chia sẻ phương án thiết kế cuối cùng. Vấn đề thứ hai, về điều khoản phạt vi phạm, hợp đồng hiện ghi phạt 0,05% mỗi ngày chậm giao, chúng tôi muốn tăng lên 0,1%."
        },
        {
          "speaker": "王律师",
          "zh": "0.1%有点高，我们的生产确实有时候会受到供应链影响，能不能区分一下，不可抗力情况下不罚款，正常情况下的延误才罚款？",
          "vi": "0,1% hơi cao, sản xuất của chúng tôi đôi khi bị ảnh hưởng bởi chuỗi cung ứng, có thể phân biệt không — bất khả kháng thì không phạt, chỉ phạt khi trễ trong điều kiện bình thường?"
        },
        {
          "speaker": "Anh Dũng",
          "zh": "不可抗力免责是合理的，但不可抗力的定义需要在合同里写清楚，不能太宽泛。比如供应商断货，不能算不可抗力，因为你们应该有备货。",
          "vi": "Miễn trách nhiệm khi bất khả kháng là hợp lý, nhưng định nghĩa bất khả kháng cần ghi rõ trong hợp đồng, không thể quá rộng. Ví dụ nhà cung cấp đứt hàng không thể tính là bất khả kháng, vì các anh nên có dự trữ hàng."
        },
        {
          "speaker": "王律师",
          "zh": "这个建议合理，我们来修改一下不可抗力的定义范围。第三个问题是争议解决，目前写的是中国法律，在深圳仲裁，我们是否可以改成在香港仲裁？香港的法律体系对外资企业更透明。",
          "vi": "Đề xuất này hợp lý, chúng tôi sẽ chỉnh sửa phạm vi định nghĩa bất khả kháng. Vấn đề thứ ba là giải quyết tranh chấp, hiện ghi là luật TQ, trọng tài tại Thâm Quyến, có thể đổi sang trọng tài tại Hồng Kông không? Hệ thống pháp lý Hồng Kông minh bạch hơn với doanh nghiệp nước ngoài."
        },
        {
          "speaker": "王律师",
          "zh": "香港仲裁费用比较高，我们这边有点顾虑。能不能改成新加坡？新加坡仲裁中心（SIAC）在国际上也很受认可。",
          "vi": "Phí trọng tài Hồng Kông khá cao, phía chúng tôi có chút lo ngại. Có thể đổi sang Singapore không? Trung tâm trọng tài Singapore (SIAC) cũng được quốc tế công nhận rộng rãi."
        },
        {
          "speaker": "Anh Dũng",
          "zh": "新加坡也可以接受，比中国大陆的仲裁对我们来说更公平一些。好，那我们先把这些修改意见整理成书面文件，你们更新合同草案后，我们再最终确认签字。",
          "vi": "Singapore cũng chấp nhận được, so với trọng tài đại lục TQ thì công bằng hơn với phía chúng tôi. Tốt, vậy chúng ta tổng hợp các điểm chỉnh sửa này thành văn bản, các anh cập nhật bản thảo hợp đồng xong, chúng tôi xác nhận lần cuối rồi ký."
        },
        {
          "speaker": "王律师",
          "zh": "好的，我们一周内给您更新版本，请确认后我们安排双方签字。",
          "vi": "Được, trong một tuần chúng tôi gửi bản cập nhật cho anh, sau khi xác nhận chúng tôi sắp xếp hai bên ký."
        }
      ]
    },
    "notes": [
      {
        "title": "Dấu công ty (公章) quan trọng như chữ ký",
        "body": "Ở TQ, hợp đồng có chữ ký nhưng thiếu dấu đỏ công ty (公章) có thể bị tranh cãi về hiệu lực. Luôn yêu cầu bản có đủ chữ ký và dấu công ty. Khi nhận hợp đồng scan, kiểm tra xem có đủ cả hai không."
      },
      {
        "title": "Điều khoản 知识产权: đừng bao giờ bỏ qua",
        "body": "Nhiều buyer mới bỏ qua điều khoản IP vì nghĩ không quan trọng. Thực tế rất phổ biến trường hợp nhà máy TQ sản xuất hàng y chang cho đối thủ cạnh tranh của bạn sau khi biết thiết kế. NDA và điều khoản IP rõ ràng là lớp bảo vệ tối thiểu."
      },
      {
        "title": "Bất khả kháng: định nghĩa càng hẹp càng tốt cho bên mua",
        "body": "Nhà máy TQ có xu hướng định nghĩa 不可抗力 rộng để thoát trách nhiệm chậm giao. Bên mua nên yêu cầu liệt kê cụ thể các trường hợp được coi là bất khả kháng (thiên tai, chiến tranh, lệnh cấm chính phủ) và loại trừ các trường hợp như: thiếu nguyên liệu, máy hỏng, thiếu nhân công."
      },
      {
        "title": "Chọn địa điểm trọng tài: ảnh hưởng lớn đến kết quả",
        "body": "Trọng tài tại TQ có xu hướng có lợi hơn cho bên TQ. Singapore (SIAC) và Hồng Kông (HKIAC) được coi là trung lập hơn và phán quyết dễ thi hành quốc tế hơn. ICC (Paris) là lựa chọn quốc tế nhất nhưng đắt nhất."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Trong hợp đồng TQ, 甲方 thường là ai?",
          "options": {
            "A": "Bên bán / bên cung cấp",
            "B": "Bên mua / bên thuê dịch vụ",
            "C": "Bên trung gian",
            "D": "Cơ quan nhà nước"
          }
        },
        {
          "num": 2,
          "q": "Điều khoản 知识产权 quan trọng vì lý do gì?",
          "options": {
            "A": "Yêu cầu bắt buộc của hải quan",
            "B": "Bảo vệ thiết kế và thương hiệu của người mua, tránh nhà máy bán cho đối thủ",
            "C": "Giảm chi phí sản xuất",
            "D": "Tăng thời hạn bảo hành"
          }
        },
        {
          "num": 3,
          "q": "不可抗力 gồm những trường hợp nào?",
          "options": {
            "A": "Nhà máy thiếu nhân công",
            "B": "Thiên tai, chiến tranh, lệnh cấm của chính phủ",
            "C": "Nhà cung cấp đứt hàng",
            "D": "Máy móc hỏng hóc"
          }
        },
        {
          "num": 4,
          "q": "Hợp đồng TQ cần có gì để có hiệu lực đầy đủ?",
          "options": {
            "A": "Chỉ cần chữ ký giám đốc",
            "B": "Chữ ký và dấu công ty (公章)",
            "C": "Chỉ cần dấu công ty",
            "D": "Xác nhận từ cơ quan nhà nước"
          }
        },
        {
          "num": 5,
          "q": "Địa điểm trọng tài nào được coi là trung lập nhất cho doanh nghiệp nước ngoài?",
          "options": {
            "A": "Thâm Quyến",
            "B": "Bắc Kinh",
            "C": "Singapore hoặc Hồng Kông",
            "D": "Hà Nội"
          }
        },
        {
          "num": 6,
          "q": "NDA (保密协议) nên được ký vào thời điểm nào?",
          "options": {
            "A": "Sau khi đã chia sẻ thiết kế",
            "B": "Trước khi chia sẻ bất kỳ thông tin bảo mật nào",
            "C": "Sau khi ký hợp đồng chính",
            "D": "Chỉ cần khi đặt hàng số lượng lớn"
          }
        },
        {
          "num": 7,
          "q": "违约 trong hợp đồng bao gồm những vi phạm nào?",
          "options": {
            "A": "Chỉ vi phạm về chất lượng",
            "B": "Chỉ vi phạm về thời hạn giao hàng",
            "C": "Mọi vi phạm điều khoản đã ký: thời gian, chất lượng, thanh toán...",
            "D": "Chỉ vi phạm về giá cả"
          }
        },
        {
          "num": 8,
          "q": "Bên mua nên định nghĩa 不可抗力 thế nào trong hợp đồng?",
          "options": {
            "A": "Càng rộng càng tốt để linh hoạt",
            "B": "Càng hẹp và cụ thể càng tốt để tránh nhà máy lạm dụng",
            "C": "Không cần định nghĩa",
            "D": "Theo định nghĩa tiêu chuẩn của pháp luật TQ"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Hợp đồng bằng miệng hoặc qua WeChat có giá trị pháp lý tương đương hợp đồng bằng văn bản."
        },
        {
          "num": 10,
          "q": "Dấu công ty (公章) ở TQ quan trọng không kém chữ ký giám đốc."
        },
        {
          "num": 11,
          "q": "Nhà cung cấp đứt hàng (断货) thường được coi là trường hợp bất khả kháng và miễn trách nhiệm."
        },
        {
          "num": 12,
          "q": "Điều khoản giải quyết tranh chấp không quan trọng vì các bên thường tự đàm phán được."
        },
        {
          "num": 13,
          "q": "NDA và điều khoản IP là lớp bảo vệ tối thiểu khi chia sẻ thiết kế với nhà máy."
        },
        {
          "num": 14,
          "q": "Trọng tài SIAC (Singapore) được coi là trung lập hơn trọng tài tại Thâm Quyến cho bên nước ngoài."
        }
      ],
      "fillblank": {
        "wordbank": [
          "合同",
          "甲方",
          "违约",
          "不可抗力",
          "知识产权",
          "保密协议"
        ],
        "items": [
          {
            "num": 15,
            "q": "请起草一份____，包括价格、交期、付款条件和质量标准。"
          },
          {
            "num": 16,
            "q": "在分享产品设计之前，请先签署____，保护我们的设计不外泄。"
          },
          {
            "num": 17,
            "q": "合同规定____负责验货，____负责按时生产和交货。"
          },
          {
            "num": 18,
            "q": "台风属于____，工厂申请延期不承担____责任。"
          },
          {
            "num": 19,
            "q": "合同中需要明确____归属，我们的设计不能被第三方使用。"
          },
          {
            "num": 20,
            "q": "如果一方____，须按合同规定支付____金。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "合同中需要明确知识产权归属，所有产品设计专属于甲方，乙方不得向任何第三方提供。"
        },
        {
          "num": 22,
          "q": "不可抗力条款应明确定义，供应商断货、机器故障不属于不可抗力，不得以此为由延迟交货。"
        },
        {
          "num": 23,
          "q": "如发生争议，双方同意首先协商解决；协商不成的，提交新加坡国际仲裁中心仲裁。"
        },
        {
          "num": 24,
          "q": "合同有效期为两年，期满前三十天如任何一方无异议则自动续签一年。"
        },
        {
          "num": 25,
          "q": "迟延交货每逾期一天，乙方应向甲方支付合同总金额0.1%的违约金，最高不超过合同总额的10%。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Trước khi ký hợp đồng, chúng tôi cần ký thỏa thuận bảo mật để bảo vệ thiết kế sản phẩm của chúng tôi."
        },
        {
          "num": 27,
          "q": "Hợp đồng cần ghi rõ điều khoản bất khả kháng, chỉ bao gồm thiên tai, chiến tranh và lệnh cấm của chính phủ."
        },
        {
          "num": 28,
          "q": "Chúng tôi muốn điều khoản giải quyết tranh chấp là trọng tài Singapore, không phải trọng tài trong nước TQ."
        },
        {
          "num": 29,
          "q": "Bên B vi phạm hợp đồng về chất lượng, bên A có quyền yêu cầu bồi thường và chấm dứt hợp đồng."
        },
        {
          "num": 30,
          "q": "Vui lòng gửi bản thảo hợp đồng song ngữ Trung-Anh, chúng tôi cần luật sư xem xét trước khi ký."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "C",
        "6": "B",
        "7": "C",
        "8": "B"
      },
      "tf": {
        "9": false,
        "10": true,
        "11": false,
        "12": false,
        "13": true,
        "14": true
      },
      "fillblank": {
        "15": "合同",
        "16": "保密协议",
        "17": [
          "甲方",
          "乙方"
        ],
        "18": [
          "不可抗力",
          "违约"
        ],
        "19": "知识产权",
        "20": [
          "违约",
          "违约"
        ]
      },
      "zh2vi": {
        "21": "Trong hợp đồng cần ghi rõ quy thuộc sở hữu trí tuệ, toàn bộ thiết kế sản phẩm thuộc độc quyền của bên A, bên B không được cung cấp cho bất kỳ bên thứ ba nào.",
        "22": "Điều khoản bất khả kháng cần được định nghĩa rõ ràng, nhà cung cấp đứt hàng và máy hỏng không thuộc bất khả kháng, không được viện dẫn để trễ giao hàng.",
        "23": "Nếu xảy ra tranh chấp, hai bên đồng ý trước tiên giải quyết bằng đàm phán; nếu đàm phán không thành, đệ trình trọng tài SIAC giải quyết.",
        "24": "Hợp đồng có hiệu lực 2 năm, trước 30 ngày hết hạn nếu không bên nào có ý kiến thì tự động gia hạn thêm 1 năm.",
        "25": "Mỗi ngày chậm giao hàng, bên B phải thanh toán cho bên A khoản phạt 0,1% tổng giá trị hợp đồng, tối đa không vượt quá 10% tổng giá trị hợp đồng."
      },
      "vi2zh": {
        "26": "签合同之前，我们需要先签保密协议，保护我们的产品设计。",
        "27": "合同需要明确不可抗力的条款，仅包括自然灾害、战争和政府禁令。",
        "28": "我们希望争议解决条款是新加坡仲裁，而不是中国大陆仲裁。",
        "29": "乙方违反合同质量条款，甲方有权要求赔偿并终止合同。",
        "30": "请发送中英双语合同草案，我们需要律师审核后再签字。"
      }
    }
  },
  {
    "num": 10,
    "title": "CHỨNG TỪ XUẤT NHẬP KHẨU",
    "date": "6/6",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "商业发票",
        "pinyin": "shāngyè fāpiào",
        "vi": "hóa đơn thương mại (Commercial Invoice)",
        "explanation": "Chứng từ do người bán phát hành, liệt kê chi tiết hàng hóa, số lượng, đơn giá, tổng giá trị, điều kiện giao hàng. Đây là tài liệu cơ bản nhất trong bộ chứng từ xuất khẩu — hải quan dùng để tính thuế nhập khẩu, ngân hàng dùng để thanh toán L/C.",
        "example": {
          "zh": "请发一份商业发票给我，我需要用来清关。",
          "vi": "Vui lòng gửi một hóa đơn thương mại cho tôi, tôi cần để thông quan."
        }
      },
      {
        "num": 2,
        "hanzi": "装箱单",
        "pinyin": "zhuāngxiāng dān",
        "vi": "phiếu đóng gói (Packing List)",
        "explanation": "Tài liệu liệt kê chi tiết từng kiện hàng: số lượng thùng, trọng lượng từng thùng, kích thước, tổng khối lượng. Hải quan và kho bãi dùng để kiểm tra và giao nhận hàng. Sai lệch giữa Packing List và hàng thực tế = vấn đề thông quan.",
        "example": {
          "zh": "装箱单和实际货物必须完全一致，否则会影响清关。",
          "vi": "Packing list và hàng thực tế phải hoàn toàn khớp nhau, nếu không sẽ ảnh hưởng thông quan."
        }
      },
      {
        "num": 3,
        "hanzi": "提单",
        "pinyin": "tí dān",
        "vi": "vận đơn đường biển (Bill of Lading - B/L)",
        "explanation": "Chứng từ quan trọng nhất trong vận tải biển — vừa là biên nhận hàng hóa, vừa là hợp đồng vận chuyển, vừa là chứng từ sở hữu hàng. Ai có vận đơn gốc = người đó có quyền nhận hàng. Không có B/L = không lấy được hàng ở cảng đích.",
        "example": {
          "zh": "提单是提货的关键文件，请妥善保管，不要遗失。",
          "vi": "Vận đơn là tài liệu quan trọng để nhận hàng, vui lòng giữ gìn cẩn thận, không được thất lạc."
        }
      },
      {
        "num": 4,
        "hanzi": "原产地证",
        "pinyin": "yuánchǎndì zhèng",
        "vi": "giấy chứng nhận xuất xứ (Certificate of Origin - C/O)",
        "explanation": "Tài liệu chứng nhận hàng hóa có xuất xứ từ nước nào. Quan trọng vì thuế nhập khẩu phụ thuộc vào xuất xứ — hàng TQ có thể chịu thuế bổ sung 25% khi vào Mỹ (thuế chiến tranh thương mại), trong khi hàng VN có thể được ưu đãi thuế hơn theo một số hiệp định thương mại.",
        "example": {
          "zh": "进入美国市场需要原产地证，请确认是中国产还是越南产。",
          "vi": "Vào thị trường Mỹ cần giấy chứng nhận xuất xứ, vui lòng xác nhận xuất xứ TQ hay VN."
        }
      },
      {
        "num": 5,
        "hanzi": "清关",
        "pinyin": "qīngguān",
        "vi": "thông quan (customs clearance)",
        "explanation": "Quá trình làm thủ tục hải quan để hàng hóa được phép nhập vào hoặc xuất khỏi một nước. Cần nộp đủ chứng từ, khai báo chính xác và nộp thuế nếu có. Hàng bị \"kẹt hải quan\" (卡关) là ác mộng của mọi người làm xuất nhập khẩu.",
        "example": {
          "zh": "我们的货代负责在美国港口清关，所有文件需要提前准备好。",
          "vi": "Forwarder của chúng tôi chịu trách nhiệm thông quan tại cảng Mỹ, mọi chứng từ cần chuẩn bị trước."
        }
      },
      {
        "num": 6,
        "hanzi": "报关",
        "pinyin": "bàoguān",
        "vi": "khai báo hải quan",
        "explanation": "Hành động khai báo thông tin hàng hóa với cơ quan hải quan trước khi xuất hoặc nhập. 报关 là bước trong quy trình 清关 tổng thể. Mô tả hàng hóa (品名), mã HS (HS编码), và giá trị phải khai báo chính xác — khai sai có thể bị phạt hoặc tịch thu hàng.",
        "example": {
          "zh": "请确认货物的HS编码，这会影响到报关和关税计算。",
          "vi": "Vui lòng xác nhận mã HS của hàng hóa, điều này sẽ ảnh hưởng đến khai báo hải quan và tính thuế."
        }
      },
      {
        "num": 7,
        "hanzi": "关税",
        "pinyin": "guānshuì",
        "vi": "thuế hải quan / thuế nhập khẩu",
        "explanation": "Khoản thuế chính phủ nước nhập khẩu thu trên hàng hóa nhập khẩu. Tỷ lệ thuế phụ thuộc mã HS và xuất xứ hàng hóa. Hàng TQ xuất sang Mỹ hiện chịu thuế bổ sung 25% theo Section 301 (thuế chiến tranh thương mại) cho nhiều danh mục sản phẩm.",
        "example": {
          "zh": "这个产品进口到美国的关税是多少？是否受到加征关税的影响？",
          "vi": "Thuế nhập khẩu sản phẩm này vào Mỹ là bao nhiêu? Có bị ảnh hưởng bởi thuế bổ sung không?"
        }
      },
      {
        "num": 8,
        "hanzi": "HS编码",
        "pinyin": "HS biānmǎ",
        "vi": "mã HS (Harmonized System code)",
        "explanation": "Hệ thống mã số quốc tế để phân loại hàng hóa, gồm 6–10 chữ số. Mã HS xác định mức thuế nhập khẩu, yêu cầu chứng nhận, và quy định kiểm tra. Mã HS sai = có thể khai thuế sai, bị phạt hoặc bị giữ hàng. Tìm mã HS chính xác là việc cần làm trước khi xuất hàng lần đầu.",
        "example": {
          "zh": "这款办公椅的HS编码是9401，进口美国关税是0%。",
          "vi": "Mã HS của ghế văn phòng này là 9401, thuế nhập khẩu vào Mỹ là 0%."
        }
      },
      {
        "num": 9,
        "hanzi": "保险单",
        "pinyin": "bǎoxiǎn dān",
        "vi": "hợp đồng bảo hiểm hàng hóa (Insurance Certificate)",
        "explanation": "Chứng từ bảo hiểm cho hàng hóa trong quá trình vận chuyển. Bắt buộc trong điều kiện CIF. Tỷ lệ bảo hiểm thường 110% giá trị hàng. Khi hàng bị mất hoặc hư hỏng trong vận chuyển, 保险单 là cơ sở để bồi thường.",
        "example": {
          "zh": "CIF条件下，卖方需要为货物购买保险并提供保险单。",
          "vi": "Trong điều kiện CIF, người bán cần mua bảo hiểm cho hàng và cung cấp hợp đồng bảo hiểm."
        }
      },
      {
        "num": 10,
        "hanzi": "电放提单",
        "pinyin": "diàn fàng tídān",
        "vi": "điện giải phóng hàng (Telex Release)",
        "explanation": "Thay thế cho vận đơn gốc (original B/L) — người bán điện báo cho đại lý tàu tại cảng đích để giải phóng hàng mà không cần vận đơn giấy gốc. Tiết kiệm thời gian và rủi ro mất chứng từ. Phù hợp khi khách và nhà máy có mức độ tin tưởng cao, thường dùng với hàng T/T đã thanh toán đủ.",
        "example": {
          "zh": "货款已全部收到，我们安排电放，不需要寄原始提单了。",
          "vi": "Tiền hàng đã nhận đủ, chúng tôi sắp xếp điện giải phóng, không cần gửi vận đơn gốc nữa."
        }
      }
    ],
    "dialogue": {
      "context": "Nhà máy TQ và forwarder VN đang phối hợp chuẩn bị bộ chứng từ để xuất hàng sang Mỹ. Bạn là phiên dịch.",
      "characters": [
        {
          "name": "跟单员小张 (Xiǎo Zhāng)",
          "role": "Nhân viên theo dõi đơn hàng nhà máy TQ"
        },
        {
          "name": "Anh Phúc",
          "role": "Nhân viên logistics công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "小张",
          "zh": "您好，货物已经装柜了，现在需要准备出口文件，请问你们需要哪些单据？",
          "vi": "Xin chào, hàng đã đóng container rồi, bây giờ cần chuẩn bị chứng từ xuất khẩu, anh cần những tài liệu gì?"
        },
        {
          "speaker": "Anh Phúc",
          "zh": "我们需要标准的一套：商业发票、装箱单、提单。另外因为要进入美国，还需要原产地证。",
          "vi": "Chúng tôi cần bộ chuẩn: hóa đơn thương mại, packing list, vận đơn. Ngoài ra vì vào Mỹ, còn cần giấy chứng nhận xuất xứ."
        },
        {
          "speaker": "小张",
          "zh": "好的，商业发票和装箱单我这边可以出。请问发票上的货物描述和HS编码你们确认过了吗？美国那边的关税是多少？",
          "vi": "Được, hóa đơn và packing list tôi có thể xuất. Mô tả hàng hóa và mã HS trên hóa đơn anh đã xác nhận chưa? Thuế nhập khẩu bên Mỹ là bao nhiêu?"
        },
        {
          "speaker": "Anh Phúc",
          "zh": "HS编码我们查过了，这款产品是9401.30，进口美国是0%关税，不受加征关税影响。但是请你们发票上的品名和描述要跟申报的一致，不能模糊。",
          "vi": "Chúng tôi đã tra mã HS rồi, sản phẩm này là 9401.30, nhập Mỹ thuế 0%, không bị ảnh hưởng bởi thuế bổ sung. Nhưng mô tả hàng trên hóa đơn phải khớp với khai báo, không được mơ hồ."
        },
        {
          "speaker": "小张",
          "zh": "明白，我们会按照实际产品如实描述。原产地证方面，这批货是在中国生产的，我们可以申请中国原产地证，但是需要注意，中国产品进美国可能有额外的审查。",
          "vi": "Hiểu, chúng tôi sẽ mô tả thực tế sản phẩm. Về giấy chứng nhận xuất xứ, lô hàng này sản xuất ở TQ, chúng tôi có thể xin C/O TQ, nhưng cần lưu ý hàng TQ vào Mỹ có thể bị kiểm tra thêm."
        },
        {
          "speaker": "Anh Phúc",
          "zh": "这个我们知道，目前这个HS编码暂时没有加征关税，所以没有问题。关于提单，因为货款已经全部付清了，我们希望做电放提单，不需要寄原始提单，可以吗？",
          "vi": "Cái này chúng tôi biết, hiện tại mã HS này chưa bị thuế bổ sung nên không vấn đề. Về vận đơn, vì tiền hàng đã thanh toán đủ rồi, chúng tôi muốn làm điện giải phóng hàng, không cần gửi vận đơn gốc, được không?"
        },
        {
          "speaker": "小张",
          "zh": "可以，电放更方便。货物到港后你们直接凭我们的电放通知去提货就好了。请问你们的清关代理是谁？我把所有文件同步发给他们。",
          "vi": "Được, điện giải phóng tiện hơn. Hàng đến cảng anh trực tiếp dùng thông báo điện giải phóng của chúng tôi đi lấy hàng là được. Anh cho tôi biết đại lý thông quan của anh là ai? Tôi sẽ gửi tất cả chứng từ đồng thời cho họ."
        },
        {
          "speaker": "Anh Phúc",
          "zh": "我们的美国清关代理是Pacific Customs Brokers，我一会儿把他们的联系方式发给你。另外，这批货的保险怎么处理？我们是FOB价，需要自己买保险吗？",
          "vi": "Đại lý thông quan Mỹ của chúng tôi là Pacific Customs Brokers, lát tôi gửi thông tin liên hệ của họ cho anh. Ngoài ra bảo hiểm lô hàng này xử lý thế nào? Chúng tôi là giá FOB, tự mua bảo hiểm hay sao?"
        },
        {
          "speaker": "小张",
          "zh": "对，你们是FOB价，保险需要你们自己安排，建议买110%货值的全险。我们这边会提供装箱单和发票供你们报保险用。",
          "vi": "Đúng, anh dùng giá FOB, bảo hiểm cần phía anh tự sắp xếp, khuyến nghị mua toàn hiểm 110% giá trị hàng. Phía chúng tôi sẽ cung cấp packing list và hóa đơn để anh khai báo bảo hiểm."
        },
        {
          "speaker": "Anh Phúc",
          "zh": "好，我来安排保险。所有文件我需要在出货后48小时内收到，包括商业发票、装箱单、提单复印件还有原产地证，可以做到吗？",
          "vi": "Tốt, tôi sắp xếp bảo hiểm. Mọi chứng từ tôi cần nhận trong 48 giờ sau khi xuất hàng, bao gồm hóa đơn thương mại, packing list, bản sao vận đơn và C/O, có làm được không?"
        },
        {
          "speaker": "小张",
          "zh": "没问题，出货后24小时内我把所有文件发给你和你的清关代理。",
          "vi": "Không vấn đề, trong 24 giờ sau khi xuất hàng tôi sẽ gửi toàn bộ chứng từ cho anh và đại lý thông quan của anh."
        }
      ]
    },
    "notes": [
      {
        "title": "Mã HS: tra cứu đúng từ đầu",
        "body": "Mã HS sai có thể dẫn đến khai thuế sai, bị phạt hoặc bị hải quan giữ hàng. Tra cứu mã HS tại website hải quan Mỹ (hts.usitc.gov) hoặc hỏi đại lý thông quan chuyên nghiệp. Cùng một sản phẩm, mô tả khác nhau có thể ra mã HS khác nhau và mức thuế khác nhau."
      },
      {
        "title": "Thuế chiến tranh thương mại Mỹ-TQ vẫn còn hiệu lực",
        "body": "Từ 2018, Mỹ áp thuế bổ sung 25% lên hàng trăm tỷ USD hàng TQ theo Section 301. Nhiều mặt hàng tiêu dùng, điện tử, nội thất bị ảnh hưởng. Trước khi nhập hàng TQ vào Mỹ, phải kiểm tra xem mã HS của mình có nằm trong danh sách chịu thuế bổ sung không."
      },
      {
        "title": "Điện giải phóng hàng (Telex Release) vs vận đơn gốc",
        "body": "Vận đơn gốc cần gửi qua đường bưu điện quốc tế (mất 1–2 tuần) trước khi nhận hàng. Điện giải phóng tiết kiệm thời gian và loại bỏ rủi ro thất lạc. Chỉ nên làm điện giải phóng khi đã thanh toán đủ hoặc có mức độ tin tưởng cao với đối tác."
      },
      {
        "title": "Mô tả hàng hóa trên chứng từ: chính xác là bắt buộc",
        "body": "Mô tả hàng hóa trên Commercial Invoice và Packing List phải khớp hoàn toàn với hàng thực tế và khai báo hải quan. Không được ghi chung chung để \"tiết kiệm\" thuế — đây là gian lận hải quan, hậu quả nghiêm trọng."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Chứng từ nào quan trọng nhất để nhận hàng tại cảng đích?",
          "options": {
            "A": "Hóa đơn thương mại",
            "B": "Packing list",
            "C": "Vận đơn (Bill of Lading)",
            "D": "Giấy chứng nhận xuất xứ"
          }
        },
        {
          "num": 2,
          "q": "原产地证 quan trọng vì lý do gì?",
          "options": {
            "A": "Để chứng minh hàng hóa an toàn",
            "B": "Để xác định mức thuế nhập khẩu dựa trên xuất xứ",
            "C": "Để đặt chỗ tàu",
            "D": "Để mua bảo hiểm"
          }
        },
        {
          "num": 3,
          "q": "Điện giải phóng hàng (电放提单) phù hợp khi nào?",
          "options": {
            "A": "Khi hàng chưa sản xuất xong",
            "B": "Khi tiền hàng đã thanh toán đủ và hai bên tin tưởng nhau",
            "C": "Khi hàng bị hải quan giữ",
            "D": "Khi cần thay đổi người nhận hàng"
          }
        },
        {
          "num": 4,
          "q": "Mã HS (HS编码) được dùng để làm gì?",
          "options": {
            "A": "Theo dõi vị trí container",
            "B": "Phân loại hàng hóa và xác định mức thuế nhập khẩu",
            "C": "Tính trọng lượng hàng",
            "D": "Xác định nhà sản xuất"
          }
        },
        {
          "num": 5,
          "q": "Trong điều kiện FOB, ai chịu trách nhiệm mua bảo hiểm hàng hóa?",
          "options": {
            "A": "Người bán",
            "B": "Người mua",
            "C": "Công ty vận chuyển",
            "D": "Hải quan"
          }
        },
        {
          "num": 6,
          "q": "Thuế chiến tranh thương mại Mỹ-TQ (Section 301) áp thuế bổ sung bao nhiêu?",
          "options": {
            "A": "5%",
            "B": "10%",
            "C": "15%",
            "D": "25%"
          }
        },
        {
          "num": 7,
          "q": "Packing List (装箱单) dùng để làm gì?",
          "options": {
            "A": "Tính thuế nhập khẩu",
            "B": "Liệt kê chi tiết từng kiện hàng cho hải quan và kho bãi kiểm tra",
            "C": "Thanh toán qua ngân hàng",
            "D": "Đặt chỗ tàu"
          }
        },
        {
          "num": 8,
          "q": "Tỷ lệ bảo hiểm hàng hóa thường là bao nhiêu so với giá trị hàng?",
          "options": {
            "A": "50%",
            "B": "80%",
            "C": "100%",
            "D": "110%"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Ai có vận đơn gốc là người có quyền nhận hàng tại cảng đích."
        },
        {
          "num": 10,
          "q": "Khai báo hàng hóa mơ hồ hoặc sai trên chứng từ để tiết kiệm thuế là hành vi hợp pháp."
        },
        {
          "num": 11,
          "q": "Mã HS sai có thể dẫn đến bị phạt hoặc hải quan giữ hàng."
        },
        {
          "num": 12,
          "q": "Điện giải phóng hàng nhanh hơn gửi vận đơn gốc qua bưu điện."
        },
        {
          "num": 13,
          "q": "Hàng TQ vào Mỹ đều bị áp thuế bổ sung 25% theo Section 301."
        },
        {
          "num": 14,
          "q": "Trong điều kiện CIF, người bán phải mua bảo hiểm hàng hóa cho người mua."
        }
      ],
      "fillblank": {
        "wordbank": [
          "商业发票",
          "提单",
          "原产地证",
          "HS编码",
          "清关",
          "电放提单"
        ],
        "items": [
          {
            "num": 15,
            "q": "进口美国需要提供____，以确认产品的关税税率。"
          },
          {
            "num": 16,
            "q": "____是提货的关键文件，必须妥善保管。"
          },
          {
            "num": 17,
            "q": "货款已付清，我们选择做____，不需要等原始单据邮寄了。"
          },
          {
            "num": 18,
            "q": "____和装箱单必须与实际货物完全一致，否则会影响____。"
          },
          {
            "num": 19,
            "q": "请确认这个产品的____是多少，这会影响进口美国的关税。"
          },
          {
            "num": 20,
            "q": "我们的清关代理会负责美国港口的____手续。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "出货后24小时内，我们会提供完整的出口文件：商业发票、装箱单、提单和原产地证。"
        },
        {
          "num": 22,
          "q": "这个产品的HS编码是9403，进口美国是0%关税，不在加征关税的范围内，请放心。"
        },
        {
          "num": 23,
          "q": "由于货款已经全额到账，我们安排电放，请直接联系你们的货代去提货。"
        },
        {
          "num": 24,
          "q": "发票上的货物描述必须准确，与实际货物一致，不能使用模糊或不准确的描述。"
        },
        {
          "num": 25,
          "q": "建议购买110%货值的货物保险，以防运输途中发生损失。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Vui lòng gửi đầy đủ chứng từ: hóa đơn thương mại, packing list và C/O trong 24 giờ sau khi xuất hàng."
        },
        {
          "num": 27,
          "q": "Mã HS của sản phẩm này là gì? Có bị ảnh hưởng bởi thuế bổ sung khi vào Mỹ không?"
        },
        {
          "num": 28,
          "q": "Tiền hàng đã thanh toán đủ, chúng tôi muốn làm điện giải phóng hàng thay vì gửi vận đơn gốc."
        },
        {
          "num": 29,
          "q": "Đại lý thông quan của chúng tôi tại cảng Los Angeles cần bộ chứng từ đầy đủ trước khi tàu cập cảng."
        },
        {
          "num": 30,
          "q": "Sản phẩm này có xuất xứ TQ hay xuất xứ VN? Điều này ảnh hưởng đến thuế nhập khẩu vào Mỹ."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "C",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "D",
        "7": "B",
        "8": "D"
      },
      "tf": {
        "9": true,
        "10": false,
        "11": true,
        "12": true,
        "13": false,
        "14": true
      },
      "fillblank": {
        "15": "原产地证",
        "16": "提单",
        "17": "电放提单",
        "18": [
          "商业发票",
          "清关"
        ],
        "19": "HS编码",
        "20": "清关"
      },
      "zh2vi": {
        "21": "Trong 24 giờ sau khi xuất hàng, chúng tôi sẽ cung cấp đầy đủ chứng từ xuất khẩu: hóa đơn thương mại, packing list, vận đơn và C/O.",
        "22": "Mã HS của sản phẩm này là 9403, thuế nhập khẩu vào Mỹ là 0%, không nằm trong danh sách thuế bổ sung, anh yên tâm.",
        "23": "Do tiền hàng đã về đủ, chúng tôi sắp xếp điện giải phóng, vui lòng liên hệ trực tiếp forwarder của anh để lấy hàng.",
        "24": "Mô tả hàng hóa trên hóa đơn phải chính xác, khớp với hàng thực tế, không được dùng mô tả mơ hồ hoặc không chính xác.",
        "25": "Khuyến nghị mua bảo hiểm toàn hiểm 110% giá trị hàng để phòng tổn thất trong quá trình vận chuyển."
      },
      "vi2zh": {
        "26": "请在出货后24小时内发送完整文件：商业发票、装箱单和原产地证。",
        "27": "这个产品的HS编码是多少？进口美国会受到加征关税影响吗？",
        "28": "货款已付清，我们希望做电放提单，不需要邮寄原始提单。",
        "29": "我们在洛杉矶港的清关代理需要在船到港前收到完整的单据。",
        "30": "这个产品是中国产还是越南产？这会影响进口美国的关税税率。"
      }
    }
  },
  {
    "num": 11,
    "title": "ĐÀM PHÁN GIÁ & THƯƠNG LƯỢNG",
    "date": "7/6",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "砍价",
        "pinyin": "kǎn jià",
        "vi": "mặc cả / ép giá",
        "explanation": "Hành động người mua đàm phán để giảm giá xuống. Trong văn hóa kinh doanh TQ, 砍价 là điều hoàn toàn bình thường và được mong đợi — báo giá ban đầu thường cao hơn mức thực tế chấp nhận được, chừa chỗ cho đàm phán. Không 砍价 bị coi là người mua không chuyên nghiệp.",
        "example": {
          "zh": "你们的价格太高了，能不能砍一砍？",
          "vi": "Giá của anh cao quá, có thể giảm không?"
        }
      },
      {
        "num": 2,
        "hanzi": "让步",
        "pinyin": "ràng bù",
        "vi": "nhượng bộ / nhường",
        "explanation": "Hành động một bên chấp nhận giảm yêu cầu của mình để đạt thỏa thuận. Trong đàm phán, 让步 cần có đi có lại — nếu chỉ một bên luôn nhượng bộ, cuộc đàm phán mất cân bằng. Người TQ giỏi đàm phán biết khi nào nên 让步 và khi nào cần giữ vững lập trường.",
        "example": {
          "zh": "我们在价格上已经让步很多了，希望贵方在交期上也能让一让。",
          "vi": "Chúng tôi đã nhượng bộ nhiều về giá, hy vọng quý vị cũng có thể linh hoạt hơn về thời gian giao hàng."
        }
      },
      {
        "num": 3,
        "hanzi": "底价",
        "pinyin": "dǐ jià",
        "vi": "giá sàn / giá thấp nhất có thể chấp nhận",
        "explanation": "Mức giá thấp nhất mà người bán có thể bán mà không bị lỗ. Đây là thông tin người bán không bao giờ tiết lộ chủ động. Người mua giỏi sẽ đàm phán để tiếp cận gần 底价 nhất có thể thông qua việc tăng số lượng, đặt hàng dài hạn, hoặc giảm yêu cầu dịch vụ.",
        "example": {
          "zh": "这已经是我们的底价了，再低我们就亏本了。",
          "vi": "Đây đã là giá sàn của chúng tôi rồi, thấp hơn nữa chúng tôi lỗ."
        }
      },
      {
        "num": 4,
        "hanzi": "折扣",
        "pinyin": "zhékòu",
        "vi": "chiết khấu / giảm giá (%)",
        "explanation": "Giảm giá theo tỷ lệ phần trăm. Phân biệt với 降价 (giảm giá tuyệt đối — giảm X đồng). 折扣 thường gắn với điều kiện cụ thể: đặt số lượng lớn, thanh toán nhanh, khách hàng lâu năm, hoặc mua nhiều mặt hàng cùng lúc.",
        "example": {
          "zh": "如果订单量达到2000个，我们可以给8%的折扣。",
          "vi": "Nếu đơn hàng đạt 2000 cái, chúng tôi có thể chiết khấu 8%."
        }
      },
      {
        "num": 5,
        "hanzi": "报价虚高",
        "pinyin": "bàojià xū gāo",
        "vi": "báo giá cao hơn thực tế để chừa chỗ đàm phán",
        "explanation": "Thực tế phổ biến trong đàm phán TQ — giá báo ban đầu cao hơn mức thực sự muốn bán, để người mua có cảm giác đạt được 让步 khi đàm phán xuống. Người mua kinh nghiệm biết điều này và không bao giờ chấp nhận giá đầu tiên.",
        "example": {
          "zh": "我们都明白报价有水分，请给我们一个实在的价格。",
          "vi": "Chúng ta đều hiểu báo giá có phần ảo, vui lòng cho chúng tôi mức giá thực tế."
        }
      },
      {
        "num": 6,
        "hanzi": "成交",
        "pinyin": "chéngjīao",
        "vi": "chốt deal / thỏa thuận xong",
        "explanation": "Khoảnh khắc hai bên đồng ý với các điều kiện và quyết định hợp tác. 成交 thường được xác nhận bằng lời, sau đó tiếp theo là ký kết hợp đồng chính thức. 成交价 = giá cuối cùng hai bên đồng ý.",
        "example": {
          "zh": "如果你们能做到48美元FOB，我们现在就可以成交。",
          "vi": "Nếu các anh có thể làm được 48 đô FOB, chúng tôi có thể chốt ngay bây giờ."
        }
      },
      {
        "num": 7,
        "hanzi": "互利共赢",
        "pinyin": "hùlì gòng yíng",
        "vi": "cùng có lợi / win-win",
        "explanation": "Nguyên tắc đàm phán cả hai bên đều được lợi, không có bên thua. Đây là cách diễn đạt mục tiêu đàm phán mà người TQ rất hay dùng — kể cả khi thực tế họ đang cố gắng nghiêng về phía mình. Khi nghe 互利共赢, biết rằng đối phương đang định hướng đàm phán theo tư duy dài hạn.",
        "example": {
          "zh": "我们的目标是互利共赢，希望建立长期稳定的合作关系。",
          "vi": "Mục tiêu của chúng tôi là cùng có lợi, hy vọng xây dựng quan hệ hợp tác lâu dài ổn định."
        }
      },
      {
        "num": 8,
        "hanzi": "涨价",
        "pinyin": "zhǎng jià",
        "vi": "tăng giá",
        "explanation": "Nhà cung cấp thông báo tăng giá, thường do nguyên liệu tăng, chi phí nhân công tăng, hoặc tỷ giá thay đổi. Khi nhận thông báo 涨价, người mua có quyền yêu cầu giải thích chi tiết và đàm phán để giảm mức tăng.",
        "example": {
          "zh": "由于原材料涨价20%，我们不得不调整报价，新价格上涨8%。",
          "vi": "Do nguyên liệu tăng 20%, chúng tôi buộc phải điều chỉnh báo giá, giá mới tăng 8%."
        }
      },
      {
        "num": 9,
        "hanzi": "锁价",
        "pinyin": "suǒ jià",
        "vi": "chốt giá / khóa giá",
        "explanation": "Thỏa thuận giữ nguyên mức giá trong một khoảng thời gian nhất định, bất kể thị trường biến động. Người mua muốn 锁价 để lên kế hoạch chi phí. Người bán ít muốn 锁价 vì mất linh hoạt khi nguyên liệu tăng.",
        "example": {
          "zh": "我们希望能锁价6个月，以便做好成本预算。",
          "vi": "Chúng tôi muốn chốt giá 6 tháng để lập kế hoạch chi phí."
        }
      },
      {
        "num": 10,
        "hanzi": "以量换价",
        "pinyin": "yǐ liàng huàn jià",
        "vi": "dùng số lượng đổi lấy giá tốt hơn",
        "explanation": "Chiến thuật đàm phán: cam kết mua số lượng lớn hơn để đổi lại mức giá thấp hơn. Hiệu quả nhất khi người mua thực sự có khả năng thực hiện cam kết số lượng đó — nhà máy sẽ không chấp nhận nếu người mua từng đặt ít hơn cam kết.",
        "example": {
          "zh": "如果我们把年订单量从5000个增加到10000个，价格能降多少？",
          "vi": "Nếu chúng tôi tăng số lượng đặt hàng hàng năm từ 5000 lên 10000 cái, giá có thể giảm bao nhiêu?"
        }
      }
    ],
    "dialogue": {
      "context": "Cuộc đàm phán giá căng thẳng giữa buyer VN và nhà máy TQ cho đơn hàng ghế văn phòng lớn. Bạn là phiên dịch.",
      "characters": [
        {
          "name": "销售总监陈总 (Chén zǒng)",
          "role": "Giám đốc kinh doanh nhà máy TQ"
        },
        {
          "name": "Anh Khải",
          "role": "Giám đốc thu mua công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "Anh Khải",
          "zh": "陈总，我们收到你们的最新报价是55美元FOB，但是我们觉得这个价格跟市场上其他供应商比偏高，我们的目标价是48美元。",
          "vi": "Anh Trần, chúng tôi nhận báo giá mới nhất của anh là 55 đô FOB, nhưng chúng tôi thấy mức này cao hơn so với các nhà cung cấp khác trên thị trường, giá mục tiêu của chúng tôi là 48 đô."
        },
        {
          "speaker": "陈总",
          "zh": "48美元我们很难接受，原材料成本就不低，55美元已经是比较有竞争力的价格了。请问您从哪里看到更低的价格？",
          "vi": "48 đô chúng tôi rất khó chấp nhận, chi phí nguyên liệu đã không thấp, 55 đô đã là mức khá cạnh tranh rồi. Anh thấy mức giá thấp hơn ở đâu?"
        },
        {
          "speaker": "Anh Khải",
          "zh": "我们询过几家，有供应商报价是50美元，质量也差不多。我们跟你们谈，是因为更看重你们的交期稳定性和服务，但价格也需要有竞争力。",
          "vi": "Chúng tôi đã hỏi một vài nhà cung cấp, có nơi báo 50 đô, chất lượng cũng tương đương. Chúng tôi thương lượng với anh vì coi trọng tính ổn định giao hàng và dịch vụ của anh hơn, nhưng giá cũng cần cạnh tranh."
        },
        {
          "speaker": "陈总",
          "zh": "我理解您的考虑。这样吧，如果您这次订单量能达到2000个，我们可以做到51美元，这已经是在原来基础上让了很多了。",
          "vi": "Tôi hiểu suy nghĩ của anh. Thế này nhé, nếu đơn hàng lần này của anh đạt 2000 cái, chúng tôi có thể làm 51 đô, đã nhượng bộ nhiều so với ban đầu rồi."
        },
        {
          "speaker": "Anh Khải",
          "zh": "2000个我们可以，但51美元还是高。我们的亚马逊竞争很激烈，成本控制非常重要。能不能做到49美元？",
          "vi": "2000 cái chúng tôi được, nhưng 51 đô vẫn cao. Thị trường Amazon của chúng tôi cạnh tranh rất khốc liệt, kiểm soát chi phí cực kỳ quan trọng. Có thể làm 49 đô không?"
        },
        {
          "speaker": "陈总",
          "zh": "49美元真的很困难，我们的生产成本摆在那里。但是我们很重视和贵公司的长期合作。这样，如果您能承诺今年全年的订单都从我们这里下，量不低于8000个，我们可以做到50美元，这是我们的底价了。",
          "vi": "49 đô thực sự rất khó, chi phí sản xuất của chúng tôi có một ngưỡng nhất định. Nhưng chúng tôi rất coi trọng hợp tác lâu dài với quý công ty. Thế này, nếu anh có thể cam kết toàn bộ đơn hàng trong năm nay đều đặt từ chúng tôi, số lượng không dưới 8000 cái, chúng tôi có thể làm 50 đô, đây là giá sàn của chúng tôi."
        },
        {
          "speaker": "Anh Khải",
          "zh": "全年8000个可以承诺，但是50美元还是差了一点。我们能不能这样：50美元成交，但是你们免费帮我们做产品包装设计，为我们的亚马逊品牌定制？",
          "vi": "Cam kết 8000 cái cả năm được, nhưng 50 đô vẫn còn chênh một chút. Hay thế này: chốt 50 đô, nhưng anh miễn phí thiết kế bao bì sản phẩm cho chúng tôi, định制theo thương hiệu Amazon của chúng tôi?"
        },
        {
          "speaker": "陈总",
          "zh": "包装设计我们可以配合，但设计费通常是收费的，不过考虑到8000个的年订单量，我们愿意提供一套基础包装设计作为赠送。那50美元，年采购8000个，包装设计免费，可以成交吗？",
          "vi": "Thiết kế bao bì chúng tôi có thể phối hợp, nhưng phí thiết kế thường tính tiền, tuy nhiên xét đến 8000 cái đặt hàng trong năm, chúng tôi sẵn sàng tặng một bộ thiết kế bao bì cơ bản. Vậy 50 đô, đặt 8000 cái/năm, thiết kế bao bì miễn phí, chốt được không?"
        },
        {
          "speaker": "Anh Khải",
          "zh": "可以成交！我们的目标就是互利共赢，期待和贵公司长期合作。",
          "vi": "Chốt! Mục tiêu của chúng tôi chính là cùng có lợi, mong được hợp tác lâu dài với quý công ty."
        }
      ]
    },
    "notes": [
      {
        "title": "Không bao giờ chấp nhận giá đầu tiên",
        "body": "Đây là quy tắc vàng trong đàm phán với nhà cung cấp TQ. Báo giá đầu tiên gần như luôn có \"nước\" — chỗ để đàm phán xuống. Ngay cả khi giá hợp lý, cũng nên hỏi lại \"còn có thể giảm thêm không?\" để kiểm tra."
      },
      {
        "title": "Chiến thuật \"tôi có báo giá rẻ hơn từ nhà cung cấp khác\"",
        "body": "Đây là chiến thuật đàm phán phổ biến và hợp lệ. Nhưng phải có cơ sở — nếu nói có giá rẻ hơn mà không có thật, và nhà cung cấp hỏi lại thì mất uy tín. Khi dùng chiến thuật này, cần biết rằng nhà máy TQ thường hỏi lại \"ai báo giá đó?\" hoặc \"chất lượng giống nhau không?\"."
      },
      {
        "title": "Dùng điều kiện phi giá để đàm phán",
        "body": "Khi giá đã về gần đáy, hãy đàm phán thêm những giá trị khác: thiết kế bao bì miễn phí, thời hạn giao hàng ngắn hơn, ưu tiên sản xuất, hỗ trợ kỹ thuật, hoặc thanh toán linh hoạt hơn. Như trong hội thoại, anh Khải đã dùng \"thiết kế bao bì\" để thêm giá trị mà không cần nhà máy giảm thêm tiền mặt."
      },
      {
        "title": "Cam kết số lượng: phải thực tế",
        "body": "Khi dùng chiến thuật 以量换价, cam kết phải thực tế. Nếu cam kết 8000 cái nhưng chỉ đặt 3000, nhà máy sẽ nhớ và lần sau sẽ không tin vào cam kết nữa — mất đi đòn bẩy đàm phán quý giá."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Tại sao không nên chấp nhận giá báo đầu tiên của nhà cung cấp TQ?",
          "options": {
            "A": "Vì giá đầu tiên luôn sai",
            "B": "Vì báo giá ban đầu thường có chỗ đàm phán (报价虚高)",
            "C": "Vì luật TQ không cho phép",
            "D": "Vì phải chờ 3 ngày mới được xem giá thật"
          }
        },
        {
          "num": 2,
          "q": "底价 là gì?",
          "options": {
            "A": "Giá thấp nhất thị trường",
            "B": "Mức giá thấp nhất người bán có thể chấp nhận mà không lỗ",
            "C": "Giá bán lẻ cuối cùng",
            "D": "Giá nhập khẩu tối thiểu"
          }
        },
        {
          "num": 3,
          "q": "Chiến thuật 以量换价 có nghĩa là gì?",
          "options": {
            "A": "Giảm chất lượng để giảm giá",
            "B": "Cam kết mua số lượng lớn để đổi lấy đơn giá thấp hơn",
            "C": "Thanh toán nhanh để được giảm giá",
            "D": "Mua nhiều mặt hàng khác nhau cùng lúc"
          }
        },
        {
          "num": 4,
          "q": "Khi nhà máy báo 涨价, người mua nên làm gì?",
          "options": {
            "A": "Chấp nhận ngay vì nguyên liệu tăng là thật",
            "B": "Yêu cầu giải thích chi tiết và đàm phán giảm mức tăng",
            "C": "Hủy đơn hàng ngay lập tức",
            "D": "Không phản ứng gì"
          }
        },
        {
          "num": 5,
          "q": "锁价 có lợi cho ai hơn?",
          "options": {
            "A": "Người bán",
            "B": "Người mua vì giúp ổn định chi phí kế hoạch",
            "C": "Cả hai bên như nhau",
            "D": "Công ty vận chuyển"
          }
        },
        {
          "num": 6,
          "q": "Khi đàm phán đến mức giá gần đáy, chiến thuật nào tốt hơn?",
          "options": {
            "A": "Tiếp tục ép giá tiền mặt",
            "B": "Đàm phán thêm giá trị phi tiền tệ (thiết kế, dịch vụ, ưu tiên sản xuất...)",
            "C": "Đe dọa chuyển sang nhà cung cấp khác",
            "D": "Kết thúc đàm phán"
          }
        },
        {
          "num": 7,
          "q": "互利共赢 mô tả mục tiêu đàm phán nào?",
          "options": {
            "A": "Người mua thắng hoàn toàn",
            "B": "Người bán thắng hoàn toàn",
            "C": "Cả hai bên đều có lợi",
            "D": "Người trung gian có lợi"
          }
        },
        {
          "num": 8,
          "q": "让步 trong đàm phán cần nguyên tắc gì?",
          "options": {
            "A": "Chỉ một bên nhượng bộ",
            "B": "Có đi có lại — nếu một bên nhượng bộ, bên kia cũng nên đổi lại điều gì đó",
            "C": "Nhượng bộ càng nhiều càng tốt",
            "D": "Không bao giờ nhượng bộ"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Cam kết số lượng lớn để đổi giá tốt hơn chỉ hiệu quả nếu thực sự thực hiện được cam kết đó."
        },
        {
          "num": 10,
          "q": "砍价 bị coi là bất lịch sự trong văn hóa kinh doanh TQ."
        },
        {
          "num": 11,
          "q": "Khi nói \"tôi có báo giá rẻ hơn từ nhà cung cấp khác\", không cần phải có báo giá thực tế."
        },
        {
          "num": 12,
          "q": "Đàm phán để được thiết kế bao bì miễn phí là hình thức đàm phán giá trị phi tiền tệ."
        },
        {
          "num": 13,
          "q": "底价 là thông tin nhà cung cấp thường tự nguyện tiết lộ để đàm phán nhanh hơn."
        },
        {
          "num": 14,
          "q": "锁价 giúp người mua lên kế hoạch chi phí mà không lo giá tăng trong kỳ hạn đã chốt."
        }
      ],
      "fillblank": {
        "wordbank": [
          "砍价",
          "让步",
          "底价",
          "折扣",
          "成交",
          "互利共赢"
        ],
        "items": [
          {
            "num": 15,
            "q": "你们的报价有点高，我们能不能____一下，争取一个更合理的价格？"
          },
          {
            "num": 16,
            "q": "我们在价格上已经____了很多，希望你们在交期上也能灵活一点。"
          },
          {
            "num": 17,
            "q": "这已经是我们的____了，再低真的做不到。"
          },
          {
            "num": 18,
            "q": "订单量达到3000个以上，我们可以给10%的____。"
          },
          {
            "num": 19,
            "q": "如果你们同意50美元FOB，我们现在就可以____！"
          },
          {
            "num": 20,
            "q": "我们双方的目标都是____，建立长期稳定的合作关系。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "你们的报价比市场价高了10%，我们希望能降到更有竞争力的水平，否则我们需要考虑其他供应商。"
        },
        {
          "num": 22,
          "q": "如果你们能承诺年采购量10000个，我们可以在现有价格基础上再降5%，这已经是我们的极限了。"
        },
        {
          "num": 23,
          "q": "价格方面我们可以接受，但希望你们能把交货期从45天缩短到30天，作为对我们的额外支持。"
        },
        {
          "num": 24,
          "q": "我们希望锁价一年，这样我们可以给美国客户报一个稳定的价格，双方都有保障。"
        },
        {
          "num": 25,
          "q": "由于铜价上涨了30%，我们不得不调整报价，但我们尽量将涨幅控制在8%，请理解。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Báo giá của anh là 60 đô, nhưng nhà cung cấp khác báo 54 đô cho sản phẩm tương đương. Anh có thể xem xét lại không?"
        },
        {
          "num": 27,
          "q": "Nếu chúng tôi tăng số lượng lên 5000 cái, giá có thể giảm bao nhiêu? Chúng tôi muốn dùng số lượng đổi lấy giá tốt hơn."
        },
        {
          "num": 28,
          "q": "Chúng tôi có thể chấp nhận 52 đô nếu anh cam kết giao hàng trong 25 ngày thay vì 40 ngày."
        },
        {
          "num": 29,
          "q": "Đây là lần đầu hợp tác, sau khi tin tưởng nhau rồi, chúng tôi sẽ tăng đơn hàng — đó mới là hợp tác cùng có lợi thực sự."
        },
        {
          "num": 30,
          "q": "Chúng tôi muốn chốt giá cho 12 tháng, anh có thể đảm bảo giá không đổi trong thời gian đó không?"
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "C",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": false,
        "11": false,
        "12": true,
        "13": false,
        "14": true
      },
      "fillblank": {
        "15": "砍价",
        "16": "让步",
        "17": "底价",
        "18": "折扣",
        "19": "成交",
        "20": "互利共赢"
      },
      "zh2vi": {
        "21": "Báo giá của anh cao hơn giá thị trường 10%, chúng tôi hy vọng có thể giảm xuống mức cạnh tranh hơn, nếu không chúng tôi cần xem xét nhà cung cấp khác.",
        "22": "Nếu các anh cam kết đặt 10000 cái/năm, chúng tôi có thể giảm thêm 5% so với giá hiện tại, đây đã là giới hạn của chúng tôi.",
        "23": "Về giá chúng tôi có thể chấp nhận, nhưng mong các anh rút ngắn thời gian giao hàng từ 45 ngày xuống 30 ngày như một sự hỗ trợ thêm cho chúng tôi.",
        "24": "Chúng tôi muốn chốt giá một năm, như vậy có thể báo giá ổn định cho khách Mỹ, cả hai bên đều có đảm bảo.",
        "25": "Do giá đồng tăng 30%, chúng tôi buộc phải điều chỉnh báo giá, nhưng chúng tôi cố gắng kiểm soát mức tăng ở 8%, mong anh thông cảm."
      },
      "vi2zh": {
        "26": "您的报价是60美元，但其他供应商报价54美元，产品相当。您能重新考虑一下吗？",
        "27": "如果我们把数量增加到5000个，价格可以降多少？我们想以量换价。",
        "28": "如果您能保证25天交货而不是40天，我们可以接受52美元。",
        "29": "这是我们第一次合作，建立信任之后我们会增加订单量——这才是真正的互利共赢。",
        "30": "我们希望锁定12个月的价格，您能保证这段时间内价格不变吗？"
      }
    }
  },
  {
    "num": 12,
    "title": "HỘI CHỢ TRIỂN LÃM — NGÔN NGỮ TỔNG QUÁT",
    "date": "8/6",
    "phase": 1,
    "vocab": [
      {
        "num": 1,
        "hanzi": "展会",
        "pinyin": "zhǎnhuì",
        "vi": "hội chợ triển lãm",
        "explanation": "Sự kiện thương mại tập hợp nhà sản xuất, nhà cung cấp và người mua từ khắp nơi. Hội chợ lớn nhất TQ cho hàng tiêu dùng là Canton Fair (广交会) tổ chức tại Quảng Châu mỗi năm 2 kỳ. Đây là nơi lý tưởng để tìm nhà cung cấp mới, so sánh sản phẩm, và xây dựng quan hệ trực tiếp.",
        "example": {
          "zh": "我们每年都会参加广交会，今年的展位是B馆3号。",
          "vi": "Chúng tôi tham gia Canton Fair mỗi năm, gian hàng năm nay là Khu B số 3."
        }
      },
      {
        "num": 2,
        "hanzi": "展位",
        "pinyin": "zhǎnwèi",
        "vi": "gian hàng / booth triển lãm",
        "explanation": "Không gian được thuê tại hội chợ để trưng bày sản phẩm. Kích thước từ 9m² (gian nhỏ) đến hàng trăm m² (gian lớn của tập đoàn). Vị trí 展位 quan trọng — gian gần lối vào hay gần khu vực đông khách tham quan thì tốt hơn.",
        "example": {
          "zh": "我们的展位在二楼入口旁边，很好找。",
          "vi": "Gian hàng của chúng tôi ở cạnh lối vào tầng 2, rất dễ tìm."
        }
      },
      {
        "num": 3,
        "hanzi": "样品展示",
        "pinyin": "yàngpǐn zhǎnshì",
        "vi": "trưng bày mẫu sản phẩm",
        "explanation": "Hoạt động cốt lõi tại hội chợ — trưng bày sản phẩm thực tế để khách tham quan có thể nhìn, sờ, thử. Với người mua chuyên nghiệp, việc trực tiếp cầm và kiểm tra sản phẩm quan trọng hơn nhiều so với xem catalog.",
        "example": {
          "zh": "我们在展位上展示了今年的新款产品，欢迎您来体验。",
          "vi": "Chúng tôi trưng bày các sản phẩm mẫu mới năm nay tại gian hàng, hoan nghênh anh đến trải nghiệm."
        }
      },
      {
        "num": 4,
        "hanzi": "名片交换",
        "pinyin": "míngpiàn jiāohuàn",
        "vi": "trao đổi danh thiếp",
        "explanation": "Nghi thức quan trọng tại hội chợ — thu thập danh thiếp là cách lưu thông tin liên hệ nhanh nhất. Tại Canton Fair, mỗi ngày một nhân viên bán hàng có thể trao đổi hàng chục đến hàng trăm danh thiếp.",
        "example": {
          "zh": "这是我的名片，请问方便留一张您的吗？",
          "vi": "Đây là danh thiếp của tôi, tiện thì anh để lại cho tôi một tấm của anh nhé?"
        }
      },
      {
        "num": 5,
        "hanzi": "现场演示",
        "pinyin": "xiànchǎng yǎnshì",
        "vi": "demo trực tiếp tại chỗ",
        "explanation": "Nhân viên bán hàng trực tiếp thao tác/trình bày tính năng sản phẩm ngay tại gian hàng. Đặc biệt quan trọng với sản phẩm điện tử, máy móc, hoặc hàng có tính năng phức tạp.",
        "example": {
          "zh": "我来给您做一个现场演示，看看这款产品的主要功能。",
          "vi": "Để tôi demo trực tiếp cho anh xem, giới thiệu các tính năng chính của sản phẩm này."
        }
      },
      {
        "num": 6,
        "hanzi": "参展商",
        "pinyin": "cānzhǎn shāng",
        "vi": "đơn vị tham gia triển lãm / exhibitor",
        "explanation": "Công ty hoặc tổ chức có gian hàng tại hội chợ. Phân biệt với 参观者 (visitor) — khách tham quan không có gian hàng. Một hội chợ lớn như Canton Fair có hàng nghìn 参展商 từ khắp TQ và thế giới.",
        "example": {
          "zh": "今年广交会有超过两万家参展商，规模非常大。",
          "vi": "Năm nay Canton Fair có hơn 20.000 đơn vị tham gia, quy mô rất lớn."
        }
      },
      {
        "num": 7,
        "hanzi": "意向客户",
        "pinyin": "yìxiàng kèhù",
        "vi": "khách hàng tiềm năng",
        "explanation": "Người tham quan thể hiện sự quan tâm đến sản phẩm nhưng chưa quyết định mua. Mục tiêu của nhân viên tại hội chợ là chuyển đổi 意向客户 thành 正式客户 (khách hàng thực sự). Sau hội chợ, follow-up kịp thời là chìa khóa để không mất khách hàng tiềm năng.",
        "example": {
          "zh": "这次展会我们接待了超过200个意向客户，后续跟进工作很重要。",
          "vi": "Lần hội chợ này chúng tôi tiếp đón hơn 200 khách hàng tiềm năng, công việc theo dõi sau đó rất quan trọng."
        }
      },
      {
        "num": 8,
        "hanzi": "广交会",
        "pinyin": "Guǎngjiāohuì",
        "vi": "Canton Fair (Hội chợ xuất nhập khẩu Trung Quốc)",
        "explanation": "Hội chợ thương mại lớn nhất TQ, tổ chức tại Quảng Châu mỗi năm 2 lần (tháng 4 và tháng 10), chia làm 3 giai đoạn cho các ngành khác nhau. Đây là điểm đến bắt buộc cho bất kỳ ai làm xuất nhập khẩu TQ nghiêm túc. Hội chợ thu hút hàng trăm nghìn khách từ hơn 200 quốc gia.",
        "example": {
          "zh": "广交会是我们每年最重要的获客渠道之一。",
          "vi": "Canton Fair là một trong những kênh tìm kiếm khách hàng quan trọng nhất của chúng tôi mỗi năm."
        }
      },
      {
        "num": 9,
        "hanzi": "洽谈",
        "pinyin": "qiàtán",
        "vi": "đàm phán / thảo luận kinh doanh",
        "explanation": "Cuộc trò chuyện kinh doanh nghiêm túc tại hội chợ — thảo luận về sản phẩm, giá cả, điều kiện hợp tác. Khác với giai đoạn chào hỏi xã giao ban đầu. Khi bắt đầu 洽谈, cả hai bên đã thể hiện sự quan tâm thực sự đến hợp tác.",
        "example": {
          "zh": "如果您有兴趣，我们可以找个安静的地方详细洽谈。",
          "vi": "Nếu anh quan tâm, chúng ta có thể tìm chỗ yên tĩnh để đàm phán chi tiết hơn."
        }
      },
      {
        "num": 10,
        "hanzi": "后续跟进",
        "pinyin": "hòuxù gēnjìn",
        "vi": "theo dõi sau / follow-up",
        "explanation": "Hành động liên hệ lại với khách hàng tiềm năng sau hội chợ để tiếp tục quá trình bán hàng. Đây là bước quan trọng nhất — 80% cơ hội từ hội chợ bị mất vì thiếu follow-up kịp thời và chuyên nghiệp. Nên follow-up trong vòng 48 giờ sau khi gặp.",
        "example": {
          "zh": "展会结束后，我们会在48小时内给所有意向客户发邮件跟进。",
          "vi": "Sau khi hội chợ kết thúc, chúng tôi sẽ gửi email theo dõi cho tất cả khách hàng tiềm năng trong 48 giờ."
        }
      }
    ],
    "dialogue": {
      "context": "Tại Canton Fair tháng 4. Anh Hùng (buyer VN) đang tham quan gian hàng của một nhà máy sản xuất đồ gia dụng TQ. Bạn là phiên dịch đi cùng.",
      "characters": [
        {
          "name": "销售代表小刘 (Xiǎo Liú)",
          "role": "Nhân viên kinh doanh nhà máy TQ tại hội chợ"
        },
        {
          "name": "Anh Hùng",
          "role": "Buyer VN"
        }
      ],
      "lines": [
        {
          "speaker": "小刘",
          "zh": "您好，欢迎来到我们的展位！我是小刘，请问您是做哪个市场的？",
          "vi": "Xin chào, chào mừng đến gian hàng của chúng tôi! Tôi là Tiểu Lưu, xin hỏi anh làm thị trường nào?"
        },
        {
          "speaker": "Anh Hùng",
          "zh": "你好，我们是越南公司，主要做出口美国的贸易，在亚马逊上销售。",
          "vi": "Chào, chúng tôi là công ty Việt Nam, chủ yếu làm thương mại xuất khẩu sang Mỹ, bán trên Amazon."
        },
        {
          "speaker": "小刘",
          "zh": "太好了，我们很多产品都很适合亚马逊市场。请问您对哪类产品感兴趣？我们主要做厨房用品和居家收纳系列。",
          "vi": "Tuyệt quá, nhiều sản phẩm của chúng tôi rất phù hợp với thị trường Amazon. Anh quan tâm đến loại sản phẩm nào? Chúng tôi chủ yếu làm đồ dùng nhà bếp và dòng đồ chứa đựng gia dụng."
        },
        {
          "speaker": "Anh Hùng",
          "zh": "我对你们的收纳系列比较感兴趣，能给我介绍一下吗？",
          "vi": "Tôi khá quan tâm đến dòng đồ chứa đựng của anh, anh có thể giới thiệu không?"
        },
        {
          "speaker": "小刘",
          "zh": "当然，请跟我来。这是我们今年的新款多功能收纳盒，采用环保PP材料，通过了美国FDA认证，适合食品接触。这一款在美国亚马逊上已经有很好的销售记录了。",
          "vi": "Tất nhiên, mời anh theo tôi. Đây là mẫu hộp đựng đa năng mới năm nay, làm bằng vật liệu PP thân thiện môi trường, đã qua chứng nhận FDA Mỹ, phù hợp tiếp xúc thực phẩm. Mẫu này đã có doanh số tốt trên Amazon Mỹ rồi."
        },
        {
          "speaker": "Anh Hùng",
          "zh": "材料是PP，FDA认证我们有要求。价格大概是多少，FOB价？",
          "vi": "Vật liệu PP, chứng nhận FDA là yêu cầu của chúng tôi. Giá khoảng bao nhiêu, giá FOB?"
        },
        {
          "speaker": "小刘",
          "zh": "这款产品的FOB广州价是3.8美元，起订量是500个。如果量大可以进一步商谈。这是我们的产品目录和报价单，您可以带回去参考。",
          "vi": "Giá FOB cảng Quảng Châu mẫu này là 3,8 đô, MOQ 500 cái. Nếu số lượng lớn có thể bàn thêm. Đây là catalog và bảng báo giá của chúng tôi, anh mang về tham khảo."
        },
        {
          "speaker": "Anh Hùng",
          "zh": "好，我先看看。能不能留一个样品给我？",
          "vi": "Tốt, tôi xem qua. Có thể để lại mẫu cho tôi không?"
        },
        {
          "speaker": "小刘",
          "zh": "当然可以，样品免费提供，快递费您这边承担。这是我的名片，请问方便留一张您的吗？展会之后我会及时跟进。",
          "vi": "Tất nhiên, mẫu cung cấp miễn phí, phí chuyển phát nhanh phía anh chịu. Đây là danh thiếp của tôi, anh có thể để lại cho tôi tấm của anh không? Sau hội chợ tôi sẽ theo dõi kịp thời."
        },
        {
          "speaker": "Anh Hùng",
          "zh": "好的，这是我的名片。我们现在还有时间，能找个地方详细洽谈一下吗？主要想了解你们的OEM能力和最小起订量。",
          "vi": "Được, đây là danh thiếp của tôi. Chúng tôi còn thời gian, có thể tìm chỗ ngồi đàm phán chi tiết không? Chủ yếu muốn tìm hiểu về năng lực OEM và số lượng đặt hàng tối thiểu."
        },
        {
          "speaker": "小刘",
          "zh": "非常欢迎！我们在展位后面有一个洽谈区，请随我来。我们今天专门为有意向的客户准备了详细的资料和样品。",
          "vi": "Rất hoan nghênh! Chúng tôi có khu vực đàm phán phía sau gian hàng, mời anh theo tôi. Hôm nay chúng tôi đã chuẩn bị tài liệu và mẫu chi tiết cho khách hàng có quan tâm thực sự."
        }
      ]
    },
    "notes": [
      {
        "title": "Canton Fair: lịch và cách tham dự",
        "body": "Canton Fair diễn ra 2 lần/năm: tháng 4 (kỳ Xuân) và tháng 10 (kỳ Thu), mỗi kỳ chia 3 giai đoạn khoảng 5 ngày/giai đoạn. Giai đoạn 1: thiết bị điện tử & điện. Giai đoạn 2: đồ dùng gia đình & trang trí. Giai đoạn 3: hàng may mặc & thực phẩm. Đăng ký tham dự miễn phí qua website chính thức. Đặt khách sạn sớm — Quảng Châu kín phòng trong mùa hội chợ."
      },
      {
        "title": "Chiến lược tham quan hội chợ hiệu quả",
        "body": "Không dành quá 5 phút ở mỗi gian hàng khi đang tham quan sơ bộ. Thu thập catalog và danh thiếp ở giai đoạn 1, đánh dấu gian hàng quan tâm, quay lại đàm phán sâu ở giai đoạn 2. Đi với phiên dịch có kinh nghiệm thương mại — không chỉ cần biết dịch, mà cần hiểu ngành."
      },
      {
        "title": "Follow-up là quan trọng nhất",
        "body": "Kết thúc hội chợ, gửi email follow-up trong 48 giờ, nhắc lại nội dung đã trao đổi, gửi thông tin chi tiết đã hứa. Phần lớn đối tác TQ sau hội chợ sẽ ưu tiên xử lý khách hàng follow-up nhanh nhất. Nếu bạn chờ 1–2 tuần sau hội chợ mới liên hệ, họ đã có hàng chục khách mới và bạn không còn ưu tiên nữa."
      },
      {
        "title": "Vai trò phiên dịch tại hội chợ",
        "body": "Phiên dịch tại hội chợ khác phiên dịch trong phòng họp — phải linh hoạt hơn, di chuyển liên tục, dịch nhanh hơn trong môi trường ồn ào. Cần biết trước ngành hàng khách tham quan để không phải giải thích từ đầu khi đến gian hàng. Nếu không biết từ kỹ thuật, hỏi ngay nhân viên gian hàng thay vì đoán."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Canton Fair (广交会) được tổ chức ở đâu và bao nhiêu lần mỗi năm?",
          "options": {
            "A": "Thượng Hải, 1 lần",
            "B": "Quảng Châu, 2 lần mỗi năm",
            "C": "Bắc Kinh, 3 lần mỗi năm",
            "D": "Thâm Quyến, 2 lần mỗi năm"
          }
        },
        {
          "num": 2,
          "q": "Khi tham quan hội chợ, chiến lược nào hiệu quả nhất?",
          "options": {
            "A": "Dành nhiều thời gian ở mỗi gian hàng ngay từ đầu",
            "B": "Tham quan sơ bộ trước, đánh dấu gian quan tâm, quay lại đàm phán sau",
            "C": "Chỉ đến gian hàng của các thương hiệu lớn",
            "D": "Không cần chuẩn bị trước"
          }
        },
        {
          "num": 3,
          "q": "Follow-up sau hội chợ nên thực hiện trong bao lâu?",
          "options": {
            "A": "2 tuần",
            "B": "1 tháng",
            "C": "48 giờ",
            "D": "1 tuần"
          }
        },
        {
          "num": 4,
          "q": "意向客户 là ai?",
          "options": {
            "A": "Khách hàng đã ký hợp đồng",
            "B": "Người quan tâm đến sản phẩm nhưng chưa quyết định mua",
            "C": "Khách hàng VIP của công ty",
            "D": "Người mua lần đầu tiên"
          }
        },
        {
          "num": 5,
          "q": "洽谈 khác giai đoạn chào hỏi ban đầu như thế nào?",
          "options": {
            "A": "Hoàn toàn giống nhau",
            "B": "洽谈 là thảo luận kinh doanh nghiêm túc sau khi cả hai bên đã thể hiện quan tâm",
            "C": "洽谈 không cần phiên dịch",
            "D": "洽谈 chỉ diễn ra sau khi ký hợp đồng"
          }
        },
        {
          "num": 6,
          "q": "Vị trí 展位 tại hội chợ ảnh hưởng đến điều gì?",
          "options": {
            "A": "Chất lượng sản phẩm",
            "B": "Số lượng khách tham quan ghé gian hàng",
            "C": "Giá báo tại hội chợ",
            "D": "Thời gian setup gian hàng"
          }
        },
        {
          "num": 7,
          "q": "Tại sao phiên dịch tại hội chợ khó hơn trong phòng họp?",
          "options": {
            "A": "Từ vựng khó hơn",
            "B": "Phải linh hoạt, di chuyển, dịch nhanh trong môi trường ồn ào",
            "C": "Cần biết tiếng Anh thêm",
            "D": "Thời gian dài hơn"
          }
        },
        {
          "num": 8,
          "q": "Giai đoạn Canton Fair nào phù hợp nhất cho người mua đồ gia dụng?",
          "options": {
            "A": "Giai đoạn 1 (điện tử)",
            "B": "Giai đoạn 2 (đồ gia dụng & trang trí)",
            "C": "Giai đoạn 3 (may mặc & thực phẩm)",
            "D": "Cả ba giai đoạn như nhau"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Tham dự Canton Fair với tư cách buyer là miễn phí."
        },
        {
          "num": 10,
          "q": "Nếu chờ 1–2 tuần sau hội chợ mới follow-up, cơ hội hợp tác giảm đáng kể."
        },
        {
          "num": 11,
          "q": "Trực tiếp cầm và kiểm tra sản phẩm tại hội chợ quan trọng hơn chỉ xem catalog."
        },
        {
          "num": 12,
          "q": "Phiên dịch tại hội chợ chỉ cần biết dịch ngôn ngữ, không cần hiểu về ngành hàng."
        },
        {
          "num": 13,
          "q": "Canton Fair là hội chợ lớn nhất TQ và một trong những hội chợ thương mại lớn nhất thế giới."
        },
        {
          "num": 14,
          "q": "后续跟进 (follow-up) sau hội chợ là bước quan trọng nhất để chuyển đổi khách hàng tiềm năng."
        }
      ],
      "fillblank": {
        "wordbank": [
          "展会",
          "展位",
          "意向客户",
          "洽谈",
          "广交会",
          "后续跟进"
        ],
        "items": [
          {
            "num": 15,
            "q": "我们今年参加了____，在B馆有一个12平米的____。"
          },
          {
            "num": 16,
            "q": "这次____我们遇到了很多来自东南亚的____，质量都很高。"
          },
          {
            "num": 17,
            "q": "如果您感兴趣，我们可以到旁边的安静区域____，详细介绍产品和价格。"
          },
          {
            "num": 18,
            "q": "展会结束后的____非常重要，我们要在48小时内联系所有有兴趣的客户。"
          },
          {
            "num": 19,
            "q": "____每年春秋各举办一次，是全球最大的贸易展之一。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 20,
          "q": "我们每年都会参加广交会，今年的展位在B馆126号，欢迎您来参观洽谈。"
        },
        {
          "num": 21,
          "q": "这次展会我们带来了20多款新品，都是专门针对北美市场设计的，符合FDA和CPSC标准。"
        },
        {
          "num": 22,
          "q": "这是我们的产品目录，里面有详细的规格参数和起订量，您有时间的话我们可以坐下来洽谈。"
        },
        {
          "num": 23,
          "q": "展会结束后我会发邮件给您，把今天介绍的产品详细资料和最新报价单发给您，方便后续跟进。"
        },
        {
          "num": 24,
          "q": "我们今年新推出了一款环保系列，用的都是可回收材料，非常适合对绿色产品有要求的市场。"
        }
      ],
      "vi2zh": [
        {
          "num": 25,
          "q": "Gian hàng của anh ở đâu? Chúng tôi muốn đến tham quan sản phẩm mới của anh."
        },
        {
          "num": 26,
          "q": "Chúng tôi đang tìm nhà cung cấp cho dòng sản phẩm bếp, có thể cho tôi catalog và bảng báo giá không?"
        },
        {
          "num": 27,
          "q": "Sản phẩm này có chứng nhận FDA không? Đây là yêu cầu bắt buộc cho thị trường Mỹ của chúng tôi."
        },
        {
          "num": 28,
          "q": "Chúng tôi quan tâm đến sản phẩm này, có thể bố trí chỗ ngồi đàm phán chi tiết không?"
        },
        {
          "num": 29,
          "q": "Đây là danh thiếp của tôi, sau hội chợ anh nhớ gửi email theo dõi cho tôi nhé."
        },
        {
          "num": 30,
          "q": "Chúng tôi đến Canton Fair lần này với mục tiêu tìm 3 đến 5 nhà cung cấp mới cho năm tới."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "C",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": true,
        "11": true,
        "12": false,
        "13": true,
        "14": true
      },
      "fillblank": {
        "15": [
          "广交会",
          "展位"
        ],
        "16": [
          "展会",
          "意向客户"
        ],
        "17": "洽谈",
        "18": "后续跟进",
        "19": "广交会"
      },
      "zh2vi": {
        "20": "Chúng tôi tham gia Canton Fair mỗi năm, năm nay gian hàng ở B126, hoan nghênh anh đến tham quan đàm phán.",
        "21": "Lần hội chợ này chúng tôi mang theo hơn 20 mẫu sản phẩm mới, đều được thiết kế riêng cho thị trường Bắc Mỹ, đạt tiêu chuẩn FDA và CPSC.",
        "22": "Đây là catalog của chúng tôi, có thông số chi tiết và MOQ, nếu anh có thời gian chúng ta có thể ngồi xuống đàm phán.",
        "23": "Sau hội chợ tôi sẽ gửi email cho anh, gửi kèm tài liệu chi tiết và bảng báo giá mới nhất về các sản phẩm đã giới thiệu hôm nay để tiện follow-up.",
        "24": "Năm nay chúng tôi ra mắt dòng sản phẩm thân thiện môi trường, dùng toàn bộ vật liệu có thể tái chế, rất phù hợp với thị trường yêu cầu sản phẩm xanh."
      },
      "vi2zh": {
        "25": "你们的展位在哪里？我们想来参观一下你们的新产品。",
        "26": "我们正在寻找厨房产品的供应商，可以给我一份产品目录和报价单吗？",
        "27": "这个产品有FDA认证吗？这是我们美国市场的强制要求。",
        "28": "我们对这款产品感兴趣，能安排个地方坐下来详细洽谈吗？",
        "29": "这是我的名片，展会结束后请记得发邮件跟进联系我。",
        "30": "我们这次来广交会的目标是为明年找3到5个新的供应商。"
      }
    }
  },
  {
    "num": 13,
    "title": "OEM/ODM — KHÁI NIỆM & QUY TRÌNH",
    "date": "9/6",
    "phase": 2,
    "vocab": [
      {
        "num": 1,
        "hanzi": "OEM (贴牌生产)",
        "pinyin": "OEM (tiē pái shēngchǎn)",
        "vi": "sản xuất theo thương hiệu khách hàng",
        "explanation": "Original Equipment Manufacturer — nhà máy sản xuất sản phẩm theo thiết kế và thương hiệu của khách hàng. Sản phẩm OEM được bán dưới thương hiệu của người mua, không phải thương hiệu nhà máy. Ví dụ: bạn thiết kế một chiếc ghế, đặt nhà máy TQ sản xuất, gắn logo thương hiệu của bạn rồi bán trên Amazon — đó là OEM.",
        "example": {
          "zh": "我们专门做OEM，客户提供设计，我们负责生产。",
          "vi": "Chúng tôi chuyên làm OEM, khách hàng cung cấp thiết kế, chúng tôi chịu trách nhiệm sản xuất."
        }
      },
      {
        "num": 2,
        "hanzi": "ODM (原始设计制造)",
        "pinyin": "ODM (yuánshǐ shèjì zhìzào)",
        "vi": "thiết kế và sản xuất theo yêu cầu khách",
        "explanation": "Original Design Manufacturer — nhà máy vừa thiết kế vừa sản xuất sản phẩm theo briefing của khách hàng. Khách hàng đưa ra yêu cầu tính năng, kích thước, mục tiêu thị trường — nhà máy tự thiết kế và sản xuất. Linh hoạt hơn OEM nhưng IP thiết kế thường thuộc nhà máy trừ khi mua lại.",
        "example": {
          "zh": "我们有自己的设计团队，可以根据您的需求提供ODM服务。",
          "vi": "Chúng tôi có đội ngũ thiết kế riêng, có thể cung cấp dịch vụ ODM theo yêu cầu của anh."
        }
      },
      {
        "num": 3,
        "hanzi": "私模",
        "pinyin": "sī mó",
        "vi": "khuôn riêng / khuôn độc quyền",
        "explanation": "Khuôn sản xuất được tạo riêng cho một khách hàng cụ thể — sản phẩm từ khuôn này chỉ được sản xuất cho khách hàng đó. Chi phí cao hơn nhưng đảm bảo tính độc quyền thiết kế. Khác với 公模 (khuôn chung) mà nhiều khách có thể dùng.",
        "example": {
          "zh": "为了保证产品独特性，我们建议开私模，避免其他客户用同款外形。",
          "vi": "Để đảm bảo tính độc đáo của sản phẩm, chúng tôi khuyến nghị làm khuôn riêng, tránh khách hàng khác dùng cùng kiểu dáng."
        }
      },
      {
        "num": 4,
        "hanzi": "公模",
        "pinyin": "gōng mó",
        "vi": "khuôn chung / khuôn cơ sở",
        "explanation": "Khuôn có sẵn của nhà máy, nhiều khách hàng có thể cùng dùng. Chi phí thấp hơn nhiều so với khuôn riêng. Phù hợp khi sản phẩm không cần thiết kế độc đáo hoặc khi muốn kiểm tra thị trường trước khi đầu tư khuôn riêng.",
        "example": {
          "zh": "如果预算有限，可以先用我们的公模，改一下颜色和LOGO就可以了。",
          "vi": "Nếu ngân sách hạn chế, có thể dùng khuôn chung của chúng tôi trước, chỉ cần thay màu và logo là được."
        }
      },
      {
        "num": 5,
        "hanzi": "打样周期",
        "pinyin": "dǎyàng zhōuqī",
        "vi": "thời gian làm mẫu",
        "explanation": "Khoảng thời gian từ khi xác nhận yêu cầu đến khi mẫu hoàn thành. Thường từ 7–20 ngày tùy độ phức tạp. 打样周期 là bước đầu tiên trong toàn bộ quy trình OEM/ODM và thường bị underestimate — trễ mẫu = trễ toàn bộ kế hoạch.",
        "example": {
          "zh": "这款产品的打样周期是15天，请您在确认设计后15天内可以收到样品。",
          "vi": "Thời gian làm mẫu của sản phẩm này là 15 ngày, sau khi xác nhận thiết kế 15 ngày anh có thể nhận được mẫu."
        }
      },
      {
        "num": 6,
        "hanzi": "大货生产",
        "pinyin": "dàhuò shēngchǎn",
        "vi": "sản xuất đại trà / sản xuất hàng loạt",
        "explanation": "Giai đoạn sản xuất số lượng lớn sau khi mẫu đã được phê duyệt. Phân biệt với 打样 (làm mẫu) — 大货 mới là sản xuất thực sự. Chất lượng 大货 đôi khi kém hơn mẫu — đây là vấn đề phổ biến và cần kiểm soát.",
        "example": {
          "zh": "样品确认后，大货生产需要30天，请提前安排。",
          "vi": "Sau khi mẫu xác nhận, sản xuất đại trà cần 30 ngày, vui lòng sắp xếp trước."
        }
      },
      {
        "num": 7,
        "hanzi": "品牌授权",
        "pinyin": "pǐnpái shòuquán",
        "vi": "cấp phép thương hiệu / license thương hiệu",
        "explanation": "Quá trình người mua cấp phép chính thức cho nhà máy sử dụng logo và thương hiệu của mình trên sản phẩm. Trong hợp đồng OEM, phải quy định rõ nhà máy chỉ được dùng logo trên sản phẩm sản xuất cho khách hàng đó, không được dùng cho mục đích khác.",
        "example": {
          "zh": "我们的LOGO是注册商标，使用前需要签署品牌授权协议。",
          "vi": "Logo của chúng tôi là thương hiệu đã đăng ký, cần ký thỏa thuận cấp phép thương hiệu trước khi sử dụng."
        }
      },
      {
        "num": 8,
        "hanzi": "工艺文件",
        "pinyin": "gōngyì wénjiàn",
        "vi": "tài liệu kỹ thuật sản xuất",
        "explanation": "Bộ tài liệu mô tả chi tiết cách sản xuất sản phẩm: thông số kỹ thuật, quy trình lắp ráp, tiêu chuẩn chất lượng từng bước. Đây là \"công thức\" của sản phẩm — phải giữ bí mật và yêu cầu nhà máy ký NDA trước khi cung cấp.",
        "example": {
          "zh": "我们会提供详细的工艺文件，请工厂严格按照文件要求生产。",
          "vi": "Chúng tôi sẽ cung cấp tài liệu kỹ thuật chi tiết, đề nghị nhà máy sản xuất theo đúng yêu cầu tài liệu."
        }
      },
      {
        "num": 9,
        "hanzi": "外观专利",
        "pinyin": "wàiguān zhuānlì",
        "vi": "bằng sáng chế kiểu dáng công nghiệp",
        "explanation": "Bảo hộ pháp lý cho hình thức bên ngoài (kiểu dáng) của sản phẩm. Khác với 发明专利 (bằng sáng chế phát minh). Trong thương mại, 外观专利 thường dễ đăng ký hơn và quan trọng để bảo vệ sản phẩm trên Amazon khỏi bị copy.",
        "example": {
          "zh": "这款产品我们已经申请了外观专利，工厂不能向其他客户提供相同外形的产品。",
          "vi": "Sản phẩm này chúng tôi đã đăng ký bằng sáng chế kiểu dáng, nhà máy không được cung cấp sản phẩm cùng kiểu dáng cho khách hàng khác."
        }
      },
      {
        "num": 10,
        "hanzi": "独家合作",
        "pinyin": "dújiā hézuò",
        "vi": "hợp tác độc quyền",
        "explanation": "Thỏa thuận nhà máy chỉ cung cấp sản phẩm đó (hoặc sản phẩm tương tự) cho một khách hàng duy nhất trong một thị trường hoặc khoảng thời gian nhất định. Người mua muốn 独家合作 để bảo vệ lợi thế cạnh tranh; nhà máy thường yêu cầu cam kết số lượng tối thiểu để đổi lại sự độc quyền.",
        "example": {
          "zh": "我们希望签订独家合作协议，保证在美国市场上只有我们销售这款产品。",
          "vi": "Chúng tôi muốn ký thỏa thuận hợp tác độc quyền, đảm bảo chỉ chúng tôi bán sản phẩm này ở thị trường Mỹ."
        }
      }
    ],
    "dialogue": {
      "context": "Công ty VN muốn phát triển sản phẩm OEM riêng để bán trên Amazon, đang họp với nhà máy TQ về quy trình và điều kiện.",
      "characters": [
        {
          "name": "产品经理老吴 (Lǎo Wú)",
          "role": "Quản lý sản phẩm nhà máy TQ"
        },
        {
          "name": "Chị Lan",
          "role": "Giám đốc phát triển sản phẩm công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "Chị Lan",
          "zh": "我们想开发一款专属的OEM产品在亚马逊美国站销售，产品是多功能厨房置物架，我们有自己的设计，但不确定能不能实现。",
          "vi": "Chúng tôi muốn phát triển một sản phẩm OEM riêng để bán trên Amazon Mỹ, sản phẩm là kệ bếp đa năng, chúng tôi có thiết kế riêng nhưng không chắc có thể thực hiện được không."
        },
        {
          "speaker": "老吴",
          "zh": "没问题，我们有十多年的OEM经验，帮很多亚马逊卖家开发过产品。您有设计图纸或者参考图吗？",
          "vi": "Không vấn đề, chúng tôi có hơn 10 năm kinh nghiệm OEM, đã phát triển sản phẩm cho nhiều seller Amazon rồi. Anh/chị có bản vẽ thiết kế hoặc hình tham khảo không?"
        },
        {
          "speaker": "Chị Lan",
          "zh": "有，这是我们的设计草图和功能要求。我们希望做私模，不想跟其他卖家用同款外形。",
          "vi": "Có, đây là bản phác thảo thiết kế và yêu cầu tính năng. Chúng tôi muốn làm khuôn riêng, không muốn dùng cùng kiểu dáng với seller khác."
        },
        {
          "speaker": "老吴",
          "zh": "私模没问题，我先看看设计。这个形状需要开两个模，模具费大概是2万到2万5千元人民币。打样周期是20天左右。",
          "vi": "Khuôn riêng không vấn đề, để tôi xem thiết kế trước. Hình dạng này cần mở 2 khuôn, phí khuôn khoảng 20.000 đến 25.000 nhân dân tệ. Thời gian làm mẫu khoảng 20 ngày."
        },
        {
          "speaker": "Chị Lan",
          "zh": "模具费2万多，我们觉得可以接受。但我有个问题，如果我们花钱开了模，这个模具的所有权是谁的？",
          "vi": "Phí khuôn hơn 20.000 tệ, chúng tôi thấy có thể chấp nhận được. Nhưng tôi có câu hỏi: nếu chúng tôi bỏ tiền làm khuôn, khuôn đó thuộc sở hữu của ai?"
        },
        {
          "speaker": "老吴",
          "zh": "这是个很好的问题。通常来说，客户付的模具费，模具归客户所有，但存放在我们工厂。如果您要带走或者转到其他工厂，需要提前通知我们安排。",
          "vi": "Đây là câu hỏi rất hay. Thông thường khách hàng trả phí khuôn thì khuôn thuộc sở hữu của khách, nhưng được lưu tại nhà máy chúng tôi. Nếu chị muốn mang đi hoặc chuyển sang nhà máy khác, cần thông báo trước để chúng tôi sắp xếp."
        },
        {
          "speaker": "Chị Lan",
          "zh": "好，这个要在合同里写清楚。另外，我们想要独家合作，这款产品只做给我们，不能做给其他客户，可以吗？",
          "vi": "Tốt, điều này phải ghi rõ trong hợp đồng. Ngoài ra chúng tôi muốn hợp tác độc quyền, sản phẩm này chỉ làm cho chúng tôi, không làm cho khách hàng khác, được không?"
        },
        {
          "speaker": "老吴",
          "zh": "独家合作的话，我们需要您承诺一个最低年采购量，比如5000个，这样我们才能保留产能给您。",
          "vi": "Hợp tác độc quyền thì chúng tôi cần chị cam kết số lượng mua tối thiểu hàng năm, ví dụ 5000 cái, như vậy chúng tôi mới giữ công suất sản xuất cho chị được."
        },
        {
          "speaker": "Chị Lan",
          "zh": "5000个可以承诺。还有一个重要问题，我们的品牌LOGO用的是美国注册商标，使用前需要我们签品牌授权协议，工厂这边能配合吗？",
          "vi": "5000 cái có thể cam kết. Còn một vấn đề quan trọng, logo thương hiệu của chúng tôi là thương hiệu đã đăng ký tại Mỹ, trước khi dùng cần chúng tôi ký thỏa thuận cấp phép thương hiệu, nhà máy có thể phối hợp không?"
        },
        {
          "speaker": "老吴",
          "zh": "完全没问题，我们经常跟亚马逊卖家合作，这些都是标准流程，保密协议、品牌授权协议我们都可以签。",
          "vi": "Hoàn toàn không vấn đề, chúng tôi thường xuyên hợp tác với seller Amazon, những cái này đều là quy trình tiêu chuẩn, NDA, thỏa thuận cấp phép thương hiệu chúng tôi đều có thể ký."
        },
        {
          "speaker": "Chị Lan",
          "zh": "好，那我们下一步先把合同框架确定，然后我发正式的设计文件给您，你们评估一下具体的模具费和打样费，我们尽快推进。",
          "vi": "Tốt, vậy bước tiếp theo trước tiên xác định khung hợp đồng, sau đó tôi gửi tài liệu thiết kế chính thức cho anh, anh đánh giá cụ thể phí khuôn và phí làm mẫu, chúng ta đẩy nhanh tiến độ."
        },
        {
          "speaker": "老吴",
          "zh": "好的，我今天下午就发合同草案给您，包括保密条款和知识产权归属，请您的法务确认。",
          "vi": "Được, chiều nay tôi sẽ gửi bản thảo hợp đồng cho chị, bao gồm điều khoản bảo mật và quy thuộc sở hữu trí tuệ, nhờ bộ phận pháp lý của chị xác nhận."
        }
      ]
    },
    "notes": [
      {
        "title": "OEM vs ODM: chọn cái nào?",
        "body": "OEM: bạn có thiết kế, nhà máy chỉ sản xuất. Bạn kiểm soát hoàn toàn thiết kế nhưng tốn công và tiền phát triển. ODM: nhà máy thiết kế và sản xuất theo briefing của bạn. Nhanh hơn và rẻ hơn để bắt đầu, nhưng thiết kế thường không thực sự độc quyền. Với người mới bán Amazon, ODM là điểm khởi đầu tốt hơn; khi có doanh số ổn định mới chuyển sang OEM đầy đủ."
      },
      {
        "title": "Khuôn riêng (私模) vs khuôn chung (公模)",
        "body": "Khuôn chung: rẻ hơn nhiều, có thể bắt đầu ngay, nhưng sản phẩm giống nhiều seller khác. Khuôn riêng: đắt hơn (thường 15.000–50.000 tệ), mất thêm 3–4 tuần, nhưng sản phẩm độc quyền kiểu dáng. Với sản phẩm lần đầu, dùng khuôn chung để test thị trường, sau khi chứng minh được doanh số mới đầu tư khuôn riêng."
      },
      {
        "title": "Hợp đồng OEM cần có những gì",
        "body": "Ngoài các điều khoản thông thường, hợp đồng OEM cần thêm: quy thuộc sở hữu khuôn, điều khoản IP và thiết kế, NDA, điều khoản độc quyền (nếu có), phạm vi sử dụng logo, và điều khoản về chất lượng 大货 phải khớp mẫu."
      },
      {
        "title": "Đăng ký bằng sáng chế kiểu dáng trước khi xuất hàng",
        "body": "Nếu sản phẩm có thiết kế độc đáo, hãy đăng ký 外观专利 tại Mỹ (Design Patent) trước khi bán. Chi phí thường 800–1500 USD với luật sư chuyên sở hữu trí tuệ. Điều này bảo vệ bạn khỏi bị đối thủ copy thiết kế trên Amazon và từ chính nhà máy sản xuất cho bạn."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Điểm khác nhau chính giữa OEM và ODM là gì?",
          "options": {
            "A": "OEM đắt hơn ODM",
            "B": "OEM: khách cung cấp thiết kế; ODM: nhà máy tự thiết kế theo yêu cầu khách",
            "C": "ODM chỉ dùng cho sản phẩm điện tử",
            "D": "OEM nhanh hơn ODM"
          }
        },
        {
          "num": 2,
          "q": "私模 khác 公模 ở điểm nào?",
          "options": {
            "A": "私模 rẻ hơn",
            "B": "私模 là khuôn riêng chỉ dành cho một khách hàng, 公模 là khuôn dùng chung",
            "C": "公模 chất lượng tốt hơn",
            "D": "私模 chỉ dùng cho nhựa"
          }
        },
        {
          "num": 3,
          "q": "Với người mới bán Amazon, nên bắt đầu bằng OEM hay ODM?",
          "options": {
            "A": "OEM vì bảo vệ thiết kế tốt hơn",
            "B": "ODM để bắt đầu nhanh và test thị trường, sau này mới chuyển OEM",
            "C": "Cả hai đều như nhau",
            "D": "Không nên dùng cái nào"
          }
        },
        {
          "num": 4,
          "q": "Để có hợp tác độc quyền (独家合作), người mua thường cần cam kết điều gì?",
          "options": {
            "A": "Thanh toán nhanh hơn",
            "B": "Số lượng mua tối thiểu hàng năm",
            "C": "Không yêu cầu kiểm định bên thứ ba",
            "D": "Chỉ mua một loại sản phẩm"
          }
        },
        {
          "num": 5,
          "q": "品牌授权协议 cần thiết khi nào?",
          "options": {
            "A": "Khi đặt hàng lần đầu tiên",
            "B": "Trước khi nhà máy được phép in logo thương hiệu đã đăng ký lên sản phẩm",
            "C": "Chỉ khi bán ở thị trường Mỹ",
            "D": "Sau khi đã xuất hàng"
          }
        },
        {
          "num": 6,
          "q": "Nếu khách hàng trả phí khuôn, khuôn đó thuộc sở hữu của ai?",
          "options": {
            "A": "Luôn thuộc nhà máy",
            "B": "Thường thuộc khách hàng nhưng lưu tại nhà máy — cần ghi rõ trong hợp đồng",
            "C": "Thuộc nhà nước",
            "D": "Thuộc công ty vận chuyển"
          }
        },
        {
          "num": 7,
          "q": "打样周期 ảnh hưởng đến kế hoạch ra mắt sản phẩm như thế nào?",
          "options": {
            "A": "Không ảnh hưởng",
            "B": "Trễ mẫu dẫn đến trễ toàn bộ kế hoạch — cần tính vào timeline kỹ lưỡng",
            "C": "Chỉ ảnh hưởng nếu mẫu bị lỗi",
            "D": "Chỉ quan trọng với sản phẩm điện tử"
          }
        },
        {
          "num": 8,
          "q": "外观专利 bảo vệ điều gì?",
          "options": {
            "A": "Công thức sản xuất",
            "B": "Kiểu dáng bên ngoài của sản phẩm",
            "C": "Thương hiệu và logo",
            "D": "Quy trình sản xuất"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Chất lượng hàng đại trà (大货) luôn giống hệt mẫu xác nhận."
        },
        {
          "num": 10,
          "q": "NDA và thỏa thuận cấp phép thương hiệu là quy trình tiêu chuẩn khi làm OEM với seller Amazon."
        },
        {
          "num": 11,
          "q": "Dùng khuôn chung (公模) không thể thêm logo riêng của người mua."
        },
        {
          "num": 12,
          "q": "Hợp đồng OEM cần ghi rõ quy thuộc sở hữu khuôn và IP thiết kế."
        },
        {
          "num": 13,
          "q": "独家合作 có lợi hoàn toàn cho người mua mà không cần cam kết gì thêm."
        },
        {
          "num": 14,
          "q": "Đăng ký bằng sáng chế kiểu dáng ở Mỹ giúp bảo vệ thiết kế khỏi bị copy trên Amazon."
        }
      ],
      "fillblank": {
        "wordbank": [
          "OEM",
          "ODM",
          "私模",
          "打样周期",
          "大货生产",
          "独家合作"
        ],
        "items": [
          {
            "num": 15,
            "q": "我们提供设计，工厂负责生产，这是____模式。"
          },
          {
            "num": 16,
            "q": "我们没有自己的设计团队，所以选择____服务，由工厂根据我们的需求设计。"
          },
          {
            "num": 17,
            "q": "为了产品的独特性，我们决定花钱开____，不用公模。"
          },
          {
            "num": 18,
            "q": "样品做好后，____需要30天，请提前安排好生产计划。"
          },
          {
            "num": 19,
            "q": "这款产品的____是15天，也就是说确认设计后两周多就能收到样品。"
          },
          {
            "num": 20,
            "q": "我们希望签署____协议，保证在北美市场只有我们销售这款产品。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "我们可以根据您的设计要求提供OEM服务，也可以由我们的设计团队帮您开发新产品（ODM）。"
        },
        {
          "num": 22,
          "q": "开私模需要一次性投入，但可以保证产品的独特性，避免市场上出现同款竞品。"
        },
        {
          "num": 23,
          "q": "大货生产必须严格按照确认样的标准，如有差异，我们会安排返工或重新生产。"
        },
        {
          "num": 24,
          "q": "独家合作协议需要您承诺年采购量不低于8000个，以确保我们为您保留足够的产能。"
        },
        {
          "num": 25,
          "q": "我们建议您在产品上市前申请美国外观专利，保护设计不被竞争对手复制。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Chúng tôi muốn làm OEM, chúng tôi có sẵn thiết kế, nhà máy chỉ cần sản xuất theo đúng thông số."
        },
        {
          "num": 27,
          "q": "Thời gian làm khuôn riêng là bao lâu và chi phí khoảng bao nhiêu?"
        },
        {
          "num": 28,
          "q": "Sau khi mẫu được duyệt, cần bao lâu để bắt đầu sản xuất đại trà và xuất hàng?"
        },
        {
          "num": 29,
          "q": "Chúng tôi muốn ký thỏa thuận bảo mật và thỏa thuận cấp phép thương hiệu trước khi cung cấp tài liệu thiết kế."
        },
        {
          "num": 30,
          "q": "Hợp tác độc quyền nghĩa là gì cụ thể? Nhà máy có thể sản xuất sản phẩm tương tự cho khách hàng khác không?"
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": false,
        "10": true,
        "11": false,
        "12": true,
        "13": false,
        "14": true
      },
      "fillblank": {
        "15": "OEM",
        "16": "ODM",
        "17": "私模",
        "18": "大货生产",
        "19": "打样周期",
        "20": "独家合作"
      },
      "zh2vi": {
        "21": "Chúng tôi có thể cung cấp dịch vụ OEM theo thiết kế của anh, hoặc đội thiết kế của chúng tôi có thể giúp phát triển sản phẩm mới cho anh (ODM).",
        "22": "Làm khuôn riêng cần đầu tư một lần, nhưng đảm bảo tính độc đáo của sản phẩm, tránh xuất hiện sản phẩm tương tự cạnh tranh trên thị trường.",
        "23": "Sản xuất đại trà phải theo đúng tiêu chuẩn mẫu xác nhận, nếu có sai lệch chúng tôi sẽ sắp xếp làm lại hoặc sản xuất lại.",
        "24": "Thỏa thuận hợp tác độc quyền cần anh cam kết số lượng mua hàng năm không dưới 8000 cái, để đảm bảo chúng tôi giữ đủ công suất sản xuất cho anh.",
        "25": "Chúng tôi khuyến nghị anh đăng ký bằng sáng chế kiểu dáng Mỹ trước khi sản phẩm ra thị trường, bảo vệ thiết kế không bị đối thủ sao chép."
      },
      "vi2zh": {
        "26": "我们想做OEM，我们有现成的设计，工厂只需要按照规格生产就可以。",
        "27": "开私模需要多长时间，费用大概是多少？",
        "28": "样品通过后，需要多长时间才能开始大货生产和出货？",
        "29": "在提供设计文件之前，我们需要先签保密协议和品牌授权协议。",
        "30": "独家合作具体是什么意思？工厂能不能给其他客户生产类似的产品？"
      }
    }
  },
  {
    "num": 14,
    "title": "NỘI THẤT: VẬT LIỆU & SẢN PHẨM",
    "date": "10/6",
    "phase": 2,
    "vocab": [
      {
        "num": 1,
        "hanzi": "实木",
        "pinyin": "shímù",
        "vi": "gỗ đặc / gỗ nguyên khối",
        "explanation": "Gỗ tự nhiên nguyên khối, không ghép hoặc ép. Chất lượng cao nhất trong ngành nội thất, độ bền cao, giá trị thẩm mỹ tốt. Phổ biến nhất là pine (松木 sōngmù), oak (橡木 xiàngmù), walnut (胡桃木 hútáomù), acacia (相思木 xiāngsīmù). Trong thị trường Amazon Mỹ, 实木 sản phẩm có thể bán giá cao hơn 2–3 lần so với MDF.",
        "example": {
          "zh": "这款餐桌是实木的，用的是北美白橡木，质感很好。",
          "vi": "Bàn ăn này làm bằng gỗ đặc, dùng gỗ sồi trắng Bắc Mỹ, cảm giác rất tốt."
        }
      },
      {
        "num": 2,
        "hanzi": "密度板 (MDF)",
        "pinyin": "mìdù bǎn",
        "vi": "ván MDF",
        "explanation": "Medium Density Fiberboard — ván ép từ sợi gỗ và keo. Rẻ hơn gỗ đặc nhiều, bề mặt phẳng mịn dễ sơn phủ, nhưng không chịu nước và nặng hơn. Phổ biến nhất trong đồ nội thất tầm trung. Nhà mua Amazon hay hỏi \"是实木还是MDF?\" để xác định chất lượng.",
        "example": {
          "zh": "这款书柜用的是MDF加实木贴皮，性价比比较高。",
          "vi": "Kệ sách này dùng MDF kết hợp veneer gỗ thật, tính giá cả chất lượng khá tốt."
        }
      },
      {
        "num": 3,
        "hanzi": "刨花板 (颗粒板)",
        "pinyin": "pàohuā bǎn",
        "vi": "ván dăm (Particle Board)",
        "explanation": "Ván ép từ mảnh gỗ nhỏ và keo. Rẻ nhất trong nhóm, nhưng nặng, dễ ẩm mốc và kém bền nhất. Thường dùng cho đồ nội thất giá rẻ. Cần phân biệt rõ với MDF khi báo giá vì MDF tốt hơn đáng kể.",
        "example": {
          "zh": "刨花板成本低但不够耐用，建议升级到MDF或实木。",
          "vi": "Ván dăm chi phí thấp nhưng không đủ bền, khuyến nghị nâng cấp lên MDF hoặc gỗ đặc."
        }
      },
      {
        "num": 4,
        "hanzi": "五金件",
        "pinyin": "wǔjīn jiàn",
        "vi": "phụ kiện kim loại / hardware",
        "explanation": "Tất cả các phụ kiện kim loại trong đồ nội thất: bản lề (合页 héyè), tay nắm (拉手 lāshou), thanh trượt ngăn kéo (抽屉导轨 chōuti dǎoguǐ), vít, đinh... Chất lượng 五金件 ảnh hưởng lớn đến trải nghiệm sử dụng — ngăn kéo trơn hay giật cục phụ thuộc vào thanh trượt.",
        "example": {
          "zh": "这款橱柜的五金件用的是德国海蒂诗品牌，质量很好。",
          "vi": "Phụ kiện kim loại của tủ bếp này dùng thương hiệu Hettich Đức, chất lượng rất tốt."
        }
      },
      {
        "num": 5,
        "hanzi": "板材",
        "pinyin": "bǎncái",
        "vi": "vật liệu tấm / panel",
        "explanation": "Thuật ngữ chung chỉ các loại ván/tấm dùng làm đồ nội thất: gỗ đặc, MDF, ván dăm, ván ép (胶合板 jiāohébǎn). Khi đặt hàng OEM nội thất, 板材 là thông số đầu tiên cần xác nhận.",
        "example": {
          "zh": "请告诉我这款产品用的是什么板材，这会影响我们的定价。",
          "vi": "Vui lòng cho biết sản phẩm này dùng loại vật liệu tấm gì, điều này sẽ ảnh hưởng đến định giá của chúng tôi."
        }
      },
      {
        "num": 6,
        "hanzi": "表面处理",
        "pinyin": "biǎomiàn chǔlǐ",
        "vi": "xử lý bề mặt / hoàn thiện bề mặt",
        "explanation": "Quá trình hoàn thiện bề mặt sản phẩm: sơn (喷漆 pēnqī), phủ veneer (贴皮 tiē pí), bọc vải (包布 bāo bù), dán giấy (贴纸 tiē zhǐ). Bề mặt hoàn thiện quyết định ngoại quan và cảm giác khi chạm vào — rất quan trọng với hàng bán online.",
        "example": {
          "zh": "这款产品的表面处理是哑光烤漆，颜色是白色，符合北欧风格。",
          "vi": "Hoàn thiện bề mặt của sản phẩm này là sơn bóng mờ, màu trắng, phù hợp phong cách Bắc Âu."
        }
      },
      {
        "num": 7,
        "hanzi": "承重",
        "pinyin": "chéngzhòng",
        "vi": "tải trọng / khả năng chịu tải",
        "explanation": "Trọng lượng tối đa sản phẩm có thể chịu mà không bị hỏng hoặc biến dạng. Thông số quan trọng với kệ, ghế, bàn. Yêu cầu 承重 thường được ghi rõ trong tiêu chuẩn ASTM (Mỹ) hoặc EN (Châu Âu). Khai sai 承重 = bị trả hàng và review 1 sao.",
        "example": {
          "zh": "这款书架的承重是每层50公斤，符合ASTM F2057标准。",
          "vi": "Kệ sách này tải trọng 50kg mỗi tầng, đạt tiêu chuẩn ASTM F2057."
        }
      },
      {
        "num": 8,
        "hanzi": "环保等级",
        "pinyin": "huánbǎo děngjí",
        "vi": "cấp độ thân thiện môi trường / tiêu chuẩn phát thải",
        "explanation": "Tiêu chuẩn đánh giá lượng formaldehyde phát thải từ gỗ công nghiệp. Tiêu chuẩn TQ: E0 (tốt nhất) < E1 < E2. Tiêu chuẩn Mỹ: CARB Phase 2 (bắt buộc vào California). Hàng bán ở Mỹ (đặc biệt California) phải đạt CARB Phase 2 — không đạt = bị cấm bán.",
        "example": {
          "zh": "我们所有板材都达到CARB Phase 2标准，符合加州法规。",
          "vi": "Tất cả vật liệu tấm của chúng tôi đều đạt tiêu chuẩn CARB Phase 2, tuân thủ quy định bang California."
        }
      },
      {
        "num": 9,
        "hanzi": "安装说明",
        "pinyin": "ānzhuāng shuōmíng",
        "vi": "hướng dẫn lắp ráp",
        "explanation": "Tài liệu hướng dẫn khách hàng tự lắp ráp sản phẩm (RTA — Ready to Assemble). Cực kỳ quan trọng với hàng Amazon — hướng dẫn không rõ ràng = review 1–2 sao, returns cao. Hướng dẫn cần có cả bản vẽ hình ảnh rõ ràng (không chỉ chữ) và có tiếng Anh.",
        "example": {
          "zh": "请确保安装说明清晰易懂，最好有中英文版本，配有详细的图示。",
          "vi": "Vui lòng đảm bảo hướng dẫn lắp ráp rõ ràng dễ hiểu, tốt nhất có cả bản Trung-Anh, kèm hình vẽ chi tiết."
        }
      },
      {
        "num": 10,
        "hanzi": "包装方式",
        "pinyin": "bāozhuāng fāngshì",
        "vi": "phương thức đóng gói",
        "explanation": "Cách thức đóng gói sản phẩm để vận chuyển và bán hàng. Với đồ nội thất Amazon, đóng gói cần đảm bảo: bảo vệ sản phẩm khỏi hư hỏng trong vận chuyển, dễ mở, trông đẹp khi khách mở hộp (unboxing experience). Bọc xốp (泡沫 pàomò), carton cứng (硬纸箱 yìng zhǐxiāng), và góc bảo vệ (护角 hùjiǎo) là tiêu chuẩn.",
        "example": {
          "zh": "亚马逊FBA对包装有严格要求，请确保包装能承受多次搬运不损坏产品。",
          "vi": "Amazon FBA có yêu cầu nghiêm ngặt về đóng gói, vui lòng đảm bảo đóng gói chịu được nhiều lần di chuyển mà sản phẩm không bị hư hỏng."
        }
      }
    ],
    "dialogue": {
      "context": "Buyer VN đang đặt hàng kệ sách để bán Amazon Mỹ, đang xác nhận thông số vật liệu với nhà máy.",
      "characters": [
        {
          "name": "工厂产品专员小胡 (Xiǎo Hú)",
          "role": "Chuyên viên sản phẩm nhà máy"
        },
        {
          "name": "Anh Minh",
          "role": "Nhân viên thu mua VN"
        }
      ],
      "lines": [
        {
          "speaker": "Anh Minh",
          "zh": "我们要订一款5层书架，准备在美国亚马逊销售，我需要确认一下材料和规格。",
          "vi": "Chúng tôi muốn đặt kệ sách 5 tầng để bán trên Amazon Mỹ, cần xác nhận thông số vật liệu và thông số kỹ thuật."
        },
        {
          "speaker": "小胡",
          "zh": "好的。请问您对材料有什么要求？我们目前有三种材料可以选：实木松木、MDF、和颗粒板。",
          "vi": "Được. Anh có yêu cầu gì về vật liệu? Hiện tại chúng tôi có 3 loại: gỗ đặc thông, MDF và ván dăm."
        },
        {
          "speaker": "Anh Minh",
          "zh": "美国客户比较在意材料，我们希望用实木，但成本也要控制。有没有折中的方案？",
          "vi": "Khách Mỹ khá quan tâm đến vật liệu, chúng tôi muốn dùng gỗ đặc nhưng chi phí cũng cần kiểm soát. Có phương án trung gian nào không?"
        },
        {
          "speaker": "小胡",
          "zh": "有的，可以考虑实木框架加MDF背板的方案，既有实木的质感，成本比全实木低30%左右。",
          "vi": "Có, có thể xem xét phương án khung gỗ đặc kết hợp tấm lưng MDF, vừa có cảm giác gỗ thật, chi phí thấp hơn gỗ đặc toàn phần khoảng 30%."
        },
        {
          "speaker": "Anh Minh",
          "zh": "这个方案可以接受。那表面处理怎么做？我们的目标风格是北欧简约，颜色倾向白色或浅木色。",
          "vi": "Phương án này chấp nhận được. Vậy xử lý bề mặt thế nào? Phong cách mục tiêu của chúng tôi là Bắc Âu tối giản, nghiêng về màu trắng hoặc màu gỗ nhạt."
        },
        {
          "speaker": "小胡",
          "zh": "白色的话我们可以做哑光白漆，质感很好；浅木色可以做实木贴皮加清漆，保留木纹。这两种方案我们都有成熟工艺。",
          "vi": "Màu trắng có thể làm sơn trắng mờ, cảm giác rất tốt; màu gỗ nhạt có thể làm veneer gỗ thật kết hợp dầu sơn trong, giữ nguyên vân gỗ. Cả hai phương án chúng tôi đều có quy trình thành thục."
        },
        {
          "speaker": "Anh Minh",
          "zh": "先做哑光白漆的样品吧。另外，承重方面有什么要求？",
          "vi": "Làm mẫu sơn trắng mờ trước nhé. Ngoài ra tải trọng có yêu cầu gì không?"
        },
        {
          "speaker": "小胡",
          "zh": "我们的5层书架，每层承重测试是60公斤，整体承重200公斤，符合ASTM F2057标准，这个数据我们可以出检测报告。",
          "vi": "Kệ sách 5 tầng của chúng tôi, mỗi tầng kiểm tra tải trọng 60kg, tổng tải trọng 200kg, đạt tiêu chuẩn ASTM F2057, dữ liệu này chúng tôi có thể xuất báo cáo kiểm định."
        },
        {
          "speaker": "Anh Minh",
          "zh": "CARB Phase 2达标吗？加州的客户特别关注这个。",
          "vi": "Đạt CARB Phase 2 không? Khách hàng California đặc biệt quan tâm điểm này."
        },
        {
          "speaker": "小胡",
          "zh": "我们所有板材都是E0环保等级，完全达到CARB Phase 2标准，可以提供相关证书。",
          "vi": "Tất cả vật liệu tấm của chúng tôi đều ở cấp độ E0 thân thiện môi trường, hoàn toàn đạt tiêu chuẩn CARB Phase 2, có thể cung cấp chứng nhận liên quan."
        },
        {
          "speaker": "Anh Minh",
          "zh": "很好。最后，亚马逊FBA对包装有要求，这款产品你们是怎么包装的？",
          "vi": "Tốt. Cuối cùng, Amazon FBA có yêu cầu về đóng gói, sản phẩm này anh đóng gói thế nào?"
        },
        {
          "speaker": "小胡",
          "zh": "我们用双层硬纸箱，内部四角有泡沫护角，每个层板单独用气泡膜包裹，测试过从1.2米高度跌落不破损。安装说明是中英双语，有详细图示，很多客户反映安装方便。",
          "vi": "Chúng tôi dùng thùng carton 2 lớp, bên trong 4 góc có xốp bảo vệ, mỗi tấm kệ được quấn riêng bằng màng bóng khí, đã test rơi từ độ cao 1,2m không vỡ. Hướng dẫn lắp ráp bằng cả tiếng Trung và tiếng Anh, có hình vẽ chi tiết, nhiều khách phản hồi lắp ráp dễ dàng."
        },
        {
          "speaker": "Anh Minh",
          "zh": "好，那我们先下100个的试单，确认实物质量后再下大货。",
          "vi": "Tốt, vậy chúng tôi đặt thử 100 cái trước, xác nhận chất lượng thực tế rồi mới đặt hàng đại trà."
        }
      ]
    },
    "notes": [
      {
        "title": "Tháp vật liệu nội thất: gỗ đặc > MDF > ván dăm",
        "body": "Khi chọn vật liệu, hiểu rõ hierarchy: gỗ đặc (实木) tốt nhất nhưng đắt nhất; MDF (密度板) tốt thứ hai, bề mặt đẹp, giá trung bình; ván dăm (刨花板) rẻ nhất nhưng kém bền nhất. Phương án ghép (thực gỗ + MDF) là lựa chọn tốt nhất về chi phí và chất lượng."
      },
      {
        "title": "CARB Phase 2: bắt buộc cho thị trường Mỹ",
        "body": "Nếu bán ở California (chiếm 12% dân số Mỹ và là thị trường Amazon lớn nhất), CARB Phase 2 không phải lựa chọn mà là bắt buộc. Phạt vi phạm rất nặng. Luôn yêu cầu nhà máy cung cấp chứng nhận CARB Phase 2 và giữ lại."
      },
      {
        "title": "Hướng dẫn lắp ráp: nguyên nhân thầm lặng của review xấu",
        "body": "Đồ nội thất RTA (Ready to Assemble) thường bị review xấu vì hướng dẫn không rõ. Hướng dẫn tốt cần: sơ đồ hình ảnh rõ ràng (không chỉ chữ), liệt kê đầy đủ phụ kiện kèm theo, cảnh báo bước phức tạp, tiếng Anh đơn giản dễ hiểu. Đầu tư vào hướng dẫn tốt = ít returns và review tốt hơn."
      },
      {
        "title": "Đóng gói cho Amazon FBA",
        "body": "Amazon có tiêu chuẩn đóng gói nghiêm ngặt. Gói hàng phải chịu được 6 mặt áp lực thùng (ISTA 1A test). Sản phẩm lắp ráp cần bọc từng phần riêng. Nhãn barcode phải đặt đúng vị trí và quét được. Vi phạm tiêu chuẩn đóng gói = Amazon từ chối nhận hàng vào kho FBA."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Thứ tự chất lượng từ cao xuống thấp của vật liệu nội thất là gì?",
          "options": {
            "A": "MDF > Gỗ đặc > Ván dăm",
            "B": "Gỗ đặc > MDF > Ván dăm",
            "C": "Ván dăm > MDF > Gỗ đặc",
            "D": "Tất cả như nhau"
          }
        },
        {
          "num": 2,
          "q": "CARB Phase 2 kiểm soát điều gì?",
          "options": {
            "A": "Độ bền vật liệu",
            "B": "Lượng formaldehyde phát thải từ gỗ công nghiệp",
            "C": "Trọng lượng sản phẩm",
            "D": "Màu sắc bề mặt"
          }
        },
        {
          "num": 3,
          "q": "Phương án vật liệu nào cân bằng tốt nhất giữa chi phí và chất lượng cho nội thất Amazon?",
          "options": {
            "A": "Toàn bộ gỗ đặc",
            "B": "Toàn bộ ván dăm",
            "C": "Khung gỗ đặc kết hợp MDF",
            "D": "Toàn bộ MDF"
          }
        },
        {
          "num": 4,
          "q": "五金件 ảnh hưởng đến trải nghiệm người dùng như thế nào?",
          "options": {
            "A": "Không ảnh hưởng",
            "B": "Quyết định trải nghiệm sử dụng (ngăn kéo trơn/giật, bản lề chắc/lỏng...)",
            "C": "Chỉ ảnh hưởng đến ngoại quan",
            "D": "Chỉ quan trọng với đồ gỗ cao cấp"
          }
        },
        {
          "num": 5,
          "q": "Tại sao hướng dẫn lắp ráp kém chất lượng là vấn đề nghiêm trọng với hàng Amazon?",
          "options": {
            "A": "Vi phạm quy định Amazon",
            "B": "Gây review xấu, tăng tỷ lệ returns vì khách không lắp được",
            "C": "Tăng chi phí đóng gói",
            "D": "Không phải vấn đề nghiêm trọng"
          }
        },
        {
          "num": 6,
          "q": "Khi bán đồ nội thất tại California, chứng nhận nào bắt buộc phải có?",
          "options": {
            "A": "ISO 9001",
            "B": "SGS",
            "C": "CARB Phase 2",
            "D": "CE"
          }
        },
        {
          "num": 7,
          "q": "承重 không đủ như mô tả sẽ dẫn đến hậu quả gì?",
          "options": {
            "A": "Hải quan từ chối nhập khẩu",
            "B": "Khách trả hàng và review 1 sao vì sản phẩm không đáp ứng như mô tả",
            "C": "Không có hậu quả",
            "D": "Nhà máy phải bồi thường"
          }
        },
        {
          "num": 8,
          "q": "Đóng gói cho Amazon FBA cần đáp ứng yêu cầu gì quan trọng nhất?",
          "options": {
            "A": "Phải có màu sắc đẹp",
            "B": "Phải chịu được nhiều lần di chuyển mà sản phẩm không bị hư hỏng",
            "C": "Phải bằng vật liệu tái chế",
            "D": "Phải có nhãn tiếng Anh"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "MDF có bề mặt phẳng hơn gỗ đặc và dễ sơn phủ hơn."
        },
        {
          "num": 10,
          "q": "Ván dăm (刨花板) là lựa chọn tốt nhất cho đồ nội thất bán ở thị trường cao cấp."
        },
        {
          "num": 11,
          "q": "CARB Phase 2 là tiêu chuẩn tự nguyện, không bắt buộc khi bán ở California."
        },
        {
          "num": 12,
          "q": "Hướng dẫn lắp ráp chỉ cần chữ, không cần hình ảnh minh họa."
        },
        {
          "num": 13,
          "q": "Phương án khung gỗ đặc + MDF tiết kiệm hơn toàn bộ gỗ đặc khoảng 30%."
        },
        {
          "num": 14,
          "q": "Amazon FBA có tiêu chuẩn nghiêm ngặt về đóng gói và có thể từ chối nhận hàng nếu không đạt."
        }
      ],
      "fillblank": {
        "wordbank": [
          "实木",
          "密度板",
          "五金件",
          "表面处理",
          "承重",
          "环保等级"
        ],
        "items": [
          {
            "num": 15,
            "q": "这款产品的框架是____，背板是____，性价比不错。"
          },
          {
            "num": 16,
            "q": "书架每层的____是多少？美国客户会问ASTM标准。"
          },
          {
            "num": 17,
            "q": "我们用的板材____是E0，完全符合CARB Phase 2标准。"
          },
          {
            "num": 18,
            "q": "抽屉的____用的是什么品牌？希望是德国或者日本的品牌。"
          },
          {
            "num": 19,
            "q": "____是哑光白漆，符合北欧简约风格，在亚马逊很受欢迎。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 20,
          "q": "这款书架采用实木框架加MDF背板，E0环保等级，CARB Phase 2达标，每层承重60公斤。"
        },
        {
          "num": 21,
          "q": "表面处理有三种选择：哑光白漆、哑光黑漆或者实木贴皮加清漆，请问您倾向哪种？"
        },
        {
          "num": 22,
          "q": "我们的五金件全部采用德国海蒂诗品牌，抽屉导轨有阻尼功能，使用寿命超过50000次开合。"
        },
        {
          "num": 23,
          "q": "包装方面，我们用双层硬纸箱加四角泡沫护角，通过ISTA 1A跌落测试，可以安全送达亚马逊FBA仓库。"
        },
        {
          "num": 24,
          "q": "安装说明是中英双语，共16个步骤，每步都有详细图示，平均安装时间约30分钟。"
        }
      ],
      "vi2zh": [
        {
          "num": 25,
          "q": "Sản phẩm này dùng vật liệu gì? Là gỗ đặc, MDF hay ván dăm?"
        },
        {
          "num": 26,
          "q": "Chứng nhận CARB Phase 2 có chưa? Đây là yêu cầu bắt buộc để bán hàng ở California."
        },
        {
          "num": 27,
          "q": "Tải trọng mỗi tầng kệ là bao nhiêu? Khách Mỹ thường hỏi thông số này."
        },
        {
          "num": 28,
          "q": "Hướng dẫn lắp ráp có tiếng Anh không? Phải có hình vẽ rõ ràng cho từng bước."
        },
        {
          "num": 29,
          "q": "Chúng tôi muốn phương án khung gỗ đặc kết hợp MDF, xử lý bề mặt màu trắng mờ."
        },
        {
          "num": 30,
          "q": "Đóng gói phải đủ chắc để hàng không bị hỏng khi vận chuyển vào kho FBA Amazon."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "C",
        "4": "B",
        "5": "B",
        "6": "C",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": false,
        "11": false,
        "12": false,
        "13": true,
        "14": true
      },
      "fillblank": {
        "15": [
          "实木",
          "密度板"
        ],
        "16": "承重",
        "17": "环保等级",
        "18": "五金件",
        "19": "表面处理"
      },
      "zh2vi": {
        "20": "Kệ sách này dùng khung gỗ đặc kết hợp tấm lưng MDF, cấp độ E0 thân thiện môi trường, đạt CARB Phase 2, tải trọng mỗi tầng 60kg.",
        "21": "Xử lý bề mặt có 3 lựa chọn: sơn trắng mờ, sơn đen mờ hoặc veneer gỗ thật kết hợp dầu sơn trong, anh nghiêng về loại nào?",
        "22": "Toàn bộ phụ kiện kim loại của chúng tôi dùng thương hiệu Hettich Đức, thanh trượt ngăn kéo có chức năng giảm chấn, tuổi thọ hơn 50.000 lần đóng mở.",
        "23": "Về đóng gói, chúng tôi dùng thùng carton 2 lớp và xốp bảo vệ 4 góc, đã qua kiểm tra rơi ISTA 1A, có thể vận chuyển an toàn đến kho FBA Amazon.",
        "24": "Hướng dẫn lắp ráp bằng cả tiếng Trung và tiếng Anh, tổng 16 bước, mỗi bước có hình vẽ chi tiết, thời gian lắp ráp trung bình khoảng 30 phút."
      },
      "vi2zh": {
        "25": "这款产品用的是什么材料？是实木、密度板还是刨花板？",
        "26": "有CARB Phase 2认证吗？这是在加州销售的强制要求。",
        "27": "每层的承重是多少？美国客户经常问这个数据。",
        "28": "安装说明有英文版吗？每个步骤必须有清晰的图示。",
        "29": "我们希望用实木框架加MDF的方案，表面处理是哑光白漆。",
        "30": "包装必须足够坚固，确保货物运到亚马逊FBA仓库时不会损坏。"
      }
    }
  },
  {
    "num": 15,
    "title": "NỘI THẤT: TIÊU CHUẨN XUẤT MỸ",
    "date": "11/6",
    "phase": 2,
    "vocab": [
      {
        "num": 1,
        "hanzi": "ASTM标准",
        "pinyin": "ASTM biāozhǔn",
        "vi": "tiêu chuẩn ASTM",
        "explanation": "American Society for Testing and Materials — tổ chức tiêu chuẩn Mỹ, ban hành hàng nghìn tiêu chuẩn kỹ thuật cho vật liệu và sản phẩm. Với đồ nội thất: ASTM F2057 (tủ và kệ chống đổ), ASTM F2933 (đồ trẻ em). Khi bán đồ nội thất ở Mỹ, phải biết mình cần đáp ứng tiêu chuẩn ASTM nào.",
        "example": {
          "zh": "这款书柜需要通过ASTM F2057的防倾倒测试才能在美国销售。",
          "vi": "Kệ sách này cần qua kiểm tra chống đổ ASTM F2057 mới có thể bán ở Mỹ."
        }
      },
      {
        "num": 2,
        "hanzi": "防倾倒装置",
        "pinyin": "fáng qīngdǎo zhuāngzhì",
        "vi": "thiết bị chống đổ (anti-tip device)",
        "explanation": "Dây hoặc thanh neo cố định đồ nội thất cao (tủ, kệ) vào tường để tránh đổ ngã gây thương tích — đặc biệt quan trọng với trẻ em. Sau nhiều vụ tai nạn trẻ em bị tủ đổ đè, Mỹ đã ban hành quy định bắt buộc kèm theo thiết bị chống đổ (anti-tip hardware) với nhiều loại đồ nội thất.",
        "example": {
          "zh": "美国要求所有高柜必须附带防倾倒装置，并在安装说明中注明安装方法。",
          "vi": "Mỹ yêu cầu tất cả tủ cao phải đi kèm thiết bị chống đổ và ghi rõ cách lắp trong hướng dẫn."
        }
      },
      {
        "num": 3,
        "hanzi": "甲醛含量",
        "pinyin": "jiǎquán hánliàng",
        "vi": "hàm lượng formaldehyde",
        "explanation": "Lượng formaldehyde (chất hóa học gây ung thư) phát thải từ vật liệu gỗ ép. Được đo bằng ppm hoặc mg/m². CARB Phase 2 quy định mức tối đa cho từng loại vật liệu. Kiểm tra 甲醛含量 là bắt buộc trước khi xuất sang Mỹ và Châu Âu.",
        "example": {
          "zh": "我们的板材甲醛含量低于CARB Phase 2的标准值，可以提供第三方检测报告。",
          "vi": "Hàm lượng formaldehyde trong vật liệu tấm của chúng tôi thấp hơn mức chuẩn CARB Phase 2, có thể cung cấp báo cáo kiểm định bên thứ ba."
        }
      },
      {
        "num": 4,
        "hanzi": "儿童安全",
        "pinyin": "értóng ānquán",
        "vi": "an toàn trẻ em",
        "explanation": "Tiêu chuẩn và yêu cầu đặc biệt cho sản phẩm có thể tiếp xúc với trẻ em. Bao gồm: không có cạnh sắc, không có vít lộ ra ngoài, không có phụ kiện nhỏ có thể nuốt, sơn không chứa chì (铅). Với đồ nội thất trẻ em, phải đạt ASTM F963 và thường cần kiểm định CPSC (Consumer Product Safety Commission).",
        "example": {
          "zh": "如果产品定位为儿童家具，必须满足更严格的儿童安全标准。",
          "vi": "Nếu sản phẩm định vị là đồ nội thất trẻ em, phải đáp ứng tiêu chuẩn an toàn trẻ em nghiêm ngặt hơn."
        }
      },
      {
        "num": 5,
        "hanzi": "铅含量",
        "pinyin": "qiān hánliàng",
        "vi": "hàm lượng chì",
        "explanation": "Chì trong sơn là mối nguy hiểm đặc biệt với trẻ em. Mỹ quy định sơn trên đồ dùng gia đình không được vượt 90ppm chì theo CPSIA (Consumer Product Safety Improvement Act). Vi phạm = bị thu hồi hàng, phạt nặng, và tổn hại thương hiệu nghiêm trọng.",
        "example": {
          "zh": "所有涂料必须通过铅含量检测，确保低于90ppm，符合CPSIA要求。",
          "vi": "Tất cả sơn phủ phải qua kiểm tra hàm lượng chì, đảm bảo thấp hơn 90ppm, đáp ứng yêu cầu CPSIA."
        }
      },
      {
        "num": 6,
        "hanzi": "加州65号提案",
        "pinyin": "jiāzhōu 65 hào tí'àn",
        "vi": "California Proposition 65",
        "explanation": "Luật California yêu cầu cảnh báo người tiêu dùng nếu sản phẩm chứa hóa chất có thể gây ung thư hoặc dị tật bẩm sinh. Danh sách hóa chất rất dài, bao gồm nhiều chất phổ biến trong nội thất (formaldehyde, chì...). Nếu sản phẩm cần cảnh báo Prop 65, phải in nhãn cảnh báo theo mẫu chuẩn.",
        "example": {
          "zh": "我们需要确认这款产品是否需要加州65号提案的警示标签。",
          "vi": "Chúng tôi cần xác nhận sản phẩm này có cần nhãn cảnh báo California Proposition 65 không."
        }
      },
      {
        "num": 7,
        "hanzi": "承重测试",
        "pinyin": "chéngzhòng cèshì",
        "vi": "kiểm tra tải trọng",
        "explanation": "Thử nghiệm kiểm tra sản phẩm có chịu được tải trọng tối đa đã công bố hay không. Với kệ sách, ghế, bàn — đây là kiểm tra bắt buộc. Phải được thực hiện bởi phòng thí nghiệm độc lập để kết quả có giá trị pháp lý khi marketing ở Mỹ.",
        "example": {
          "zh": "我们的书架通过了第三方承重测试，每层60公斤的承重有检测报告支撑。",
          "vi": "Kệ sách của chúng tôi đã qua kiểm tra tải trọng bên thứ ba, tải trọng 60kg/tầng có báo cáo kiểm định chứng minh."
        }
      },
      {
        "num": 8,
        "hanzi": "UPC码 / 条形码",
        "pinyin": "UPC mǎ / tiáoxíng mǎ",
        "vi": "mã UPC / barcode",
        "explanation": "Universal Product Code — mã vạch duy nhất định danh sản phẩm. Bắt buộc khi bán trên Amazon. Người bán Amazon phải mua UPC từ GS1 (tổ chức cấp phép chính thức) hoặc mua từ reseller (rẻ hơn nhưng có rủi ro). Mỗi biến thể sản phẩm (màu, kích thước khác nhau) cần UPC riêng.",
        "example": {
          "zh": "每个产品变体都需要一个独立的UPC码，请确认你们需要几个。",
          "vi": "Mỗi biến thể sản phẩm cần một UPC riêng, vui lòng xác nhận anh cần bao nhiêu cái."
        }
      },
      {
        "num": 9,
        "hanzi": "FBA标准",
        "pinyin": "FBA biāozhǔn",
        "vi": "tiêu chuẩn FBA (Fulfillment by Amazon)",
        "explanation": "Bộ quy tắc chi tiết của Amazon về cách đóng gói, dán nhãn, và chuẩn bị hàng hóa trước khi gửi vào kho Amazon. Bao gồm: kích thước tối đa, trọng lượng tối đa, yêu cầu barcode FNSKU, quy định đóng gói từng loại sản phẩm. Vi phạm = Amazon từ chối nhận hoặc tính phí xử lý thêm.",
        "example": {
          "zh": "工厂在打包前必须了解亚马逊FBA的包装要求，避免到了仓库被拒收。",
          "vi": "Nhà máy trước khi đóng gói phải hiểu rõ yêu cầu đóng gói FBA Amazon, tránh đến kho bị từ chối nhận."
        }
      },
      {
        "num": 10,
        "hanzi": "退货率",
        "pinyin": "tuìhuò lǜ",
        "vi": "tỷ lệ hoàn hàng (return rate)",
        "explanation": "Tỷ lệ phần trăm sản phẩm bị khách hàng trả lại. Với đồ nội thất Amazon, tỷ lệ hoàn hàng bình thường khoảng 5–8%. Trên 10% là dấu hiệu có vấn đề nghiêm trọng. Nguyên nhân phổ biến: hàng hư hỏng khi vận chuyển, không đúng mô tả, lắp ráp khó, chất lượng kém hơn kỳ vọng.",
        "example": {
          "zh": "我们这款产品的退货率只有4%，在家具类目里属于优秀水平。",
          "vi": "Tỷ lệ hoàn hàng sản phẩm này của chúng tôi chỉ 4%, thuộc mức xuất sắc trong danh mục đồ nội thất."
        }
      }
    ],
    "dialogue": {
      "context": "Cuộc họp giữa nhà máy nội thất TQ và buyer VN để chuẩn bị toàn bộ chứng nhận cần thiết cho thị trường Mỹ.",
      "characters": [
        {
          "name": "品质经理李工 (Lǐ gōng)",
          "role": "Kỹ sư quản lý chất lượng nhà máy"
        },
        {
          "name": "Anh Tân",
          "role": "Nhân viên phát triển sản phẩm công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "Anh Tân",
          "zh": "李工，我们准备把这款衣柜推到美国亚马逊市场，在合规方面需要做哪些准备？",
          "vi": "Kỹ sư Lý, chúng tôi chuẩn bị đưa tủ quần áo này lên Amazon Mỹ, về tuân thủ quy định cần chuẩn bị gì?"
        },
        {
          "speaker": "李工",
          "zh": "美国市场的要求比较多，我来逐一说明。首先是CARB Phase 2，我们的板材已经通过认证，可以提供证书。",
          "vi": "Thị trường Mỹ có nhiều yêu cầu, tôi sẽ giải thích từng điểm. Trước tiên là CARB Phase 2, vật liệu tấm của chúng tôi đã được chứng nhận, có thể cung cấp chứng chỉ."
        },
        {
          "speaker": "Anh Tân",
          "zh": "好，CARB Phase 2没问题。甲醛含量方面呢？",
          "vi": "Tốt, CARB Phase 2 không vấn đề. Còn hàm lượng formaldehyde?"
        },
        {
          "speaker": "李工",
          "zh": "我们的甲醛含量低于0.05ppm，远低于CARB的要求，第三方检测报告可以提供。另外，因为是衣柜，高度超过1.5米，按照美国法规，必须附带防倾倒装置。",
          "vi": "Hàm lượng formaldehyde của chúng tôi thấp hơn 0,05ppm, thấp hơn nhiều so với yêu cầu CARB, báo cáo kiểm định bên thứ ba có thể cung cấp. Ngoài ra, vì là tủ quần áo, chiều cao trên 1,5m, theo quy định Mỹ phải đi kèm thiết bị chống đổ."
        },
        {
          "speaker": "Anh Tân",
          "zh": "防倾倒装置我们知道，这个需要额外的费用吗？",
          "vi": "Thiết bị chống đổ chúng tôi biết, cái này có chi phí thêm không?"
        },
        {
          "speaker": "李工",
          "zh": "防倾倒装置本身很便宜，一套大概2到3元人民币，主要是要确保附在包装里，并且安装说明要清楚注明安装方法，否则亚马逊会有问题。",
          "vi": "Bản thân thiết bị chống đổ rất rẻ, một bộ khoảng 2–3 nhân dân tệ, quan trọng là phải đảm bảo đặt trong hộp hàng, và hướng dẫn lắp ráp phải ghi rõ cách lắp thiết bị này, không thì Amazon sẽ có vấn đề."
        },
        {
          "speaker": "Anh Tân",
          "zh": "明白了。还有关于铅含量，因为表面有喷漆，这个需要检测吗？",
          "vi": "Hiểu rồi. Về hàm lượng chì, vì bề mặt có sơn, cái này cần kiểm tra không?"
        },
        {
          "speaker": "李工",
          "zh": "是的，所有涂料必须通过铅含量检测，我们用的是符合CPSIA要求的水性漆，铅含量远低于90ppm的上限，可以出报告。",
          "vi": "Có, tất cả sơn phủ phải qua kiểm tra hàm lượng chì, chúng tôi dùng sơn gốc nước đạt yêu cầu CPSIA, hàm lượng chì thấp hơn nhiều so với ngưỡng 90ppm, có thể xuất báo cáo."
        },
        {
          "speaker": "Anh Tân",
          "zh": "好。加州65号提案方面怎么处理？",
          "vi": "Tốt. California Proposition 65 xử lý thế nào?"
        },
        {
          "speaker": "李工",
          "zh": "根据我们的检测结果，这款产品不需要加上Prop 65警示标签，因为我们的材料和涂料都符合要求。但我建议您请律师最终确认，因为Prop 65的化学品名单会定期更新。",
          "vi": "Dựa trên kết quả kiểm định của chúng tôi, sản phẩm này không cần dán nhãn cảnh báo Prop 65, vì vật liệu và sơn phủ của chúng tôi đều đạt yêu cầu. Nhưng tôi khuyến nghị anh nhờ luật sư xác nhận lần cuối, vì danh sách hóa chất Prop 65 được cập nhật định kỳ."
        },
        {
          "speaker": "Anh Tân",
          "zh": "好建议，我会安排的。关于FBA包装方面，有什么特别需要注意的吗？",
          "vi": "Gợi ý hay, tôi sẽ sắp xếp. Về đóng gói FBA có gì cần chú ý đặc biệt không?"
        },
        {
          "speaker": "李工",
          "zh": "FBA要求每件产品都有独立的FNSKU标签，另外这款衣柜分5个包装箱，每箱都要有单独的条形码。高度超过140cm的包装箱还需要标注\"双人搬运\"警示。",
          "vi": "FBA yêu cầu mỗi sản phẩm phải có nhãn FNSKU riêng, ngoài ra tủ này chia 5 thùng đóng gói, mỗi thùng phải có barcode riêng. Thùng đóng gói cao trên 140cm còn cần dán cảnh báo \"cần hai người khiêng\"."
        },
        {
          "speaker": "Anh Tân",
          "zh": "好的，我记下了。我们还需要哪些认证吗？",
          "vi": "Tốt, tôi ghi nhớ rồi. Chúng tôi còn cần chứng nhận nào nữa không?"
        },
        {
          "speaker": "李工",
          "zh": "基本上这些就够了，除非您定位为儿童家具，那还需要ASTM F963认证。如果是成人家具，目前这些文件已经足够了。",
          "vi": "Về cơ bản là đủ rồi, trừ khi anh định vị là đồ nội thất trẻ em thì còn cần chứng nhận ASTM F963. Nếu là đồ nội thất người lớn thì những tài liệu này đã đủ rồi."
        }
      ]
    },
    "notes": [
      {
        "title": "Checklist tuân thủ cho nội thất xuất Mỹ",
        "body": "Đây là danh sách kiểm tra tối thiểu: CARB Phase 2 (vật liệu gỗ ép) / Kiểm tra formaldehyde / Kiểm tra chì trong sơn (nếu có sơn) / Chống đổ (nếu tủ/kệ cao >1.5m) / Prop 65 đánh giá / UPC barcode / Hướng dẫn lắp ráp tiếng Anh / Đóng gói đạt FBA."
      },
      {
        "title": "Prop 65: không phải cứ cần nhãn cảnh báo là xấu",
        "body": "Nhiều sản phẩm nội thất TQ bán ở Mỹ có nhãn cảnh báo Prop 65 — điều này không tự động cấm bán. Nhưng nhãn cảnh báo ảnh hưởng đến tâm lý khách hàng và có thể giảm conversion rate trên Amazon. Đầu tư vào vật liệu sạch hơn để không cần nhãn này là chiến lược tốt hơn dài hạn."
      },
      {
        "title": "FNSKU vs UPC: hai loại barcode khác nhau trên Amazon",
        "body": "UPC là barcode thương mại chung. FNSKU là barcode riêng Amazon tạo ra cho từng seller — bắt buộc dán lên sản phẩm khi gửi FBA. Nhà máy TQ có thể dán FNSKU trước khi đóng gói nếu buyer cung cấp file barcode — tiết kiệm chi phí labeling tại kho Amazon."
      },
      {
        "title": "Cảnh báo \"hai người khiêng\": nghiêm túc, không phải trang trí",
        "body": "OSHA và Amazon yêu cầu sản phẩm trên 23kg phải có cảnh báo \"Team lift required\" (两人搬运). Thiếu cảnh báo này = vi phạm an toàn lao động và Amazon có thể từ chối nhận hàng vào kho."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "ASTM F2057 quy định tiêu chuẩn gì?",
          "options": {
            "A": "Hàm lượng formaldehyde trong gỗ",
            "B": "Kiểm tra chống đổ cho tủ và kệ",
            "C": "Hàm lượng chì trong sơn",
            "D": "Đóng gói FBA"
          }
        },
        {
          "num": 2,
          "q": "Thiết bị chống đổ bắt buộc với loại đồ nội thất nào?",
          "options": {
            "A": "Bàn và ghế",
            "B": "Tủ và kệ cao (thường >1.5m)",
            "C": "Giường",
            "D": "Tất cả đồ nội thất"
          }
        },
        {
          "num": 3,
          "q": "CPSIA giới hạn hàm lượng chì trong sơn ở mức nào?",
          "options": {
            "A": "10ppm",
            "B": "50ppm",
            "C": "90ppm",
            "D": "200ppm"
          }
        },
        {
          "num": 4,
          "q": "Nếu sản phẩm không cần nhãn Prop 65, điều đó có nghĩa là gì?",
          "options": {
            "A": "Sản phẩm không có chất hóa học nào",
            "B": "Hàm lượng các chất nguy hiểm trong sản phẩm dưới ngưỡng gây hại theo đánh giá",
            "C": "Sản phẩm chỉ bán ở các bang khác, không bán ở California",
            "D": "Sản phẩm đã được miễn trừ vĩnh viễn"
          }
        },
        {
          "num": 5,
          "q": "FNSKU khác UPC ở điểm nào?",
          "options": {
            "A": "FNSKU dùng cho hàng xuất khẩu, UPC dùng trong nước",
            "B": "FNSKU là barcode riêng Amazon cho từng seller, UPC là barcode thương mại chung",
            "C": "Hoàn toàn giống nhau",
            "D": "FNSKU không cần dán lên sản phẩm"
          }
        },
        {
          "num": 6,
          "q": "Khi nào phải dán cảnh báo \"hai người khiêng\" lên thùng hàng?",
          "options": {
            "A": "Khi thùng cao hơn 1m",
            "B": "Khi sản phẩm nặng hơn 23kg",
            "C": "Khi gửi hàng quốc tế",
            "D": "Khi hàng là đồ nội thất"
          }
        },
        {
          "num": 7,
          "q": "Nếu định vị sản phẩm là đồ nội thất trẻ em, cần thêm chứng nhận nào?",
          "options": {
            "A": "ISO 9001",
            "B": "CARB Phase 2",
            "C": "ASTM F963",
            "D": "SGS"
          }
        },
        {
          "num": 8,
          "q": "Tỷ lệ hoàn hàng bình thường cho đồ nội thất Amazon là bao nhiêu?",
          "options": {
            "A": "Dưới 1%",
            "B": "5–8%",
            "C": "15–20%",
            "D": "Trên 25%"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "CARB Phase 2 chỉ áp dụng cho sản phẩm bán ở California, các bang khác không cần."
        },
        {
          "num": 10,
          "q": "Nhà máy TQ có thể dán FNSKU barcode lên sản phẩm trước khi đóng gói nếu buyer cung cấp file barcode."
        },
        {
          "num": 11,
          "q": "Sản phẩm có nhãn Prop 65 cảnh báo bị cấm bán trên Amazon."
        },
        {
          "num": 12,
          "q": "Thiết bị chống đổ đi kèm là yêu cầu pháp lý ở Mỹ cho tủ và kệ cao, không chỉ là gợi ý."
        },
        {
          "num": 13,
          "q": "Tỷ lệ hoàn hàng 4% cho đồ nội thất Amazon là mức xuất sắc."
        },
        {
          "num": 14,
          "q": "Mỗi biến thể sản phẩm (màu, kích thước khác nhau) cần UPC barcode riêng."
        }
      ],
      "fillblank": {
        "wordbank": [
          "CARB Phase 2",
          "防倾倒装置",
          "甲醛含量",
          "铅含量",
          "FBA标准",
          "退货率"
        ],
        "items": [
          {
            "num": 15,
            "q": "这款衣柜高度1.8米，必须附带____，这是美国法规要求。"
          },
          {
            "num": 16,
            "q": "所有板材必须通过____认证，特别是加州市场。"
          },
          {
            "num": 17,
            "q": "请提供____检测报告，确认低于CARB Phase 2的标准值。"
          },
          {
            "num": 18,
            "q": "喷漆产品需要检测____，必须低于CPSIA规定的90ppm。"
          },
          {
            "num": 19,
            "q": "工厂打包前必须了解____，避免亚马逊仓库拒收。"
          },
          {
            "num": 20,
            "q": "我们的目标是把____控制在5%以下，这需要高质量的包装和清晰的安装说明。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "这款衣柜需要满足以下美国市场要求：CARB Phase 2认证、甲醛检测报告、铅含量检测、防倾倒装置。"
        },
        {
          "num": 22,
          "q": "根据ASTM F2057，高度超过30英寸的储物柜必须配备防倾倒装置，安装说明必须包含安装指引。"
        },
        {
          "num": 23,
          "q": "我们建议请专业律师评估加州65号提案的合规风险，因为化学品名单每年更新。"
        },
        {
          "num": 24,
          "q": "FBA包装要求每个独立产品贴FNSKU标签，5箱以上的产品组还需要外箱条形码和重量标注。"
        },
        {
          "num": 25,
          "q": "我们这款产品的退货率只有3.8%，主要得益于清晰的安装说明和牢固的包装。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Sản phẩm này cần những chứng nhận gì để bán trên Amazon Mỹ? Anh có thể liệt kê giúp không?"
        },
        {
          "num": 27,
          "q": "Tủ này cao 1,8m, theo luật Mỹ có phải đi kèm thiết bị chống đổ không?"
        },
        {
          "num": 28,
          "q": "Chúng tôi cần báo cáo kiểm định bên thứ ba cho CARB Phase 2 và hàm lượng chì trước khi đặt hàng."
        },
        {
          "num": 29,
          "q": "Tỷ lệ hoàn hàng cao thường do nguyên nhân gì? Làm sao để giảm xuống dưới 5%?"
        },
        {
          "num": 30,
          "q": "Nhà máy có thể dán FNSKU barcode cho chúng tôi trước khi đóng gói vào thùng không?"
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "C",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "C",
        "8": "B"
      },
      "tf": {
        "9": false,
        "10": true,
        "11": false,
        "12": true,
        "13": true,
        "14": true
      },
      "fillblank": {
        "15": "防倾倒装置",
        "16": "CARB Phase 2",
        "17": "甲醛含量",
        "18": "铅含量",
        "19": "FBA标准",
        "20": "退货率"
      },
      "zh2vi": {
        "21": "Tủ quần áo này cần đáp ứng các yêu cầu thị trường Mỹ sau: chứng nhận CARB Phase 2, báo cáo kiểm định formaldehyde, kiểm tra hàm lượng chì, thiết bị chống đổ.",
        "22": "Theo ASTM F2057, tủ chứa đồ cao hơn 30 inch phải đi kèm thiết bị chống đổ, hướng dẫn lắp ráp phải bao gồm hướng dẫn lắp thiết bị này.",
        "23": "Chúng tôi khuyến nghị nhờ luật sư chuyên nghiệp đánh giá rủi ro tuân thủ Proposition 65 California, vì danh sách hóa chất được cập nhật hàng năm.",
        "24": "Yêu cầu đóng gói FBA: mỗi sản phẩm riêng lẻ dán nhãn FNSKU, bộ sản phẩm 5 thùng trở lên cần barcode ngoài thùng và ghi trọng lượng.",
        "25": "Tỷ lệ hoàn hàng sản phẩm này của chúng tôi chỉ 3,8%, chủ yếu nhờ hướng dẫn lắp ráp rõ ràng và đóng gói chắc chắn."
      },
      "vi2zh": {
        "26": "这款产品需要哪些认证才能在美国亚马逊上销售？能帮我列一下清单吗？",
        "27": "这个衣柜高1.8米，根据美国法规是否必须附带防倾倒装置？",
        "28": "在下订单前，我们需要CARB Phase 2和铅含量的第三方检测报告。",
        "29": "退货率高通常是什么原因？怎么把退货率控制在5%以下？",
        "30": "工厂能不能在打包前帮我们贴FNSKU条形码？"
      }
    }
  },
  {
    "num": 16,
    "title": "MỸ PHẨM: THÀNH PHẦN & SẢN PHẨM",
    "date": "12/6",
    "phase": 2,
    "vocab": [
      {
        "num": 1,
        "hanzi": "护肤品",
        "pinyin": "hùfū pǐn",
        "vi": "sản phẩm chăm sóc da",
        "explanation": "Danh mục rộng bao gồm: kem dưỡng ẩm (保湿霜 bǎoshī shuāng), serum, toner (爽肤水 shuǎngfū shuǐ), kem chống nắng (防晒霜 fángshài shuāng), mặt nạ (面膜 miànmó). Đây là danh mục phát triển nhanh nhất trên Amazon Mỹ, thị trường trị giá hàng tỷ đô hàng năm.",
        "example": {
          "zh": "我们专注于天然成分的护肤品，主打美国市场。",
          "vi": "Chúng tôi tập trung vào sản phẩm chăm sóc da thành phần thiên nhiên, nhắm vào thị trường Mỹ."
        }
      },
      {
        "num": 2,
        "hanzi": "成分表 (INCI)",
        "pinyin": "chénfèn biǎo",
        "vi": "danh sách thành phần (INCI list)",
        "explanation": "International Nomenclature of Cosmetic Ingredients — danh sách thành phần theo tên khoa học quốc tế, bắt buộc in trên nhãn mỹ phẩm ở Mỹ và EU. Thứ tự liệt kê từ nhiều đến ít theo tỷ lệ. Thành phần phải khớp hoàn toàn với công thức thực tế — gian lận thành phần là vi phạm pháp luật nghiêm trọng.",
        "example": {
          "zh": "美国FDA要求所有化妆品必须在标签上列出完整的INCI成分表。",
          "vi": "FDA Mỹ yêu cầu tất cả mỹ phẩm phải liệt kê đầy đủ danh sách thành phần INCI trên nhãn."
        }
      },
      {
        "num": 3,
        "hanzi": "防腐剂",
        "pinyin": "fángfǔ jì",
        "vi": "chất bảo quản",
        "explanation": "Hóa chất thêm vào mỹ phẩm để ngăn vi khuẩn và nấm mốc phát triển. Phổ biến: parabens, phenoxyethanol, benzyl alcohol. Mỹ phẩm \"Paraben-free\" (不含对羟基苯甲酸酯) đang là xu hướng thị trường vì lo ngại sức khỏe. FDA Mỹ có danh sách chất bảo quản bị cấm khác EU.",
        "example": {
          "zh": "我们的产品是无防腐剂配方，用天然抗氧化剂代替，但保质期相对较短。",
          "vi": "Sản phẩm của chúng tôi là công thức không có chất bảo quản, dùng chất chống oxy hóa thiên nhiên thay thế, nhưng hạn sử dụng tương đối ngắn hơn."
        }
      },
      {
        "num": 4,
        "hanzi": "保质期",
        "pinyin": "bǎozhì qī",
        "vi": "hạn sử dụng / thời hạn bảo quản",
        "explanation": "Thời gian sản phẩm giữ được chất lượng và an toàn khi chưa mở. Mỹ phẩm thường có 2–3 năm. Sau khi mở (PAO — Period After Opening), thường ghi bằng ký hiệu hộp mở với số tháng (ví dụ 12M = dùng trong 12 tháng sau khi mở). Hàng mỹ phẩm không được vào Mỹ nếu còn ít hơn 30% thời hạn sử dụng.",
        "example": {
          "zh": "这款产品的保质期是两年，开封后建议在12个月内使用完。",
          "vi": "Hạn sử dụng sản phẩm này là 2 năm, sau khi mở khuyến nghị dùng hết trong 12 tháng."
        }
      },
      {
        "num": 5,
        "hanzi": "活性成分",
        "pinyin": "huóxìng chénfèn",
        "vi": "hoạt chất / thành phần hoạt tính",
        "explanation": "Thành phần có tác dụng sinh học thực sự trong sản phẩm — ví dụ: retinol (视黄醇), hyaluronic acid (玻尿酸), niacinamide (烟酰胺), vitamin C. Nồng độ hoạt chất quyết định hiệu quả sản phẩm. Nếu công bố sản phẩm có retinol 1%, trong thực tế phải đạt đúng 1%.",
        "example": {
          "zh": "这款精华含有5%的烟酰胺和2%的玻尿酸，有美白和保湿的效果。",
          "vi": "Serum này chứa 5% niacinamide và 2% hyaluronic acid, có tác dụng làm trắng và dưỡng ẩm."
        }
      },
      {
        "num": 6,
        "hanzi": "皮肤测试",
        "pinyin": "pífū cèshì",
        "vi": "kiểm tra da / skin test",
        "explanation": "Thử nghiệm kiểm tra sản phẩm có gây kích ứng da hay không. Bao gồm: patch test (贴片测试) và in-use test. Không phải bắt buộc theo pháp luật Mỹ nhưng là thực hành tốt nhất và giúp đưa ra claim \"dermatologist tested\" (皮肤科医生测试认可) trên nhãn.",
        "example": {
          "zh": "我们的产品经过了皮肤科医生测试，证明对敏感肌肤安全。",
          "vi": "Sản phẩm của chúng tôi đã được bác sĩ da liễu kiểm tra, chứng minh an toàn cho da nhạy cảm."
        }
      },
      {
        "num": 7,
        "hanzi": "天然成分",
        "pinyin": "tiānrán chénfèn",
        "vi": "thành phần thiên nhiên",
        "explanation": "Nguyên liệu có nguồn gốc từ thực vật, động vật hoặc khoáng chất tự nhiên, không qua tổng hợp hóa học. Xu hướng \"clean beauty\" và \"natural ingredients\" đang rất mạnh ở thị trường Mỹ. Tuy nhiên \"natural\" không được pháp lý định nghĩa chặt chẽ — người bán cần cẩn thận khi dùng từ này trong marketing.",
        "example": {
          "zh": "我们使用的都是经过认证的有机天然成分，来自可持续种植的植物。",
          "vi": "Chúng tôi dùng toàn thành phần thiên nhiên hữu cơ có chứng nhận, từ thực vật được trồng bền vững."
        }
      },
      {
        "num": 8,
        "hanzi": "配方",
        "pinyin": "pèifāng",
        "vi": "công thức (formula)",
        "explanation": "Danh sách và tỷ lệ các thành phần tạo nên sản phẩm mỹ phẩm — đây là thông tin bí mật thương mại quan trọng nhất của nhà sản xuất. Khi làm OEM mỹ phẩm, cần NDA chặt chẽ trước khi trao đổi 配方. Người mua nên sở hữu hoặc có bản quyền 配方 của mình.",
        "example": {
          "zh": "我们的配方是自主研发的，已经申请了专利，保密协议签署后才能分享细节。",
          "vi": "Công thức của chúng tôi là tự nghiên cứu phát triển, đã đăng ký bằng sáng chế, phải ký NDA mới có thể chia sẻ chi tiết."
        }
      },
      {
        "num": 9,
        "hanzi": "批次记录",
        "pinyin": "pīcì jìlù",
        "vi": "hồ sơ lô sản xuất (batch record)",
        "explanation": "Tài liệu ghi lại toàn bộ thông tin về một lô sản xuất: nguyên liệu sử dụng, tỷ lệ, nhiệt độ sản xuất, kiểm tra chất lượng, ngày sản xuất, hạn sử dụng. FDA Mỹ yêu cầu lưu giữ 批次记录 ít nhất 2 năm. Khi có sự cố, 批次记录 là tài liệu truy xuất nguồn gốc.",
        "example": {
          "zh": "每一批产品都有完整的批次记录，出现问题时可以快速追溯。",
          "vi": "Mỗi lô sản phẩm đều có hồ sơ lô đầy đủ, khi có vấn đề có thể truy xuất nhanh chóng."
        }
      },
      {
        "num": 10,
        "hanzi": "不含有害成分",
        "pinyin": "bù hán yǒuhài chénfèn",
        "vi": "không chứa thành phần độc hại",
        "explanation": "Xu hướng thị trường hiện nay: \"free-from\" claims — không chứa parabens (无防腐剂), không chứa sulfate (无硫酸盐), không chứa hương liệu nhân tạo (无人工香精), không chứa silicone (无硅油). Những claim này ảnh hưởng lớn đến quyết định mua hàng của người tiêu dùng Mỹ nhưng phải chứng minh được thực tế.",
        "example": {
          "zh": "我们的产品不含对羟基苯甲酸酯、硫酸盐和人工香精，符合clean beauty标准。",
          "vi": "Sản phẩm của chúng tôi không chứa parabens, sulfate và hương liệu nhân tạo, đạt tiêu chuẩn clean beauty."
        }
      }
    ],
    "dialogue": {
      "context": "Công ty VN đang tìm nhà sản xuất OEM mỹ phẩm TQ để phát triển dòng serum bán Amazon Mỹ. Bạn là phiên dịch.",
      "characters": [
        {
          "name": "研发经理王博士 (Wáng bóshì)",
          "role": "Giám đốc R&D nhà máy mỹ phẩm"
        },
        {
          "name": "Chị Thảo",
          "role": "Giám đốc phát triển sản phẩm công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "Chị Thảo",
          "zh": "我们想开发一款面向美国市场的精华液，定位是天然成分、美白补水，主要卖点是含有玻尿酸和烟酰胺。",
          "vi": "Chúng tôi muốn phát triển serum nhắm vào thị trường Mỹ, định vị là thành phần thiên nhiên, làm trắng dưỡng ẩm, điểm bán hàng chính là chứa hyaluronic acid và niacinamide."
        },
        {
          "speaker": "王博士",
          "zh": "这两个成分搭配非常好，市场接受度也高。请问您希望烟酰胺的浓度是多少？高浓度更有效果，但价格也更高。",
          "vi": "Hai thành phần này kết hợp rất tốt, thị trường chấp nhận cao. Xin hỏi nồng độ niacinamide mong muốn là bao nhiêu? Nồng độ cao hơn thì hiệu quả hơn nhưng giá cũng cao hơn."
        },
        {
          "speaker": "Chị Thảo",
          "zh": "我们希望做5%的烟酰胺，这个浓度在市场上比较受认可，效果和成本的平衡也好。玻尿酸这边，我们想用多分子量的，保湿效果更好。",
          "vi": "Chúng tôi muốn niacinamide 5%, nồng độ này được thị trường khá công nhận, cân bằng tốt giữa hiệu quả và chi phí. Về hyaluronic acid, chúng tôi muốn dùng đa phân tử, hiệu quả dưỡng ẩm tốt hơn."
        },
        {
          "speaker": "王博士",
          "zh": "5%烟酰胺加多分子量玻尿酸，这个方案我们有现成的基础配方可以调整。防腐剂方面，您有什么要求？美国客户现在对parabens比较敏感。",
          "vi": "Niacinamide 5% kết hợp hyaluronic acid đa phân tử, phương án này chúng tôi có công thức nền sẵn có thể điều chỉnh. Về chất bảo quản, anh/chị có yêu cầu gì? Khách Mỹ hiện khá nhạy cảm với parabens."
        },
        {
          "speaker": "Chị Thảo",
          "zh": "我们要做parabens-free，用苯氧乙醇作为替代防腐剂，你们有这方面的经验吗？",
          "vi": "Chúng tôi muốn làm không chứa parabens, dùng phenoxyethanol như chất bảo quản thay thế, anh có kinh nghiệm trong lĩnh vực này không?"
        },
        {
          "speaker": "王博士",
          "zh": "有的，苯氧乙醇是现在主流的替代选择，我们经常做这类配方。保质期方面，不含parabens的产品通常是18个月，您这边可以接受吗？",
          "vi": "Có, phenoxyethanol là lựa chọn thay thế chủ lưu hiện nay, chúng tôi thường làm loại công thức này. Về hạn sử dụng, sản phẩm không chứa parabens thường là 18 tháng, phía chị chấp nhận được không?"
        },
        {
          "speaker": "Chị Thảo",
          "zh": "18个月可以，亚马逊入库要求剩余保质期不少于6个月，我们要控制好库存周转。另外，FDA的要求方面，成分表是INCI格式吗？",
          "vi": "18 tháng được, Amazon yêu cầu nhập kho còn ít nhất 6 tháng hạn sử dụng, chúng tôi cần kiểm soát tốt vòng quay tồn kho. Ngoài ra về yêu cầu FDA, danh sách thành phần có theo định dạng INCI không?"
        },
        {
          "speaker": "王博士",
          "zh": "是的，我们的所有产品标签都按照FDA要求，使用INCI成分命名，并且按照含量从多到少的顺序排列。我们也会提供完整的批次记录。",
          "vi": "Có, tất cả nhãn sản phẩm của chúng tôi đều theo yêu cầu FDA, dùng tên INCI và sắp xếp theo thứ tự từ nhiều đến ít. Chúng tôi cũng sẽ cung cấp hồ sơ lô đầy đủ."
        },
        {
          "speaker": "Chị Thảo",
          "zh": "很好。最后一个问题，关于加州65号提案，这款产品会涉及到吗？",
          "vi": "Tốt. Câu hỏi cuối, California Proposition 65 có liên quan đến sản phẩm này không?"
        },
        {
          "speaker": "王博士",
          "zh": "我们会做Prop 65评估，目前这个配方里没有需要警示的成分，但我建议在上市前请第三方机构确认一下，更稳妥。",
          "vi": "Chúng tôi sẽ đánh giá Prop 65, hiện tại công thức này không có thành phần cần cảnh báo, nhưng tôi khuyến nghị trước khi ra thị trường nhờ tổ chức bên thứ ba xác nhận lại, để chắc chắn hơn."
        }
      ]
    },
    "notes": [
      {
        "title": "Mỹ phẩm: FDA Mỹ vs EU là hai thế giới khác nhau",
        "body": "FDA Mỹ cho phép nhiều thành phần mà EU cấm. EU cấm hơn 1300 thành phần trong khi Mỹ chỉ cấm khoảng 11. Đây là lý do cùng một nhà máy TQ có thể xuất mỹ phẩm vào EU hay Mỹ nhưng cần công thức khác nhau đôi khi."
      },
      {
        "title": "Niacinamide và Hyaluronic Acid: hai hoạt chất bán chạy nhất",
        "body": "Niacinamide (烟酰胺): làm trắng, thu nhỏ lỗ chân lông, kiểm soát dầu. 5–10% là dải nồng độ hiệu quả. Hyaluronic Acid (玻尿酸): dưỡng ẩm. Đa phân tử (多分子量) thấm sâu hơn đơn phân tử. Đây là hai thành phần buyer Amazon hay hỏi nhà máy vì thị trường đang cần."
      },
      {
        "title": "Hạn sử dụng và tồn kho Amazon: phải tính trước",
        "body": "Amazon FBA từ chối nhận hàng mỹ phẩm nếu hạn sử dụng còn dưới 6 tháng. Với sản phẩm 18 tháng hạn, thực tế bạn chỉ có 12 tháng để bán. Phải tính thời gian sản xuất + vận chuyển + nhập kho = thường 3–4 tháng. Vậy cần bán hết trong khoảng 8–9 tháng."
      },
      {
        "title": "\"Dermatologist tested\" và các claims trên nhãn",
        "body": "Các claims như \"dermatologist tested\", \"hypoallergenic\", \"non-comedogenic\" không được pháp lý định nghĩa ở Mỹ nhưng ảnh hưởng lớn đến doanh số. Cần có bằng chứng thực tế (kết quả test) để hỗ trợ claim nếu FTC điều tra."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "INCI list bắt buộc liệt kê thành phần theo thứ tự nào?",
          "options": {
            "A": "Theo thứ tự bảng chữ cái",
            "B": "Từ nhiều nhất đến ít nhất theo tỷ lệ",
            "C": "Từ ít nhất đến nhiều nhất",
            "D": "Thứ tự tùy nhà sản xuất"
          }
        },
        {
          "num": 2,
          "q": "Tại sao sản phẩm không chứa parabens có hạn sử dụng ngắn hơn?",
          "options": {
            "A": "Vì thành phần tự nhiên đắt hơn",
            "B": "Parabens là chất bảo quản hiệu quả, thay thế bằng phenoxyethanol làm giảm thời gian bảo quản",
            "C": "Vì quy định FDA",
            "D": "Không có sự khác biệt"
          }
        },
        {
          "num": 3,
          "q": "Amazon FBA từ chối nhận mỹ phẩm khi hạn sử dụng còn dưới bao lâu?",
          "options": {
            "A": "1 tháng",
            "B": "3 tháng",
            "C": "6 tháng",
            "D": "12 tháng"
          }
        },
        {
          "num": 4,
          "q": "Nồng độ niacinamide nào được thị trường công nhận rộng rãi và cân bằng tốt giữa hiệu quả và chi phí?",
          "options": {
            "A": "1%",
            "B": "5%",
            "C": "15%",
            "D": "25%"
          }
        },
        {
          "num": 5,
          "q": "批次记录 (batch record) cần lưu giữ bao lâu theo FDA?",
          "options": {
            "A": "6 tháng",
            "B": "1 năm",
            "C": "Ít nhất 2 năm",
            "D": "Không quy định"
          }
        },
        {
          "num": 6,
          "q": "天然成分 trong marketing mỹ phẩm Mỹ có vấn đề gì?",
          "options": {
            "A": "Bị cấm hoàn toàn",
            "B": "Không được pháp lý định nghĩa chặt chẽ, cần cẩn thận khi claim",
            "C": "Phải đăng ký với FDA",
            "D": "Không có vấn đề gì"
          }
        },
        {
          "num": 7,
          "q": "Hyaluronic acid đa phân tử (多分子量) tốt hơn đơn phân tử vì lý do gì?",
          "options": {
            "A": "Rẻ hơn",
            "B": "Thấm sâu hơn vào da, dưỡng ẩm hiệu quả hơn",
            "C": "Ổn định hơn trong công thức",
            "D": "Không có sự khác biệt"
          }
        },
        {
          "num": 8,
          "q": "Khi claim \"dermatologist tested\" trên nhãn, cần có gì?",
          "options": {
            "A": "Không cần gì thêm",
            "B": "Bằng chứng thực tế từ kết quả test để hỗ trợ claim nếu bị điều tra",
            "C": "Xác nhận từ FDA",
            "D": "Chỉ cần nhà sản xuất ký xác nhận"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "FDA Mỹ và EU có cùng danh sách thành phần bị cấm trong mỹ phẩm."
        },
        {
          "num": 10,
          "q": "Danh sách thành phần INCI phải in trên nhãn theo yêu cầu FDA."
        },
        {
          "num": 11,
          "q": "Sản phẩm hạn 18 tháng thực tế chỉ có 8–9 tháng để bán trên Amazon sau khi trừ thời gian sản xuất và vận chuyển."
        },
        {
          "num": 12,
          "q": "Công thức sản phẩm (配方) không phải thông tin bí mật và không cần NDA."
        },
        {
          "num": 13,
          "q": "\"Paraben-free\" là xu hướng thị trường Mỹ đang tăng trưởng mạnh."
        },
        {
          "num": 14,
          "q": "Hoạt chất trong mỹ phẩm quyết định hiệu quả thực sự của sản phẩm."
        }
      ],
      "fillblank": {
        "wordbank": [
          "成分表",
          "防腐剂",
          "保质期",
          "活性成分",
          "配方",
          "批次记录"
        ],
        "items": [
          {
            "num": 15,
            "q": "FDA要求所有化妆品标签上必须有完整的____（INCI格式）。"
          },
          {
            "num": 16,
            "q": "我们的产品不含____，使用天然抗菌成分代替，但____会相对缩短。"
          },
          {
            "num": 17,
            "q": "这款精华的____包括5%烟酰胺和2%玻尿酸，效果经过临床验证。"
          },
          {
            "num": 18,
            "q": "在提供产品____之前，请先签署保密协议。"
          },
          {
            "num": 19,
            "q": "每一批产品出货前，我们都会提供完整的____，包括原料来源和质检结果。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 20,
          "q": "这款精华含有5%烟酰胺和多分子量玻尿酸，采用无防腐剂配方，保质期18个月，符合FDA要求。"
        },
        {
          "num": 21,
          "q": "我们所有产品的成分表都按INCI格式排列，完全符合FDA的标签规定，可以直接在美国市场销售。"
        },
        {
          "num": 22,
          "q": "产品的批次记录我们保存至少两年，出现质量问题时可以快速追溯到具体生产批次和原材料来源。"
        },
        {
          "num": 23,
          "q": "我们建议您在产品上市前做一次第三方成分安全评估，确认没有加州65号提案的风险。"
        },
        {
          "num": 24,
          "q": "Clean beauty趋势在北美市场越来越强，消费者对无对羟基苯甲酸酯、无硫酸盐的产品偏好明显提升。"
        }
      ],
      "vi2zh": [
        {
          "num": 25,
          "q": "Chúng tôi muốn phát triển serum chứa niacinamide 5% và hyaluronic acid đa phân tử, không chứa parabens."
        },
        {
          "num": 26,
          "q": "Hạn sử dụng tối thiểu của sản phẩm là bao nhiêu? Amazon yêu cầu còn ít nhất 6 tháng khi nhập kho."
        },
        {
          "num": 27,
          "q": "Danh sách thành phần INCI đã được chuẩn bị chưa? Đây là bắt buộc theo yêu cầu FDA."
        },
        {
          "num": 28,
          "q": "Chúng tôi cần hồ sơ lô cho mỗi đơn hàng để theo dõi chất lượng và có thể truy xuất nguồn gốc khi cần."
        },
        {
          "num": 29,
          "q": "Sản phẩm này có thể claim \"dermatologist tested\" không? Cần bằng chứng kiểm định nào?"
        },
        {
          "num": 30,
          "q": "Trước khi chia sẻ công thức, chúng tôi cần ký NDA. Công thức là tài sản trí tuệ quan trọng nhất của chúng tôi."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "C",
        "4": "B",
        "5": "C",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": false,
        "10": true,
        "11": true,
        "12": false,
        "13": true,
        "14": true
      },
      "fillblank": {
        "15": "成分表",
        "16": [
          "防腐剂",
          "保质期"
        ],
        "17": "活性成分",
        "18": "配方",
        "19": "批次记录"
      },
      "zh2vi": {
        "20": "Serum này chứa niacinamide 5% và hyaluronic acid đa phân tử, công thức không chứa chất bảo quản, hạn sử dụng 18 tháng, đáp ứng yêu cầu FDA.",
        "21": "Danh sách thành phần tất cả sản phẩm của chúng tôi đều theo định dạng INCI, hoàn toàn tuân thủ quy định nhãn mác FDA, có thể bán trực tiếp ở thị trường Mỹ.",
        "22": "Hồ sơ lô sản phẩm chúng tôi lưu giữ ít nhất 2 năm, khi có vấn đề chất lượng có thể nhanh chóng truy xuất đến lô sản xuất cụ thể và nguồn nguyên liệu.",
        "23": "Chúng tôi khuyến nghị trước khi sản phẩm ra thị trường thực hiện đánh giá an toàn thành phần bên thứ ba, xác nhận không có rủi ro Proposition 65 California.",
        "24": "Xu hướng clean beauty tại thị trường Bắc Mỹ ngày càng mạnh, người tiêu dùng ngày càng ưa chuộng sản phẩm không chứa parabens, không chứa sulfate."
      },
      "vi2zh": {
        "25": "我们想开发一款含5%烟酰胺和多分子量玻尿酸的精华，无防腐剂配方。",
        "26": "产品的最低保质期是多少？亚马逊要求入库时至少还有6个月保质期。",
        "27": "INCI成分表准备好了吗？这是FDA的强制要求。",
        "28": "每批货我们需要批次记录，用于质量追踪，必要时可以溯源。",
        "29": "这款产品可以claim\"皮肤科医生测试认可\"吗？需要哪些检测证明？",
        "30": "在分享配方之前，我们需要签署保密协议。配方是我们最重要的知识产权。"
      }
    }
  },
  {
    "num": 17,
    "title": "MỸ PHẨM: CHỨNG NHẬN FDA & QUY ĐỊNH",
    "date": "13/6",
    "phase": 2,
    "vocab": [
      {
        "num": 1,
        "hanzi": "FDA备案",
        "pinyin": "FDA bèi'àn",
        "vi": "đăng ký thông báo FDA",
        "explanation": "Sau khi Luật MoCRA (Modernization of Cosmetics Regulation Act) có hiệu lực 2022, tất cả nhà sản xuất và thương hiệu mỹ phẩm bán ở Mỹ phải đăng ký với FDA và thông báo sản phẩm. Đây là thay đổi lớn nhất trong quy định mỹ phẩm Mỹ trong 80 năm. Thời hạn: nhà sản xuất nhỏ phải tuân thủ từ 12/2024.",
        "example": {
          "zh": "根据MoCRA，所有在美国销售的化妆品需要向FDA进行产品备案。",
          "vi": "Theo MoCRA, tất cả mỹ phẩm bán ở Mỹ cần đăng ký thông báo sản phẩm với FDA."
        }
      },
      {
        "num": 2,
        "hanzi": "药妆 (OTC Drug)",
        "pinyin": "yàozhuāng",
        "vi": "dược mỹ phẩm (thuốc OTC)",
        "explanation": "Sản phẩm vừa là mỹ phẩm vừa có công dụng dược phẩm: kem chống nắng (SPF), kem trị mụn (benzoyl peroxide), kem chống gàu. Theo FDA, những sản phẩm này là OTC drug — yêu cầu cao hơn mỹ phẩm thông thường: phải đăng ký với FDA, nhãn Drug Facts bắt buộc.",
        "example": {
          "zh": "含有SPF的防晒霜在美国被归类为OTC药品，不是普通化妆品，监管要求更严格。",
          "vi": "Kem chống nắng có SPF ở Mỹ được phân loại là thuốc OTC, không phải mỹ phẩm thông thường, yêu cầu quản lý chặt hơn."
        }
      },
      {
        "num": 3,
        "hanzi": "标签合规",
        "pinyin": "biāoqiān héguī",
        "vi": "tuân thủ nhãn mác",
        "explanation": "Nhãn mỹ phẩm bán ở Mỹ phải có: tên sản phẩm, tên và địa chỉ nhà sản xuất hoặc phân phối, khối lượng tịnh, INCI ingredients list, hướng dẫn sử dụng, cảnh báo (nếu cần). Tất cả phải bằng tiếng Anh. Nhãn không đúng = hàng bị giữ ở hải quan hoặc thu hồi.",
        "example": {
          "zh": "进入美国市场的化妆品必须满足FDA的标签合规要求，包括完整的英文成分表。",
          "vi": "Mỹ phẩm vào thị trường Mỹ phải đáp ứng yêu cầu tuân thủ nhãn mác FDA, bao gồm danh sách thành phần tiếng Anh đầy đủ."
        }
      },
      {
        "num": 4,
        "hanzi": "第三方检测机构",
        "pinyin": "dìsānfāng jiǎncè jīgòu",
        "vi": "tổ chức kiểm định bên thứ ba",
        "explanation": "Phòng thí nghiệm độc lập thực hiện kiểm tra và cấp chứng nhận cho sản phẩm. Phổ biến nhất: SGS, Intertek, Bureau Veritas, Eurofins. Kết quả từ các tổ chức này được FDA và Amazon chấp nhận.",
        "example": {
          "zh": "我们建议在上市前委托SGS或Intertek进行全面的安全性检测。",
          "vi": "Chúng tôi khuyến nghị trước khi ra thị trường thuê SGS hoặc Intertek thực hiện kiểm tra an toàn toàn diện."
        }
      },
      {
        "num": 5,
        "hanzi": "重金属检测",
        "pinyin": "zhòngjīnshǔ jiǎncè",
        "vi": "kiểm tra kim loại nặng",
        "explanation": "Kiểm tra hàm lượng chì (铅), thủy ngân (汞), asen (砷), cadmium (镉) trong sản phẩm mỹ phẩm. FDA Mỹ có giới hạn cho từng kim loại. Đặc biệt quan trọng với son môi, phấn nền, mỹ phẩm màu — các sản phẩm tiếp xúc trực tiếp với niêm mạc hoặc da mặt.",
        "example": {
          "zh": "色彩类化妆品必须进行重金属检测，特别是铅和汞的含量需要严格控制。",
          "vi": "Mỹ phẩm màu phải kiểm tra kim loại nặng, đặc biệt hàm lượng chì và thủy ngân cần kiểm soát chặt chẽ."
        }
      },
      {
        "num": 6,
        "hanzi": "微生物检测",
        "pinyin": "wēishēngwù jiǎncè",
        "vi": "kiểm tra vi sinh",
        "explanation": "Kiểm tra sản phẩm có nhiễm vi khuẩn (tổng số vi khuẩn hiếu khí, E. coli, Staphylococcus aureus...) hay không. Mỹ phẩm nhiễm vi sinh là nguy cơ sức khỏe nghiêm trọng và bị thu hồi ngay. Đặc biệt quan trọng với sản phẩm chứa nước (lotion, toner, serum).",
        "example": {
          "zh": "含水产品在出货前必须进行微生物检测，确保符合FDA的限量标准。",
          "vi": "Sản phẩm có nước trước khi xuất hàng phải kiểm tra vi sinh, đảm bảo đạt giới hạn của FDA."
        }
      },
      {
        "num": 7,
        "hanzi": "皮肤刺激性测试",
        "pinyin": "pífū cìjīxìng cèshì",
        "vi": "kiểm tra kích ứng da",
        "explanation": "Thử nghiệm xác định sản phẩm có gây kích ứng da hay không. Có thể là patch test trên người tình nguyện hoặc in-vitro test trong phòng thí nghiệm. Kết quả cho phép claim \"dermatologist tested\" hoặc \"hypoallergenic\" trên nhãn.",
        "example": {
          "zh": "我们做了20人的皮肤刺激性测试，结果显示产品对敏感肌肤安全。",
          "vi": "Chúng tôi đã thực hiện kiểm tra kích ứng da trên 20 người, kết quả cho thấy sản phẩm an toàn cho da nhạy cảm."
        }
      },
      {
        "num": 8,
        "hanzi": "召回",
        "pinyin": "zhàohuí",
        "vi": "thu hồi sản phẩm (recall)",
        "explanation": "Hành động nhà sản xuất hoặc FDA thu hồi sản phẩm đã bán ra thị trường vì lý do an toàn. 召回 gây thiệt hại rất lớn: chi phí thu hồi, phạt, tổn hại thương hiệu, mất doanh thu. Nguyên nhân phổ biến nhất: nhiễm vi sinh, thành phần vượt ngưỡng an toàn, nhãn sai.",
        "example": {
          "zh": "因为被检测出汞含量超标，这款美白霜在美国被FDA强制召回。",
          "vi": "Vì bị phát hiện hàm lượng thủy ngân vượt ngưỡng, kem làm trắng này đã bị FDA cưỡng chế thu hồi tại Mỹ."
        }
      },
      {
        "num": 9,
        "hanzi": "禁用成分",
        "pinyin": "jìnyòng chénfèn",
        "vi": "thành phần bị cấm",
        "explanation": "Danh sách hóa chất FDA cấm sử dụng trong mỹ phẩm. Danh sách Mỹ ngắn hơn EU nhiều (khoảng 11 chất) nhưng vẫn quan trọng. Thủy ngân (汞) bị cấm hoàn toàn, chloroform, hexachlorophene... Nhà sản xuất phải đảm bảo không dùng bất kỳ thành phần cấm nào.",
        "example": {
          "zh": "在配方开发阶段，我们就会对照FDA的禁用成分清单进行排查。",
          "vi": "Ở giai đoạn phát triển công thức, chúng tôi đã đối chiếu danh sách thành phần cấm của FDA để kiểm tra."
        }
      },
      {
        "num": 10,
        "hanzi": "GMP认证",
        "pinyin": "GMP rènzhèng",
        "vi": "chứng nhận GMP (Good Manufacturing Practice)",
        "explanation": "Tiêu chuẩn sản xuất tốt — quy định về điều kiện nhà máy, quy trình sản xuất, kiểm soát chất lượng để đảm bảo sản phẩm an toàn và đồng nhất. FDA Mỹ không cấp chứng nhận GMP cho mỹ phẩm nhưng yêu cầu tuân thủ GMP guidelines. ISO 22716 là tiêu chuẩn GMP quốc tế cho mỹ phẩm.",
        "example": {
          "zh": "我们工厂通过了ISO 22716认证，这是国际公认的化妆品GMP标准，可以证明我们的生产条件符合要求。",
          "vi": "Nhà máy chúng tôi đã được chứng nhận ISO 22716, đây là tiêu chuẩn GMP mỹ phẩm được quốc tế công nhận, chứng minh điều kiện sản xuất của chúng tôi đáp ứng yêu cầu."
        }
      }
    ],
    "dialogue": {
      "context": "Buyer VN chuẩn bị launch sản phẩm mỹ phẩm trên Amazon Mỹ, đang hỏi về quy trình đăng ký và kiểm định.",
      "characters": [
        {
          "name": "合规顾问陈女士 (Chén nǚshì)",
          "role": "Cố vấn tuân thủ quy định mỹ phẩm"
        },
        {
          "name": "Anh Đức",
          "role": "Giám đốc công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "Anh Đức",
          "zh": "陈女士，我们准备在美国亚马逊上卖护肤精华，需要做哪些合规准备？",
          "vi": "Chị Trần, chúng tôi chuẩn bị bán serum dưỡng da trên Amazon Mỹ, cần chuẩn bị gì về tuân thủ quy định?"
        },
        {
          "speaker": "陈女士",
          "zh": "首先，根据2022年的MoCRA法规，您需要向FDA进行产品备案，包括公司注册和产品通报，这是新要求。",
          "vi": "Trước tiên, theo luật MoCRA năm 2022, anh cần đăng ký thông báo sản phẩm với FDA, bao gồm đăng ký công ty và thông báo sản phẩm — đây là yêu cầu mới."
        },
        {
          "speaker": "Anh Đức",
          "zh": "MoCRA以前不需要的，这个备案流程复杂吗？",
          "vi": "Trước MoCRA không cần, quy trình đăng ký này có phức tạp không?"
        },
        {
          "speaker": "陈女士",
          "zh": "相对来说不太复杂，但需要提供产品信息、成分表、负责任联系人等信息。我建议您找有经验的合规顾问来操作，第一次做比较繁琐。",
          "vi": "Tương đối không quá phức tạp, nhưng cần cung cấp thông tin sản phẩm, danh sách thành phần, thông tin liên lạc chịu trách nhiệm... Tôi khuyến nghị anh tìm cố vấn tuân thủ có kinh nghiệm để thực hiện, lần đầu làm khá rườm rà."
        },
        {
          "speaker": "Anh Đức",
          "zh": "好的。关于产品检测，我们需要做哪些测试？",
          "vi": "Được. Về kiểm định sản phẩm, chúng tôi cần làm những test nào?"
        },
        {
          "speaker": "陈女士",
          "zh": "最基本的是微生物检测和重金属检测，这两个是安全性的底线。另外，您的产品声称有美白效果，需要注意\"美白\"在美国法规上比较敏感，如果含有美白活性成分可能被归为OTC药品，受到更严格的监管。",
          "vi": "Cơ bản nhất là kiểm tra vi sinh và kiểm tra kim loại nặng, đây là hai ngưỡng an toàn tối thiểu. Ngoài ra, sản phẩm của anh claim có hiệu quả làm trắng, cần lưu ý \"làm trắng\" trong quy định Mỹ khá nhạy cảm, nếu chứa hoạt chất làm trắng có thể bị phân loại là thuốc OTC, chịu quản lý chặt hơn."
        },
        {
          "speaker": "Anh Đức",
          "zh": "这个问题很重要。我们用的是烟酰胺，不是那些美国FDA认为是药物的成分，应该是普通化妆品吧？",
          "vi": "Vấn đề này rất quan trọng. Chúng tôi dùng niacinamide, không phải những thành phần mà FDA coi là dược phẩm, nên là mỹ phẩm thông thường đúng không?"
        },
        {
          "speaker": "陈女士",
          "zh": "对，烟酰胺本身不在FDA的OTC美白成分清单里，所以是普通化妆品。但是您在产品描述中要避免使用\"美白皮肤\"这样的说法，可以用\"提亮肤色\"来代替，这样就不会触发OTC药品的监管要求。",
          "vi": "Đúng, niacinamide bản thân không có trong danh sách thành phần làm trắng OTC của FDA, nên là mỹ phẩm thông thường. Nhưng trong mô tả sản phẩm của anh cần tránh dùng từ \"làm trắng da\", có thể dùng \"làm sáng tông da\" thay thế, như vậy sẽ không kích hoạt yêu cầu quản lý thuốc OTC."
        },
        {
          "speaker": "Anh Đức",
          "zh": "好，我明白了。标签方面还有什么需要注意的？",
          "vi": "Tốt, tôi hiểu rồi. Về nhãn mác còn cần chú ý gì?"
        },
        {
          "speaker": "陈女士",
          "zh": "标签必须有英文，包括：产品名称、净含量、成分表（INCI格式）、负责任联系人信息。另外要特别注意，不能有虚假或误导性声明。",
          "vi": "Nhãn phải có tiếng Anh, bao gồm: tên sản phẩm, khối lượng tịnh, danh sách thành phần (INCI), thông tin liên hệ chịu trách nhiệm. Ngoài ra đặc biệt chú ý không được có claim sai sự thật hoặc gây nhầm lẫn."
        },
        {
          "speaker": "Anh Đức",
          "zh": "我们的工厂有ISO 22716认证，这个对我们有帮助吗？",
          "vi": "Nhà máy của chúng tôi có chứng nhận ISO 22716, điều này có giúp ích không?"
        },
        {
          "speaker": "陈女士",
          "zh": "有的，ISO 22716是国际GMP标准，虽然FDA不强制要求，但这个认证可以证明您的生产条件符合良好生产规范，在市场上也是一个竞争优势。",
          "vi": "Có, ISO 22716 là tiêu chuẩn GMP quốc tế, dù FDA không bắt buộc, nhưng chứng nhận này chứng minh điều kiện sản xuất của anh đáp ứng tiêu chuẩn sản xuất tốt, đây cũng là lợi thế cạnh tranh trên thị trường."
        }
      ]
    },
    "notes": [
      {
        "title": "MoCRA 2022: thay đổi lớn nhất trong quy định mỹ phẩm Mỹ trong 80 năm",
        "body": "Trước 2022, FDA gần như không có quyền thu hồi mỹ phẩm. MoCRA thay đổi điều đó: bắt buộc đăng ký, báo cáo tác dụng phụ nghiêm trọng, FDA có quyền thu hồi. Ai bán mỹ phẩm ở Mỹ mà không biết MoCRA là đang chấp nhận rủi ro pháp lý nghiêm trọng."
      },
      {
        "title": "\"Brightening\" vs \"Whitening\": chọn từ cẩn thận",
        "body": "Trên nhãn mỹ phẩm Mỹ, tránh dùng \"whitening\" (làm trắng) — FDA coi đây là drug claim nếu không có hoạt chất OTC đi kèm. Thay bằng \"brightening\" (làm sáng) hoặc \"even skin tone\" (đều màu da) — an toàn hơn về mặt pháp lý."
      },
      {
        "title": "Kim loại nặng: thủy ngân trong kem trắng da là vấn đề lớn",
        "body": "Nhiều kem làm trắng da từ TQ, Đông Nam Á và Mỹ Latin bị FDA thu hồi vì chứa thủy ngân (汞). FDA phát hiện hàng chục sản phẩm mỗi năm. Đây là lý do kiểm tra kim loại nặng là bắt buộc trước khi xuất hàng đi Mỹ."
      },
      {
        "title": "ISO 22716: đầu tư vào nhà máy có chứng nhận này",
        "body": "Khi chọn nhà máy OEM mỹ phẩm, ưu tiên nhà máy có ISO 22716. Điều này đảm bảo quy trình sản xuất đáng tin cậy và là bằng chứng cho người mua sỉ, nhà phân phối và Amazon (trong một số trường hợp) rằng sản phẩm được sản xuất đúng chuẩn."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "MoCRA (2022) yêu cầu điều gì mới với mỹ phẩm bán ở Mỹ?",
          "options": {
            "A": "Phải có FDA approval như thuốc",
            "B": "Phải đăng ký thông báo với FDA và báo cáo tác dụng phụ nghiêm trọng",
            "C": "Phải test trên 100 người tình nguyện",
            "D": "Phải in nhãn bằng 3 ngôn ngữ"
          }
        },
        {
          "num": 2,
          "q": "Kem chống nắng có SPF ở Mỹ được phân loại là gì?",
          "options": {
            "A": "Mỹ phẩm thông thường",
            "B": "Thuốc OTC (Over-the-Counter Drug)",
            "C": "Thực phẩm bổ sung",
            "D": "Thiết bị y tế"
          }
        },
        {
          "num": 3,
          "q": "Tại sao nên dùng \"brightening\" thay vì \"whitening\" trên nhãn mỹ phẩm Mỹ?",
          "options": {
            "A": "\"Brightening\" nghe đẹp hơn",
            "B": "\"Whitening\" có thể kích hoạt yêu cầu quản lý thuốc OTC",
            "C": "FDA cấm hoàn toàn từ \"whitening\"",
            "D": "Không có sự khác biệt pháp lý"
          }
        },
        {
          "num": 4,
          "q": "Kim loại nặng nào thường gặp nhất trong các vụ thu hồi kem làm trắng da ở Mỹ?",
          "options": {
            "A": "Chì",
            "B": "Thủy ngân",
            "C": "Asen",
            "D": "Cadmium"
          }
        },
        {
          "num": 5,
          "q": "ISO 22716 là chứng nhận về điều gì?",
          "options": {
            "A": "An toàn thành phần hóa học",
            "B": "Tiêu chuẩn GMP (sản xuất tốt) quốc tế cho mỹ phẩm",
            "C": "Kiểm tra hạn sử dụng",
            "D": "Đóng gói và vận chuyển"
          }
        },
        {
          "num": 6,
          "q": "Sản phẩm mỹ phẩm bị thu hồi phổ biến nhất vì nguyên nhân gì?",
          "options": {
            "A": "Nhãn mác không đẹp",
            "B": "Nhiễm vi sinh, thành phần vượt ngưỡng an toàn, nhãn sai",
            "C": "Giá quá cao",
            "D": "Bao bì không đạt chuẩn Amazon"
          }
        },
        {
          "num": 7,
          "q": "Kiểm tra vi sinh quan trọng nhất với loại sản phẩm nào?",
          "options": {
            "A": "Phấn khô",
            "B": "Sản phẩm chứa nước (lotion, toner, serum)",
            "C": "Son dưỡng môi",
            "D": "Nước hoa"
          }
        },
        {
          "num": 8,
          "q": "Nhãn mỹ phẩm bán ở Mỹ bắt buộc phải có gì?",
          "options": {
            "A": "Tên bằng tiếng Trung",
            "B": "Tên sản phẩm, khối lượng tịnh, INCI list, thông tin liên hệ — tất cả bằng tiếng Anh",
            "C": "Chỉ cần thành phần chính",
            "D": "Ngày sản xuất và tên nhà máy"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "MoCRA cho phép FDA thu hồi mỹ phẩm không an toàn — điều này không có trước 2022."
        },
        {
          "num": 10,
          "q": "Nhà sản xuất mỹ phẩm có thể tự viết \"dermatologist tested\" mà không cần bằng chứng kiểm định."
        },
        {
          "num": 11,
          "q": "Kiểm tra kim loại nặng đặc biệt quan trọng với mỹ phẩm màu và sản phẩm làm trắng da."
        },
        {
          "num": 12,
          "q": "Niacinamide bị FDA phân loại là thành phần OTC drug."
        },
        {
          "num": 13,
          "q": "ISO 22716 là chứng nhận bắt buộc theo yêu cầu của FDA cho nhà máy sản xuất mỹ phẩm."
        },
        {
          "num": 14,
          "q": "Mỹ phẩm chứa thành phần bị cấm có thể bị thu hồi và nhà sản xuất bị phạt nặng."
        }
      ],
      "fillblank": {
        "wordbank": [
          "FDA备案",
          "重金属检测",
          "微生物检测",
          "标签合规",
          "召回",
          "GMP认证"
        ],
        "items": [
          {
            "num": 15,
            "q": "根据MoCRA，所有在美国销售的化妆品需要做____，包括公司注册。"
          },
          {
            "num": 16,
            "q": "含水产品上市前必须通过____，确保不含危险细菌。"
          },
          {
            "num": 17,
            "q": "美白类产品特别需要____，汞超标会导致产品被____。"
          },
          {
            "num": 18,
            "q": "进入美国市场，____方面最容易出问题，建议请专业人士审查英文标签。"
          },
          {
            "num": 19,
            "q": "我们工厂有ISO 22716____，证明符合国际化妆品生产规范。"
          },
          {
            "num": 20,
            "q": "违反FDA规定的产品可能被强制____，损失非常大。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "根据MoCRA法规，您需要向FDA提交产品备案，包括公司注册、成分表和负责任联系人信息。"
        },
        {
          "num": 22,
          "q": "您的产品声称有\"美白\"效果，建议改为\"提亮肤色\"，避免触发OTC药品的监管要求。"
        },
        {
          "num": 23,
          "q": "出货前必须通过SGS的微生物检测和重金属检测，这是进入美国市场的最低合规门槛。"
        },
        {
          "num": 24,
          "q": "我们工厂通过了ISO 22716认证，意味着我们的生产全程符合国际化妆品GMP标准。"
        },
        {
          "num": 25,
          "q": "请注意产品标签上不能有虚假或误导性声明，否则可能面临FDA的执法行动。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Theo MoCRA, chúng tôi cần đăng ký thông báo sản phẩm với FDA trước khi bán ở Mỹ phải không?"
        },
        {
          "num": 27,
          "q": "Sản phẩm chứa nước cần kiểm tra vi sinh trước khi xuất hàng, đây là yêu cầu bắt buộc."
        },
        {
          "num": 28,
          "q": "Nhà máy có chứng nhận ISO 22716 không? Đây là bằng chứng quan trọng về điều kiện sản xuất đạt chuẩn."
        },
        {
          "num": 29,
          "q": "Chúng tôi muốn claim \"brightening\" thay vì \"whitening\" để tránh bị phân loại là OTC drug."
        },
        {
          "num": 30,
          "q": "Sản phẩm cần kiểm tra kim loại nặng trước khi xuất sang Mỹ, đặc biệt kiểm tra thủy ngân và chì."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": false,
        "11": true,
        "12": false,
        "13": false,
        "14": true
      },
      "fillblank": {
        "15": "FDA备案",
        "16": "微生物检测",
        "17": [
          "重金属检测",
          "召回"
        ],
        "18": "标签合规",
        "19": "GMP认证",
        "20": "召回"
      },
      "zh2vi": {
        "21": "Theo quy định MoCRA, anh cần nộp đăng ký thông báo sản phẩm với FDA, bao gồm đăng ký công ty, danh sách thành phần và thông tin liên hệ chịu trách nhiệm.",
        "22": "Sản phẩm của anh claim có hiệu quả \"làm trắng\", khuyến nghị đổi thành \"làm sáng tông da\" để tránh kích hoạt yêu cầu quản lý thuốc OTC.",
        "23": "Trước khi xuất hàng phải qua kiểm tra vi sinh và kim loại nặng của SGS, đây là ngưỡng tuân thủ tối thiểu để vào thị trường Mỹ.",
        "24": "Nhà máy của chúng tôi đã được chứng nhận ISO 22716, nghĩa là toàn bộ quy trình sản xuất của chúng tôi đáp ứng tiêu chuẩn GMP mỹ phẩm quốc tế.",
        "25": "Vui lòng lưu ý nhãn sản phẩm không được có claim sai hoặc gây nhầm lẫn, nếu không có thể đối mặt với hành động thực thi của FDA."
      },
      "vi2zh": {
        "26": "根据MoCRA，我们在美国销售前需要向FDA进行产品备案，是吗？",
        "27": "含水产品出货前必须做微生物检测，这是强制要求。",
        "28": "工厂有ISO 22716认证吗？这是证明生产条件达标的重要证明。",
        "29": "我们想用\"提亮肤色\"代替\"美白\"，避免被归类为OTC药品。",
        "30": "产品出口到美国前需要做重金属检测，特别要检测汞和铅的含量。"
      }
    }
  },
  {
    "num": 18,
    "title": "THỜI TRANG: CHẤT LIỆU & SẢN PHẨM",
    "date": "14/6",
    "phase": 2,
    "vocab": [
      {
        "num": 1,
        "hanzi": "面料",
        "pinyin": "miànliào",
        "vi": "vải / chất liệu vải",
        "explanation": "Thuật ngữ chung chỉ loại vải dùng để may quần áo. Mỗi loại vải có đặc tính khác nhau về độ mềm, độ co giãn, thoáng khí, bền màu... Khi đặt hàng OEM thời trang, 面料 là thông số đầu tiên phải xác nhận vì ảnh hưởng đến toàn bộ cảm giác sản phẩm và giá thành.",
        "example": {
          "zh": "请问这款T恤用的是什么面料？棉含量是多少？",
          "vi": "Sản phẩm áo phông này dùng chất liệu gì? Tỷ lệ cotton là bao nhiêu?"
        }
      },
      {
        "num": 2,
        "hanzi": "棉",
        "pinyin": "mián",
        "vi": "bông / cotton",
        "explanation": "Sợi tự nhiên từ cây bông, phổ biến nhất trong thời trang. Các loại thường gặp: 纯棉 (100% cotton), 有机棉 (organic cotton — đang được ưa chuộng), 精梳棉 (combed cotton — mềm hơn), 环锭纺棉 (ring-spun cotton — chất lượng cao hơn). Với thị trường Mỹ, ring-spun cotton 100% có giá bán cao hơn đáng kể.",
        "example": {
          "zh": "我们要求用180克重的纯棉面料，精梳棉效果更好。",
          "vi": "Chúng tôi yêu cầu dùng vải cotton 100% trọng lượng 180gsm, combed cotton hiệu quả tốt hơn."
        }
      },
      {
        "num": 3,
        "hanzi": "聚酯纤维",
        "pinyin": "jùzhǐ xiānwéi",
        "vi": "polyester / sợi tổng hợp",
        "explanation": "Sợi tổng hợp phổ biến nhất — rẻ, bền, ít nhăn, giữ màu tốt nhưng kém thoáng khí hơn cotton. Nhiều sản phẩm là poly-cotton blend (涤棉混纺) — kết hợp ưu điểm của cả hai. Tỷ lệ phổ biến: 60% cotton / 40% polyester hoặc 65/35.",
        "example": {
          "zh": "运动系列用的是85%聚酯纤维加15%氨纶，有弹力，适合运动。",
          "vi": "Dòng thể thao dùng 85% polyester và 15% spandex, có độ đàn hồi, phù hợp vận động."
        }
      },
      {
        "num": 4,
        "hanzi": "氨纶",
        "pinyin": "ānlún",
        "vi": "spandex / elastane (Lycra)",
        "explanation": "Sợi có độ co giãn cao — thêm vào vải để tăng độ đàn hồi. Chỉ cần 2–5% spandex là vải đã có độ giãn tốt. Bắt buộc trong quần áo thể thao, đồ bơi, jeans co giãn. Lycra là tên thương hiệu của spandex.",
        "example": {
          "zh": "这款瑜伽裤用的是尼龙加氨纶，四向弹力，穿着非常舒适。",
          "vi": "Quần yoga này dùng nylon và spandex, đàn hồi 4 chiều, mặc rất thoải mái."
        }
      },
      {
        "num": 5,
        "hanzi": "克重 (GSM)",
        "pinyin": "kè zhòng",
        "vi": "trọng lượng vải (gram per square meter)",
        "explanation": "Đơn vị đo độ dày/nặng của vải: gram trên mỗi mét vuông. Áo phông nhẹ: 140–160 gsm. Áo phông thường: 180–200 gsm. Áo dày/cao cấp: 220–280 gsm. GSM cao hơn = vải dày hơn, nặng hơn, thường chất lượng cảm nhận tốt hơn. Khi bán Amazon, GSM là thông số phân biệt tầm giá.",
        "example": {
          "zh": "美国亚马逊上的中高端T恤一般用220克以上的面料，手感更好。",
          "vi": "Áo phông tầm trung cao cấp trên Amazon Mỹ thường dùng vải từ 220gsm trở lên, cảm giác tốt hơn."
        }
      },
      {
        "num": 6,
        "hanzi": "色牢度",
        "pinyin": "sè láodù",
        "vi": "độ bền màu (color fastness)",
        "explanation": "Khả năng vải giữ màu khi giặt, phơi nắng, ma sát, đổ mồ hôi. Tiêu chuẩn đánh giá từ 1–5 (5 là tốt nhất). Màu kém bền = review xấu trên Amazon vì khách hàng Mỹ giặt hàng ngày và kỳ vọng màu không phai sau 20–30 lần giặt.",
        "example": {
          "zh": "我们的面料色牢度达到4级以上，水洗30次不褪色。",
          "vi": "Độ bền màu vải của chúng tôi đạt cấp 4 trở lên, giặt 30 lần không phai màu."
        }
      },
      {
        "num": 7,
        "hanzi": "缩水率",
        "pinyin": "suōshuǐ lǜ",
        "vi": "tỷ lệ co rút sau giặt (shrinkage rate)",
        "explanation": "Phần trăm vải bị co lại sau khi giặt lần đầu. Cotton thường co 3–5% nếu không qua xử lý pre-shrunk. Hàng xuất Mỹ phải được pre-shrunk (预缩处理) hoặc khai báo tỷ lệ co trên nhãn để khách hàng biết. Áo co nhiều sau giặt = review xấu, returns.",
        "example": {
          "zh": "我们的面料经过预缩处理，缩水率控制在3%以内，符合美国市场标准。",
          "vi": "Vải của chúng tôi đã qua xử lý pre-shrunk, tỷ lệ co rút kiểm soát trong 3%, đạt tiêu chuẩn thị trường Mỹ."
        }
      },
      {
        "num": 8,
        "hanzi": "成衣",
        "pinyin": "chéngyī",
        "vi": "quần áo thành phẩm / ready-to-wear",
        "explanation": "Quần áo đã được may hoàn chỉnh, sẵn sàng mặc ngay (phân biệt với vải thô hoặc bán thành phẩm). Trong xuất nhập khẩu, 成衣 là danh mục sản phẩm cụ thể trong HS code. OEM thời trang chủ yếu là 成衣.",
        "example": {
          "zh": "我们专注于成衣OEM生产，从裁剪到成品，全程在我们工厂完成。",
          "vi": "Chúng tôi tập trung vào sản xuất OEM quần áo thành phẩm, từ cắt vải đến thành phẩm đều hoàn thành tại nhà máy."
        }
      },
      {
        "num": 9,
        "hanzi": "尺码",
        "pinyin": "chǐmǎ",
        "vi": "cỡ size",
        "explanation": "Thông số kích thước của quần áo. Hệ thống size Mỹ (S/M/L/XL/XXL hoặc số) khác với TQ và VN — phải có bảng size chuyển đổi rõ ràng. Amazon yêu cầu size chart chi tiết trên trang sản phẩm. Sai size = return rate cao nhất trong ngành thời trang.",
        "example": {
          "zh": "请提供美国市场的尺码对照表，美国客户身材通常比亚洲客户大一到两码。",
          "vi": "Vui lòng cung cấp bảng chuyển đổi size cho thị trường Mỹ, khách Mỹ thường to hơn khách Á một đến hai size."
        }
      },
      {
        "num": 10,
        "hanzi": "版型",
        "pinyin": "bǎnxíng",
        "vi": "dáng / kiểu dáng (cut/fit)",
        "explanation": "Kiểu cắt may quyết định dáng quần áo khi mặc: 修身 (slim fit — ôm người), 宽松 (loose fit — rộng), 直筒 (regular fit — thẳng), 收腰 (fitted waist). Với thị trường Mỹ, dáng quần áo phải phù hợp với vóc dáng người Mỹ — thường cần cỡ bigger và looser hơn so với thiết kế TQ gốc.",
        "example": {
          "zh": "我们需要针对美国体型调整版型，肩宽和胸围都要加大，保持宽松舒适的风格。",
          "vi": "Chúng tôi cần điều chỉnh dáng cắt cho vóc dáng người Mỹ, rộng vai và vòng ngực đều cần tăng, giữ phong cách rộng thoải mái."
        }
      }
    ],
    "dialogue": {
      "context": "Buyer VN đặt hàng áo phông OEM để bán Amazon Mỹ. Đang xác nhận thông số vải và dáng cắt với nhà máy.",
      "characters": [
        {
          "name": "面料技术员李姐 (Lǐ jiě)",
          "role": "Kỹ thuật viên vải nhà máy"
        },
        {
          "name": "Anh Lộc",
          "role": "Nhân viên thu mua VN"
        }
      ],
      "lines": [
        {
          "speaker": "Anh Lộc",
          "zh": "我们要订一批男士T恤，在美国亚马逊上销售，主打高质感休闲风，请问你们有什么面料推荐？",
          "vi": "Chúng tôi muốn đặt áo phông nam bán trên Amazon Mỹ, hướng đến chất lượng cao phong cách casual, anh có khuyến nghị vải gì không?"
        },
        {
          "speaker": "李姐",
          "zh": "针对美国市场的高端T恤，我们推荐用32支精梳棉，克重在220到240克之间，手感厚实，洗涤后不容易变形。",
          "vi": "Với áo phông cao cấp thị trường Mỹ, chúng tôi khuyến nghị combed cotton 32s, trọng lượng 220 đến 240 gsm, cảm giác dày dặn, sau giặt không dễ biến dạng."
        },
        {
          "speaker": "Anh Lộc",
          "zh": "220到240克听起来不错。棉的品质方面，是什么棉？",
          "vi": "220 đến 240 gsm nghe hay đấy. Về chất lượng bông, dùng loại bông nào?"
        },
        {
          "speaker": "李姐",
          "zh": "我们用的是新疆长绒棉，品质在国内属于顶级，如果您预算允许，也可以升级到有机棉，现在美国消费者对有机棉越来越感兴趣。",
          "vi": "Chúng tôi dùng bông sợi dài Tân Cương, chất lượng thuộc hàng đầu trong nước, nếu ngân sách cho phép cũng có thể nâng cấp lên organic cotton, hiện người tiêu dùng Mỹ ngày càng quan tâm đến organic cotton."
        },
        {
          "speaker": "Anh Lộc",
          "zh": "有机棉价格大概会贵多少？",
          "vi": "Organic cotton đắt hơn bao nhiêu?"
        },
        {
          "speaker": "李姐",
          "zh": "有机棉认证的面料大概比普通棉贵20到30%，但可以在亚马逊上标注\"GOTS认证有机棉\"，对溢价定价有帮助。",
          "vi": "Vải có chứng nhận organic cotton đắt hơn cotton thường khoảng 20–30%, nhưng có thể ghi trên Amazon \"GOTS certified organic cotton\", giúp định giá premium dễ hơn."
        },
        {
          "speaker": "Anh Lộc",
          "zh": "好，我们先用普通精梳棉，后续考虑有机棉。色牢度方面有什么保证？",
          "vi": "Tốt, trước mắt dùng combed cotton thường, sau mới xem xét organic. Về độ bền màu có đảm bảo gì không?"
        },
        {
          "speaker": "李姐",
          "zh": "我们的染色工艺色牢度达到ISO 4级标准，水洗50次后颜色基本无变化，这点您可以放心。",
          "vi": "Quy trình nhuộm màu của chúng tôi đạt tiêu chuẩn ISO cấp 4, giặt 50 lần màu gần như không thay đổi, điểm này anh yên tâm."
        },
        {
          "speaker": "Anh Lộc",
          "zh": "很好。缩水率呢？这个问题在亚马逊上经常被投诉。",
          "vi": "Tốt. Còn tỷ lệ co rút? Vấn đề này hay bị khiếu nại trên Amazon."
        },
        {
          "speaker": "李姐",
          "zh": "我们会做预缩处理，缩水率控制在3%以内，在标签上会标明洗涤建议，冷水洗可以进一步减少缩水。",
          "vi": "Chúng tôi sẽ qua xử lý pre-shrunk, tỷ lệ co rút kiểm soát trong 3%, trên nhãn sẽ ghi hướng dẫn giặt, giặt nước lạnh có thể giảm co rút thêm."
        },
        {
          "speaker": "Anh Lộc",
          "zh": "版型方面，我们需要针对美国体型，能调整吗？",
          "vi": "Về dáng cắt, chúng tôi cần điều chỉnh cho vóc dáng người Mỹ, có làm được không?"
        },
        {
          "speaker": "李姐",
          "zh": "完全可以，我们有专门针对北美市场的版型，肩宽和胸围比亚洲版大，版型是宽松版，适合美国消费者的穿着习惯。您需要我们发一套美版的尺码对照表吗？",
          "vi": "Hoàn toàn được, chúng tôi có dáng cắt riêng cho thị trường Bắc Mỹ, rộng vai và vòng ngực hơn phiên bản Á, dáng cắt rộng, phù hợp thói quen mặc của người tiêu dùng Mỹ. Anh muốn chúng tôi gửi bảng chuyển đổi size phiên bản Mỹ không?"
        },
        {
          "speaker": "Anh Lộc",
          "zh": "需要，另外样品做好后，我们会找美国本地的消费者试穿，反馈版型是否合适。",
          "vi": "Cần, ngoài ra sau khi mẫu làm xong, chúng tôi sẽ nhờ người tiêu dùng Mỹ bản địa thử mặc, xem phản hồi về dáng cắt có phù hợp không."
        },
        {
          "speaker": "李姐",
          "zh": "好的，我们也建议这样做。美国市场对fit的要求很细，本地试穿反馈对我们调整版型很有帮助。",
          "vi": "Tốt, chúng tôi cũng khuyến nghị làm vậy. Thị trường Mỹ yêu cầu về fit rất chi tiết, phản hồi thử mặc tại chỗ rất có ích cho chúng tôi điều chỉnh dáng cắt."
        }
      ]
    },
    "notes": [
      {
        "title": "GSM: thông số quan trọng nhất khi mô tả áo phông trên Amazon",
        "body": "Trong trang sản phẩm Amazon, ghi rõ GSM là cách phân biệt với hàng rẻ tiền. Khách hàng Mỹ giờ biết tìm thông số này. Áo 180 gsm vs 240 gsm là sự khác biệt rõ ràng về cảm giác cầm tay — và khách Amazon có thể cảm nhận được qua ảnh và review."
      },
      {
        "title": "GOTS: chứng nhận organic cotton có giá trị",
        "body": "GOTS (Global Organic Textile Standard) là tiêu chuẩn quốc tế cho vải hữu cơ — chứng nhận từ canh tác đến sản xuất. Sản phẩm có GOTS có thể bán giá cao hơn 20–40% và thu hút phân khúc khách hàng ý thức về môi trường đang ngày càng lớn ở Mỹ."
      },
      {
        "title": "Size: nguyên nhân return cao nhất trong thời trang Amazon",
        "body": "Sai size = return. Và return trong thời trang trên Amazon thường đạt 20–30% nếu không có size chart rõ ràng. Giải pháp: (1) bảng size chi tiết trên trang Amazon có hình minh họa cách đo, (2) ghi rõ size model (chiều cao/cân nặng/size mặc trong ảnh), (3) nếu có thể, test với người Mỹ thực tế trước khi launch."
      },
      {
        "title": "Thị trường Mỹ vs Á Châu: điều chỉnh version",
        "body": "Kích thước người Mỹ trung bình lớn hơn người Á Châu đáng kể. Nhà máy TQ thường có 亚版 (Asian fit) và 美版 (US fit) riêng. Khi đặt hàng, luôn chỉ định rõ 美版 (US sizing) để tránh nhận nhầm 亚版."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "GSM trong ngành vải là gì?",
          "options": {
            "A": "Giá sản phẩm tính theo cân",
            "B": "Trọng lượng vải tính theo gram trên mỗi mét vuông",
            "C": "Số sợi trên mỗi cm²",
            "D": "Tỷ lệ thành phần tổng hợp trong vải"
          }
        },
        {
          "num": 2,
          "q": "Áo phông cao cấp trên Amazon Mỹ thường có GSM khoảng bao nhiêu?",
          "options": {
            "A": "100–130 gsm",
            "B": "140–160 gsm",
            "C": "180–200 gsm",
            "D": "220 gsm trở lên"
          }
        },
        {
          "num": 3,
          "q": "Độ bền màu cấp 4 (ISO) có nghĩa là gì trong thực tế?",
          "options": {
            "A": "Phai màu sau 4 lần giặt",
            "B": "Màu giữ tốt qua nhiều lần giặt, về cơ bản không thay đổi",
            "C": "Chỉ dùng được 4 màu",
            "D": "Cần nhuộm lại sau 4 tháng"
          }
        },
        {
          "num": 4,
          "q": "Nguyên nhân return cao nhất trong thời trang trên Amazon là gì?",
          "options": {
            "A": "Chất lượng vải kém",
            "B": "Sai size / size không đúng mô tả",
            "C": "Màu sắc không đúng",
            "D": "Giá quá cao"
          }
        },
        {
          "num": 5,
          "q": "预缩处理 giúp giải quyết vấn đề gì?",
          "options": {
            "A": "Tăng độ bền màu",
            "B": "Giảm tỷ lệ co rút vải sau giặt",
            "C": "Cải thiện cảm giác vải",
            "D": "Tăng tuổi thọ sản phẩm"
          }
        },
        {
          "num": 6,
          "q": "Chứng nhận GOTS liên quan đến điều gì?",
          "options": {
            "A": "An toàn hóa chất trong vải",
            "B": "Tiêu chuẩn vải hữu cơ từ canh tác đến sản xuất",
            "C": "Độ bền màu",
            "D": "Kích thước sản phẩm"
          }
        },
        {
          "num": 7,
          "q": "Khi đặt hàng thời trang cho thị trường Mỹ, cần chỉ định điều gì để tránh nhận nhầm size?",
          "options": {
            "A": "Tên nhà máy",
            "B": "美版 (US sizing) thay vì 亚版 (Asian sizing)",
            "C": "Màu sắc cụ thể",
            "D": "Loại vải"
          }
        },
        {
          "num": 8,
          "q": "Spandex/Lycra (氨纶) thường chiếm tỷ lệ bao nhiêu trong vải đàn hồi?",
          "options": {
            "A": "30–50%",
            "B": "15–25%",
            "C": "2–5% đủ để tạo độ đàn hồi tốt",
            "D": "60–70%"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Vải cao GSM không có nghĩa là luôn chất lượng tốt hơn, nhưng thường được cảm nhận là dày và nặng hơn."
        },
        {
          "num": 10,
          "q": "Nhà máy TQ thường có phiên bản size Á Châu và Mỹ riêng biệt cho cùng một thiết kế."
        },
        {
          "num": 11,
          "q": "100% polyester thoáng khí hơn 100% cotton."
        },
        {
          "num": 12,
          "q": "Organic cotton theo chứng nhận GOTS có thể bán giá premium hơn cotton thường."
        },
        {
          "num": 13,
          "q": "Tỷ lệ co rút 3% sau giặt là mức chấp nhận được cho thị trường Mỹ."
        },
        {
          "num": 14,
          "q": "Size chart chi tiết trên trang Amazon là không cần thiết vì khách hàng đã biết size của mình."
        }
      ],
      "fillblank": {
        "wordbank": [
          "面料",
          "克重",
          "色牢度",
          "缩水率",
          "版型",
          "尺码"
        ],
        "items": [
          {
            "num": 15,
            "q": "请问这款T恤的____是多少？220克的感觉比150克厚实很多。"
          },
          {
            "num": 16,
            "q": "我们要求____达到ISO 4级以上，水洗多次不能褪色。"
          },
          {
            "num": 17,
            "q": "经过预缩处理后，____控制在3%以内，符合美国标准。"
          },
          {
            "num": 18,
            "q": "我们需要针对美国体型的____，请提供美版的____对照表。"
          },
          {
            "num": 19,
            "q": "这款运动裤用的____是85%聚酯纤维加15%氨纶，弹力很好。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 20,
          "q": "这款T恤用的是240克精梳棉，色牢度4级，缩水率3%以内，专门针对美国市场的版型。"
        },
        {
          "num": 21,
          "q": "有机棉比普通棉贵20-30%，但可以申请GOTS认证，在亚马逊上有助于提高售价和吸引环保意识强的消费者。"
        },
        {
          "num": 22,
          "q": "我们提供美版和亚版两种版型，美版肩宽和胸围都更大，适合北美消费者的体型。"
        },
        {
          "num": 23,
          "q": "请在亚马逊产品页面提供详细的尺码对照表，包括胸围、腰围、臀围的具体数字，这样可以大幅降低退货率。"
        },
        {
          "num": 24,
          "q": "我们建议样品出来后，找美国本地消费者进行试穿测试，重点测试版型和舒适度，根据反馈再做调整。"
        }
      ],
      "vi2zh": [
        {
          "num": 25,
          "q": "Vải của áo phông này nặng bao nhiêu GSM? Chúng tôi cần ít nhất 220 gsm cho thị trường Mỹ."
        },
        {
          "num": 26,
          "q": "Độ bền màu có đạt cấp 4 theo tiêu chuẩn ISO không? Khách Mỹ giặt thường xuyên nên yêu cầu này quan trọng."
        },
        {
          "num": 27,
          "q": "Anh có thể gửi bảng chuyển đổi size phiên bản Mỹ không? Chúng tôi cần đăng lên trang Amazon."
        },
        {
          "num": 28,
          "q": "Vải đã qua xử lý pre-shrunk chưa? Tỷ lệ co rút phải kiểm soát dưới 3%."
        },
        {
          "num": 29,
          "q": "Chúng tôi muốn nâng cấp lên organic cotton GOTS cho dòng sản phẩm cao cấp, giá tăng thêm bao nhiêu?"
        },
        {
          "num": 30,
          "q": "Dáng cắt cần điều chỉnh cho vóc dáng người Mỹ, đặc biệt phần vai và ngực cần rộng hơn phiên bản Á."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "D",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "B",
        "8": "C"
      },
      "tf": {
        "9": true,
        "10": true,
        "11": false,
        "12": true,
        "13": true,
        "14": false
      },
      "fillblank": {
        "15": "克重",
        "16": "色牢度",
        "17": "缩水率",
        "18": [
          "版型",
          "尺码"
        ],
        "19": "面料"
      },
      "zh2vi": {
        "20": "Áo phông này dùng combed cotton 240gsm, độ bền màu cấp 4, tỷ lệ co rút trong 3%, dáng cắt riêng cho thị trường Mỹ.",
        "21": "Organic cotton đắt hơn cotton thường 20–30%, nhưng có thể xin chứng nhận GOTS, trên Amazon giúp tăng giá bán và thu hút người tiêu dùng có ý thức môi trường.",
        "22": "Chúng tôi cung cấp hai dáng cắt: phiên bản Mỹ và phiên bản Á, phiên bản Mỹ rộng vai và vòng ngực hơn, phù hợp vóc dáng người tiêu dùng Bắc Mỹ.",
        "23": "Vui lòng đăng bảng chuyển đổi size chi tiết trên trang Amazon, bao gồm số đo cụ thể vòng ngực, vòng eo, vòng hông, như vậy có thể giảm đáng kể tỷ lệ hoàn hàng.",
        "24": "Chúng tôi khuyến nghị sau khi có mẫu, tìm người tiêu dùng Mỹ bản địa thử mặc, tập trung đánh giá dáng cắt và độ thoải mái, sau đó điều chỉnh theo phản hồi."
      },
      "vi2zh": {
        "25": "这款T恤的面料克重是多少？我们需要至少220克才能打入美国市场。",
        "26": "色牢度能达到ISO 4级吗？美国客户经常洗涤，这个要求很重要。",
        "27": "能发一份美版尺码对照表吗？我们需要上传到亚马逊产品页面。",
        "28": "面料有没有做预缩处理？缩水率必须控制在3%以内。",
        "29": "我们想为高端系列升级到GOTS认证有机棉，价格会增加多少？",
        "30": "版型需要针对美国体型调整，特别是肩宽和胸围要比亚版更大。"
      }
    }
  },
  {
    "num": 19,
    "title": "THỜI TRANG: SẢN XUẤT & KIỂM HÀNG",
    "date": "15/6",
    "phase": 2,
    "vocab": [
      {
        "num": 1,
        "hanzi": "工艺单",
        "pinyin": "gōngyì dān",
        "vi": "tech pack / tài liệu kỹ thuật sản xuất",
        "explanation": "Bộ tài liệu kỹ thuật hoàn chỉnh mà buyer cung cấp cho nhà máy, bao gồm: bản vẽ kỹ thuật chi tiết, thông số vải, màu sắc (Pantone), hướng dẫn may, thông số size... Đây là \"ngôn ngữ\" giao tiếp chính thức giữa buyer và nhà máy thời trang. Tech pack tốt = ít sai sót = ít làm lại.",
        "example": {
          "zh": "请按照我们提供的工艺单生产，有不清楚的地方及时联系我们确认。",
          "vi": "Vui lòng sản xuất theo tech pack chúng tôi cung cấp, chỗ nào không rõ liên hệ xác nhận ngay."
        }
      },
      {
        "num": 2,
        "hanzi": "潘通色号",
        "pinyin": "Pāntōng sè hào",
        "vi": "mã màu Pantone",
        "explanation": "Hệ thống màu sắc tiêu chuẩn quốc tế (Pantone Matching System - PMS). Khi chỉ định màu, dùng mã Pantone thay vì mô tả bằng lời (ví dụ \"xanh dương đậm\") để tránh hiểu nhầm. Nhà máy TQ sẽ dùng mã Pantone để phối màu vải và sơn/in. Pantone color guide là công cụ bắt buộc của designer.",
        "example": {
          "zh": "这款T恤的颜色请对标Pantone 19-4024 TCX，深海军蓝色。",
          "vi": "Màu áo phông này vui lòng căn cứ theo Pantone 19-4024 TCX, màu navy đậm."
        }
      },
      {
        "num": 3,
        "hanzi": "车缝工艺",
        "pinyin": "chēféng gōngyì",
        "vi": "quy trình may / kỹ thuật may",
        "explanation": "Tất cả các thao tác may: đường chỉ (针迹), số mũi khâu trên cm (针脚密度), loại chỉ, kiểu may (平缝 bình thường, 包缝 overlock, 链式缝 chain stitch...). Quy trình may kỹ lưỡng quyết định độ bền của sản phẩm — đường may kém = sản phẩm bung chỉ sau vài lần mặc.",
        "example": {
          "zh": "请确保所有接缝使用双线车缝，针脚密度不低于每厘米12针。",
          "vi": "Vui lòng đảm bảo tất cả đường may dùng double stitch, mật độ mũi khâu không dưới 12 mũi/cm."
        }
      },
      {
        "num": 4,
        "hanzi": "印花",
        "pinyin": "yìnhuā",
        "vi": "in hoa văn / in lên vải",
        "explanation": "Kỹ thuật in họa tiết, logo, hình ảnh lên vải. Các loại chính: 丝网印花 (screen printing — phổ biến nhất cho số lượng lớn), DTG (直喷印花 — in kỹ thuật số, phù hợp số lượng nhỏ, màu phức tạp), 热转印 (heat transfer), 刺绣 (thêu). Mỗi loại có chi phí, độ bền và giới hạn màu khác nhau.",
        "example": {
          "zh": "我们的LOGO图案建议用丝网印花，颜色数量在4种以内，可以控制成本。",
          "vi": "Logo của chúng tôi khuyến nghị dùng screen printing, số màu trong 4 màu để kiểm soát chi phí."
        }
      },
      {
        "num": 5,
        "hanzi": "刺绣",
        "pinyin": "cìxiù",
        "vi": "thêu",
        "explanation": "Kỹ thuật tạo họa tiết bằng chỉ thêu — tạo cảm giác cao cấp hơn in. Phù hợp cho logo nhỏ, brand name, hoặc thiết kế đơn giản. Đắt hơn in, cần file DST (định dạng kỹ thuật số cho máy thêu). Thêu chất lượng cao cần mật độ mũi thêu phù hợp để không bị xù lông.",
        "example": {
          "zh": "胸口的品牌LOGO我们要求用刺绣，这样更有质感，和这款帽子的定价相符。",
          "vi": "Logo thương hiệu ở ngực chúng tôi yêu cầu thêu, như vậy có cảm giác cao cấp hơn, phù hợp với mức giá của chiếc mũ này."
        }
      },
      {
        "num": 6,
        "hanzi": "水洗",
        "pinyin": "shuǐxǐ",
        "vi": "xử lý nước (washed finish)",
        "explanation": "Quy trình xử lý quần áo sau khi sản xuất để tạo hiệu ứng đặc biệt: 石洗 (stone wash — hiệu ứng bạc màu vintage), 酸洗 (acid wash), 雪花洗 (snow wash). Thường dùng cho jeans và quần áo denim. Mỗi kiểu xử lý cho màu sắc và cảm giác vải khác nhau.",
        "example": {
          "zh": "这款牛仔裤需要石洗处理，要有复古做旧的感觉，但不能太夸张。",
          "vi": "Quần jeans này cần xử lý stone wash, tạo cảm giác vintage cũ kỹ, nhưng không được quá phóng đại."
        }
      },
      {
        "num": 7,
        "hanzi": "缝纫线",
        "pinyin": "féngrèn xiàn",
        "vi": "chỉ may",
        "explanation": "Chỉ dùng để may quần áo. Màu chỉ, độ굵 (tex/denier) và chất liệu chỉ phải được ghi rõ trong tech pack. Chỉ không khớp màu = lỗi thẩm mỹ. Chỉ không đủ bền = bung chỉ = review xấu. Chỉ màu thường khớp với màu vải hoặc tương phản có chủ ý.",
        "example": {
          "zh": "请用和面料颜色相同的缝纫线，或者参考我们工艺单上的潘通色号。",
          "vi": "Vui lòng dùng chỉ may cùng màu với vải, hoặc tham khảo mã Pantone trong tech pack của chúng tôi."
        }
      },
      {
        "num": 8,
        "hanzi": "辅料",
        "pinyin": "fǔliào",
        "vi": "vật liệu phụ / trim / notions",
        "explanation": "Tất cả vật liệu không phải vải chính: cúc (纽扣 niǔkòu), khóa kéo (拉链 lāliàn), nhãn mác (标签 biāoqiān), dây viền, bọ... Chất lượng 辅料 ảnh hưởng đến độ bền và ngoại quan. Khóa kéo YKK (Nhật) là tiêu chuẩn chất lượng quốc tế được khách hàng Mỹ công nhận.",
        "example": {
          "zh": "这款夹克的拉链请用YKK品牌，客户对这个品牌的品质有认知，有助于提升产品价值感。",
          "vi": "Khóa kéo của chiếc áo khoác này vui lòng dùng thương hiệu YKK, khách hàng có nhận thức về chất lượng thương hiệu này, giúp nâng cao cảm nhận giá trị sản phẩm."
        }
      },
      {
        "num": 9,
        "hanzi": "抽检标准",
        "pinyin": "chōujiǎn biāozhǔn",
        "vi": "tiêu chuẩn kiểm tra ngẫu nhiên",
        "explanation": "Quy tắc xác định bao nhiêu sản phẩm cần kiểm tra từ một lô và ngưỡng chấp nhận lỗi là bao nhiêu. Trong thời trang, AQL 2.5 là tiêu chuẩn phổ biến. Các điểm kiểm tra: thông số kích thước (quan trọng nhất), lỗi may, màu sắc, in/thêu, nhãn mác.",
        "example": {
          "zh": "我们按AQL 2.5进行抽检，重点检查尺寸偏差、针脚质量和印花准确性。",
          "vi": "Chúng tôi kiểm tra theo AQL 2.5, tập trung kiểm tra sai lệch kích thước, chất lượng đường may và độ chính xác của in."
        }
      },
      {
        "num": 10,
        "hanzi": "尺寸偏差",
        "pinyin": "chǐcùn piānchā",
        "vi": "sai lệch kích thước",
        "explanation": "Khoảng chênh lệch cho phép giữa kích thước thực tế và kích thước trong spec sheet. Ví dụ: chiều dài áo ±1.5cm là chấp nhận được, hơn mức đó là lỗi. Sai lệch kích thước là nguyên nhân return lớn nhất trong thời trang online — khách nhận áo M nhưng size thực tế gần L.",
        "example": {
          "zh": "允许的尺寸偏差是±1.5厘米，超过这个范围的产品需要返工或作为不合格品处理。",
          "vi": "Sai lệch kích thước cho phép là ±1,5cm, vượt quá phạm vi này sản phẩm cần làm lại hoặc xử lý như hàng lỗi."
        }
      }
    ],
    "dialogue": {
      "context": "Kiểm tra lô hàng áo phông trước khi xuất. Nhân viên kiểm hàng phát hiện một số vấn đề và đang thảo luận với nhà máy.",
      "characters": [
        {
          "name": "质检员小刘 (Xiǎo Liú)",
          "role": "Kiểm định viên bên thứ ba"
        },
        {
          "name": "工厂QC王工 (Wáng gōng)",
          "role": "Nhân viên QC nhà máy"
        },
        {
          "name": "Chị Phương",
          "role": "Đại diện buyer VN"
        }
      ],
      "lines": [
        {
          "speaker": "小刘",
          "zh": "我已经完成了这批2000件T恤的抽检，发现了几个问题需要跟大家说明。",
          "vi": "Tôi đã hoàn thành kiểm tra ngẫu nhiên lô 2000 áo phông này, phát hiện vài vấn đề cần nói với mọi người."
        },
        {
          "speaker": "Chị Phương",
          "zh": "请说，具体是什么问题？",
          "vi": "Vui lòng nói, cụ thể là vấn đề gì?"
        },
        {
          "speaker": "小刘",
          "zh": "第一，有85件产品的胸口印花位置偏移超过1.5厘米，不符合工艺单要求。第二，有32件产品的缝纫线颜色和面料颜色不匹配，看起来是用错了线。第三，抽到12件，肩宽尺寸超过允许偏差±1.5厘米的范围。",
          "vi": "Thứ nhất, có 85 sản phẩm vị trí in trên ngực lệch hơn 1,5cm, không đạt yêu cầu tech pack. Thứ hai, có 32 sản phẩm màu chỉ may không khớp với màu vải, có vẻ dùng nhầm chỉ. Thứ ba, lấy 12 sản phẩm kiểm, kích thước vai vượt phạm vi sai lệch cho phép ±1,5cm."
        },
        {
          "speaker": "王工",
          "zh": "关于印花位置，我们会全检并返工，这个问题我们承认。缝纫线颜色不对，应该是某个批次搞错了，我来调查一下。尺寸问题，能让我看一下具体是哪几件吗？",
          "vi": "Về vị trí in, chúng tôi sẽ kiểm tra toàn bộ và làm lại, vấn đề này chúng tôi thừa nhận. Màu chỉ không đúng, có lẽ nhầm một lô nào đó, tôi điều tra lại. Vấn đề kích thước, có thể cho tôi xem cụ thể là những sản phẩm nào không?"
        },
        {
          "speaker": "小刘",
          "zh": "当然，这是检测记录，标注了所有问题产品的编号。",
          "vi": "Tất nhiên, đây là hồ sơ kiểm tra, có đánh dấu số hiệu tất cả sản phẩm lỗi."
        },
        {
          "speaker": "王工",
          "zh": "看了一下，尺寸超差的都是同一天生产的，可能是那天模板出了问题。我们会对那天生产的所有产品进行全检。",
          "vi": "Nhìn qua thấy những sản phẩm sai kích thước đều được sản xuất cùng một ngày, có thể ngày đó template bị lỗi. Chúng tôi sẽ kiểm tra toàn bộ sản phẩm sản xuất trong ngày đó."
        },
        {
          "speaker": "Chị Phương",
          "zh": "好，我需要在出货前看到处理结果。具体来说，所有印花位置不对的要返工，缝纫线颜色不对的也要全部换线，尺寸超差的需要确认是否可以返工，不行的要报废重做。",
          "vi": "Tốt, tôi cần xem kết quả xử lý trước khi xuất hàng. Cụ thể: tất cả sản phẩm in lệch phải làm lại, chỉ sai màu cũng phải thay chỉ toàn bộ, sản phẩm sai kích thước cần xác nhận có thể làm lại được không, không thể thì phải hủy và sản xuất lại."
        },
        {
          "speaker": "王工",
          "zh": "明白，我们今天开始全检，大概三天可以完成处理，请问三天后您这边能安排复检吗？",
          "vi": "Hiểu, hôm nay chúng tôi bắt đầu kiểm tra toàn bộ, khoảng 3 ngày có thể xử lý xong, sau 3 ngày phía chị có thể sắp xếp kiểm tra lại không?"
        },
        {
          "speaker": "Chị Phương",
          "zh": "可以，三天后我让SGS重新来复检，复检通过才能出货。这次出了这些问题，对交期有什么影响？",
          "vi": "Được, sau 3 ngày tôi nhờ SGS kiểm tra lại, qua kiểm tra mới xuất hàng. Lần này phát sinh những vấn đề này, ảnh hưởng thế nào đến thời gian giao hàng?"
        },
        {
          "speaker": "王工",
          "zh": "返工需要三天，加上复检大概要五天，所以这批货出货时间要推迟五天，非常抱歉。",
          "vi": "Làm lại cần 3 ngày, cộng kiểm tra lại khoảng 5 ngày, nên lô hàng này xuất hàng phải trễ 5 ngày, rất xin lỗi."
        },
        {
          "speaker": "Chị Phương",
          "zh": "五天的延误，会影响我们的亚马逊旺季计划。返工和复检的费用由工厂承担吗？",
          "vi": "Trễ 5 ngày sẽ ảnh hưởng kế hoạch mùa cao điểm Amazon của chúng tôi. Chi phí làm lại và kiểm tra lại do nhà máy chịu phải không?"
        },
        {
          "speaker": "王工",
          "zh": "返工和复检费用我们全部承担，这是我们的生产问题。迟延交货方面，我们愿意在下一批订单上给您额外的折扣作为补偿。",
          "vi": "Chi phí làm lại và kiểm tra lại chúng tôi toàn bộ chịu, đây là vấn đề sản xuất của chúng tôi. Về chậm giao hàng, chúng tôi sẵn sàng tặng thêm chiết khấu trên đơn hàng tiếp theo như một khoản bù đắp."
        }
      ]
    },
    "notes": [
      {
        "title": "Tech pack: đầu tư quan trọng nhất trong thời trang OEM",
        "body": "Tech pack càng chi tiết, sản phẩm làm ra càng đúng ý. Những lỗi như \"in lệch 1.5cm\" hay \"màu chỉ không đúng\" thường xảy ra khi tech pack thiếu thông số cụ thể. Chi phí thuê designer làm tech pack chuyên nghiệp (100–300 USD/sản phẩm) ít hơn nhiều so với chi phí làm lại hàng."
      },
      {
        "title": "Screen printing vs DTG vs thêu: chọn đúng kỹ thuật",
        "body": "Screen printing: tốt nhất cho số lượng lớn (>100 cái), màu phẳng đơn giản, giá rẻ/cái khi số lượng lớn. DTG (Direct to Garment): tốt cho số lượng nhỏ hoặc thiết kế nhiều màu phức tạp, giá cao hơn/cái. Thêu: cao cấp nhất về cảm giác, phù hợp logo nhỏ trên áo polo, mũ, túi."
      },
      {
        "title": "YKK: thương hiệu khóa kéo khách Mỹ biết và tin",
        "body": "Khi buyer mô tả sản phẩm trên Amazon và mention \"YKK zipper\", đây là USP (điểm bán hàng độc đáo) thực sự. Khách hàng Mỹ biết tên YKK và tin tưởng chất lượng. Chi phí chênh lệch giữa YKK và khóa kéo generic TQ không đáng kể so với giá trị cảm nhận mang lại."
      },
      {
        "title": "Mùa vụ Amazon: deadline giao hàng thực sự không thể trễ",
        "body": "Với người bán Amazon, mùa lễ hội (Thanksgiving, Black Friday, Christmas) bắt đầu từ tháng 10. Amazon yêu cầu hàng vào kho FBA trước 15/10 để kịp mùa. Trễ 5 ngày trong tháng 10 = mất toàn bộ cơ hội bán mùa — thiệt hại có thể là cả năm doanh thu."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Tech pack (工艺单) là gì?",
          "options": {
            "A": "Hóa đơn thanh toán cho nhà máy",
            "B": "Bộ tài liệu kỹ thuật đầy đủ để nhà máy sản xuất đúng yêu cầu",
            "C": "Danh sách vật liệu",
            "D": "Hợp đồng sản xuất"
          }
        },
        {
          "num": 2,
          "q": "Screen printing phù hợp nhất khi nào?",
          "options": {
            "A": "Số lượng nhỏ dưới 20 cái",
            "B": "Thiết kế nhiều màu phức tạp như ảnh chụp",
            "C": "Số lượng lớn với thiết kế màu phẳng đơn giản",
            "D": "Chỉ dùng cho áo thun trắng"
          }
        },
        {
          "num": 3,
          "q": "Mã màu Pantone giải quyết vấn đề gì?",
          "options": {
            "A": "Xác định chất lượng vải",
            "B": "Tránh hiểu nhầm màu sắc giữa buyer và nhà máy",
            "C": "Tính giá thành sản phẩm",
            "D": "Xác định kích thước"
          }
        },
        {
          "num": 4,
          "q": "Khóa kéo YKK được buyer Amazon nhắc đến vì lý do gì?",
          "options": {
            "A": "Giá rẻ nhất thị trường",
            "B": "Thương hiệu được khách Mỹ biết và tin về chất lượng, là USP thực sự",
            "C": "Dễ mua nhất ở TQ",
            "D": "Nhẹ nhất trong các loại khóa kéo"
          }
        },
        {
          "num": 5,
          "q": "Sai lệch kích thước ±1.5cm trong thời trang Amazon dẫn đến hậu quả gì chủ yếu?",
          "options": {
            "A": "Hải quan từ chối nhập khẩu",
            "B": "Tăng tỷ lệ returns vì size không đúng mô tả",
            "C": "Không có hậu quả",
            "D": "Phải thay đổi mã HS"
          }
        },
        {
          "num": 6,
          "q": "Thêu (刺绣) phù hợp nhất cho loại sản phẩm nào?",
          "options": {
            "A": "In hình ảnh phức tạp nhiều màu trên áo phông",
            "B": "Logo nhỏ trên áo polo, mũ, túi — tạo cảm giác cao cấp",
            "C": "In số lượng lớn với chi phí thấp",
            "D": "In trên vải mỏng"
          }
        },
        {
          "num": 7,
          "q": "Trong lịch Amazon, deadline hàng vào kho FBA cho mùa lễ hội Mỹ thường là khi nào?",
          "options": {
            "A": "Tháng 12",
            "B": "Tháng 11",
            "C": "Trước 15/10",
            "D": "Đầu tháng 9"
          }
        },
        {
          "num": 8,
          "q": "辅料 bao gồm những gì?",
          "options": {
            "A": "Chỉ vải chính",
            "B": "Cúc, khóa kéo, nhãn mác, dây viền và các vật liệu phụ khác",
            "C": "Máy móc sản xuất",
            "D": "Nguyên liệu thô"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Tech pack kém chi tiết là nguyên nhân chính dẫn đến sai sót trong sản xuất thời trang OEM."
        },
        {
          "num": 10,
          "q": "DTG (direct to garment) rẻ hơn screen printing cho số lượng lớn trên 500 cái."
        },
        {
          "num": 11,
          "q": "Màu chỉ may không khớp màu vải là lỗi nhỏ không ảnh hưởng đến chất lượng sản phẩm."
        },
        {
          "num": 12,
          "q": "Mùa lễ hội Mỹ (Black Friday, Christmas) là giai đoạn quan trọng nhất trong năm cho seller Amazon."
        },
        {
          "num": 13,
          "q": "Chi phí làm lại hàng lỗi do sản xuất phải do buyer VN chịu."
        },
        {
          "num": 14,
          "q": "AQL 2.5 là tiêu chuẩn kiểm tra ngẫu nhiên phổ biến cho hàng thời trang xuất Mỹ."
        }
      ],
      "fillblank": {
        "wordbank": [
          "工艺单",
          "潘通色号",
          "印花",
          "刺绣",
          "尺寸偏差",
          "辅料"
        ],
        "items": [
          {
            "num": 15,
            "q": "请按照我们的____严格生产，颜色请对照____。"
          },
          {
            "num": 16,
            "q": "品牌LOGO建议用____代替____，质感更高级，更符合我们的定价区间。"
          },
          {
            "num": 17,
            "q": "这批货有32件____超过了±1.5厘米，需要全部返工。"
          },
          {
            "num": 18,
            "q": "____方面请用YKK拉链和高质量纽扣，这些细节很影响客户对产品的整体印象。"
          },
          {
            "num": 19,
            "q": "这款T恤前胸的图案用____工艺，颜色是4色，请参考工艺单上的____。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 20,
          "q": "这批货的抽检结果显示，有4%的产品存在印花位置偏差超过1.5厘米，需要全部返工处理。"
        },
        {
          "num": 21,
          "q": "技术文件（工艺单）是我们和工厂沟通的正式语言，请严格按照我们的工艺单生产，有疑问及时确认。"
        },
        {
          "num": 22,
          "q": "这款帽子的刺绣需要提供DST格式的刺绣文件，我们的设计师会处理好再发给工厂。"
        },
        {
          "num": 23,
          "q": "请注意所有缝纫线的颜色必须与工艺单上的潘通色号一致，抽检时我们会重点检查这一项。"
        },
        {
          "num": 24,
          "q": "亚马逊旺季前货物必须进入FBA仓库，这次延误5天对我们影响很大，希望工厂配合加急处理。"
        }
      ],
      "vi2zh": [
        {
          "num": 25,
          "q": "Chúng tôi sẽ gửi tech pack đầy đủ bao gồm bản vẽ kỹ thuật, mã Pantone và hướng dẫn may chi tiết."
        },
        {
          "num": 26,
          "q": "Logo trên ngực áo polo này cần thêu, không phải in. Anh có thể nhận file DST không?"
        },
        {
          "num": 27,
          "q": "Kiểm tra ngẫu nhiên phát hiện màu chỉ may không khớp màu vải trong 32 sản phẩm, cần xử lý toàn bộ."
        },
        {
          "num": 28,
          "q": "Sai lệch kích thước cho phép là ±1,5cm, vượt quá mức này phải xử lý như hàng lỗi."
        },
        {
          "num": 29,
          "q": "Khóa kéo cần dùng YKK, không dùng hàng thay thế khác. Đây là yêu cầu không thể thay đổi."
        },
        {
          "num": 30,
          "q": "Sau khi làm lại xong, cần sắp xếp SGS kiểm tra lại theo AQL 2.5 trước khi xuất hàng."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "C",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "C",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": false,
        "11": false,
        "12": true,
        "13": false,
        "14": true
      },
      "fillblank": {
        "15": [
          "工艺单",
          "潘通色号"
        ],
        "16": [
          "刺绣",
          "印花"
        ],
        "17": "尺寸偏差",
        "18": "辅料",
        "19": [
          "印花",
          "潘通色号"
        ]
      },
      "zh2vi": {
        "20": "Kết quả kiểm tra ngẫu nhiên lô hàng này cho thấy 4% sản phẩm có vị trí in lệch hơn 1,5cm, cần toàn bộ làm lại.",
        "21": "Tài liệu kỹ thuật (tech pack) là ngôn ngữ giao tiếp chính thức giữa chúng tôi và nhà máy, vui lòng sản xuất theo đúng tech pack, có vấn đề gì xác nhận ngay.",
        "22": "Thêu mũ này cần cung cấp file thêu định dạng DST, designer của chúng tôi sẽ xử lý xong rồi gửi cho nhà máy.",
        "23": "Lưu ý màu chỉ may phải khớp với mã Pantone trong tech pack, khi kiểm tra ngẫu nhiên chúng tôi sẽ tập trung kiểm tra điểm này.",
        "24": "Hàng phải vào kho FBA Amazon trước mùa cao điểm, lần trễ 5 ngày này ảnh hưởng rất lớn đến chúng tôi, mong nhà máy phối hợp xử lý khẩn."
      },
      "vi2zh": {
        "25": "我们会发一份完整的工艺单，包括技术图纸、潘通色号和详细的车缝要求。",
        "26": "这款polo衫胸口的LOGO需要刺绣，不是印花。您能接受DST格式的文件吗？",
        "27": "抽检发现32件产品的缝纫线颜色与面料颜色不匹配，需要全部处理。",
        "28": "允许的尺寸偏差是±1.5厘米，超过这个范围必须作为不合格品处理。",
        "29": "拉链必须用YKK，不接受其他替代品，这是不可更改的要求。",
        "30": "返工完成后，需要安排SGS按照AQL 2.5进行复检，复检通过才能出货。"
      }
    }
  },
  {
    "num": 20,
    "title": "HỘI THOẠI TỔNG HỢP: HÀNG TIÊU DÙNG B2B",
    "date": "16/6",
    "phase": 2,
    "vocab": [],
    "dialogue": {
      "context": "Cuộc họp chiến lược giữa giám đốc công ty VN chuyên mua hàng OEM đa ngành với đội ngũ nhà máy TQ chuyên sản xuất nhiều danh mục. Đây là cuộc họp định hướng hợp tác cho toàn năm. Bạn là phiên dịch chính.",
      "characters": [
        {
          "name": "王总 (Wáng zǒng)",
          "role": "Giám đốc tập đoàn nhà máy TQ"
        },
        {
          "name": "林经理 (Lín jīnglǐ)",
          "role": "Giám đốc kinh doanh quốc tế"
        },
        {
          "name": "Anh Việt",
          "role": "Giám đốc công ty mua hàng VN"
        },
        {
          "name": "Chị Hà",
          "role": "Phụ trách phát triển sản phẩm công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "王总",
          "zh": "欢迎越南团队来到我们工厂，今天这次会议非常重要，我们希望确定今年全年的合作计划，涵盖家居、美妆和服装三个品类。",
          "vi": "Hoan nghênh đội ngũ Việt Nam đến nhà máy, cuộc họp hôm nay rất quan trọng, chúng tôi muốn xác định kế hoạch hợp tác cả năm, bao gồm ba danh mục: gia dụng, mỹ phẩm và thời trang."
        },
        {
          "speaker": "Anh Việt",
          "zh": "非常感谢王总的热情接待。我们公司今年在亚马逊美国站的业务增长了40%，我们对扩大与贵工厂合作规模非常有信心。",
          "vi": "Xin cảm ơn sự tiếp đón nồng nhiệt của Giám đốc Vương. Năm nay công ty chúng tôi trên Amazon Mỹ tăng trưởng 40%, chúng tôi rất tin tưởng vào việc mở rộng quy mô hợp tác với quý nhà máy."
        },
        {
          "speaker": "王总",
          "zh": "很高兴听到这个消息。我们先从家居类目开始讨论吧，这是我们合作最久的品类。",
          "vi": "Vui khi nghe điều này. Chúng ta bắt đầu thảo luận từ danh mục gia dụng nhé, đây là danh mục chúng ta hợp tác lâu nhất."
        },
        {
          "speaker": "Chị Hà",
          "zh": "家居方面，我们今年想开发三款新品：一款实木框架加MDF的书架，一款5层储物柜（需要配防倾倒装置），还有一款儿童书桌，需要满足ASTM F963标准。",
          "vi": "Về gia dụng, năm nay chúng tôi muốn phát triển 3 sản phẩm mới: một kệ sách khung gỗ đặc kết hợp MDF, một tủ chứa đồ 5 tầng cần kèm thiết bị chống đổ, và một bàn học trẻ em cần đạt tiêu chuẩn ASTM F963."
        },
        {
          "speaker": "林经理",
          "zh": "这三款我们都有能力生产。儿童书桌因为需要儿童安全认证，打样周期可能要延长到30天，其他两款正常20天就可以出样品。模具方面，书架和储物柜可以用我们的公模，如果需要特殊外形，可以开私模。",
          "vi": "Ba sản phẩm này chúng tôi đều có năng lực sản xuất. Bàn học trẻ em do cần chứng nhận an toàn trẻ em, thời gian làm mẫu có thể kéo dài đến 30 ngày, hai sản phẩm còn lại bình thường 20 ngày có thể ra mẫu. Về khuôn, kệ sách và tủ chứa đồ có thể dùng khuôn chung của chúng tôi, nếu cần hình dạng đặc biệt thì làm khuôn riêng."
        },
        {
          "speaker": "Chị Hà",
          "zh": "书架我们想开私模，有独特造型，不想和其他卖家撞款。储物柜先用公模测试市场，如果反应好再开私模。",
          "vi": "Kệ sách chúng tôi muốn làm khuôn riêng, có kiểu dáng đặc biệt, không muốn trùng với seller khác. Tủ chứa đồ trước dùng khuôn chung để test thị trường, nếu phản ứng tốt mới làm khuôn riêng."
        },
        {
          "speaker": "王总",
          "zh": "好，这个方案合理。接下来谈美妆品类，这是我们今年重点开发的方向。",
          "vi": "Tốt, phương án này hợp lý. Tiếp theo bàn danh mục mỹ phẩm, đây là hướng phát triển trọng tâm năm nay."
        },
        {
          "speaker": "Chị Hà",
          "zh": "我们想开发两款产品：一款含5%烟酰胺的精华，和一款含防晒成分的日霜。日霜这款需要特别注意，因为含SPF，在美国属于OTC药品类别，监管要求更严。",
          "vi": "Chúng tôi muốn phát triển hai sản phẩm: một serum chứa niacinamide 5% và một kem dưỡng ngày có chứa chống nắng. Sản phẩm kem dưỡng ngày cần đặc biệt chú ý, vì có SPF nên ở Mỹ thuộc danh mục thuốc OTC, yêu cầu quản lý chặt hơn."
        },
        {
          "speaker": "林经理",
          "zh": "精华我们可以做，配方开发大概2到3个月，包括稳定性测试。日霜这边，OTC药品我们有专门的部门来处理，需要做Drug Facts标签，还需要FDA的相关备案，这个流程会比较长，大概需要4到6个月。",
          "vi": "Serum chúng tôi làm được, phát triển công thức khoảng 2–3 tháng, bao gồm kiểm tra độ ổn định. Kem dưỡng ngày, thuốc OTC chúng tôi có bộ phận chuyên xử lý, cần làm nhãn Drug Facts, cần đăng ký liên quan với FDA, quy trình này khá dài, khoảng 4–6 tháng."
        },
        {
          "speaker": "Anh Việt",
          "zh": "时间上我们能接受，但是我有几个重要问题：第一，所有产品的成分表要符合INCI标准；第二，出货前要做微生物和重金属检测；第三，美白相关的产品描述要用\"提亮\"而不是\"美白\"，避免OTC监管。",
          "vi": "Về thời gian chúng tôi chấp nhận được, nhưng tôi có vài vấn đề quan trọng: thứ nhất, danh sách thành phần tất cả sản phẩm phải theo tiêu chuẩn INCI; thứ hai, trước khi xuất hàng phải kiểm tra vi sinh và kim loại nặng; thứ ba, mô tả sản phẩm liên quan làm trắng phải dùng \"làm sáng\" thay vì \"làm trắng\" để tránh quản lý OTC."
        },
        {
          "speaker": "林经理",
          "zh": "这三点我们完全理解，这是我们做美国市场的标准流程。",
          "vi": "Ba điểm này chúng tôi hoàn toàn hiểu, đây là quy trình tiêu chuẩn khi làm thị trường Mỹ của chúng tôi."
        },
        {
          "speaker": "王总",
          "zh": "最后谈服装品类。",
          "vi": "Cuối cùng bàn danh mục thời trang."
        },
        {
          "speaker": "Chị Hà",
          "zh": "服装方面，我们需要500件男士polo衫和1000件女士T恤。Polo衫要求纯棉220克，刺绣LOGO，YKK拉链；T恤要求200克有机棉，丝网印花，要有GOTS认证。",
          "vi": "Về thời trang, chúng tôi cần 500 áo polo nam và 1000 áo phông nữ. Polo yêu cầu cotton 100% 220gsm, thêu logo, khóa kéo YKK; áo phông yêu cầu organic cotton 200gsm, screen printing, cần chứng nhận GOTS."
        },
        {
          "speaker": "林经理",
          "zh": "这个没问题。我需要您提供完整的工艺单，包括潘通色号和详细的尺寸表。版型方面，确认是美版还是亚版？",
          "vi": "Cái này không vấn đề. Tôi cần anh/chị cung cấp tech pack đầy đủ, bao gồm mã Pantone và bảng kích thước chi tiết. Về dáng cắt, xác nhận dùng phiên bản Mỹ hay Á?"
        },
        {
          "speaker": "Chị Hà",
          "zh": "美版，我们的客户在美国。另外，所有服装出货前需要按AQL 2.5进行第三方抽检，我们会安排SGS来。",
          "vi": "Phiên bản Mỹ, khách hàng của chúng tôi ở Mỹ. Ngoài ra, tất cả thời trang trước khi xuất hàng cần kiểm tra ngẫu nhiên bên thứ ba theo AQL 2.5, chúng tôi sẽ sắp xếp SGS đến."
        },
        {
          "speaker": "王总",
          "zh": "好，今天讨论得非常充分。总结一下：家居三款新品，美妆两款，服装两款，共七款产品，我们的年度合作计划就以这七款为基础。付款条件按照我们的惯例，30%定金，70%出货前付清，这边可以接受吗？",
          "vi": "Tốt, hôm nay thảo luận rất đầy đủ. Tóm tắt: 3 sản phẩm mới gia dụng, 2 mỹ phẩm, 2 thời trang, tổng 7 sản phẩm, kế hoạch hợp tác năm của chúng ta dựa trên 7 sản phẩm này. Điều kiện thanh toán theo thông lệ, 30% cọc 70% trước khi xuất, phía anh có chấp nhận không?"
        },
        {
          "speaker": "Anh Việt",
          "zh": "付款条件可以接受。另外，考虑到今年合作规模扩大，我们希望把账期从目前的0天改为出货后30天付款，双方建立更深的信任关系。",
          "vi": "Điều kiện thanh toán chấp nhận được. Ngoài ra, xét đến quy mô hợp tác năm nay mở rộng, chúng tôi muốn đổi kỳ hạn thanh toán từ hiện tại 0 ngày thành 30 ngày sau xuất hàng, để hai bên xây dựng quan hệ tin tưởng sâu hơn."
        },
        {
          "speaker": "王总",
          "zh": "今年是我们合作第三年，我认为可以考虑。我们内部确认一下，下周给您正式答复。",
          "vi": "Năm nay là năm hợp tác thứ ba của chúng ta, tôi cho rằng có thể xem xét. Chúng tôi xác nhận nội bộ, tuần sau trả lời chính thức cho anh."
        },
        {
          "speaker": "Anh Việt",
          "zh": "非常好。期待今年双方合作更上一层楼，互利共赢！",
          "vi": "Rất tốt. Kỳ vọng năm nay hai bên hợp tác lên một tầm cao mới, cùng có lợi!"
        },
        {
          "speaker": "王总",
          "zh": "合作愉快！",
          "vi": "Chúc hợp tác vui vẻ!"
        }
      ]
    },
    "notes": [
      {
        "title": "Phiên dịch cuộc họp chiến lược đa ngành: chuẩn bị kỹ",
        "body": "Đây là loại cuộc họp khó nhất cho phiên dịch — nhảy nhanh giữa thuật ngữ nội thất, mỹ phẩm và thời trang trong cùng một cuộc họp. Chuẩn bị trước glossary cho từng ngành. Khi gặp từ không biết, đừng đoán — hỏi ngay hoặc dùng tiếng Anh tạm thời rồi xác nhận sau."
      },
      {
        "title": "Kỳ hạn thanh toán (账期): cột mốc tin tưởng",
        "body": "Trong hội thoại, anh Việt xin chuyển từ 0 ngày lên 30 ngày 账期 sau 3 năm hợp tác. Đây là diễn tiến tự nhiên và hợp lý trong quan hệ B2B dài hạn. Nhà máy xem xét thay vì từ chối ngay — đây là dấu hiệu mối quan hệ tốt."
      },
      {
        "title": "Phát triển sản phẩm OTC drug: timeline dài",
        "body": "Kem chống nắng có SPF cần 4–6 tháng để hoàn thiện đầy đủ quy trình (công thức + ổn định + kiểm định + FDA registration). Đây là loại sản phẩm cần lên kế hoạch sớm ít nhất 6–9 tháng trước khi muốn launch."
      },
      {
        "title": "Hội thoại tổng hợp: kỹ năng then chốt của phiên dịch",
        "body": "Trong cuộc họp thực tế, tốc độ nói sẽ nhanh hơn trong bài học này. Phiên dịch cần ghi chú nhanh (có thể bằng shorthand/ký hiệu riêng), dịch liên tục mà không làm gián đoạn luồng thảo luận. Khi dịch sang tiếng Việt, luôn dùng ngôi xưng đúng: \"chúng tôi\" cho bên mình, \"quý công ty/các anh\" cho bên kia."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Trong cuộc họp chiến lược đa ngành, điều quan trọng nhất với phiên dịch là gì?",
          "options": {
            "A": "Dịch từng chữ một",
            "B": "Chuẩn bị glossary cho từng ngành trước cuộc họp",
            "C": "Chỉ dịch phần quan trọng",
            "D": "Dịch vào cuối mỗi buổi"
          }
        },
        {
          "num": 2,
          "q": "Kem dưỡng ngày có SPF ở Mỹ được phân loại như thế nào?",
          "options": {
            "A": "Mỹ phẩm thông thường",
            "B": "Thực phẩm chức năng",
            "C": "Thuốc OTC",
            "D": "Thiết bị y tế"
          }
        },
        {
          "num": 3,
          "q": "Khi mở khuôn riêng (私模) cho kệ sách, mục tiêu chính là gì?",
          "options": {
            "A": "Giảm chi phí sản xuất",
            "B": "Tạo kiểu dáng độc đáo, tránh trùng với seller khác",
            "C": "Tăng tốc độ sản xuất",
            "D": "Đơn giản hóa quy trình"
          }
        },
        {
          "num": 4,
          "q": "Bàn học trẻ em cần tiêu chuẩn gì?",
          "options": {
            "A": "CARB Phase 2",
            "B": "ASTM F963 (an toàn đồ trẻ em)",
            "C": "ISO 22716",
            "D": "GOTS"
          }
        },
        {
          "num": 5,
          "q": "Áo polo yêu cầu khóa kéo YKK vì lý do gì?",
          "options": {
            "A": "Giá rẻ nhất",
            "B": "Dễ mua ở TQ",
            "C": "Thương hiệu được khách Mỹ tin tưởng về chất lượng",
            "D": "Không cần lý do đặc biệt"
          }
        },
        {
          "num": 6,
          "q": "Organic cotton cho áo phông cần có chứng nhận gì?",
          "options": {
            "A": "ISO 9001",
            "B": "GOTS",
            "C": "CARB Phase 2",
            "D": "FDA"
          }
        },
        {
          "num": 7,
          "q": "Khi xin 账期 30 ngày sau 3 năm hợp tác, điều này phản ánh điều gì?",
          "options": {
            "A": "Công ty VN gặp khó khăn tài chính",
            "B": "Mối quan hệ tin cậy đã được xây dựng qua thời gian",
            "C": "Nhà máy muốn thoát khỏi hợp tác",
            "D": "Đây là yêu cầu bất thường"
          }
        },
        {
          "num": 8,
          "q": "Serum niacinamide 5% cần bao lâu để hoàn thiện từ khi bắt đầu phát triển?",
          "options": {
            "A": "2 tuần",
            "B": "1 tháng",
            "C": "2–3 tháng bao gồm kiểm tra độ ổn định",
            "D": "6 tháng"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Trong cùng một cuộc họp có thể bàn cả ba danh mục hàng hóa khác nhau."
        },
        {
          "num": 10,
          "q": "Mô tả mỹ phẩm trên Amazon nên dùng \"làm sáng\" thay vì \"làm trắng\" để tránh phân loại OTC."
        },
        {
          "num": 11,
          "q": "Tủ chứa đồ 5 tầng không cần thiết bị chống đổ khi bán ở Mỹ."
        },
        {
          "num": 12,
          "q": "Áo phông organic cotton GOTS có thể bán giá cao hơn áo phông thường."
        },
        {
          "num": 13,
          "q": "Phiên dịch nên dịch toàn bộ nội dung cuộc họp, không bỏ sót phần xã giao hay tóm tắt."
        },
        {
          "num": 14,
          "q": "Khi không biết thuật ngữ kỹ thuật, phiên dịch nên đoán thay vì hỏi lại để tránh mất thể diện."
        }
      ],
      "fillblank": {
        "wordbank": [
          "独家合作",
          "防倾倒装置",
          "成分表",
          "工艺单",
          "账期",
          "互利共赢"
        ],
        "items": [
          {
            "num": 15,
            "q": "高柜必须附带____，这是美国市场的法规要求。"
          },
          {
            "num": 16,
            "q": "所有美妆产品的____必须符合INCI标准，按照含量从多到少排列。"
          },
          {
            "num": 17,
            "q": "请按照____严格生产，特别注意潘通色号和版型规格。"
          },
          {
            "num": 18,
            "q": "合作三年后，我们希望能给予30天的____，以加深双方的信任关系。"
          },
          {
            "num": 19,
            "q": "我们希望签署____协议，确保在北美市场，这款产品只有我们在销售。"
          },
          {
            "num": 20,
            "q": "双方都希望____，长期稳定的合作才是最大的共同利益。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "今年我们计划合作七款新品，涵盖家居、美妆和服装三个品类，请双方确认时间节点和付款方式。"
        },
        {
          "num": 22,
          "q": "儿童书桌需要满足ASTM F963标准，打样周期30天，同时需要申请相关安全认证，整个流程大概45天。"
        },
        {
          "num": 23,
          "q": "含SPF的防晒霜在美国属于OTC药品，需要Drug Facts标签和FDA备案，整个上市准备需要4到6个月。"
        },
        {
          "num": 24,
          "q": "服装产品出货前必须按AQL 2.5进行第三方抽检，确保尺寸偏差、印花质量和面料符合工艺单要求。"
        },
        {
          "num": 25,
          "q": "合作第三年了，我们对贵公司的信任度很高，希望把付款条件改为出货后30天结清，方便我们做账务计划。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Kế hoạch hợp tác năm nay của chúng tôi bao gồm 7 sản phẩm mới trong ba danh mục, anh có thể xác nhận thời gian sản xuất cho từng sản phẩm không?"
        },
        {
          "num": 27,
          "q": "Tất cả sản phẩm mỹ phẩm phải có báo cáo kiểm tra vi sinh và kim loại nặng trước khi xuất hàng."
        },
        {
          "num": 28,
          "q": "Kệ sách muốn làm khuôn riêng để có kiểu dáng độc quyền, chi phí khuôn và thời gian làm khuôn là bao nhiêu?"
        },
        {
          "num": 29,
          "q": "Sau 3 năm hợp tác ổn định, chúng tôi hy vọng nhà máy có thể cung cấp kỳ hạn thanh toán 30 ngày."
        },
        {
          "num": 30,
          "q": "Chúng tôi cam kết sẽ tiếp tục mở rộng đơn hàng, mục tiêu là cùng có lợi và hợp tác lâu dài!"
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "C",
        "3": "B",
        "4": "B",
        "5": "C",
        "6": "B",
        "7": "B",
        "8": "C"
      },
      "tf": {
        "9": true,
        "10": true,
        "11": false,
        "12": true,
        "13": true,
        "14": false
      },
      "fillblank": {
        "15": "防倾倒装置",
        "16": "成分表",
        "17": "工艺单",
        "18": "账期",
        "19": "独家合作",
        "20": "互利共赢"
      },
      "zh2vi": {
        "21": "Năm nay chúng ta kế hoạch hợp tác 7 sản phẩm mới, bao gồm 3 danh mục gia dụng, mỹ phẩm và thời trang, nhờ hai bên xác nhận các mốc thời gian và phương thức thanh toán.",
        "22": "Bàn học trẻ em cần đạt tiêu chuẩn ASTM F963, thời gian làm mẫu 30 ngày, đồng thời cần xin chứng nhận an toàn liên quan, toàn bộ quy trình khoảng 45 ngày.",
        "23": "Kem chống nắng có SPF ở Mỹ là thuốc OTC, cần nhãn Drug Facts và đăng ký FDA, toàn bộ chuẩn bị ra thị trường cần 4–6 tháng.",
        "24": "Sản phẩm thời trang trước khi xuất phải kiểm tra ngẫu nhiên bên thứ ba theo AQL 2.5, đảm bảo sai lệch kích thước, chất lượng in và vải đáp ứng yêu cầu tech pack.",
        "25": "Hợp tác năm thứ ba rồi, chúng tôi rất tin tưởng quý công ty, mong đổi điều kiện thanh toán thành 30 ngày sau xuất hàng để thuận tiện lên kế hoạch tài chính."
      },
      "vi2zh": {
        "26": "我们今年的合作计划包括三个品类共7款新品，您能确认每款产品的生产时间吗？",
        "27": "所有美妆产品出货前必须有微生物和重金属检测报告。",
        "28": "书架要开私模，以保证造型独特，模具费用和制作时间是多少？",
        "29": "三年合作下来很稳定，我们希望工厂能提供30天的账期。",
        "30": "我们承诺会继续扩大订单，目标就是互利共赢，长期合作！"
      }
    }
  },
  {
    "num": 21,
    "title": "SẢN PHẨM ĐIỆN TỬ & THÔNG SỐ KỸ THUẬT",
    "date": "17/6",
    "phase": 3,
    "vocab": [
      {
        "num": 1,
        "hanzi": "电子产品",
        "pinyin": "diànzǐ chǎnpǐn",
        "vi": "sản phẩm điện tử",
        "explanation": "Danh mục rộng: điện thoại phụ kiện (手机配件), loa Bluetooth (蓝牙音箱), tai nghe (耳机), đồ gia dụng thông minh (智能家居), thiết bị sạc (充电设备), camera (摄像头)... Đây là danh mục cạnh tranh nhất trên Amazon Mỹ nhưng cũng có biên lợi nhuận tốt nếu có sản phẩm khác biệt.",
        "example": {
          "zh": "我们主要生产消费类电子产品，专注于智能家居和音频设备。",
          "vi": "Chúng tôi chủ yếu sản xuất điện tử tiêu dùng, tập trung vào nhà thông minh và thiết bị âm thanh."
        }
      },
      {
        "num": 2,
        "hanzi": "规格参数",
        "pinyin": "guīgé cānshù",
        "vi": "thông số kỹ thuật (specifications)",
        "explanation": "Tất cả thông số mô tả sản phẩm điện tử: công suất (瓦数), điện áp (电压), tần số (频率), dung lượng pin (电池容量), kết nối (连接方式), trọng lượng, kích thước... Spec sheet đầy đủ và chính xác là bắt buộc khi bán điện tử — sai spec = hàng bị trả về hàng loạt.",
        "example": {
          "zh": "请提供完整的规格参数表，包括功率、电压范围和工作温度。",
          "vi": "Vui lòng cung cấp bảng thông số kỹ thuật đầy đủ, bao gồm công suất, dải điện áp và nhiệt độ vận hành."
        }
      },
      {
        "num": 3,
        "hanzi": "功率",
        "pinyin": "gōnglǜ",
        "vi": "công suất (watt)",
        "explanation": "Lượng điện năng tiêu thụ hoặc phát ra, tính bằng watt (W) hoặc kilowatt (kW). Quan trọng với tất cả thiết bị điện. Cần chú ý: công suất định mức (额定功率) vs công suất tối đa (最大功率). Sai công suất = không đúng spec, khách trả hàng, nguy cơ cháy nổ.",
        "example": {
          "zh": "这款快充头的功率是65W，支持PD协议，兼容苹果和安卓设备。",
          "vi": "Củ sạc nhanh này có công suất 65W, hỗ trợ giao thức PD, tương thích thiết bị Apple và Android."
        }
      },
      {
        "num": 4,
        "hanzi": "电压",
        "pinyin": "diànyā",
        "vi": "điện áp (voltage)",
        "explanation": "Đặc biệt quan trọng khi xuất sang Mỹ — Mỹ dùng 110V/60Hz trong khi TQ và VN dùng 220V/50Hz. Sản phẩm phải hỗ trợ 100–240V đa điện áp (多电压) để bán toàn cầu, hoặc chỉ 110V cho thị trường Mỹ. Sản phẩm điện áp sai = cháy thiết bị, nguy hiểm, thu hồi khẩn cấp.",
        "example": {
          "zh": "这款产品支持100-240V宽电压输入，全球通用，不需要变压器。",
          "vi": "Sản phẩm này hỗ trợ đầu vào điện áp rộng 100–240V, dùng toàn cầu, không cần biến áp."
        }
      },
      {
        "num": 5,
        "hanzi": "蓝牙",
        "pinyin": "lányá",
        "vi": "Bluetooth",
        "explanation": "Giao thức kết nối không dây tầm ngắn. Phiên bản hiện tại: Bluetooth 5.3/5.4. Với sản phẩm âm thanh, hãy chú ý: codec hỗ trợ (SBC, AAC, aptX, LDAC), tầm kết nối, độ trễ (延迟). Đây là thông số khách hàng Mỹ hay hỏi khi mua tai nghe, loa.",
        "example": {
          "zh": "这款耳机支持蓝牙5.3，支持AAC和aptX编解码器，延迟低于50毫秒。",
          "vi": "Tai nghe này hỗ trợ Bluetooth 5.3, hỗ trợ codec AAC và aptX, độ trễ dưới 50ms."
        }
      },
      {
        "num": 6,
        "hanzi": "电池容量",
        "pinyin": "diànchí róngliàng",
        "vi": "dung lượng pin (mAh/Wh)",
        "explanation": "Lượng điện năng pin có thể lưu trữ, tính bằng mAh (milliampere-hour) hoặc Wh (watt-hour). Quyết định thời gian sử dụng. Quan trọng: pin lithium có giới hạn vận chuyển hàng không (100Wh mỗi viên cho hành lý xách tay, 160Wh cần xin phép). Ảnh hưởng đến logistics.",
        "example": {
          "zh": "这款移动电源的电池容量是20000mAh，相当于50Wh，可以空运，不受航空限制。",
          "vi": "Pin dự phòng này dung lượng 20000mAh, tương đương 50Wh, có thể vận chuyển hàng không, không bị hạn chế."
        }
      },
      {
        "num": 7,
        "hanzi": "防水等级",
        "pinyin": "fángshuǐ děngjí",
        "vi": "cấp độ chống nước (IP rating)",
        "explanation": "IP (Ingress Protection) rating — tiêu chuẩn IEC 60529 mô tả mức độ bảo vệ khỏi bụi và nước. IPX4 = chống bắn nước. IP67 = chống bụi hoàn toàn, chịu ngâm 1m trong 30 phút. IP68 = chịu ngâm sâu hơn. Đây là thông số quan trọng cho loa ngoài trời, tai nghe thể thao.",
        "example": {
          "zh": "这款蓝牙音箱的防水等级是IP67，可以在浴室或户外使用，不怕雨水。",
          "vi": "Loa Bluetooth này có cấp độ chống nước IP67, có thể dùng trong phòng tắm hay ngoài trời, không sợ mưa."
        }
      },
      {
        "num": 8,
        "hanzi": "待机时间",
        "pinyin": "dàijī shíjiān",
        "vi": "thời gian chờ / thời gian sử dụng pin",
        "explanation": "Thời gian thiết bị có thể hoạt động với một lần sạc đầy. 待机时间 (standby time — chế độ chờ) thường dài hơn nhiều 使用时间 (usage time — thời gian sử dụng thực tế). Phải khai báo rõ ràng — khai sai = review xấu từ khách hàng.",
        "example": {
          "zh": "在中等音量下，这款耳机的使用时间可以达到8小时，配合充电盒总续航36小时。",
          "vi": "Ở âm lượng trung bình, tai nghe này sử dụng được 8 giờ, kết hợp hộp sạc tổng thời lượng 36 giờ."
        }
      },
      {
        "num": 9,
        "hanzi": "兼容性",
        "pinyin": "jiānróng xìng",
        "vi": "khả năng tương thích (compatibility)",
        "explanation": "Thiết bị điện tử có hoạt động với các thiết bị/hệ điều hành khác không. Ví dụ: tai nghe tương thích iOS và Android, sạc không dây tương thích Qi standard, hub USB tương thích Mac và Windows. 兼容性 kém = reviews xấu từ khách Apple hoặc Android.",
        "example": {
          "zh": "这款无线充电器兼容所有支持Qi标准的设备，包括iPhone和三星手机。",
          "vi": "Bộ sạc không dây này tương thích tất cả thiết bị hỗ trợ chuẩn Qi, bao gồm iPhone và điện thoại Samsung."
        }
      },
      {
        "num": 10,
        "hanzi": "保修期",
        "pinyin": "bǎoxiū qī",
        "vi": "thời hạn bảo hành",
        "explanation": "Khoảng thời gian nhà sản xuất/bán hàng cam kết sửa chữa hoặc thay thế sản phẩm lỗi miễn phí. Tiêu chuẩn thị trường Mỹ cho điện tử tiêu dùng: 1 năm. Nhiều seller Amazon tăng cạnh tranh bằng cách cung cấp bảo hành 2 năm. Bảo hành tốt = tăng tỷ lệ chuyển đổi.",
        "example": {
          "zh": "我们提供18个月的保修期，超过市场平均水平，对买家来说是额外的保障。",
          "vi": "Chúng tôi cung cấp bảo hành 18 tháng, vượt mức trung bình thị trường, là đảm bảo thêm cho người mua."
        }
      }
    ],
    "dialogue": {
      "context": "Buyer VN đang tìm nhà cung cấp loa Bluetooth OEM để bán Amazon Mỹ, đang đàm phán thông số kỹ thuật.",
      "characters": [
        {
          "name": "技术总监赵工 (Zhào gōng)",
          "role": "Giám đốc kỹ thuật nhà máy điện tử TQ"
        },
        {
          "name": "Anh Quân",
          "role": "Trưởng phòng phát triển sản phẩm VN"
        }
      ],
      "lines": [
        {
          "speaker": "Anh Quân",
          "zh": "赵工，我们要开发一款户外蓝牙音箱，主打防水、续航长，目标客户是户外运动爱好者，在亚马逊美国站销售。",
          "vi": "Kỹ sư Triệu, chúng tôi muốn phát triển loa Bluetooth ngoài trời, điểm mạnh là chống nước và pin bền, khách hàng mục tiêu là người yêu thể thao ngoài trời, bán trên Amazon Mỹ."
        },
        {
          "speaker": "赵工",
          "zh": "好的，这类产品我们很有经验。请问您对主要规格有什么具体要求？",
          "vi": "Tốt, loại sản phẩm này chúng tôi rất có kinh nghiệm. Anh có yêu cầu cụ thể về các thông số chính không?"
        },
        {
          "speaker": "Anh Quân",
          "zh": "防水等级至少要IP67，续航要达到12小时以上，蓝牙版本要5.0以上，声音质量要好，支持360度环绕音效更好。",
          "vi": "Cấp độ chống nước ít nhất IP67, thời lượng pin phải đạt 12 giờ trở lên, phiên bản Bluetooth phải từ 5.0 trở lên, chất lượng âm thanh tốt, hỗ trợ âm thanh 360 độ vòng quanh thì càng tốt."
        },
        {
          "speaker": "赵工",
          "zh": "IP67、12小时续航、蓝牙5.3这些都没问题。360度环绕音效需要双扬声器设计，我们有现成的方案。功率方面，您希望是多少瓦？",
          "vi": "IP67, pin 12 giờ, Bluetooth 5.3 đều không vấn đề. Âm thanh 360 độ cần thiết kế loa kép, chúng tôi có phương án sẵn. Về công suất, anh muốn bao nhiêu watt?"
        },
        {
          "speaker": "Anh Quân",
          "zh": "20瓦左右，声音要足够响，在户外也能清楚听到，但体积不能太大，要便携。",
          "vi": "Khoảng 20W, âm thanh phải đủ to, ở ngoài trời vẫn nghe rõ, nhưng kích thước không được quá lớn, cần portable."
        },
        {
          "speaker": "赵工",
          "zh": "20W的话，我们推荐用2×10W的双扬声器配置，加被动低音振膜，低音效果更好。电池容量大概5000mAh，可以保证12小时以上续航，重量控制在700克以内。",
          "vi": "20W thì chúng tôi khuyến nghị dùng cấu hình 2 loa kép 2×10W, thêm màng rung bass passive, hiệu ứng bass tốt hơn. Dung lượng pin khoảng 5000mAh, đảm bảo pin hơn 12 giờ, trọng lượng kiểm soát trong 700g."
        },
        {
          "speaker": "Anh Quân",
          "zh": "重量700克可以接受。这款产品如果要出口美国，FCC认证是必须的吧？",
          "vi": "Trọng lượng 700g chấp nhận được. Sản phẩm này nếu xuất Mỹ, chứng nhận FCC là bắt buộc phải không?"
        },
        {
          "speaker": "赵工",
          "zh": "对，FCC认证是强制要求。另外因为有蓝牙，还需要FCC ID认证，这个我们可以帮您申请，大概需要6到8周。",
          "vi": "Đúng, FCC là yêu cầu bắt buộc. Ngoài ra vì có Bluetooth nên cần thêm chứng nhận FCC ID, cái này chúng tôi có thể giúp anh đăng ký, khoảng 6–8 tuần."
        },
        {
          "speaker": "Anh Quân",
          "zh": "保修方面，我们希望提供18个月保修，可以在包装上和亚马逊页面上标注吗？",
          "vi": "Về bảo hành, chúng tôi muốn cung cấp bảo hành 18 tháng, có thể ghi lên bao bì và trang Amazon không?"
        },
        {
          "speaker": "赵工",
          "zh": "完全可以，我们提供OEM的产品都支持客户自定义保修政策，18个月保修我们没有问题。",
          "vi": "Hoàn toàn được, sản phẩm OEM chúng tôi đều hỗ trợ khách tùy chỉnh chính sách bảo hành, bảo hành 18 tháng không vấn đề."
        },
        {
          "speaker": "Anh Quân",
          "zh": "好。最后，这款产品的电压是多少？美国用110V，要确认兼容。",
          "vi": "Tốt. Cuối cùng, điện áp sản phẩm này là bao nhiêu? Mỹ dùng 110V, cần xác nhận tương thích."
        },
        {
          "speaker": "赵工",
          "zh": "充电部分是5V输入，通过USB-C充电，所以和电压没有关系，全球通用。您不用担心110V/220V的问题。",
          "vi": "Phần sạc là đầu vào 5V, sạc qua USB-C, nên không liên quan đến điện áp, dùng toàn cầu. Anh không cần lo vấn đề 110V/220V."
        }
      ]
    },
    "notes": [
      {
        "title": "FCC certification: bắt buộc cho mọi thiết bị điện tử bán ở Mỹ",
        "body": "Mọi thiết bị phát sóng điện từ (Bluetooth, WiFi, radio) bán tại Mỹ phải có FCC certification. Thời gian: 6–12 tuần. Chi phí: 3.000–15.000 USD tùy thiết bị. Sản phẩm không có FCC = bị hải quan giữ và có thể bị thu hồi nếu đã bán."
      },
      {
        "title": "IP rating: thông số quan trọng khi marketing",
        "body": "IP67 và IP68 là những từ khóa có giá trị trên Amazon. Luôn test thực tế và có báo cáo kiểm định từ phòng thí nghiệm độc lập. Claim IP rating sai = vi phạm FTC và Amazon policy, có thể bị kiện."
      },
      {
        "title": "Pin lithium và vận chuyển hàng không",
        "body": "Pin lithium trên 100Wh không thể vận chuyển hàng không thương mại thông thường. 5000mAh ≈ 18.5Wh (tính: mAh × điện áp pin / 1000) — an toàn. Cần tính toán Wh kỹ khi đặt hàng sản phẩm có pin."
      },
      {
        "title": "USB-C và điện áp: xu hướng xóa bỏ vấn đề điện áp",
        "body": "Phần lớn thiết bị điện tử hiện đại sạc qua USB-C với đầu vào 5V — không phụ thuộc vào điện lưới 110V hay 220V. Bộ sạc (adapter) mới là phần cần tương thích điện áp, còn thiết bị chính thường không cần lo."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "FCC certification bắt buộc cho những thiết bị nào?",
          "options": {
            "A": "Chỉ điện thoại di động",
            "B": "Mọi thiết bị phát sóng điện từ (Bluetooth, WiFi, radio) bán tại Mỹ",
            "C": "Chỉ thiết bị trên 100W",
            "D": "Không bắt buộc cho thiết bị nhỏ"
          }
        },
        {
          "num": 2,
          "q": "IP67 có nghĩa là gì?",
          "options": {
            "A": "Chống bụi và chịu ngâm nước 1m trong 30 phút",
            "B": "Chỉ chống nước bắn",
            "C": "Chỉ chống bụi",
            "D": "Không cần kiểm tra nước"
          }
        },
        {
          "num": 3,
          "q": "Mỹ dùng điện áp bao nhiêu?",
          "options": {
            "A": "220V/50Hz",
            "B": "110V/60Hz",
            "C": "220V/60Hz",
            "D": "110V/50Hz"
          }
        },
        {
          "num": 4,
          "q": "5000mAh pin tương đương khoảng bao nhiêu Wh?",
          "options": {
            "A": "5 Wh",
            "B": "18.5 Wh",
            "C": "50 Wh",
            "D": "100 Wh"
          }
        },
        {
          "num": 5,
          "q": "Tại sao thông số bảo hành 18 tháng là lợi thế cạnh tranh trên Amazon?",
          "options": {
            "A": "Vì luật Mỹ bắt buộc 18 tháng",
            "B": "Cao hơn mức tiêu chuẩn 12 tháng, tăng niềm tin của người mua",
            "C": "Vì Amazon yêu cầu",
            "D": "Giúp giảm thuế nhập khẩu"
          }
        },
        {
          "num": 6,
          "q": "Sản phẩm sạc qua USB-C có vấn đề gì về điện áp không?",
          "options": {
            "A": "Phải tương thích 110V",
            "B": "Không, USB-C sạc ở 5V nên dùng toàn cầu",
            "C": "Chỉ dùng được ở 220V",
            "D": "Cần kiểm tra từng thị trường"
          }
        },
        {
          "num": 7,
          "q": "Codec âm thanh nào tốt hơn cho chất lượng âm thanh không dây cao?",
          "options": {
            "A": "SBC (chất lượng thấp nhất)",
            "B": "aptX hoặc LDAC (chất lượng cao hơn)",
            "C": "Tất cả codec như nhau",
            "D": "Không có sự khác biệt"
          }
        },
        {
          "num": 8,
          "q": "Thời gian xin FCC certification thường mất bao lâu?",
          "options": {
            "A": "1 tuần",
            "B": "2 tuần",
            "C": "1 tháng",
            "D": "6–12 tuần"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Thiết bị Bluetooth bán ở Mỹ phải có FCC certification, không có ngoại lệ."
        },
        {
          "num": 10,
          "q": "IP68 bảo vệ tốt hơn IP67 về khả năng chống nước."
        },
        {
          "num": 11,
          "q": "Pin lithium dưới 100Wh có thể vận chuyển bằng hàng không thương mại."
        },
        {
          "num": 12,
          "q": "Claim IP rating mà không có kiểm định thực tế là vi phạm FTC và Amazon policy."
        },
        {
          "num": 13,
          "q": "Điện áp là vấn đề quan trọng cho thiết bị cắm điện trực tiếp, nhưng không phải vấn đề cho thiết bị sạc USB."
        },
        {
          "num": 14,
          "q": "Thông số kỹ thuật sai trên trang Amazon không ảnh hưởng nhiều đến tỷ lệ return."
        }
      ],
      "fillblank": {
        "wordbank": [
          "规格参数",
          "防水等级",
          "蓝牙",
          "电池容量",
          "兼容性",
          "保修期"
        ],
        "items": [
          {
            "num": 15,
            "q": "请提供完整的____表，包括功率、电压、频率和尺寸重量。"
          },
          {
            "num": 16,
            "q": "这款户外音箱的____是IP67，可以在雨中使用，不怕淋湿。"
          },
          {
            "num": 17,
            "q": "____5.3比5.0的连接更稳定，信号范围也更大。"
          },
          {
            "num": 18,
            "q": "____是10000mAh，相当于37Wh，可以安全空运。"
          },
          {
            "num": 19,
            "q": "这款充电器的____很好，支持iPhone、三星和华为所有品牌。"
          },
          {
            "num": 20,
            "q": "我们提供18个月____，超过市场标准，可以作为产品的额外卖点。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "这款蓝牙音箱防水等级IP67，支持蓝牙5.3，电池容量5000mAh，续航12小时，重量680克。"
        },
        {
          "num": 22,
          "q": "出口美国的无线电子产品必须取得FCC认证，包含蓝牙模块的产品还需要申请FCC ID，整个认证过程需要6到8周。"
        },
        {
          "num": 23,
          "q": "产品的规格参数必须在亚马逊列表页面上准确描述，任何虚假或夸大的参数都可能导致高退货率和差评。"
        },
        {
          "num": 24,
          "q": "充电接口是USB-C，输入电压5V，全球通用，美国客户不需要转换插头或变压器。"
        },
        {
          "num": 25,
          "q": "我们提供18个月保修，超过行业标准的12个月，这在亚马逊同类产品中是一个很好的差异化卖点。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Sản phẩm này có cần chứng nhận FCC không? Thời gian xin chứng nhận là bao lâu và chi phí là bao nhiêu?"
        },
        {
          "num": 27,
          "q": "Cấp độ chống nước IP67 có phải do phòng thí nghiệm độc lập kiểm định không? Chúng tôi cần báo cáo kiểm định."
        },
        {
          "num": 28,
          "q": "Dung lượng pin 5000mAh tương đương bao nhiêu Wh? Có thể vận chuyển hàng không không?"
        },
        {
          "num": 29,
          "q": "Thời gian sử dụng pin 12 giờ là ở âm lượng nào? Cần ghi rõ điều kiện kiểm tra trên trang Amazon."
        },
        {
          "num": 30,
          "q": "Chứng nhận FCC đã có chưa? Sản phẩm không có FCC sẽ bị hải quan Mỹ giữ lại."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "A",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "B",
        "8": "D"
      },
      "tf": {
        "9": true,
        "10": true,
        "11": true,
        "12": true,
        "13": true,
        "14": false
      },
      "fillblank": {
        "15": "规格参数",
        "16": "防水等级",
        "17": "蓝牙",
        "18": "电池容量",
        "19": "兼容性",
        "20": "保修期"
      },
      "zh2vi": {
        "21": "Loa Bluetooth này cấp chống nước IP67, hỗ trợ Bluetooth 5.3, dung lượng pin 5000mAh, pin 12 giờ, trọng lượng 680g.",
        "22": "Sản phẩm điện tử không dây xuất Mỹ phải có FCC certification, sản phẩm có module Bluetooth còn cần đăng ký FCC ID, toàn bộ quy trình chứng nhận mất 6–8 tuần.",
        "23": "Thông số kỹ thuật sản phẩm phải mô tả chính xác trên trang Amazon, bất kỳ thông số sai hoặc phóng đại nào đều có thể dẫn đến tỷ lệ return cao và review xấu.",
        "24": "Cổng sạc là USB-C, điện áp đầu vào 5V, dùng toàn cầu, khách Mỹ không cần đổi đầu cắm hay biến áp.",
        "25": "Chúng tôi cung cấp bảo hành 18 tháng, vượt mức tiêu chuẩn ngành 12 tháng, đây là điểm khác biệt tốt so với sản phẩm cùng loại trên Amazon."
      },
      "vi2zh": {
        "26": "这款产品需要FCC认证吗？申请时间需要多久，费用是多少？",
        "27": "IP67防水等级有没有独立实验室的检测报告？我们需要认证文件。",
        "28": "5000mAh的电池相当于多少Wh？可以空运吗？",
        "29": "12小时续航是在什么音量下测试的？亚马逊页面上需要注明测试条件。",
        "30": "FCC认证已经拿到了吗？没有FCC的产品会被美国海关扣押。"
      }
    }
  },
  {
    "num": 22,
    "title": "CHỨNG NHẬN FCC/CE/ROHS CHO ĐIỆN TỬ",
    "date": "18/6",
    "phase": 3,
    "vocab": [
      {
        "num": 1,
        "hanzi": "FCC认证",
        "pinyin": "FCC rènzhèng",
        "vi": "chứng nhận FCC (Mỹ)",
        "explanation": "Federal Communications Commission — cơ quan quản lý viễn thông Mỹ. FCC certification bắt buộc cho mọi thiết bị điện tử phát xạ điện từ bán tại Mỹ. Có hai loại: FCC Part 15 (thiết bị phổ thông) và FCC ID (thiết bị phát sóng có chủ ý như WiFi, Bluetooth). Thiếu FCC = hàng bị giữ ở hải quan Mỹ.",
        "example": {
          "zh": "这款智能插座需要FCC ID认证，因为它内置了WiFi模块。",
          "vi": "Ổ cắm thông minh này cần chứng nhận FCC ID vì có module WiFi tích hợp."
        }
      },
      {
        "num": 2,
        "hanzi": "CE认证",
        "pinyin": "CE rènzhèng",
        "vi": "chứng nhận CE (Châu Âu)",
        "explanation": "Conformité Européenne — dấu chứng nhận sản phẩm đạt tiêu chuẩn an toàn, sức khỏe và môi trường của EU. Bắt buộc để bán tại 30 nước EU+EEA. Phạm vi rộng hơn FCC: không chỉ điện tử mà còn đồ chơi, thiết bị y tế, máy móc... Không bán cho EU? Vẫn cần biết khi nhà máy xuất hàng đa thị trường.",
        "example": {
          "zh": "我们的产品同时通过了FCC和CE认证，可以在美国和欧盟市场销售。",
          "vi": "Sản phẩm của chúng tôi đã qua cả FCC và CE, có thể bán ở thị trường Mỹ và EU."
        }
      },
      {
        "num": 3,
        "hanzi": "RoHS认证",
        "pinyin": "RoHS rènzhèng",
        "vi": "chứng nhận RoHS",
        "explanation": "Restriction of Hazardous Substances — hạn chế các chất độc hại trong thiết bị điện và điện tử. EU yêu cầu bắt buộc, Mỹ không bắt buộc nhưng khuyến nghị. Cấm: chì, thủy ngân, cadmium, chromium VI và một số hợp chất hữu cơ độc hại (PBDE, PBB). Amazon ngày càng yêu cầu RoHS compliance cho nhiều danh mục điện tử.",
        "example": {
          "zh": "我们所有电子产品都符合RoHS 3标准，不含任何受限有害物质。",
          "vi": "Tất cả sản phẩm điện tử của chúng tôi đạt tiêu chuẩn RoHS 3, không chứa bất kỳ chất độc hại bị hạn chế nào."
        }
      },
      {
        "num": 4,
        "hanzi": "ETL认证",
        "pinyin": "ETL rènzhèng",
        "vi": "chứng nhận ETL (Mỹ)",
        "explanation": "Intertek ETL Listed — chứng nhận an toàn điện cho thiết bị cắm điện bán tại Mỹ và Canada. Tương đương UL (Underwriters Laboratories) — cả hai đều được OSHA chấp nhận. Bắt buộc cho các thiết bị cắm điện trực tiếp như ổ cắm, adapter, đèn điện. Không có ETL/UL = không bán được ở nhiều kênh bán lẻ lớn Mỹ.",
        "example": {
          "zh": "这款电源适配器通过了ETL认证，符合美国和加拿大的电气安全标准。",
          "vi": "Adapter nguồn này đã qua chứng nhận ETL, đạt tiêu chuẩn an toàn điện Mỹ và Canada."
        }
      },
      {
        "num": 5,
        "hanzi": "REACH法规",
        "pinyin": "REACH fǎguī",
        "vi": "quy định REACH (EU)",
        "explanation": "Registration, Evaluation, Authorisation and Restriction of Chemicals — quy định EU về đăng ký và kiểm soát hóa chất trong sản phẩm. Đặc biệt quan tâm đến SVHC (Substances of Very High Concern) — nếu sản phẩm chứa SVHC trên 0.1%, phải khai báo. Không chỉ áp dụng cho hóa chất mà cả linh kiện điện tử.",
        "example": {
          "zh": "我们已经对产品进行了REACH SVHC检测，结果合格，可以出口到欧盟市场。",
          "vi": "Chúng tôi đã kiểm tra REACH SVHC cho sản phẩm, kết quả đạt, có thể xuất sang thị trường EU."
        }
      },
      {
        "num": 6,
        "hanzi": "电磁兼容 (EMC)",
        "pinyin": "diàncí jiānróng",
        "vi": "tương thích điện từ (Electromagnetic Compatibility)",
        "explanation": "Khả năng thiết bị hoạt động đúng trong môi trường điện từ mà không gây nhiễu cho thiết bị khác và không bị nhiễu từ thiết bị khác. EMC testing là một phần của cả FCC và CE testing. Thiết bị gây nhiễu sóng = vi phạm pháp luật, phải thu hồi.",
        "example": {
          "zh": "EMC测试是FCC和CE认证的重要组成部分，确保产品不会干扰其他电子设备。",
          "vi": "Kiểm tra EMC là phần quan trọng của FCC và CE certification, đảm bảo sản phẩm không gây nhiễu thiết bị điện tử khác."
        }
      },
      {
        "num": 7,
        "hanzi": "认证周期",
        "pinyin": "rènzhèng zhōuqī",
        "vi": "thời gian chứng nhận",
        "explanation": "Thời gian từ khi nộp hồ sơ đến khi nhận được chứng nhận. FCC: 6–12 tuần. CE: 4–12 tuần tùy độ phức tạp. ETL/UL: 4–8 tuần. Phải tính thời gian này vào kế hoạch ra mắt sản phẩm — bắt đầu quá trình chứng nhận song song với phát triển sản phẩm để tiết kiệm thời gian.",
        "example": {
          "zh": "FCC认证周期通常是6到8周，建议在产品开发阶段就同步提交申请，不要等到样品全部做好再申请。",
          "vi": "Thời gian FCC thường 6–8 tuần, khuyến nghị nộp đơn đồng thời trong giai đoạn phát triển sản phẩm, không chờ đến khi mẫu hoàn chỉnh mới nộp."
        }
      },
      {
        "num": 8,
        "hanzi": "认证费用",
        "pinyin": "rènzhèng fèiyòng",
        "vi": "chi phí chứng nhận",
        "explanation": "Tổng chi phí bao gồm: phí phòng thí nghiệm kiểm tra, phí đăng ký với cơ quan quản lý, phí tư vấn. FCC: 3.000–15.000 USD. CE: 2.000–8.000 USD. ETL: 2.000–6.000 USD. Các chi phí này thường do buyer chịu khi làm OEM — cần tính vào chi phí phát triển sản phẩm.",
        "example": {
          "zh": "FCC认证的费用大概在5000到10000美元之间，具体取决于产品的复杂程度和测试项目。",
          "vi": "Chi phí FCC khoảng 5.000–10.000 đô, tùy độ phức tạp và số hạng mục kiểm tra của sản phẩm."
        }
      },
      {
        "num": 9,
        "hanzi": "标志要求",
        "pinyin": "biāozhì yāoqiú",
        "vi": "yêu cầu dán nhãn",
        "explanation": "Quy định về các dấu hiệu và logo cần in trên sản phẩm và bao bì. Mỹ: phải có FCC ID và dấu \"FCC\". EU: phải có dấu CE. Thiết bị có pin lithium: phải có biểu tượng pin + hướng dẫn tái chế (WEEE symbol ở EU). Thiếu dấu hiệu bắt buộc = vi phạm pháp luật.",
        "example": {
          "zh": "产品上必须印上FCC ID编号，包装上要有CE标志，这些是出口前必须确认的要求。",
          "vi": "Trên sản phẩm phải in số FCC ID, trên bao bì phải có dấu CE, đây là yêu cầu cần xác nhận trước khi xuất hàng."
        }
      },
      {
        "num": 10,
        "hanzi": "检测报告",
        "pinyin": "jiǎncè bàogào",
        "vi": "báo cáo kiểm định",
        "explanation": "Tài liệu chính thức từ phòng thí nghiệm được công nhận (accredited lab) ghi lại kết quả kiểm tra sản phẩm. Đây là bằng chứng cho FCC, CE, RoHS compliance. Phải lưu giữ trong ít nhất 10 năm (yêu cầu CE). Khi Amazon hoặc hải quan yêu cầu, phải xuất trình ngay.",
        "example": {
          "zh": "请保存好所有认证的检测报告，亚马逊随时可能要求提供，特别是在A-to-Z Guarantee索赔时。",
          "vi": "Vui lòng lưu giữ kỹ báo cáo kiểm định của tất cả chứng nhận, Amazon có thể yêu cầu bất cứ lúc nào, đặc biệt khi có claim A-to-Z Guarantee."
        }
      }
    ],
    "dialogue": {
      "context": "Buyer VN đang thảo luận với nhà máy TQ về kế hoạch chứng nhận cho sản phẩm ổ cắm USB thông minh xuất Mỹ.",
      "characters": [
        {
          "name": "认证专员赵丽 (Zhào Lì)",
          "role": "Chuyên viên chứng nhận nhà máy"
        },
        {
          "name": "Anh Sơn",
          "role": "Quản lý dự án công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "Anh Sơn",
          "zh": "赵丽，我们的智能USB充电插排要出口美国，需要哪些认证？",
          "vi": "Chị Triệu Lệ, ổ cắm sạc USB thông minh của chúng tôi xuất Mỹ cần những chứng nhận gì?"
        },
        {
          "speaker": "赵丽",
          "zh": "这款产品因为有插头、接触电压，同时又有WiFi模块，认证要求比较多。主要需要：ETL认证（电气安全），FCC ID认证（WiFi模块），加上RoHS合规。",
          "vi": "Sản phẩm này có ổ cắm tiếp xúc điện áp, lại có module WiFi, yêu cầu chứng nhận khá nhiều. Chủ yếu cần: ETL (an toàn điện), FCC ID (module WiFi), cộng RoHS compliance."
        },
        {
          "speaker": "Anh Sơn",
          "zh": "三个认证，时间上怎么安排？可以同时进行吗？",
          "vi": "Ba chứng nhận, sắp xếp thời gian thế nào? Có thể tiến hành đồng thời không?"
        },
        {
          "speaker": "赵丽",
          "zh": "ETL和FCC可以同时进行，两者都大概需要6到8周。RoHS是材料检测，可以更早开始，大概3到4周，通常是认证里面最快完成的。",
          "vi": "ETL và FCC có thể tiến hành đồng thời, cả hai đều khoảng 6–8 tuần. RoHS là kiểm tra vật liệu, có thể bắt đầu sớm hơn, khoảng 3–4 tuần, thường là hoàn thành nhanh nhất trong các chứng nhận."
        },
        {
          "speaker": "Anh Sơn",
          "zh": "费用上大概是多少？",
          "vi": "Chi phí khoảng bao nhiêu?"
        },
        {
          "speaker": "赵丽",
          "zh": "ETL大概3000到5000美元，FCC ID大概4000到6000美元，RoHS检测大概1000到2000美元，总费用大概在8000到13000美元之间，具体看产品复杂程度。",
          "vi": "ETL khoảng 3.000–5.000 đô, FCC ID khoảng 4.000–6.000 đô, kiểm tra RoHS khoảng 1.000–2.000 đô, tổng chi phí khoảng 8.000–13.000 đô, tùy độ phức tạp sản phẩm."
        },
        {
          "speaker": "Anh Sơn",
          "zh": "这笔费用通常是由工厂承担还是由我们（买家）承担？",
          "vi": "Chi phí này thường do nhà máy hay do chúng tôi (bên mua) chịu?"
        },
        {
          "speaker": "赵丽",
          "zh": "通常这是买家的费用，因为认证是针对您的产品、在您的品牌名义下进行的。我们工厂可以协助您做申请和测试准备工作，但费用需要您这边承担。",
          "vi": "Thông thường đây là chi phí của bên mua, vì chứng nhận là cho sản phẩm của anh, đứng tên thương hiệu của anh. Nhà máy có thể hỗ trợ anh trong quá trình đăng ký và chuẩn bị kiểm tra, nhưng chi phí phía anh chịu."
        },
        {
          "speaker": "Anh Sơn",
          "zh": "好，我明白了。这些认证拿到之后，多久有效期？需要重新认证的情况有哪些？",
          "vi": "Tốt, tôi hiểu rồi. Sau khi có chứng nhận, hiệu lực bao lâu? Trường hợp nào cần chứng nhận lại?"
        },
        {
          "speaker": "赵丽",
          "zh": "FCC ID是永久有效的，只要产品设计不变。ETL证书只要产品规格不变也是长期有效的。但如果您修改了电路设计、换了关键元器件或者更改了功率，就需要重新认证或者做更新申请。",
          "vi": "FCC ID có hiệu lực vĩnh viễn miễn là thiết kế sản phẩm không đổi. Chứng nhận ETL cũng dài hạn miễn là thông số không đổi. Nhưng nếu anh thay đổi thiết kế mạch điện, thay linh kiện quan trọng hoặc thay đổi công suất, cần chứng nhận lại hoặc làm đơn cập nhật."
        },
        {
          "speaker": "Anh Sơn",
          "zh": "明白了。还有一个问题，产品上需要印什么标识？",
          "vi": "Hiểu rồi. Còn một câu hỏi, trên sản phẩm cần in những nhãn hiệu gì?"
        },
        {
          "speaker": "赵丽",
          "zh": "产品标签上必须要有：FCC ID编号（格式固定），ETL或UL的认证标志，RoHS合规声明。另外因为有锂电池，还需要印UN38.3测试通过的标识。包装上也要有相应的标志和警告说明。",
          "vi": "Trên nhãn sản phẩm bắt buộc phải có: số FCC ID (định dạng cố định), dấu chứng nhận ETL hoặc UL, tuyên bố tuân thủ RoHS. Ngoài ra vì có pin lithium, cần in thêm nhãn đã qua kiểm tra UN38.3. Trên bao bì cũng phải có các dấu hiệu và cảnh báo tương ứng."
        },
        {
          "speaker": "Anh Sơn",
          "zh": "好，这些我们都会按要求处理。赵丽，我们能不能先讨论一下认证的时间节点，确保产品能赶上第四季度的亚马逊旺季？",
          "vi": "Tốt, những điều này chúng tôi sẽ xử lý theo yêu cầu. Chị Triệu Lệ, chúng ta có thể thảo luận về timeline chứng nhận để đảm bảo sản phẩm kịp mùa cao điểm Q4 Amazon không?"
        },
        {
          "speaker": "赵丽",
          "zh": "当然，我来给您排一个时间表。如果我们下周开始提交检测样品，顺利的话8周后可以拿到所有认证，正好赶上9月底，可以在第四季度旺季前完成备货入仓。",
          "vi": "Tất nhiên, để tôi lên kế hoạch thời gian cho anh. Nếu tuần tới bắt đầu gửi mẫu kiểm tra, thuận lợi thì sau 8 tuần có thể có đủ chứng nhận, vừa đúng cuối tháng 9, có thể hoàn thành nhập kho trước mùa cao điểm Q4."
        }
      ]
    },
    "notes": [
      {
        "title": "Bắt đầu chứng nhận sớm, song song với phát triển sản phẩm",
        "body": "Sai lầm phổ biến: chờ mẫu hoàn chỉnh 100% mới bắt đầu xin chứng nhận. Đúng ra, có thể gửi engineering sample (mẫu kỹ thuật) để bắt đầu pre-compliance testing trong khi tiếp tục hoàn thiện sản phẩm. Tiết kiệm 4–6 tuần rất quý giá trước mùa ra hàng."
      },
      {
        "title": "FCC ID vs FCC Part 15: hai loại khác nhau",
        "body": "FCC Part 15: dành cho thiết bị không phát sóng có chủ ý (máy tính, màn hình, adapter). Chỉ cần self-certification với Declaration of Conformity. FCC ID: bắt buộc cho WiFi, Bluetooth, Zigbee — cần phòng thí nghiệm được FCC ủy quyền kiểm tra và cấp số FCC ID duy nhất."
      },
      {
        "title": "UN38.3: kiểm tra vận chuyển pin lithium",
        "body": "UN38.3 là bắt buộc để vận chuyển pin lithium bằng hàng không. Kiểm tra tám bài thử: nhiệt độ cao, áp suất thấp, rung động, va đập, ngoài ra các bài thử điện. Không có UN38.3 = hàng không chấp nhận lên tàu bay."
      },
      {
        "title": "Lưu giữ hồ sơ chứng nhận: quan trọng hơn bạn nghĩ",
        "body": "Amazon ngày càng yêu cầu documents nhiều hơn — đặc biệt khi có khiếu nại an toàn sản phẩm. Hồ sơ chứng nhận phải được lưu an toàn và có thể truy cập nhanh. Mất hồ sơ = mất khả năng phản hồi khiếu nại = nguy cơ bị xóa listing."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "ETL certification cần thiết cho thiết bị nào?",
          "options": {
            "A": "Thiết bị Bluetooth",
            "B": "Thiết bị cắm điện trực tiếp vào ổ điện",
            "C": "Chỉ thiết bị WiFi",
            "D": "Chỉ thiết bị trên 1000W"
          }
        },
        {
          "num": 2,
          "q": "RoHS cấm những chất nào?",
          "options": {
            "A": "Muối và đường",
            "B": "Chì, thủy ngân, cadmium và các chất hữu cơ độc hại trong điện tử",
            "C": "Chỉ kim loại nặng",
            "D": "Tất cả chất hóa học"
          }
        },
        {
          "num": 3,
          "q": "Chi phí FCC certification thường là bao nhiêu?",
          "options": {
            "A": "100–500 USD",
            "B": "500–1000 USD",
            "C": "3.000–15.000 USD",
            "D": "Miễn phí nếu qua kiểm tra"
          }
        },
        {
          "num": 4,
          "q": "Ai thường chịu chi phí chứng nhận FCC trong mô hình OEM?",
          "options": {
            "A": "Nhà máy TQ",
            "B": "Bên mua / buyer — vì chứng nhận đứng tên thương hiệu của buyer",
            "C": "Chia đều",
            "D": "Amazon chịu"
          }
        },
        {
          "num": 5,
          "q": "UN38.3 là gì?",
          "options": {
            "A": "Tiêu chuẩn an toàn điện cho ổ cắm",
            "B": "Kiểm tra bắt buộc để vận chuyển pin lithium bằng hàng không",
            "C": "Chứng nhận chống nước",
            "D": "Tiêu chuẩn EMC"
          }
        },
        {
          "num": 6,
          "q": "Khi nào FCC ID không còn hiệu lực?",
          "options": {
            "A": "Sau 1 năm",
            "B": "Sau 3 năm",
            "C": "Khi thay đổi thiết kế mạch điện hoặc linh kiện quan trọng",
            "D": "Khi thay đổi màu sắc vỏ ngoài"
          }
        },
        {
          "num": 7,
          "q": "Tại sao nên bắt đầu xin chứng nhận song song với phát triển sản phẩm?",
          "options": {
            "A": "Vì đây là yêu cầu pháp lý",
            "B": "Để tiết kiệm 4–6 tuần, kịp mùa ra hàng",
            "C": "Vì nhà máy yêu cầu",
            "D": "Không cần thiết"
          }
        },
        {
          "num": 8,
          "q": "Sản phẩm có WiFi bắt buộc cần chứng nhận nào đặc biệt?",
          "options": {
            "A": "ETL",
            "B": "RoHS",
            "C": "FCC ID",
            "D": "GOTS"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "FCC Part 15 và FCC ID là hai loại chứng nhận khác nhau, dành cho thiết bị khác nhau."
        },
        {
          "num": 10,
          "q": "CE marking bắt buộc để bán sản phẩm điện tử tại thị trường EU."
        },
        {
          "num": 11,
          "q": "Chi phí chứng nhận thường do nhà máy TQ chịu hoàn toàn trong mô hình OEM."
        },
        {
          "num": 12,
          "q": "Khi thay đổi linh kiện quan trọng trong sản phẩm đã có FCC, phải làm lại chứng nhận hoặc update."
        },
        {
          "num": 13,
          "q": "Hồ sơ chứng nhận cần lưu giữ ít nhất 10 năm theo yêu cầu CE."
        },
        {
          "num": 14,
          "q": "Sản phẩm không có UN38.3 vẫn có thể vận chuyển pin lithium bằng hàng không."
        }
      ],
      "fillblank": {
        "wordbank": [
          "FCC认证",
          "CE认证",
          "RoHS",
          "ETL认证",
          "认证周期",
          "检测报告"
        ],
        "items": [
          {
            "num": 15,
            "q": "出口美国的插座类产品必须有____（电气安全），内置蓝牙还需要____。"
          },
          {
            "num": 16,
            "q": "____是欧盟要求，我们出口欧洲的产品必须贴CE标志。"
          },
          {
            "num": 17,
            "q": "____规定电子产品不能含有铅、汞等有害物质，这个我们的产品完全符合。"
          },
          {
            "num": 18,
            "q": "____通常是6到8周，建议在产品开发阶段就开始准备。"
          },
          {
            "num": 19,
            "q": "请保存好所有认证的____，亚马逊随时可能要求提交。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 20,
          "q": "这款智能插座需要ETL认证（电气安全）、FCC ID认证（WiFi模块）以及RoHS合规，总认证周期大约8到10周。"
        },
        {
          "num": 21,
          "q": "FCC ID认证费用由贵方承担，因为认证以您的品牌名义申请，工厂协助准备测试样品和文件。"
        },
        {
          "num": 22,
          "q": "认证通过后，您的产品需要在标签上印有FCC ID编号，包装上需要有ETL标志和RoHS合规说明。"
        },
        {
          "num": 23,
          "q": "如果日后您修改了WiFi模块或电源电路设计，需要重新提交FCC认证或申请设计变更，请提前告知我们。"
        },
        {
          "num": 24,
          "q": "我们建议您现在就开始准备认证，同步进行产品最终调试，这样可以节省6到8周时间，确保第四季度旺季前完成入仓。"
        }
      ],
      "vi2zh": [
        {
          "num": 25,
          "q": "Sản phẩm này cần những chứng nhận gì để bán ở Mỹ? Tổng chi phí và thời gian là bao nhiêu?"
        },
        {
          "num": 26,
          "q": "FCC certification có hiệu lực bao lâu? Nếu thay đổi thiết kế thì có cần làm lại không?"
        },
        {
          "num": 27,
          "q": "Chúng tôi muốn bắt đầu quá trình FCC ngay tuần tới, cần gửi bao nhiêu mẫu kiểm tra và cần chuẩn bị những tài liệu gì?"
        },
        {
          "num": 28,
          "q": "Sản phẩm có module WiFi tích hợp, anh xác nhận cần FCC ID chứ không phải chỉ FCC Part 15?"
        },
        {
          "num": 29,
          "q": "Tất cả báo cáo kiểm định và chứng nhận vui lòng gửi cho chúng tôi để lưu trữ, Amazon có thể yêu cầu bất cứ lúc nào."
        },
        {
          "num": 30,
          "q": "RoHS compliance có báo cáo kiểm định bên thứ ba không? Chúng tôi cần tài liệu này để phản hồi yêu cầu từ Amazon."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "C",
        "4": "B",
        "5": "B",
        "6": "C",
        "7": "B",
        "8": "C"
      },
      "tf": {
        "9": true,
        "10": true,
        "11": false,
        "12": true,
        "13": true,
        "14": false
      },
      "fillblank": {
        "15": [
          "ETL认证",
          "FCC认证"
        ],
        "16": "CE认证",
        "17": "RoHS",
        "18": "认证周期",
        "19": "检测报告"
      },
      "zh2vi": {
        "20": "Ổ cắm thông minh này cần ETL (an toàn điện), FCC ID (module WiFi) và RoHS compliance, tổng thời gian chứng nhận khoảng 8–10 tuần.",
        "21": "Chi phí FCC ID do phía anh chịu vì chứng nhận đứng tên thương hiệu của anh, nhà máy hỗ trợ chuẩn bị mẫu kiểm tra và tài liệu.",
        "22": "Sau khi qua chứng nhận, sản phẩm của anh cần in số FCC ID trên nhãn, trên bao bì cần có dấu ETL và tuyên bố tuân thủ RoHS.",
        "23": "Nếu sau này anh chỉnh sửa module WiFi hoặc thiết kế mạch nguồn, cần nộp lại FCC hoặc đơn thay đổi thiết kế, vui lòng báo trước cho chúng tôi.",
        "24": "Chúng tôi khuyến nghị anh bắt đầu chuẩn bị chứng nhận ngay bây giờ song song với hoàn thiện sản phẩm, như vậy tiết kiệm 6–8 tuần, đảm bảo nhập kho trước mùa cao điểm Q4."
      },
      "vi2zh": {
        "25": "这款产品要在美国销售需要哪些认证？总费用和时间大概是多少？",
        "26": "FCC认证有效期多长？如果修改设计需要重新认证吗？",
        "27": "我们想下周就开始FCC流程，需要提供几个测试样品，需要准备哪些文件？",
        "28": "产品内置了WiFi模块，确认是需要FCC ID而不是FCC Part 15吗？",
        "29": "所有认证的检测报告请发给我们存档，亚马逊随时可能要求提交。",
        "30": "RoHS合规有没有第三方检测报告？我们需要这份文件来回应亚马逊的要求。"
      }
    }
  },
  {
    "num": 23,
    "title": "LINH KIỆN ĐIỆN TỬ & BOM (BILL OF MATERIALS)",
    "date": "19/6",
    "phase": 3,
    "vocab": [
      {
        "num": 1,
        "hanzi": "元器件",
        "pinyin": "yuánqìjiàn",
        "vi": "linh kiện điện tử",
        "explanation": "Tất cả các thành phần điện tử tạo nên sản phẩm: chip xử lý (芯片), tụ điện (电容), điện trở (电阻), cuộn cảm (电感), transistor, IC... Chất lượng linh kiện quyết định tuổi thọ và hiệu năng sản phẩm. Trong bối cảnh thiếu chip toàn cầu 2021-2023, 元器件 trở thành từ khóa nóng nhất trong chuỗi cung ứng.",
        "example": {
          "zh": "目前这款芯片严重缺货，我们需要寻找替代的元器件，但需要您确认兼容性。",
          "vi": "Hiện chip này đang thiếu hàng nghiêm trọng, chúng tôi cần tìm linh kiện thay thế, nhưng cần anh xác nhận khả năng tương thích."
        }
      },
      {
        "num": 2,
        "hanzi": "芯片",
        "pinyin": "xīnpiàn",
        "vi": "chip / vi mạch tích hợp",
        "explanation": "IC (Integrated Circuit) — mạch tích hợp, là \"não bộ\" của thiết bị điện tử. Các loại phổ biến: MCU (vi điều khiển), SoC (hệ thống trên chip), DSP (xử lý tín hiệu số), FPGA. Chip là linh kiện nhạy cảm nhất về nguồn cung — thiếu chip = dừng sản xuất toàn bộ.",
        "example": {
          "zh": "这款产品的核心芯片是ESP32，负责WiFi、蓝牙和主要控制功能。",
          "vi": "Chip lõi của sản phẩm này là ESP32, đảm nhận WiFi, Bluetooth và chức năng điều khiển chính."
        }
      },
      {
        "num": 3,
        "hanzi": "BOM (物料清单)",
        "pinyin": "BOM (wùliào qīngdān)",
        "vi": "danh sách vật liệu (Bill of Materials)",
        "explanation": "Tài liệu liệt kê đầy đủ tất cả linh kiện, vật liệu, và bán thành phẩm cần thiết để sản xuất một đơn vị sản phẩm. BOM bao gồm: tên linh kiện, số hiệu (part number), nhà sản xuất, số lượng mỗi sản phẩm, và thông số kỹ thuật. BOM là tài liệu kỹ thuật quan trọng nhất trong sản xuất điện tử.",
        "example": {
          "zh": "请提供完整的BOM，包括每个元器件的型号、品牌和数量，我们需要评估供应风险。",
          "vi": "Vui lòng cung cấp BOM đầy đủ, bao gồm model, thương hiệu và số lượng từng linh kiện, chúng tôi cần đánh giá rủi ro cung ứng."
        }
      },
      {
        "num": 4,
        "hanzi": "主控芯片",
        "pinyin": "zhǔkòng xīnpiàn",
        "vi": "chip điều khiển chính (main control chip)",
        "explanation": "MCU hoặc SoC trung tâm điều khiển toàn bộ hoạt động của sản phẩm. Đây thường là linh kiện đắt nhất và khó thay thế nhất trong BOM. Với sản phẩm IoT, chip phổ biến: ESP32 (Espressif), nRF52 (Nordic), STM32 (STMicroelectronics).",
        "example": {
          "zh": "我们的智能家居产品线统一使用ESP32-S3作为主控芯片，这样可以降低采购成本和设计风险。",
          "vi": "Dòng sản phẩm nhà thông minh của chúng tôi thống nhất dùng ESP32-S3 làm chip điều khiển chính, như vậy có thể giảm chi phí thu mua và rủi ro thiết kế."
        }
      },
      {
        "num": 5,
        "hanzi": "供应商",
        "pinyin": "gōngyìng shāng",
        "vi": "nhà cung cấp linh kiện",
        "explanation": "Công ty cung cấp linh kiện cho nhà sản xuất. Phân cấp: nhà sản xuất gốc (原厂/OEM supplier), nhà phân phối ủy quyền (授权代理商), nhà phân phối thứ cấp (二级代理). Linh kiện mua từ kênh chính thống đảm bảo chất lượng và hàng thật — linh kiện \"chợ\" có nguy cơ hàng nhái (假冒元器件) rất cao.",
        "example": {
          "zh": "我们的元器件只从授权代理商采购，确保所有芯片都是原厂正品，不存在假冒风险。",
          "vi": "Linh kiện của chúng tôi chỉ mua từ nhà phân phối ủy quyền, đảm bảo tất cả chip là hàng chính hãng, không có rủi ro hàng nhái."
        }
      },
      {
        "num": 6,
        "hanzi": "交货提前期",
        "pinyin": "jiāohuò tíqiān qī",
        "vi": "lead time / thời gian giao hàng trước",
        "explanation": "Khoảng thời gian từ khi đặt mua linh kiện đến khi nhận được hàng. Chip và linh kiện bán dẫn thường có lead time dài: 12–52 tuần trong thời kỳ thiếu hàng. Lead time linh kiện quyết định lead time tổng của sản phẩm.",
        "example": {
          "zh": "这款传感器的交货提前期现在是16周，这会影响我们的整体生产计划，需要提前备货。",
          "vi": "Lead time của cảm biến này hiện là 16 tuần, điều này ảnh hưởng đến kế hoạch sản xuất tổng thể, cần dự trữ trước."
        }
      },
      {
        "num": 7,
        "hanzi": "替代料方案",
        "pinyin": "tìdài liào fāng'àn",
        "vi": "phương án linh kiện thay thế",
        "explanation": "Danh sách các linh kiện có thể thay thế cho linh kiện gốc khi thiếu hàng hoặc ngừng sản xuất (EOL — End of Life). BOM tốt luôn có 1–2 approved alternates cho mỗi linh kiện quan trọng. Thay thế linh kiện cần kiểm tra lại và có thể ảnh hưởng đến chứng nhận sản phẩm.",
        "example": {
          "zh": "我们为BOM中的每个关键元器件都准备了替代料方案，以防止供应中断影响生产。",
          "vi": "Chúng tôi đã chuẩn bị phương án linh kiện thay thế cho từng linh kiện quan trọng trong BOM để tránh gián đoạn cung ứng ảnh hưởng sản xuất."
        }
      },
      {
        "num": 8,
        "hanzi": "电路板",
        "pinyin": "diànlù bǎn",
        "vi": "bảng mạch PCB (Printed Circuit Board)",
        "explanation": "Tấm nền gắn và kết nối tất cả linh kiện điện tử. PCB layout là một trong những công việc kỹ thuật quan trọng nhất trong thiết kế điện tử. Chất lượng PCB ảnh hưởng đến độ tin cậy sản phẩm. Trong TQ, JLCPCB và PCBWay là hai nhà sản xuất PCB phổ biến cho prototype.",
        "example": {
          "zh": "这款产品的电路板是4层板，所有SMT元器件由工厂统一焊接，品质更有保障。",
          "vi": "Bảng mạch của sản phẩm này là PCB 4 lớp, tất cả linh kiện SMT do nhà máy hàn toàn bộ, chất lượng đảm bảo hơn."
        }
      },
      {
        "num": 9,
        "hanzi": "SMT贴片",
        "pinyin": "SMT tiēpiàn",
        "vi": "lắp ráp SMT (Surface Mount Technology)",
        "explanation": "Công nghệ gắn linh kiện trực tiếp lên bề mặt PCB — phổ biến nhất hiện nay. Dây chuyền SMT tự động hóa cao, năng suất lớn, chi phí thấp cho số lượng lớn. Phân biệt với THT (through-hole technology — xuyên lỗ) cho linh kiện lớn hơn.",
        "example": {
          "zh": "我们有全自动SMT贴片生产线，日产能5000件，品质一致性很好。",
          "vi": "Chúng tôi có dây chuyền SMT tự động hoàn toàn, công suất 5000 cái/ngày, tính nhất quán chất lượng rất tốt."
        }
      },
      {
        "num": 10,
        "hanzi": "假冒元器件",
        "pinyin": "jiǎmào yuánqìjiàn",
        "vi": "linh kiện nhái / hàng giả",
        "explanation": "Linh kiện không phải hàng chính hãng — có thể là: hàng đã qua sử dụng được tái đánh dấu (re-marked), hàng nhái (counterfeit), hoặc hàng kém chất lượng gắn nhãn thương hiệu lớn. Hậu quả: sản phẩm lỗi hàng loạt, nguy cơ cháy nổ, thiệt hại thương hiệu nghiêm trọng. Chỉ mua từ kênh ủy quyền để tránh.",
        "example": {
          "zh": "市场上存在大量假冒的芯片，我们要求供应商提供原厂追溯报告，证明元器件来源正规。",
          "vi": "Trên thị trường có rất nhiều chip nhái, chúng tôi yêu cầu nhà cung cấp cung cấp báo cáo truy xuất nguồn gốc từ nhà máy, chứng minh nguồn linh kiện chính thống."
        }
      }
    ],
    "dialogue": {
      "context": "Buyer VN đang review BOM với kỹ sư nhà máy TQ trước khi chốt thiết kế sản phẩm.",
      "characters": [
        {
          "name": "硬件工程师吴工 (Wú gōng)",
          "role": "Kỹ sư phần cứng nhà máy"
        },
        {
          "name": "Chị Lan",
          "role": "Kỹ sư phát triển sản phẩm công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "Chị Lan",
          "zh": "吴工，我们今天来审核一下BOM，确认元器件选型和供应风险。",
          "vi": "Kỹ sư Ngô, hôm nay chúng ta review BOM, xác nhận lựa chọn linh kiện và rủi ro cung ứng."
        },
        {
          "speaker": "吴工",
          "zh": "好，我来逐一说明。主控芯片我们选的是ESP32-S3，这个芯片集成了WiFi和蓝牙，性能稳定，价格合理，在智能家居产品里用得很广泛。",
          "vi": "Tốt, tôi sẽ giải thích từng cái. Chip điều khiển chính chúng tôi chọn ESP32-S3, chip này tích hợp WiFi và Bluetooth, hiệu năng ổn định, giá hợp lý, được dùng rất phổ biến trong sản phẩm nhà thông minh."
        },
        {
          "speaker": "Chị Lan",
          "zh": "ESP32-S3我们认可。目前这款芯片的供货情况怎么样？交货提前期大概是多少？",
          "vi": "ESP32-S3 chúng tôi chấp nhận. Tình trạng cung ứng chip này hiện tại thế nào? Lead time khoảng bao lâu?"
        },
        {
          "speaker": "吴工",
          "zh": "目前从乐鑫授权代理商采购，交货提前期是8到10周，供货比较稳定，我们也有4到6周的安全库存。",
          "vi": "Hiện mua từ nhà phân phối ủy quyền Espressif, lead time 8–10 tuần, cung ứng tương đối ổn định, chúng tôi cũng có tồn kho an toàn 4–6 tuần."
        },
        {
          "speaker": "Chị Lan",
          "zh": "好，有安全库存很重要。BOM里有没有哪个元器件供货风险比较高？",
          "vi": "Tốt, có tồn kho an toàn rất quan trọng. Trong BOM có linh kiện nào rủi ro cung ứng cao không?"
        },
        {
          "speaker": "吴工",
          "zh": "目前有两个元器件需要注意：一个是PMIC电源管理芯片，目前交货提前期达到20周，我们已经在BOM里备注了一个替代料方案；另一个是某款传感器，原厂已经宣布EOL（停产），需要尽快更换设计。",
          "vi": "Hiện có hai linh kiện cần chú ý: một là chip PMIC quản lý nguồn điện, hiện lead time lên đến 20 tuần, chúng tôi đã ghi chú phương án linh kiện thay thế trong BOM; một cái khác là một loại cảm biến, nhà sản xuất đã thông báo EOL (ngừng sản xuất), cần thay đổi thiết kế sớm."
        },
        {
          "speaker": "Chị Lan",
          "zh": "传感器停产这个问题很严重，替代料有了吗？换了以后需要重新做FCC认证吗？",
          "vi": "Vấn đề cảm biến ngừng sản xuất này nghiêm trọng, đã có linh kiện thay thế chưa? Thay xong có phải làm lại FCC certification không?"
        },
        {
          "speaker": "吴工",
          "zh": "我们已经找到了一款功能完全兼容的替代传感器，来自另一个品牌。换了传感器之后，需要做FCC认证的变更申请，大概需要3到4周，费用比全新认证低很多。",
          "vi": "Chúng tôi đã tìm được một cảm biến thay thế tương thích hoàn toàn về chức năng, từ thương hiệu khác. Sau khi thay cảm biến cần làm đơn thay đổi FCC certification, khoảng 3–4 tuần, chi phí thấp hơn nhiều so với chứng nhận mới hoàn toàn."
        },
        {
          "speaker": "Chị Lan",
          "zh": "好，你们这边尽快启动替代料验证，我们那边同步申请FCC变更。最后，我想确认一下元器件的来源，都是从授权渠道采购的吗？",
          "vi": "Tốt, phía anh nhanh chóng khởi động xác minh linh kiện thay thế, phía chúng tôi đồng thời làm đơn thay đổi FCC. Cuối cùng, tôi muốn xác nhận nguồn gốc linh kiện, tất cả đều mua từ kênh ủy quyền phải không?"
        },
        {
          "speaker": "吴工",
          "zh": "是的，我们所有关键元器件都从原厂授权代理商采购，每个元器件都有追溯报告，可以查到原厂出厂记录，完全排除假冒风险。",
          "vi": "Đúng, tất cả linh kiện quan trọng của chúng tôi đều mua từ nhà phân phối ủy quyền gốc, mỗi linh kiện đều có báo cáo truy xuất, có thể tra được hồ sơ xuất xưởng từ nhà sản xuất, hoàn toàn loại trừ rủi ro hàng nhái."
        },
        {
          "speaker": "Chị Lan",
          "zh": "很好，这一点非常重要，假冒元器件的问题在行业里很常见，我们不能有这方面的风险。你们能提供每个关键元器件的采购来源文件吗？",
          "vi": "Tốt, điểm này rất quan trọng, vấn đề linh kiện nhái rất phổ biến trong ngành, chúng tôi không thể có rủi ro này. Anh có thể cung cấp tài liệu nguồn gốc mua hàng cho từng linh kiện quan trọng không?"
        },
        {
          "speaker": "吴工",
          "zh": "当然可以，我可以整理一份元器件溯源报告发给您，包括所有关键器件的供货商信息和原厂证明。",
          "vi": "Tất nhiên, tôi có thể tổng hợp một báo cáo truy xuất nguồn gốc linh kiện gửi cho chị, bao gồm thông tin nhà cung cấp và chứng minh từ nhà sản xuất của tất cả linh kiện quan trọng."
        }
      ]
    },
    "notes": [
      {
        "title": "BOM: tài liệu bắt buộc buyer phải hiểu",
        "body": "Khi làm OEM điện tử, buyer cần đọc và hiểu BOM — không cần hiểu từng linh kiện kỹ thuật, nhưng phải hiểu rủi ro cung ứng: linh kiện nào có lead time dài, linh kiện nào sắp EOL, linh kiện nào chỉ có một nhà cung cấp (single source risk)."
      },
      {
        "title": "EOL (End of Life): linh kiện ngừng sản xuất",
        "body": "Khi nhà sản xuất chip thông báo EOL, buyer cần hành động ngay: (1) mua tích trữ một lượng lớn, (2) tìm linh kiện thay thế. Thường có 12–18 tháng notice trước khi chip ngừng hoàn toàn. Bỏ qua EOL notice = đột ngột không còn linh kiện để sản xuất."
      },
      {
        "title": "Hàng nhái linh kiện: vấn đề lớn ở TQ",
        "body": "Thị trường linh kiện TQ có tỷ lệ hàng giả/nhái cao — đặc biệt chip \"second-hand\" bị tái đánh dấu. Hậu quả: sản phẩm hỏng hàng loạt, nguy cơ cháy nổ, thu hồi sản phẩm. Giải pháp: yêu cầu nhà máy mua từ nhà phân phối ủy quyền (authorized distributor) và cung cấp traceability report."
      },
      {
        "title": "Single source risk: rủi ro một nhà cung cấp",
        "body": "Nếu một linh kiện quan trọng chỉ có thể mua từ một nhà sản xuất duy nhất (single source), đó là rủi ro lớn. Giải pháp tốt nhất: đưa vào BOM ít nhất một approved alternate từ nhà sản xuất khác ngay từ giai đoạn thiết kế."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "BOM (Bill of Materials) là gì?",
          "options": {
            "A": "Hóa đơn thanh toán cho nhà máy",
            "B": "Danh sách đầy đủ tất cả linh kiện và vật liệu cần để sản xuất một sản phẩm",
            "C": "Bảng giá linh kiện",
            "D": "Kế hoạch sản xuất"
          }
        },
        {
          "num": 2,
          "q": "EOL (End of Life) trong ngữ cảnh linh kiện điện tử có nghĩa là gì?",
          "options": {
            "A": "Sản phẩm đã hết bảo hành",
            "B": "Nhà sản xuất ngừng sản xuất linh kiện đó",
            "C": "Linh kiện bị lỗi",
            "D": "Hết hàng tạm thời"
          }
        },
        {
          "num": 3,
          "q": "Rủi ro \"single source\" trong BOM là gì?",
          "options": {
            "A": "Chỉ mua từ một nhà cung cấp duy nhất — nếu họ gặp vấn đề, toàn bộ sản xuất dừng lại",
            "B": "Mua linh kiện từ nhiều nguồn",
            "C": "Linh kiện dùng cho một sản phẩm duy nhất",
            "D": "Không có rủi ro"
          }
        },
        {
          "num": 4,
          "q": "Tại sao phải mua linh kiện từ nhà phân phối ủy quyền?",
          "options": {
            "A": "Vì rẻ hơn chợ",
            "B": "Để đảm bảo hàng thật, tránh hàng nhái gây lỗi sản phẩm hàng loạt",
            "C": "Vì delivery nhanh hơn",
            "D": "Không có sự khác biệt"
          }
        },
        {
          "num": 5,
          "q": "Lead time 20 tuần cho một linh kiện quan trọng ảnh hưởng như thế nào?",
          "options": {
            "A": "Không ảnh hưởng nếu có tồn kho",
            "B": "Cần đặt hàng trước 20 tuần để không bị gián đoạn sản xuất",
            "C": "Có thể thay thế bằng linh kiện khác ngay lập tức",
            "D": "Nhà máy sẽ tự xử lý"
          }
        },
        {
          "num": 6,
          "q": "SMT (Surface Mount Technology) là gì?",
          "options": {
            "A": "Phương pháp kiểm tra chất lượng",
            "B": "Công nghệ gắn linh kiện trực tiếp lên bề mặt PCB",
            "C": "Loại chip điều khiển",
            "D": "Giao thức kết nối không dây"
          }
        },
        {
          "num": 7,
          "q": "Khi thay linh kiện trong sản phẩm đã có FCC certification, cần làm gì?",
          "options": {
            "A": "Không cần làm gì",
            "B": "Làm đơn thay đổi FCC (design change amendment)",
            "C": "Xin FCC hoàn toàn mới từ đầu",
            "D": "Hủy FCC cũ và bán hàng mà không cần FCC"
          }
        },
        {
          "num": 8,
          "q": "Traceability report (truy xuất nguồn gốc) linh kiện dùng để làm gì?",
          "options": {
            "A": "Tính giá thành sản phẩm",
            "B": "Chứng minh linh kiện mua từ kênh chính thống, loại trừ hàng nhái",
            "C": "Xác nhận chứng nhận FCC",
            "D": "Báo cáo tài chính"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "BOM tốt nên có ít nhất một approved alternate cho mỗi linh kiện quan trọng."
        },
        {
          "num": 10,
          "q": "Hàng nhái linh kiện điện tử chỉ gây vấn đề về hiệu năng, không gây nguy hiểm an toàn."
        },
        {
          "num": 11,
          "q": "Khi nhà sản xuất thông báo EOL, thường còn 12–18 tháng để tìm giải pháp thay thế."
        },
        {
          "num": 12,
          "q": "Buyer không cần quan tâm đến BOM kỹ thuật vì đó là việc của nhà máy."
        },
        {
          "num": 13,
          "q": "Tồn kho an toàn (safety stock) 4–6 tuần giúp bù đắp khi có gián đoạn cung ứng ngắn hạn."
        },
        {
          "num": 14,
          "q": "Thay đổi linh kiện trong sản phẩm đã có chứng nhận FCC không ảnh hưởng gì đến chứng nhận đó."
        }
      ],
      "fillblank": {
        "wordbank": [
          "元器件",
          "芯片",
          "BOM",
          "交货提前期",
          "替代料方案",
          "假冒元器件"
        ],
        "items": [
          {
            "num": 15,
            "q": "请提供完整的____，包括所有关键____的型号和供应商信息。"
          },
          {
            "num": 16,
            "q": "这款____的____现在是18周，建议提前备货避免断供。"
          },
          {
            "num": 17,
            "q": "我们已经为每个高风险____准备了____，防止供应中断影响生产。"
          },
          {
            "num": 18,
            "q": "市场上____问题严重，我们要求所有采购都附带追溯报告。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 19,
          "q": "BOM中的主控芯片交货提前期是16周，建议我们提前下单备货，避免因为缺料影响生产计划。"
        },
        {
          "num": 20,
          "q": "有一款传感器已经宣布EOL，需要在未来6个月内完成替代料切换，同时需要更新FCC认证。"
        },
        {
          "num": 21,
          "q": "我们所有关键元器件都从原厂授权代理商采购，每批货都有追溯报告，完全避免假冒元器件的风险。"
        },
        {
          "num": 22,
          "q": "PMIC芯片目前只有一家供应商，这是我们BOM中最大的供应风险，我们正在寻找替代方案。"
        },
        {
          "num": 23,
          "q": "我们的SMT产线有完整的AOI光学检测，可以在生产过程中自动发现焊接缺陷，良品率保持在99%以上。"
        }
      ],
      "vi2zh": [
        {
          "num": 24,
          "q": "Vui lòng cung cấp BOM đầy đủ, bao gồm tên linh kiện, nhà sản xuất và số lượng cho từng sản phẩm."
        },
        {
          "num": 25,
          "q": "Lead time của chip điều khiển chính là bao lâu? Anh có tồn kho an toàn không?"
        },
        {
          "num": 26,
          "q": "Linh kiện nào trong BOM có rủi ro cung ứng cao nhất? Đã có phương án thay thế chưa?"
        },
        {
          "num": 27,
          "q": "Tất cả linh kiện đều mua từ nhà phân phối ủy quyền phải không? Chúng tôi cần báo cáo truy xuất nguồn gốc."
        },
        {
          "num": 28,
          "q": "Cảm biến này đã ngừng sản xuất, cần tìm linh kiện thay thế tương thích và kiểm tra lại trước khi đưa vào sản xuất đại trà."
        },
        {
          "num": 29,
          "q": "Thay linh kiện xong có cần làm lại FCC không? Chi phí và thời gian là bao nhiêu?"
        },
        {
          "num": 30,
          "q": "Báo cáo truy xuất nguồn gốc linh kiện vui lòng đính kèm khi gửi hàng, chúng tôi cần lưu hồ sơ."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "A",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": false,
        "11": true,
        "12": false,
        "13": true,
        "14": false
      },
      "fillblank": {
        "15": [
          "BOM",
          "元器件"
        ],
        "16": [
          "芯片",
          "交货提前期"
        ],
        "17": [
          "元器件",
          "替代料方案"
        ],
        "18": "假冒元器件"
      },
      "zh2vi": {
        "19": "Chip điều khiển chính trong BOM có lead time 16 tuần, khuyến nghị chúng tôi đặt hàng trước để dự trữ, tránh thiếu nguyên liệu ảnh hưởng kế hoạch sản xuất.",
        "20": "Một loại cảm biến đã thông báo EOL, cần hoàn thành việc chuyển đổi sang linh kiện thay thế trong 6 tháng tới, đồng thời cần cập nhật FCC certification.",
        "21": "Tất cả linh kiện quan trọng của chúng tôi đều mua từ nhà phân phối ủy quyền gốc, mỗi lô đều có báo cáo truy xuất, hoàn toàn tránh rủi ro linh kiện nhái.",
        "22": "Chip PMIC hiện chỉ có một nhà cung cấp, đây là rủi ro cung ứng lớn nhất trong BOM, chúng tôi đang tìm phương án thay thế.",
        "23": "Dây chuyền SMT của chúng tôi có hệ thống kiểm tra quang học AOI hoàn chỉnh, có thể tự động phát hiện lỗi hàn trong quá trình sản xuất, tỷ lệ hàng đạt duy trì trên 99%."
      },
      "vi2zh": {
        "24": "请提供完整的BOM，包括每个元器件的名称、制造商和每件产品的用量。",
        "25": "主控芯片的交货提前期是多久？您有没有安全库存？",
        "26": "BOM中哪个元器件的供应风险最高？有替代料方案吗？",
        "27": "所有元器件都是从授权代理商采购的吗？我们需要追溯报告。",
        "28": "这个传感器已经停产了，需要找一个兼容的替代品，在大规模量产前需要重新验证。",
        "29": "换了元器件之后需要重新做FCC认证吗？费用和时间大概是多少？",
        "30": "发货时请附上元器件追溯报告，我们需要留档备案。"
      }
    }
  },
  {
    "num": 24,
    "title": "SẢN XUẤT & KIỂM SOÁT CHẤT LƯỢNG ĐIỆN TỬ",
    "date": "20/6",
    "phase": 3,
    "vocab": [
      {
        "num": 1,
        "hanzi": "可靠性测试",
        "pinyin": "kěkào xìng cèshì",
        "vi": "kiểm tra độ tin cậy",
        "explanation": "Thử nghiệm đánh giá sản phẩm điện tử có hoạt động ổn định trong thời gian dài và trong điều kiện khắc nghiệt không. Bao gồm: burn-in test (lão hóa nhanh), HALT (Highly Accelerated Life Test), nhiệt độ, độ ẩm, rung động. Kết quả dự đoán tuổi thọ sản phẩm và tỷ lệ lỗi thực tế.",
        "example": {
          "zh": "出货前每批产品都要做可靠性测试，在极端温度和湿度下运行72小时，确保稳定性。",
          "vi": "Trước khi xuất hàng mỗi lô phải kiểm tra độ tin cậy, vận hành 72 giờ ở nhiệt độ và độ ẩm cực đoan, đảm bảo tính ổn định."
        }
      },
      {
        "num": 2,
        "hanzi": "PCBA测试",
        "pinyin": "PCBA cèshì",
        "vi": "kiểm tra bảng mạch sau lắp ráp",
        "explanation": "PCB Assembly test — kiểm tra toàn bộ board mạch sau khi hàn xong linh kiện. Bao gồm: ICT (In-Circuit Test — kiểm tra từng linh kiện), FCT (Functional Circuit Test — kiểm tra chức năng tổng thể), AOI (Automated Optical Inspection — kiểm tra quang học tự động). Phát hiện lỗi ở giai đoạn này rẻ hơn nhiều so với sau khi lắp ráp thành phẩm.",
        "example": {
          "zh": "我们的PCBA测试覆盖率达到98%，ICT测试可以检测出大多数焊接缺陷。",
          "vi": "Độ phủ kiểm tra PCBA của chúng tôi đạt 98%, ICT test có thể phát hiện hầu hết lỗi hàn."
        }
      },
      {
        "num": 3,
        "hanzi": "成品测试",
        "pinyin": "chéngpǐn cèshì",
        "vi": "kiểm tra thành phẩm",
        "explanation": "Kiểm tra sản phẩm hoàn chỉnh đã lắp ráp xong — kiểm tra tất cả tính năng và giao diện người dùng. Đây là bước cuối trước khi đóng gói. Thường bao gồm: bật tắt, kiểm tra kết nối WiFi/BT, đo công suất, kiểm tra cảm biến, kiểm tra LED và âm thanh.",
        "example": {
          "zh": "每台产品都经过100%成品测试，全功能验证通过后才贴上合格标签装箱。",
          "vi": "Mỗi sản phẩm đều qua kiểm tra thành phẩm 100%, xác minh toàn bộ chức năng qua mới dán nhãn đạt chuẩn và đóng hộp."
        }
      },
      {
        "num": 4,
        "hanzi": "老化测试",
        "pinyin": "lǎohuà cèshì",
        "vi": "burn-in test / kiểm tra lão hóa",
        "explanation": "Cho sản phẩm hoạt động liên tục ở nhiệt độ cao trong 24–72 giờ để \"lão hóa nhanh\" — phát hiện và loại bỏ các sản phẩm có lỗi tiềm ẩn trước khi giao khách. Dựa trên hiện tượng \"infant mortality\" — sản phẩm lỗi thường hỏng sớm, không phải muộn.",
        "example": {
          "zh": "所有产品在45°C环境下进行24小时老化测试，淘汰早期失效品，提高出货可靠性。",
          "vi": "Tất cả sản phẩm thực hiện burn-in 24 giờ ở 45°C, loại bỏ hàng lỗi sớm, nâng cao độ tin cậy khi xuất hàng."
        }
      },
      {
        "num": 5,
        "hanzi": "不良率",
        "pinyin": "bùliáng lǜ",
        "vi": "tỷ lệ hàng lỗi (defect rate)",
        "explanation": "Tỷ lệ phần trăm sản phẩm không đạt tiêu chuẩn trong quá trình sản xuất. Đơn vị đo thường dùng: PPM (parts per million — phần triệu). 100 PPM = 100 sản phẩm lỗi trên 1 triệu. Nhà máy điện tử tốt thường duy trì dưới 500 PPM. Amazon và các retailer lớn thường yêu cầu dưới 1% (10.000 PPM).",
        "example": {
          "zh": "我们的PCBA不良率控制在300PPM以内，成品不良率低于0.5%。",
          "vi": "Tỷ lệ lỗi PCBA của chúng tôi kiểm soát dưới 300 PPM, tỷ lệ lỗi thành phẩm dưới 0,5%."
        }
      },
      {
        "num": 6,
        "hanzi": "静电防护",
        "pinyin": "jìngdiàn fánghù",
        "vi": "bảo vệ tĩnh điện (ESD Protection)",
        "explanation": "Biện pháp bảo vệ linh kiện điện tử khỏi hư hỏng do tĩnh điện — rất quan trọng trong sản xuất điện tử. Nhà máy cần: dây đeo tay (腕带), thảm tĩnh điện (防静电地垫), bao bì chống tĩnh điện (防静电包装). Tĩnh điện không nhìn thấy được nhưng có thể phá hủy chip ngay lập tức hoặc gây lỗi tiềm ẩn.",
        "example": {
          "zh": "我们的SMT生产线配备了完整的ESD防护措施，所有操作员都接受过静电防护培训。",
          "vi": "Dây chuyền SMT của chúng tôi trang bị đầy đủ biện pháp bảo vệ ESD, tất cả nhân viên vận hành đều được đào tạo về bảo vệ tĩnh điện."
        }
      },
      {
        "num": 7,
        "hanzi": "生产良率",
        "pinyin": "shēngchǎn liánglǜ",
        "vi": "tỷ lệ sản phẩm đạt trong sản xuất (yield rate)",
        "explanation": "Tỷ lệ sản phẩm đạt tiêu chuẩn trên tổng số sản xuất. Ngược với 不良率. Yield rate 99% = 不良率 1%. Yield rate cao = chi phí sản xuất thấp, ít lãng phí nguyên liệu. Với điện tử, yield rate tổng thể thường được tính theo từng công đoạn: SMT → PCBA test → lắp ráp → FCT → đóng gói.",
        "example": {
          "zh": "我们整条产线的生产良率是98.5%，其中SMT工序良率是99.2%，成品测试良率是99.8%。",
          "vi": "Tỷ lệ đạt của toàn dây chuyền là 98,5%, trong đó công đoạn SMT đạt 99,2%, kiểm tra thành phẩm đạt 99,8%."
        }
      },
      {
        "num": 8,
        "hanzi": "质量追溯",
        "pinyin": "zhìliàng zhuīsù",
        "vi": "truy xuất chất lượng (quality traceability)",
        "explanation": "Khả năng theo dõi lịch sử sản xuất của từng sản phẩm — từ lô linh kiện sử dụng, thời gian sản xuất, kết quả kiểm tra từng bước, đến nhân viên thực hiện. Quan trọng khi có vấn đề chất lượng — giúp xác định nguyên nhân gốc rễ và phạm vi ảnh hưởng nhanh chóng.",
        "example": {
          "zh": "我们给每台产品赋予唯一的序列号，可以追溯到具体的生产批次和检测记录，方便售后问题定位。",
          "vi": "Chúng tôi gán số serial duy nhất cho mỗi sản phẩm, có thể truy xuất đến lô sản xuất cụ thể và hồ sơ kiểm tra, thuận tiện xác định vấn đề dịch vụ sau bán."
        }
      },
      {
        "num": 9,
        "hanzi": "防错机制",
        "pinyin": "fáng cuò jīzhì",
        "vi": "cơ chế chống lỗi (poka-yoke)",
        "explanation": "Thiết kế quy trình hoặc thiết bị để ngăn người vận hành phạm lỗi — ví dụ: kết nối một chiều (不可逆插头), kiểm tra hình dạng tự động (profile check), đèn cảnh báo khi thiếu linh kiện. Giảm phụ thuộc vào sự chú ý của con người trong dây chuyền sản xuất.",
        "example": {
          "zh": "我们的生产线设有防错机制，自动检测装配顺序和部件方向，避免人为失误。",
          "vi": "Dây chuyền sản xuất của chúng tôi có cơ chế poka-yoke, tự động kiểm tra thứ tự lắp ráp và hướng linh kiện, tránh lỗi con người."
        }
      },
      {
        "num": 10,
        "hanzi": "客诉处理",
        "pinyin": "kè sù chǔlǐ",
        "vi": "xử lý khiếu nại khách hàng",
        "explanation": "Quy trình tiếp nhận, phân tích, xử lý và phản hồi khiếu nại từ khách hàng về chất lượng sản phẩm. Bao gồm: nhận mẫu lỗi, phân tích nguyên nhân gốc rễ (root cause analysis — 根因分析), hành động khắc phục (corrective action), và phản hồi 8D report. Thời gian phản hồi ban đầu thường yêu cầu trong 24–48 giờ.",
        "example": {
          "zh": "收到客诉后，我们承诺在24小时内给出初步响应，5个工作日内提供完整的8D报告。",
          "vi": "Sau khi nhận khiếu nại, chúng tôi cam kết phản hồi ban đầu trong 24 giờ, cung cấp báo cáo 8D đầy đủ trong 5 ngày làm việc."
        }
      }
    ],
    "dialogue": {
      "context": "Buyer VN nhận được phản ánh từ khách hàng Amazon về một số sản phẩm lỗi WiFi, đang làm việc với nhà máy để phân tích và xử lý.",
      "characters": [
        {
          "name": "品质总监林总 (Lín zǒng)",
          "role": "Giám đốc chất lượng nhà máy TQ"
        },
        {
          "name": "Anh Dũng",
          "role": "Quản lý chất lượng công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "Anh Dũng",
          "zh": "林总，我们在亚马逊上收到了一批客诉，有30多个客户反映产品WiFi信号不稳定，经常断线，这个问题需要我们一起分析。",
          "vi": "Giám đốc Lâm, chúng tôi nhận được một loạt khiếu nại trên Amazon, hơn 30 khách hàng phản ánh WiFi sản phẩm không ổn định, hay bị ngắt kết nối, vấn đề này chúng ta cần cùng phân tích."
        },
        {
          "speaker": "林总",
          "zh": "我们已经看到了这些反馈，我们内部也做了初步分析。这批产品是上个月出的那批，总共5000台，现在出现问题的大概是0.6%，也就是30台左右。",
          "vi": "Chúng tôi đã thấy những phản hồi này, nội bộ cũng đã phân tích sơ bộ. Lô sản phẩm này xuất tháng trước, tổng cộng 5000 cái, hiện số có vấn đề khoảng 0,6%, tức là khoảng 30 cái."
        },
        {
          "speaker": "Anh Dũng",
          "zh": "0.6%从数字上看不高，但在亚马逊上已经产生了很多差评，对我们的排名影响很大。根因是什么？",
          "vi": "0,6% về con số không cao, nhưng trên Amazon đã tạo ra nhiều review xấu, ảnh hưởng lớn đến thứ hạng của chúng tôi. Nguyên nhân gốc rễ là gì?"
        },
        {
          "speaker": "林总",
          "zh": "初步判断是WiFi模块的天线焊接问题，有部分产品天线和主板之间的焊点在运输过程中受到震动后接触不良。我们已经对库存产品进行了排查，确认大约200台有这个风险。",
          "vi": "Phán đoán ban đầu là vấn đề hàn ăng-ten module WiFi, một số sản phẩm điểm hàn giữa ăng-ten và mainboard tiếp xúc kém sau khi chịu rung động trong vận chuyển. Chúng tôi đã kiểm tra hàng tồn kho, xác nhận khoảng 200 cái có rủi ro này."
        },
        {
          "speaker": "Anh Dũng",
          "zh": "200台！那这200台我们怎么处理？已经发到客户手里的30台呢？",
          "vi": "200 cái! Vậy 200 cái này xử lý thế nào? 30 cái đã đến tay khách thì sao?"
        },
        {
          "speaker": "林总",
          "zh": "库存的200台我们今天就安排全部返工，加固焊点，明天可以完成。已经到客户手里的，我们建议您通过亚马逊客服联系这些客户，提供免费换新或者退款，我们这边提供替换品。",
          "vi": "200 cái tồn kho hôm nay chúng tôi sắp xếp làm lại toàn bộ, gia cố điểm hàn, ngày mai có thể hoàn thành. Phần đã đến tay khách, chúng tôi khuyến nghị anh liên hệ những khách hàng này qua dịch vụ khách hàng Amazon, đề xuất đổi mới miễn phí hoặc hoàn tiền, phía chúng tôi cung cấp hàng thay thế."
        },
        {
          "speaker": "Anh Dũng",
          "zh": "好，我来安排客服处理亚马逊那边。现在最重要的是：第一，这个问题是怎么发生的？第二，后续怎么防止？",
          "vi": "Tốt, tôi sắp xếp dịch vụ khách hàng xử lý phía Amazon. Quan trọng nhất bây giờ là: thứ nhất, vấn đề này xảy ra như thế nào? Thứ hai, sau này ngăn ngừa thế nào?"
        },
        {
          "speaker": "林总",
          "zh": "我们做了详细的根因分析。这批产品的天线焊接是新换了一个供应商的锡膏，锡膏配方不同，在我们原来的回流焊参数下焊接强度不够。现在我们已经恢复原来的锡膏供应商，同时调整了回流焊温度参数，问题应该不会再出现。",
          "vi": "Chúng tôi đã phân tích nguyên nhân gốc rễ chi tiết. Lô sản phẩm này đã đổi sang nhà cung cấp mới cho chất hàn thiếc, công thức hàn khác nhau, với thông số lò hàn cũ của chúng tôi độ bền hàn không đủ. Bây giờ chúng tôi đã khôi phục lại nhà cung cấp hàn thiếc cũ, đồng thời điều chỉnh thông số nhiệt độ lò hàn, vấn đề không tái diễn nữa."
        },
        {
          "speaker": "Anh Dũng",
          "zh": "好，我需要您提供一份完整的8D报告，说明根因、纠正措施和预防措施，我们需要向亚马逊品牌监控团队提交。",
          "vi": "Tốt, tôi cần anh cung cấp báo cáo 8D đầy đủ, ghi rõ nguyên nhân gốc rễ, hành động khắc phục và biện pháp phòng ngừa, chúng tôi cần nộp cho đội giám sát thương hiệu Amazon."
        },
        {
          "speaker": "林总",
          "zh": "明白，我们5个工作日内提供完整的8D报告，同时这批后续生产的产品，我们会加强天线焊点的AOI检测，100%检测不抽检。",
          "vi": "Hiểu, trong 5 ngày làm việc chúng tôi cung cấp báo cáo 8D đầy đủ, đồng thời lô sản xuất tiếp theo, chúng tôi sẽ tăng cường kiểm tra AOI điểm hàn ăng-ten, kiểm tra 100% không chỉ lấy mẫu."
        }
      ]
    },
    "notes": [
      {
        "title": "8D Report: công cụ xử lý khiếu nại chất lượng chuyên nghiệp",
        "body": "8D Report (Eight Disciplines) là báo cáo giải quyết vấn đề 8 bước: D1-Đội nhóm, D2-Mô tả vấn đề, D3-Biện pháp tạm thời, D4-Phân tích nguyên nhân gốc rễ, D5-Hành động khắc phục lâu dài, D6-Xác nhận hiệu quả, D7-Phòng ngừa tái diễn, D8-Ghi nhận đội nhóm. Amazon và các retailer lớn thường yêu cầu 8D khi có vấn đề chất lượng nghiêm trọng."
      },
      {
        "title": "Khi nào 0.6% return rate là vấn đề lớn",
        "body": "Về số tuyệt đối 0.6% nghe nhỏ, nhưng: 30 bad reviews trên Amazon = có thể kéo rating từ 4.5 xuống 3.8 sao = giảm 30–50% conversion rate = mất doanh thu hàng nghìn đô mỗi ngày. Trong điện tử, bất kỳ vấn đề hàng loạt nào cũng cần xử lý ngay."
      },
      {
        "title": "Thay đổi nguyên liệu: rủi ro tiềm ẩn",
        "body": "Thay đổi nhà cung cấp hàn thiếc là ví dụ điển hình của \"process change without proper validation\" — thay đổi quy trình không qua kiểm định đầy đủ. Nhà máy tốt có \"Engineering Change Notice\" (ECN) quy trình để đảm bảo mọi thay đổi đều được kiểm tra trước khi áp dụng vào sản xuất."
      },
      {
        "title": "AOI và 100% inspection",
        "body": "Kiểm tra ngẫu nhiên (sampling) thường đủ cho hàng tiêu dùng thông thường. Nhưng khi có vấn đề đã xảy ra, chuyển sang 100% inspection là biện pháp tạm thời cần thiết để đảm bảo không có thêm sản phẩm lỗi xuất đi. AOI tự động hóa giúp 100% inspection khả thi về chi phí."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Mục đích của burn-in test (老化测试) là gì?",
          "options": {
            "A": "Kiểm tra thiết kế sản phẩm",
            "B": "Phát hiện và loại bỏ sản phẩm lỗi tiềm ẩn trước khi giao khách",
            "C": "Tăng tốc độ sản xuất",
            "D": "Kiểm tra đóng gói"
          }
        },
        {
          "num": 2,
          "q": "Tỷ lệ lỗi 300 PPM có nghĩa là gì?",
          "options": {
            "A": "300% lỗi",
            "B": "300 sản phẩm lỗi trên 1 triệu",
            "C": "30 sản phẩm lỗi trên 1000",
            "D": "3% lỗi"
          }
        },
        {
          "num": 3,
          "q": "AOI (Automated Optical Inspection) dùng để làm gì?",
          "options": {
            "A": "Kiểm tra chất lượng âm thanh",
            "B": "Tự động kiểm tra lỗi hàn và lắp ráp bằng hình ảnh quang học",
            "C": "Kiểm tra IP rating",
            "D": "Kiểm tra tính năng WiFi"
          }
        },
        {
          "num": 4,
          "q": "8D Report được dùng trong tình huống nào?",
          "options": {
            "A": "Báo cáo tài chính hàng quý",
            "B": "Giải quyết vấn đề chất lượng — xác định nguyên nhân gốc rễ và hành động khắc phục",
            "C": "Kế hoạch sản xuất hàng năm",
            "D": "Đăng ký chứng nhận FCC"
          }
        },
        {
          "num": 5,
          "q": "Tại sao traceability (quality traceability) quan trọng khi có vấn đề chất lượng?",
          "options": {
            "A": "Vì yêu cầu pháp lý",
            "B": "Giúp xác định nhanh nguyên nhân và phạm vi ảnh hưởng để xử lý đúng mục tiêu",
            "C": "Để tăng giá sản phẩm",
            "D": "Không cần thiết"
          }
        },
        {
          "num": 6,
          "q": "ESD (tĩnh điện) gây hại như thế nào cho linh kiện điện tử?",
          "options": {
            "A": "Chỉ gây bẩn bề mặt",
            "B": "Có thể phá hủy chip ngay lập tức hoặc gây lỗi tiềm ẩn không nhìn thấy được",
            "C": "Làm màu sắc thay đổi",
            "D": "Làm nặng thêm"
          }
        },
        {
          "num": 7,
          "q": "Khi xảy ra vấn đề chất lượng hàng loạt, nên chuyển từ kiểm tra ngẫu nhiên sang hình thức nào?",
          "options": {
            "A": "Bỏ kiểm tra hoàn toàn",
            "B": "Kiểm tra 100% (full inspection)",
            "C": "Chỉ kiểm tra 50%",
            "D": "Tăng AQL lên 4.0"
          }
        },
        {
          "num": 8,
          "q": "\"Root cause analysis\" (根因分析) có nghĩa là gì?",
          "options": {
            "A": "Kiểm tra toàn bộ dây chuyền",
            "B": "Xác định nguyên nhân sâu xa thực sự gây ra vấn đề, không chỉ hiện tượng bề mặt",
            "C": "Đánh giá nhà cung cấp",
            "D": "Kiểm tra bảo hành"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "0.6% return rate là con số nhỏ không cần xử lý khẩn cấp trên Amazon."
        },
        {
          "num": 10,
          "q": "Thay đổi nhà cung cấp hàn thiếc mà không qua kiểm định là ví dụ về \"process change without validation\"."
        },
        {
          "num": 11,
          "q": "Burn-in test phát hiện lỗi tiềm ẩn trước khi sản phẩm đến tay khách hàng."
        },
        {
          "num": 12,
          "q": "Tỷ lệ lỗi 300 PPM cao hơn 0.5% defect rate."
        },
        {
          "num": 13,
          "q": "8D Report cần hoàn thành trong 5 ngày làm việc sau khi nhận khiếu nại."
        },
        {
          "num": 14,
          "q": "Serial number trên từng sản phẩm không có tác dụng gì khi xử lý vấn đề chất lượng sau bán."
        }
      ],
      "fillblank": {
        "wordbank": [
          "可靠性测试",
          "成品测试",
          "不良率",
          "质量追溯",
          "防错机制",
          "客诉处理"
        ],
        "items": [
          {
            "num": 15,
            "q": "每台产品100%通过____才能贴合格标签，不允许抽检放行。"
          },
          {
            "num": 16,
            "q": "我们的生产____控制在0.3%以内，出货前还会做____和老化测试。"
          },
          {
            "num": 17,
            "q": "通过序列号的____，我们可以快速定位问题批次，缩短____响应时间。"
          },
          {
            "num": 18,
            "q": "生产线上的____可以自动检测装配错误，减少人为失误导致的____。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 19,
          "q": "收到客诉后，我们24小时内提供初步响应，5个工作日内提供完整8D报告，说明根因和纠正措施。"
        },
        {
          "num": 20,
          "q": "我们的生产良率是98.5%，不良率控制在1.5%以内，每台出货产品都有唯一序列号支持质量追溯。"
        },
        {
          "num": 21,
          "q": "出货前所有产品经过100%成品测试和24小时老化测试，确保WiFi、蓝牙、传感器全部功能正常。"
        },
        {
          "num": 22,
          "q": "AOI光学检测可以自动发现焊接缺陷，比人工检查更快更准确，检测覆盖率达到98%以上。"
        },
        {
          "num": 23,
          "q": "换了新的锡膏供应商后出现了焊接问题，这是因为没有经过充分的工艺验证，以后所有供应商变更都必须先做小批量验证。"
        }
      ],
      "vi2zh": [
        {
          "num": 24,
          "q": "Chúng tôi nhận được khiếu nại từ khách hàng Amazon về vấn đề kết nối WiFi không ổn định, cần phân tích nguyên nhân gốc rễ ngay."
        },
        {
          "num": 25,
          "q": "Tỷ lệ lỗi của lô này là bao nhiêu? Bao nhiêu sản phẩm cần xử lý?"
        },
        {
          "num": 26,
          "q": "Vui lòng cung cấp báo cáo 8D trong vòng 5 ngày làm việc, bao gồm nguyên nhân gốc rễ và biện pháp khắc phục."
        },
        {
          "num": 27,
          "q": "Sau khi làm lại 200 cái tồn kho, cần 100% kiểm tra chức năng trước khi xuất hàng."
        },
        {
          "num": 28,
          "q": "Mỗi sản phẩm có serial number riêng, giúp truy xuất lô sản xuất và hồ sơ kiểm tra khi cần."
        },
        {
          "num": 29,
          "q": "Burn-in test 24 giờ giúp phát hiện lỗi tiềm ẩn, đặc biệt quan trọng với sản phẩm điện tử."
        },
        {
          "num": 30,
          "q": "Mọi thay đổi nhà cung cấp linh kiện hoặc vật liệu cần qua quy trình kiểm định trước khi áp dụng vào sản xuất đại trà."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": false,
        "10": true,
        "11": true,
        "12": false,
        "13": true,
        "14": false
      },
      "fillblank": {
        "15": "成品测试",
        "16": [
          "不良率",
          "可靠性测试"
        ],
        "17": [
          "质量追溯",
          "客诉处理"
        ],
        "18": [
          "防错机制",
          "不良率"
        ]
      },
      "zh2vi": {
        "19": "Sau khi nhận khiếu nại, chúng tôi phản hồi ban đầu trong 24 giờ, cung cấp báo cáo 8D đầy đủ trong 5 ngày làm việc, nêu rõ nguyên nhân gốc rễ và hành động khắc phục.",
        "20": "Tỷ lệ đạt sản xuất của chúng tôi là 98,5%, tỷ lệ lỗi kiểm soát dưới 1,5%, mỗi sản phẩm xuất hàng có serial number duy nhất hỗ trợ truy xuất chất lượng.",
        "21": "Trước khi xuất hàng, tất cả sản phẩm qua kiểm tra thành phẩm 100% và burn-in 24 giờ, đảm bảo WiFi, Bluetooth, cảm biến tất cả chức năng bình thường.",
        "22": "Kiểm tra quang học AOI có thể tự động phát hiện lỗi hàn, nhanh và chính xác hơn kiểm tra tay, độ phủ kiểm tra đạt 98% trở lên.",
        "23": "Sau khi thay nhà cung cấp hàn thiếc mới xuất hiện vấn đề hàn, đây là do không qua kiểm định quy trình đầy đủ, sau này mọi thay đổi nhà cung cấp đều phải kiểm định lô nhỏ trước."
      },
      "vi2zh": {
        "24": "我们收到亚马逊客户关于WiFi连接不稳定的投诉，需要立即分析根本原因。",
        "25": "这批产品的不良率是多少？有多少产品需要处理？",
        "26": "请在5个工作日内提供8D报告，包括根因分析和纠正措施。",
        "27": "返工完200台库存后，出货前需要100%功能检测。",
        "28": "每台产品有独立序列号，便于追溯生产批次和检测记录。",
        "29": "24小时老化测试有助于发现潜在缺陷，对电子产品尤其重要。",
        "30": "任何元器件或材料供应商的变更都需要经过验证流程，才能用于大批量生产。"
      }
    }
  },
  {
    "num": 25,
    "title": "PHÁT TRIỂN SẢN PHẨM ODM ĐIỆN TỬ",
    "date": "21/6",
    "phase": 3,
    "vocab": [
      {
        "num": 1,
        "hanzi": "需求规格书",
        "pinyin": "xūqiú guīgé shū",
        "vi": "tài liệu yêu cầu sản phẩm (PRD/MRD)",
        "explanation": "Product Requirements Document — tài liệu mô tả toàn bộ yêu cầu của sản phẩm từ góc độ người dùng và kinh doanh: chức năng cần có, performance targets, giới hạn ngân sách, timeline. Buyer cần chuẩn bị PRD trước khi tiếp cận nhà máy ODM để đảm bảo hai bên cùng hiểu mục tiêu.",
        "example": {
          "zh": "在正式开发之前，请先提供需求规格书，我们根据这个文件评估技术可行性和开发成本。",
          "vi": "Trước khi phát triển chính thức, vui lòng cung cấp PRD trước, chúng tôi căn cứ tài liệu này đánh giá tính khả thi kỹ thuật và chi phí phát triển."
        }
      },
      {
        "num": 2,
        "hanzi": "技术可行性",
        "pinyin": "jìshù kěxíng xìng",
        "vi": "tính khả thi kỹ thuật",
        "explanation": "Đánh giá xem yêu cầu kỹ thuật của sản phẩm có thể thực hiện được không với công nghệ hiện tại và trong ngân sách đề xuất. Nhà máy ODM thường mất 1–2 tuần để đánh giá feasibility và đưa ra báo giá phát triển.",
        "example": {
          "zh": "我们对您的需求做了技术可行性评估，大部分功能可以实现，但有一个功能在目前成本范围内技术上有挑战。",
          "vi": "Chúng tôi đã đánh giá tính khả thi kỹ thuật cho yêu cầu của anh, hầu hết chức năng có thể thực hiện, nhưng có một chức năng có thách thức kỹ thuật trong phạm vi chi phí hiện tại."
        }
      },
      {
        "num": 3,
        "hanzi": "原型机 (样机)",
        "pinyin": "yuántáng jī (yàng jī)",
        "vi": "máy mẫu / prototype",
        "explanation": "Sản phẩm mẫu đầu tiên được chế tạo để kiểm tra thiết kế và chức năng — trước khi làm khuôn chính thức và sản xuất đại trà. Prototype không cần hoàn hảo về ngoại quan nhưng phải chứng minh tính năng hoạt động. Thường mất 4–8 tuần để có prototype đầu tiên.",
        "example": {
          "zh": "原型机已经做好了，主要功能都正常，外观还需要一些调整，我们下周可以给您演示。",
          "vi": "Máy mẫu đã làm xong, các chức năng chính đều bình thường, ngoại quan còn cần một số điều chỉnh, tuần tới chúng tôi có thể demo cho anh."
        }
      },
      {
        "num": 4,
        "hanzi": "EVT/DVT/PVT",
        "pinyin": "EVT/DVT/PVT",
        "vi": "các giai đoạn phát triển phần cứng",
        "explanation": "Ba giai đoạn phát triển phần cứng tiêu chuẩn: EVT (Engineering Validation Test — kiểm tra kỹ thuật), DVT (Design Validation Test — kiểm tra thiết kế hoàn chỉnh), PVT (Production Validation Test — kiểm tra sản xuất). Mỗi giai đoạn giải quyết vấn đề từ giai đoạn trước. Từ EVT đến PVT thường mất 4–9 tháng.",
        "example": {
          "zh": "目前我们的产品已经通过了DVT阶段，正在进行PVT小批量试产，发现的问题都已经修复。",
          "vi": "Hiện sản phẩm của chúng tôi đã qua giai đoạn DVT, đang thực hiện PVT sản xuất thử lô nhỏ, các vấn đề phát hiện đều đã khắc phục."
        }
      },
      {
        "num": 5,
        "hanzi": "开发费用",
        "pinyin": "kāifā fèiyòng",
        "vi": "chi phí phát triển (NRE fee)",
        "explanation": "Non-Recurring Engineering fee — khoản phí một lần trả cho nhà máy ODM để bù đắp chi phí kỹ sư thiết kế, prototype, và khuôn. Thường từ 5.000 đến 100.000+ USD tùy độ phức tạp. Khác với giá sản xuất đơn vị — NRE trả một lần, sau đó chỉ trả theo số lượng.",
        "example": {
          "zh": "这款产品的开发费用（NRE）是15000美元，包括原型机、模具和认证样品的费用，不含量产费用。",
          "vi": "Phí phát triển (NRE) sản phẩm này là 15.000 USD, bao gồm chi phí máy mẫu, khuôn và mẫu chứng nhận, không bao gồm chi phí sản xuất đại trà."
        }
      },
      {
        "num": 6,
        "hanzi": "固件开发",
        "pinyin": "gùjiàn kāifā",
        "vi": "phát triển firmware",
        "explanation": "Lập trình phần mềm nhúng (embedded software) chạy trực tiếp trên phần cứng — điều khiển tất cả chức năng của thiết bị IoT. Firmware development là một phần quan trọng của ODM điện tử. Cần thỏa thuận rõ: ai sở hữu source code, có thể modify không, update OTA (over-the-air) như thế nào.",
        "example": {
          "zh": "固件开发由我们工厂负责，但源代码所有权归客户，我们可以在合同里明确这一点。",
          "vi": "Phát triển firmware do nhà máy chúng tôi phụ trách, nhưng quyền sở hữu source code thuộc về khách hàng, chúng tôi có thể ghi rõ điều này trong hợp đồng."
        }
      },
      {
        "num": 7,
        "hanzi": "APP对接",
        "pinyin": "APP duìjiē",
        "vi": "tích hợp ứng dụng di động",
        "explanation": "Kết nối sản phẩm IoT với ứng dụng smartphone để người dùng điều khiển từ xa. Yêu cầu: SDK, API, và thống nhất giao thức truyền thông (MQTT, CoAP, hoặc custom protocol). Tuya (涂鸦) và Matter/Thread đang là hai ecosystem phổ biến nhất cho sản phẩm nhà thông minh.",
        "example": {
          "zh": "我们的产品可以接入Tuya平台，您的APP可以直接使用Tuya SDK，开发成本低，时间快。",
          "vi": "Sản phẩm của chúng tôi có thể tích hợp nền tảng Tuya, APP của anh có thể dùng trực tiếp Tuya SDK, chi phí phát triển thấp, thời gian nhanh hơn."
        }
      },
      {
        "num": 8,
        "hanzi": "量产切换",
        "pinyin": "liàngchǎn qiēhuàn",
        "vi": "chuyển sang sản xuất đại trà",
        "explanation": "Giai đoạn chuyển từ PVT (sản xuất thử) sang mass production thực sự. Đây là thời điểm quan trọng — tất cả vấn đề kỹ thuật phải được giải quyết, dây chuyền phải được kiểm tra, và tài liệu sản xuất phải hoàn chỉnh. Chuyển sang đại trà quá sớm = vấn đề chất lượng hàng loạt.",
        "example": {
          "zh": "在确认PVT没有严重问题之后，我们才会正式切换到量产模式，这个决策需要双方共同确认。",
          "vi": "Sau khi xác nhận PVT không có vấn đề nghiêm trọng, chúng tôi mới chính thức chuyển sang chế độ sản xuất đại trà, quyết định này cần hai bên cùng xác nhận."
        }
      },
      {
        "num": 9,
        "hanzi": "产品路线图",
        "pinyin": "chǎnpǐn lùxiàn tú",
        "vi": "product roadmap",
        "explanation": "Kế hoạch dài hạn cho việc phát triển và cải tiến sản phẩm — phiên bản tiếp theo sẽ có tính năng gì, timeline ra mắt từng version. Khi làm ODM, chia sẻ roadmap với nhà máy giúp họ lên kế hoạch năng lực sản xuất và phát triển linh kiện phù hợp.",
        "example": {
          "zh": "我们的产品路线图是：今年Q4出第一代，明年Q2推出升级版，增加Matter协议支持，请工厂提前了解。",
          "vi": "Roadmap sản phẩm của chúng tôi: Q4 năm nay ra thế hệ đầu tiên, Q2 năm sau ra phiên bản nâng cấp bổ sung hỗ trợ giao thức Matter, nhà máy cần biết trước."
        }
      },
      {
        "num": 10,
        "hanzi": "认证样品",
        "pinyin": "rènzhèng yàngpǐn",
        "vi": "mẫu chứng nhận (certification sample)",
        "explanation": "Mẫu sản phẩm được sản xuất đặc biệt để gửi đi làm chứng nhận FCC/CE/ETL. Phải giống hệt sản phẩm cuối cùng về phần cứng và firmware. Thường cần 3–5 mẫu cho mỗi loại chứng nhận. Chứng nhận bị từ chối vì mẫu không đại diện sản phẩm thực = mất thêm 2–3 tháng.",
        "example": {
          "zh": "我们需要5个认证样品送FCC认证，这些样品必须和量产版本完全一致，硬件和固件都不能有差异。",
          "vi": "Chúng tôi cần 5 mẫu chứng nhận gửi FCC certification, những mẫu này phải giống hoàn toàn phiên bản đại trà, phần cứng và firmware không được có sự khác biệt."
        }
      }
    ],
    "dialogue": {
      "context": "Buyer VN đang họp review tiến độ phát triển sản phẩm IoT với nhà máy ODM TQ, sau 3 tháng phát triển.",
      "characters": [
        {
          "name": "项目经理周工 (Zhōu gōng)",
          "role": "Quản lý dự án nhà máy ODM"
        },
        {
          "name": "Chị Hoa",
          "role": "Giám đốc sản phẩm công ty VN"
        }
      ],
      "lines": [
        {
          "speaker": "Chị Hoa",
          "zh": "周工，我们来做一个季度进度汇报，看看产品开发到哪个阶段了。",
          "vi": "Kỹ sư Chu, chúng ta làm báo cáo tiến độ theo quý, xem phát triển sản phẩm đang ở giai đoạn nào rồi."
        },
        {
          "speaker": "周工",
          "zh": "好的，我来汇报一下。按照计划，我们上个月完成了EVT阶段，所有主要功能都已经验证通过。这周开始进入DVT阶段，主要解决EVT中发现的一些结构和外观问题。",
          "vi": "Tốt, tôi báo cáo. Theo kế hoạch, tháng trước chúng tôi hoàn thành giai đoạn EVT, tất cả chức năng chính đã được xác minh. Tuần này bắt đầu vào giai đoạn DVT, chủ yếu giải quyết một số vấn đề cấu trúc và ngoại quan phát hiện trong EVT."
        },
        {
          "speaker": "Chị Hoa",
          "zh": "EVT发现了哪些问题？都解决了吗？",
          "vi": "EVT phát hiện vấn đề gì? Đều giải quyết chưa?"
        },
        {
          "speaker": "周工",
          "zh": "主要有三个问题：第一，WiFi天线位置导致信号弱，我们调整了天线位置，信号强度提升了15dBm；第二，按键手感不好，更换了按键型号解决了；第三，散热问题在高负载下处理器温度过高，我们增加了导热贴，问题解决了。",
          "vi": "Chủ yếu có ba vấn đề: thứ nhất, vị trí ăng-ten WiFi gây tín hiệu yếu, chúng tôi điều chỉnh vị trí ăng-ten, cường độ tín hiệu tăng 15dBm; thứ hai, cảm giác nút bấm không tốt, thay loại nút bấm khác giải quyết được; thứ ba, vấn đề tản nhiệt khi tải cao nhiệt độ bộ xử lý quá cao, chúng tôi thêm miếng dẫn nhiệt, vấn đề giải quyết rồi."
        },
        {
          "speaker": "Chị Hoa",
          "zh": "很好，这三个都是关键问题，解决了很重要。现在DVT的时间节点怎么安排？",
          "vi": "Tốt, ba điều này đều là vấn đề quan trọng, giải quyết được rất quan trọng. Bây giờ timeline DVT sắp xếp thế nào?"
        },
        {
          "speaker": "周工",
          "zh": "DVT预计需要4周，主要验证结构稳定性、防水测试和EMC测试。DVT通过后进入PVT小批量试产，预计再需要3周。如果PVT没有严重问题，可以在5月底切换到量产。",
          "vi": "DVT dự kiến cần 4 tuần, chủ yếu xác minh độ bền cấu trúc, kiểm tra chống nước và kiểm tra EMC. Sau khi DVT qua sẽ vào PVT sản xuất thử lô nhỏ, dự kiến thêm 3 tuần nữa. Nếu PVT không có vấn đề nghiêm trọng, có thể chuyển sang sản xuất đại trà cuối tháng 5."
        },
        {
          "speaker": "Chị Hoa",
          "zh": "5月底量产，那FCC认证来得及吗？我们需要在6月初进仓，赶7月的销售。",
          "vi": "Cuối tháng 5 sản xuất đại trà, FCC certification có kịp không? Chúng tôi cần nhập kho đầu tháng 6 để kịp bán tháng 7."
        },
        {
          "speaker": "周工",
          "zh": "我们在DVT阶段就会同步提交认证样品给FCC认证机构，认证和DVT同步进行。如果顺利，认证可以在5月底完成，时间上应该来得及。但这需要DVT期间没有重大的硬件改动，如果有改动可能需要重新提交认证。",
          "vi": "Chúng tôi sẽ gửi mẫu chứng nhận đến cơ quan FCC ngay trong giai đoạn DVT, chứng nhận và DVT tiến hành đồng thời. Nếu thuận lợi, chứng nhận có thể hoàn thành cuối tháng 5, về thời gian nên kịp. Nhưng điều này cần trong DVT không có thay đổi phần cứng lớn, nếu có thay đổi có thể cần nộp lại chứng nhận."
        },
        {
          "speaker": "Chị Hoa",
          "zh": "明白了。APP对接这边进展怎么样？",
          "vi": "Hiểu rồi. Tích hợp APP phía này tiến độ thế nào?"
        },
        {
          "speaker": "周工",
          "zh": "APP我们用的是Tuya平台，SDK集成已经完成，基本功能都好了，包括远程控制、定时、场景联动。还有一个OTA固件升级功能还在测试中，预计下周完成。",
          "vi": "APP chúng tôi dùng nền tảng Tuya, tích hợp SDK đã hoàn thành, các chức năng cơ bản đều ổn rồi, bao gồm điều khiển từ xa, hẹn giờ, liên kết cảnh. Còn một chức năng OTA cập nhật firmware đang trong quá trình kiểm tra, dự kiến tuần tới hoàn thành."
        },
        {
          "speaker": "Chị Hoa",
          "zh": "好。最后，认证样品什么时候可以提供给我们？我们需要自己审查一下，确认和最终产品一致。",
          "vi": "Tốt. Cuối cùng, mẫu chứng nhận khi nào có thể cung cấp cho chúng tôi? Chúng tôi cần tự kiểm tra, xác nhận giống với sản phẩm cuối cùng."
        },
        {
          "speaker": "周工",
          "zh": "DVT完成后我们提供5台认证样品给您确认，DVT预计4周后完成，也就是说大概4周后您可以收到认证样品。",
          "vi": "Sau khi DVT hoàn thành chúng tôi cung cấp 5 mẫu chứng nhận cho chị xác nhận, DVT dự kiến hoàn thành sau 4 tuần, tức là khoảng 4 tuần nữa chị có thể nhận được mẫu chứng nhận."
        }
      ]
    },
    "notes": [
      {
        "title": "EVT → DVT → PVT: không nên bỏ qua bước nào",
        "body": "Nhiều startup và người mới làm ODM muốn rút ngắn quy trình để ra hàng nhanh. Bỏ DVT hoặc PVT thường dẫn đến vấn đề chất lượng hàng loạt sau khi sản xuất đại trà. Chi phí giải quyết vấn đề sau sản xuất đại trà cao gấp 10–100 lần so với giải quyết trong giai đoạn development."
      },
      {
        "title": "Firmware ownership: điều khoản cực quan trọng",
        "body": "Ai sở hữu source code firmware? Nếu không ghi rõ trong hợp đồng, nhà máy mặc định giữ source code. Nếu sau này muốn chuyển nhà máy sản xuất hoặc tự làm firmware update, sẽ không thể làm được. Luôn đàm phán để buyer sở hữu source code — ngay cả khi phải trả thêm tiền."
      },
      {
        "title": "Tuya và Matter: hai con đường cho IoT",
        "body": "Tuya platform: nhanh ra thị trường, SDK sẵn có, APP template có thể dùng ngay. Nhược điểm: phụ thuộc vào Tuya cloud, data chạy qua server Tuya. Matter/Thread: tiêu chuẩn mở, local control, interoperability với Apple Home, Google Home, Amazon Alexa. Xu hướng 2024-2025 nghiêng về Matter cho sản phẩm cao cấp."
      },
      {
        "title": "OTA update: tính năng quan trọng nhưng phức tạp",
        "body": "Over-the-Air firmware update cho phép cải thiện sản phẩm sau khi đã bán — fix bugs, thêm tính năng. Quan trọng cho sản phẩm IoT dài hạn. Cần thiết kế kỹ: fallback mechanism (nếu update thất bại không brick thiết bị), version management, rollout strategy."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Ba giai đoạn phát triển phần cứng theo thứ tự đúng là gì?",
          "options": {
            "A": "PVT → DVT → EVT",
            "B": "EVT → DVT → PVT",
            "C": "DVT → EVT → PVT",
            "D": "Chỉ cần một giai đoạn"
          }
        },
        {
          "num": 2,
          "q": "NRE fee trong ODM điện tử là gì?",
          "options": {
            "A": "Phí sản xuất từng sản phẩm",
            "B": "Phí phát triển trả một lần cho công kỹ sư thiết kế và prototype",
            "C": "Phí chứng nhận",
            "D": "Phí vận chuyển"
          }
        },
        {
          "num": 3,
          "q": "Tại sao ownership của firmware source code quan trọng?",
          "options": {
            "A": "Không quan trọng",
            "B": "Nếu nhà máy giữ source code, buyer không thể chuyển nhà máy hay tự update firmware",
            "C": "Vì yêu cầu pháp lý",
            "D": "Vì Amazon yêu cầu"
          }
        },
        {
          "num": 4,
          "q": "OTA (Over-the-Air) update là gì?",
          "options": {
            "A": "Vận chuyển hàng không",
            "B": "Cập nhật firmware không dây sau khi sản phẩm đã bán",
            "C": "Kiểm tra chứng nhận trực tuyến",
            "D": "Đặt hàng qua internet"
          }
        },
        {
          "num": 5,
          "q": "Nền tảng Tuya được dùng phổ biến cho mục đích gì?",
          "options": {
            "A": "Quản lý kho hàng",
            "B": "Phát triển sản phẩm nhà thông minh IoT với SDK và APP sẵn có",
            "C": "Quản lý logistics",
            "D": "Thiết kế bao bì"
          }
        },
        {
          "num": 6,
          "q": "Mẫu chứng nhận (认证样品) phải như thế nào so với sản phẩm cuối cùng?",
          "options": {
            "A": "Có thể khác một chút về firmware",
            "B": "Phải giống hoàn toàn về phần cứng và firmware",
            "C": "Chỉ cần giống về ngoại quan",
            "D": "Không cần giống"
          }
        },
        {
          "num": 7,
          "q": "Giai đoạn nào trong quá trình phát triển phần cứng tốn kém nhất nếu phát hiện vấn đề?",
          "options": {
            "A": "EVT",
            "B": "DVT",
            "C": "PVT",
            "D": "Sau khi sản xuất đại trà"
          }
        },
        {
          "num": 8,
          "q": "Tại sao nên bắt đầu FCC certification song song với giai đoạn DVT?",
          "options": {
            "A": "Vì FCC yêu cầu",
            "B": "Để tiết kiệm thời gian — FCC mất 6–8 tuần, song song với DVT tiết kiệm được thời gian đó",
            "C": "Vì giá rẻ hơn",
            "D": "Vì Amazon yêu cầu"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Bỏ qua giai đoạn DVT để ra hàng nhanh hơn là quyết định tốt cho dự án OEM/ODM."
        },
        {
          "num": 10,
          "q": "Nếu hợp đồng không ghi rõ, nhà máy thường mặc định giữ source code firmware."
        },
        {
          "num": 11,
          "q": "OTA update cho phép cải thiện sản phẩm IoT sau khi đã bán mà không cần thu hồi."
        },
        {
          "num": 12,
          "q": "EVT sample có thể khác PVT sample về hardware mà không ảnh hưởng gì đến FCC certification đã nộp."
        },
        {
          "num": 13,
          "q": "Matter/Thread là tiêu chuẩn mở giúp sản phẩm IoT tương thích với Apple Home, Google Home và Amazon Alexa."
        },
        {
          "num": 14,
          "q": "Chuyển sang sản xuất đại trà trước khi PVT hoàn thành là thực hành an toàn nếu schedule bị trễ."
        }
      ],
      "fillblank": {
        "wordbank": [
          "需求规格书",
          "原型机",
          "开发费用",
          "固件开发",
          "量产切换",
          "认证样品"
        ],
        "items": [
          {
            "num": 15,
            "q": "开发前请先提供完整的____，我们根据这个评估技术可行性和____（NRE）。"
          },
          {
            "num": 16,
            "q": "____已经做好了，主要功能验证通过，外观还需要调整，下周可以演示。"
          },
          {
            "num": 17,
            "q": "____的源代码所有权要在合同里写清楚，这对您未来的产品独立性很重要。"
          },
          {
            "num": 18,
            "q": "PVT通过、所有问题修复之后，我们才会正式决定____的时间点。"
          },
          {
            "num": 19,
            "q": "FCC认证需要____，这些样品必须和量产版本完全一致。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 20,
          "q": "目前产品处于DVT阶段，主要验证结构稳定性和防水性能，预计4周后完成，然后进入PVT试产。"
        },
        {
          "num": 21,
          "q": "固件开发由我们负责，但源代码归您所有，您可以随时要求我们提供完整的源代码备份。"
        },
        {
          "num": 22,
          "q": "NRE费用是20000美元，包含原型机开发、模具和认证样品，后续量产按照单价计算，不再收NRE。"
        },
        {
          "num": 23,
          "q": "APP采用Tuya平台，SDK集成已完成，包括远程控制、定时、场景联动和OTA固件升级功能。"
        },
        {
          "num": 24,
          "q": "建议在DVT阶段同步提交FCC认证，这样可以节省6到8周时间，确保产品准时上市。"
        }
      ],
      "vi2zh": [
        {
          "num": 25,
          "q": "Phát triển sản phẩm hiện đang ở giai đoạn nào? EVT đã hoàn thành chưa? Phát hiện vấn đề gì?"
        },
        {
          "num": 26,
          "q": "Phí phát triển (NRE) bao gồm những gì? Chúng tôi cần hiểu rõ trước khi ký hợp đồng."
        },
        {
          "num": 27,
          "q": "Source code firmware phải thuộc sở hữu của chúng tôi — điều này cần ghi rõ trong hợp đồng."
        },
        {
          "num": 28,
          "q": "Mẫu chứng nhận FCC phải giống hoàn toàn sản phẩm đại trà về cả phần cứng và firmware."
        },
        {
          "num": 29,
          "q": "Sản phẩm hỗ trợ giao thức Matter không? Đây là yêu cầu quan trọng để tương thích với Apple Home."
        },
        {
          "num": 30,
          "q": "Khi nào có thể chuyển sang sản xuất đại trà? Chúng tôi cần nhập kho đầu tháng 6."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "B",
        "6": "B",
        "7": "D",
        "8": "B"
      },
      "tf": {
        "9": false,
        "10": true,
        "11": true,
        "12": false,
        "13": true,
        "14": false
      },
      "fillblank": {
        "15": [
          "需求规格书",
          "开发费用"
        ],
        "16": "原型机",
        "17": "固件开发",
        "18": "量产切换",
        "19": "认证样品"
      },
      "zh2vi": {
        "20": "Hiện sản phẩm đang ở giai đoạn DVT, chủ yếu xác minh độ bền cấu trúc và chống nước, dự kiến 4 tuần nữa hoàn thành, sau đó vào PVT sản xuất thử.",
        "21": "Firmware do chúng tôi phụ trách phát triển, nhưng source code thuộc về anh, anh có thể yêu cầu chúng tôi cung cấp backup source code đầy đủ bất cứ lúc nào.",
        "22": "Phí NRE là 20.000 USD, bao gồm phát triển máy mẫu, khuôn và mẫu chứng nhận, sau đó sản xuất đại trà tính theo đơn giá, không tính NRE thêm.",
        "23": "APP dùng nền tảng Tuya, tích hợp SDK đã hoàn thành, bao gồm điều khiển từ xa, hẹn giờ, liên kết cảnh và chức năng OTA cập nhật firmware.",
        "24": "Khuyến nghị gửi FCC certification đồng thời trong giai đoạn DVT, như vậy có thể tiết kiệm 6–8 tuần, đảm bảo sản phẩm ra mắt đúng hạn."
      },
      "vi2zh": {
        "25": "产品开发目前在哪个阶段？EVT完成了吗？发现了什么问题？",
        "26": "开发费用（NRE）包括哪些内容？我们需要在签合同前完全了解清楚。",
        "27": "固件源代码必须归我们所有——这一点需要在合同里明确写清楚。",
        "28": "FCC认证样品必须和量产版本在硬件和固件上完全一致。",
        "29": "产品支持Matter协议吗？这是与Apple Home兼容的重要要求。",
        "30": "什么时候可以切换到量产？我们需要在6月初完成入仓。"
      }
    }
  },
  {
    "num": 26,
    "title": "HỘI THOẠI TỔNG HỢP: HỘI CHỢ ĐIỆN TỬ",
    "date": "22/6",
    "phase": 3,
    "vocab": [],
    "dialogue": {
      "context": "Canton Fair tháng 4. Anh Phong (buyer VN) và phiên dịch đang tham quan gian hàng của một nhà máy điện tử TQ chuyên sản xuất sản phẩm nhà thông minh (smart home). Đây là buổi đàm phán lần đầu.",
      "characters": [
        {
          "name": "技术销售陈工 (Chén gōng)",
          "role": "Kỹ sư kinh doanh nhà máy TQ"
        },
        {
          "name": "Anh Phong",
          "role": "Buyer VN"
        }
      ],
      "lines": [
        {
          "speaker": "Chén gōng",
          "zh": "您好，欢迎来到我们的展位，我们专门生产智能家居产品，请问您对哪类产品感兴趣？",
          "vi": "Xin chào, chào mừng đến gian hàng của chúng tôi, chúng tôi chuyên sản xuất sản phẩm nhà thông minh, anh quan tâm đến loại sản phẩm nào?"
        },
        {
          "speaker": "Anh Phong",
          "zh": "你好，我们想找一款智能插座，要有WiFi功能，支持远程控制，目标是在亚马逊美国站销售。你们有这类产品吗？",
          "vi": "Chào, chúng tôi muốn tìm ổ cắm thông minh, cần có WiFi, hỗ trợ điều khiển từ xa, mục tiêu bán trên Amazon Mỹ. Anh có loại này không?"
        },
        {
          "speaker": "Chén gōng",
          "zh": "有，我们这款智能插座完全符合您的需求，WiFi 2.4GHz，支持亚马逊Alexa和谷歌助手语音控制，已经拿了FCC ID和ETL认证，可以直接在美国销售。",
          "vi": "Có, ổ cắm thông minh này của chúng tôi hoàn toàn đáp ứng yêu cầu của anh, WiFi 2.4GHz, hỗ trợ Amazon Alexa và Google Assistant, đã có FCC ID và ETL, có thể bán trực tiếp ở Mỹ."
        },
        {
          "speaker": "Anh Phong",
          "zh": "很好，认证这块很重要。规格参数能介绍一下吗？主要是额定功率和电压范围。",
          "vi": "Tốt, chứng nhận rất quan trọng. Thông số kỹ thuật có thể giới thiệu không? Chủ yếu là công suất định mức và dải điện áp."
        },
        {
          "speaker": "Chén gōng",
          "zh": "额定功率15安培，最大功率1800瓦，电压支持100-240V宽电压，全球通用，美国110V没有问题。还有一个实时功率监测功能，用户可以通过APP查看用电情况。",
          "vi": "Công suất định mức 15 ampe, công suất tối đa 1800W, hỗ trợ điện áp 100–240V đa điện áp, dùng toàn cầu, 110V Mỹ không vấn đề. Còn có chức năng giám sát công suất thực, người dùng có thể xem tình trạng điện năng qua APP."
        },
        {
          "speaker": "Anh Phong",
          "zh": "APP是Tuya平台还是自己开发的？",
          "vi": "APP là nền tảng Tuya hay tự phát triển?"
        },
        {
          "speaker": "Chén gōng",
          "zh": "我们支持两种方案：标准款用Tuya平台，开发周期短，SDK成熟；如果您需要品牌定制APP，我们可以提供ODM服务，基于我们的固件给您开发专属APP，但需要额外的开发费用。",
          "vi": "Chúng tôi hỗ trợ hai phương án: phiên bản chuẩn dùng Tuya, thời gian phát triển ngắn, SDK trưởng thành; nếu anh cần APP thương hiệu riêng, chúng tôi có thể cung cấp dịch vụ ODM, phát triển APP riêng cho anh dựa trên firmware của chúng tôi, nhưng cần thêm chi phí phát triển."
        },
        {
          "speaker": "Anh Phong",
          "zh": "我们想用自己的品牌APP，这样用户体验更统一。NRE费用大概是多少？开发周期呢？",
          "vi": "Chúng tôi muốn dùng APP thương hiệu riêng, như vậy trải nghiệm người dùng nhất quán hơn. Phí NRE khoảng bao nhiêu? Thời gian phát triển?"
        },
        {
          "speaker": "Chén gōng",
          "zh": "APP定制化开发NRE大概是8000到12000美元，开发周期10到12周。固件源代码归您所有，这个我们可以合同里明确。",
          "vi": "Phí NRE tùy chỉnh APP khoảng 8.000–12.000 USD, thời gian phát triển 10–12 tuần. Source code firmware thuộc về anh, điều này chúng tôi có thể ghi rõ trong hợp đồng."
        },
        {
          "speaker": "Anh Phong",
          "zh": "好，这点很重要，上次我们合作另一家供应商，固件是他们的，后来转厂遇到了麻烦。那BOM方面，有没有关键元器件供货风险？",
          "vi": "Tốt, điểm này quan trọng, lần trước hợp tác với nhà cung cấp khác, firmware của họ, sau khi chuyển nhà máy gặp rắc rối. Vậy phía BOM, có rủi ro cung ứng linh kiện quan trọng nào không?"
        },
        {
          "speaker": "Chén gōng",
          "zh": "我们的主控芯片是ESP32-S3，目前供货稳定，交货提前期8周，我们有6周安全库存。有一个PMIC芯片交货提前期是16周，这个我们已经提前备了3个月的货。",
          "vi": "Chip điều khiển chính của chúng tôi là ESP32-S3, hiện cung ứng ổn định, lead time 8 tuần, chúng tôi có tồn kho an toàn 6 tuần. Có một chip PMIC lead time 16 tuần, cái này chúng tôi đã dự trữ trước 3 tháng."
        },
        {
          "speaker": "Anh Phong",
          "zh": "备货做得好。出货前的测试流程是怎样的？",
          "vi": "Dự trữ làm tốt. Quy trình kiểm tra trước khi xuất hàng thế nào?"
        },
        {
          "speaker": "Chén gōng",
          "zh": "每台产品都会经过功能全检和24小时老化测试，不良率控制在0.3%以内。每台有唯一序列号，支持质量追溯。出货前还会做一批AQL 1.5的第三方抽检。",
          "vi": "Mỗi sản phẩm đều qua kiểm tra chức năng toàn bộ và burn-in 24 giờ, tỷ lệ lỗi kiểm soát dưới 0,3%. Mỗi cái có serial number duy nhất, hỗ trợ truy xuất chất lượng. Trước khi xuất còn làm kiểm tra ngẫu nhiên bên thứ ba theo AQL 1.5."
        },
        {
          "speaker": "Anh Phong",
          "zh": "AQL 1.5，很严格，这个标准我们接受。那我想了解一下认证情况，RoHS也有吗？",
          "vi": "AQL 1.5, nghiêm ngặt đấy, tiêu chuẩn này chúng tôi chấp nhận. Muốn tìm hiểu về tình trạng chứng nhận, RoHS cũng có không?"
        },
        {
          "speaker": "Chén gōng",
          "zh": "有，FCC ID、ETL、RoHS我们都有，检测报告随时可以提供。另外因为含有锂电池的备用电源模块，我们还做了UN38.3的运输安全认证，可以空运，没有限制。",
          "vi": "Có, FCC ID, ETL, RoHS đều có, báo cáo kiểm định có thể cung cấp bất cứ lúc nào. Ngoài ra vì có module nguồn dự phòng chứa pin lithium, chúng tôi còn làm chứng nhận an toàn vận chuyển UN38.3, có thể vận chuyển hàng không, không bị hạn chế."
        },
        {
          "speaker": "Anh Phong",
          "zh": "那太好了，如果要订50000个，FOB深圳港的单价是多少？",
          "vi": "Tốt quá, nếu đặt 50.000 cái, đơn giá FOB cảng Thâm Quyến là bao nhiêu?"
        },
        {
          "speaker": "Chén gōng",
          "zh": "50000个的话，FOB深圳港单价是6.8美元，含标准包装和FBA要求的FNSKU标签服务。如果需要OEM定制包装，每件加0.3美元。",
          "vi": "50.000 cái thì giá FOB cảng Thâm Quyến là 6,8 USD, bao gồm đóng gói tiêu chuẩn và dịch vụ dán nhãn FNSKU theo yêu cầu FBA. Nếu cần đóng gói OEM tùy chỉnh, mỗi cái cộng thêm 0,3 USD."
        },
        {
          "speaker": "Anh Phong",
          "zh": "6.8美元，比我们预期稍微高一点。我们的目标价是6.2美元，有空间吗？",
          "vi": "6,8 đô hơi cao hơn kỳ vọng một chút. Giá mục tiêu của chúng tôi là 6,2 đô, có không gian không?"
        },
        {
          "speaker": "Chén gōng",
          "zh": "6.2美元的话直接做不到，我们的成本摆在那里。这样吧，如果您这次是试单，先下5000个，我们可以做6.6；如果您承诺今年全年不低于100000个，我们可以做到6.3，这已经是我们的极限了。",
          "vi": "6,2 USD thì không thể làm ngay được, chi phí của chúng tôi có giới hạn. Thế này nhé, nếu lần này là đơn thử, trước đặt 5.000 cái, chúng tôi có thể làm 6,6; nếu anh cam kết cả năm không dưới 100.000 cái, chúng tôi có thể đến 6,3, đây là giới hạn của chúng tôi rồi."
        },
        {
          "speaker": "Anh Phong",
          "zh": "100000个全年我们可以认真考虑，但需要先看样品，再做内部评估。能先提供一套规格参数表和认证文件吗？",
          "vi": "100.000 cái cả năm chúng tôi có thể cân nhắc nghiêm túc, nhưng cần xem mẫu trước, rồi đánh giá nội bộ. Có thể cung cấp bộ thông số kỹ thuật và tài liệu chứng nhận không?"
        },
        {
          "speaker": "Chén gōng",
          "zh": "没问题，我现在给您我的名片，今天下午我把产品规格书、BOM风险评估报告和所有认证文件发给您。我们希望跟您进一步洽谈，如果方便，明天能来工厂参观吗？",
          "vi": "Không vấn đề, tôi đưa danh thiếp cho anh ngay, chiều nay tôi gửi tài liệu thông số sản phẩm, báo cáo đánh giá rủi ro BOM và tất cả tài liệu chứng nhận cho anh. Chúng tôi muốn thảo luận thêm với anh, nếu thuận tiện, ngày mai anh có thể đến tham quan nhà máy không?"
        },
        {
          "speaker": "Anh Phong",
          "zh": "可以，明天参观工厂，顺便看看你们的产线和测试设备。我会带我们的技术同事一起来。",
          "vi": "Được, ngày mai tham quan nhà máy, tiện thể xem dây chuyền và thiết bị kiểm tra. Tôi sẽ mang đồng nghiệp kỹ thuật đi cùng."
        }
      ]
    },
    "notes": [
      {
        "title": "Tham quan nhà máy: bước quan trọng sau hội chợ",
        "body": "Sau cuộc gặp tại hội chợ, tham quan nhà máy là bước xác thực quan trọng nhất. Trong buổi tham quan, chú ý: (1) quy mô thực tế có khớp với quảng cáo không, (2) dây chuyền sản xuất có đủ năng lực không, (3) thiết bị kiểm tra có đầy đủ không, (4) nhân viên có được đào tạo không."
      },
      {
        "title": "Kỹ năng đàm phán tại hội chợ điện tử",
        "body": "Đàm phán giá tại hội chợ: không chốt ngay tại gian hàng — luôn để ngỏ \"cần đánh giá nội bộ\" để có thêm thời gian. Sử dụng \"benchmark price\" (giá thị trường) như đòn bẩy mà không cần tiết lộ từ ai. Cam kết volume hàng năm là đòn bẩy mạnh nhất."
      },
      {
        "title": "Câu hỏi kỹ thuật cần hỏi tại hội chợ điện tử",
        "body": "Ngoài giá, buyer cần hỏi: FCC/ETL/RoHS status (có sẵn hay còn phải làm), MOSFET/chip specs, lead time của linh kiện quan trọng, quy trình kiểm tra, traceability system. Người hỏi được những câu này sẽ được nhà máy tôn trọng hơn."
      },
      {
        "title": "Firmware và source code: học từ sai lầm",
        "body": "Trong hội thoại, anh Phong đề cập đến kinh nghiệm xấu khi nhà cung cấp giữ firmware. Đây là vấn đề rất phổ biến. Khi anh ấy hỏi về điều này ngay tại gian hàng hội chợ và nhà máy trả lời rõ ràng \"source code thuộc về anh\", đó là tín hiệu tốt về độ chuyên nghiệp của nhà máy."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Câu hỏi kỹ thuật nào quan trọng nhất cần hỏi khi tìm nhà cung cấp điện tử tại hội chợ?",
          "options": {
            "A": "Màu sắc bao bì",
            "B": "Tình trạng chứng nhận FCC/ETL, rủi ro BOM, quy trình kiểm tra",
            "C": "Thời gian làm việc của nhà máy",
            "D": "Số lượng nhân viên"
          }
        },
        {
          "num": 2,
          "q": "Tại sao không nên chốt giá ngay tại gian hàng hội chợ?",
          "options": {
            "A": "Vì không礼phép",
            "B": "Để có thêm thời gian đánh giá và sử dụng \"cần xem xét nội bộ\" như đòn bẩy tiếp tục đàm phán",
            "C": "Vì giá tại hội chợ luôn không chính xác",
            "D": "Vì cần giấy phép đặc biệt"
          }
        },
        {
          "num": 3,
          "q": "Ổ cắm thông minh cần những chứng nhận gì để bán ở Mỹ?",
          "options": {
            "A": "Chỉ FCC",
            "B": "FCC ID + ETL + RoHS",
            "C": "Chỉ ETL",
            "D": "CE là đủ"
          }
        },
        {
          "num": 4,
          "q": "Khi buyer nói \"chúng tôi quan tâm nhưng cần đánh giá nội bộ\", đây là kỹ thuật đàm phán gì?",
          "options": {
            "A": "Từ chối",
            "B": "Giữ quyền thương lượng và không bộc lộ quá sớm sự quan tâm",
            "C": "Yêu cầu giảm giá thêm",
            "D": "Kết thúc cuộc đàm phán"
          }
        },
        {
          "num": 5,
          "q": "Khi nhà máy nói \"source code firmware thuộc về khách hàng\", điều đó có nghĩa là gì thực tế?",
          "options": {
            "A": "Buyer có thể làm firmware update độc lập",
            "B": "Buyer có thể chuyển sang nhà máy khác mà không mất firmware",
            "C": "Cả A và B đều đúng",
            "D": "Không có ý nghĩa thực tế"
          }
        },
        {
          "num": 6,
          "q": "Cam kết volume hàng năm (年度采购量) là đòn bẩy gì trong đàm phán giá?",
          "options": {
            "A": "Đòn bẩy yếu nhất",
            "B": "Đòn bẩy mạnh nhất — nhà máy sẵn sàng giảm giá để đảm bảo volume ổn định",
            "C": "Không phải đòn bẩy",
            "D": "Chỉ áp dụng cho sản phẩm đại trà"
          }
        },
        {
          "num": 7,
          "q": "Trong hội thoại, AQL 1.5 được coi là tiêu chuẩn như thế nào so với AQL 2.5?",
          "options": {
            "A": "Lỏng hơn",
            "B": "Nghiêm ngặt hơn (cho phép ít lỗi hơn)",
            "C": "Giống nhau",
            "D": "AQL 1.5 không tồn tại"
          }
        },
        {
          "num": 8,
          "q": "Khi tham quan nhà máy sau hội chợ, cần chú ý điều gì?",
          "options": {
            "A": "Chỉ xem phòng họp",
            "B": "Quy mô thực tế, dây chuyền, thiết bị kiểm tra, và đào tạo nhân viên",
            "C": "Chỉ xem sản phẩm trưng bày",
            "D": "Thời gian ăn trưa"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "Ổ cắm với điện áp 100–240V có thể dùng ở cả Mỹ (110V) và Châu Âu (220V)."
        },
        {
          "num": 10,
          "q": "Tại hội chợ, cần chốt giá ngay để không mất cơ hội."
        },
        {
          "num": 11,
          "q": "FCC ID và ETL là hai chứng nhận khác nhau, bổ sung cho nhau (không thay thế cho nhau)."
        },
        {
          "num": 12,
          "q": "Nếu nhà máy đã dự trữ 3 tháng tồn kho cho linh kiện lead time 16 tuần, rủi ro cung ứng đã được giảm thiểu đáng kể."
        },
        {
          "num": 13,
          "q": "Buyer không cần quan tâm đến quy trình kiểm tra của nhà máy."
        },
        {
          "num": 14,
          "q": "Mang kỹ sư kỹ thuật đi tham quan nhà máy giúp đánh giá chuyên sâu hơn so với chỉ đi một mình."
        }
      ],
      "fillblank": {
        "wordbank": [
          "FCC认证",
          "规格参数",
          "不良率",
          "固件",
          "BOM",
          "年度采购量"
        ],
        "items": [
          {
            "num": 15,
            "q": "请提供完整的____表，包括额定功率、电压范围、防水等级和工作温度。"
          },
          {
            "num": 16,
            "q": "这款产品已经拿到了____ID和ETL认证，可以直接在美国销售。"
          },
          {
            "num": 17,
            "q": "我们控制____在0.3%以内，每台产品都有序列号支持追溯。"
          },
          {
            "num": 18,
            "q": "____源代码归您所有，您有完全的控制权，可以自己进行更新和修改。"
          },
          {
            "num": 19,
            "q": "如果您承诺____不低于10万个，我们可以提供更有竞争力的单价。"
          },
          {
            "num": 20,
            "q": "在签合同前，请提供完整的____，我们需要评估关键元器件的供应风险。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 21,
          "q": "这款智能插座已经通过FCC ID、ETL和RoHS认证，可以在美国合法销售，认证文件随时可以提供。"
        },
        {
          "num": 22,
          "q": "如果您需要品牌定制APP，我们提供ODM服务，NRE费用8000美元，开发周期10周，源代码归您所有。"
        },
        {
          "num": 23,
          "q": "我们的产品支持100-240V宽电压，无需变压器，全球通用，特别适合在多个市场同时销售。"
        },
        {
          "num": 24,
          "q": "每台产品经过100%功能测试和24小时老化测试，AQL 1.5抽检，不良率控制在0.3%以内。"
        },
        {
          "num": 25,
          "q": "如果年采购量达到10万个，我们可以把单价从6.8美元降到6.3美元，这是我们的最终报价。"
        }
      ],
      "vi2zh": [
        {
          "num": 26,
          "q": "Sản phẩm đã có FCC ID và ETL chưa? Chứng nhận là yêu cầu bắt buộc trước khi chúng tôi đặt hàng."
        },
        {
          "num": 27,
          "q": "Chúng tôi muốn APP thương hiệu riêng, không dùng Tuya. Phí NRE và thời gian phát triển là bao nhiêu?"
        },
        {
          "num": 28,
          "q": "Sau khi xem mẫu và đánh giá nội bộ, nếu ổn chúng tôi sẽ đặt thử 5000 cái trước, sau đó tăng dần."
        },
        {
          "num": 29,
          "q": "Source code firmware phải thuộc sở hữu của chúng tôi — đây là điều kiện không thể thiếu trong hợp đồng."
        },
        {
          "num": 30,
          "q": "Ngày mai chúng tôi muốn tham quan nhà máy, xem dây chuyền sản xuất và thiết bị kiểm tra, được không?"
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "B",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "C",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": false,
        "11": true,
        "12": true,
        "13": false,
        "14": true
      },
      "fillblank": {
        "15": "规格参数",
        "16": "FCC认证",
        "17": "不良率",
        "18": "固件",
        "19": "年度采购量",
        "20": "BOM"
      },
      "zh2vi": {
        "21": "Ổ cắm thông minh này đã qua FCC ID, ETL và RoHS, có thể bán hợp pháp ở Mỹ, tài liệu chứng nhận có thể cung cấp bất cứ lúc nào.",
        "22": "Nếu anh cần APP thương hiệu tùy chỉnh, chúng tôi cung cấp dịch vụ ODM, phí NRE 8.000 USD, thời gian phát triển 10 tuần, source code thuộc về anh.",
        "23": "Sản phẩm của chúng tôi hỗ trợ đa điện áp 100–240V, không cần biến áp, dùng toàn cầu, đặc biệt phù hợp bán đồng thời nhiều thị trường.",
        "24": "Mỗi sản phẩm qua kiểm tra chức năng 100% và burn-in 24 giờ, kiểm tra ngẫu nhiên AQL 1.5, tỷ lệ lỗi kiểm soát dưới 0,3%.",
        "25": "Nếu số lượng năm đạt 100.000 cái, chúng tôi có thể giảm đơn giá từ 6,8 xuống 6,3 USD, đây là báo giá cuối cùng của chúng tôi."
      },
      "vi2zh": {
        "26": "产品已经有FCC ID和ETL认证了吗？认证是我们下单前的硬性要求。",
        "27": "我们想要自己品牌的APP，不用Tuya平台。NRE费用和开发时间是多少？",
        "28": "看完样品并内部评估后，如果没问题我们会先下5000个试单，之后逐步增加。",
        "29": "固件源代码必须归我们所有——这是合同中不可缺少的条件。",
        "30": "明天我们想参观工厂，看生产线和检测设备，方便吗？"
      }
    }
  },
  {
    "num": 27,
    "title": "NĂNG LƯỢNG TÁI TẠO: SẢN PHẨM & CÔNG NGHỆ",
    "date": "23/6",
    "phase": 4,
    "vocab": [
      {
        "num": 1,
        "hanzi": "新能源",
        "pinyin": "xīn néng yuán",
        "vi": "năng lượng mới / năng lượng tái tạo",
        "explanation": "Thuật ngữ TQ thường dùng chỉ năng lượng mặt trời (太阳能), gió (风能), thủy điện nhỏ, địa nhiệt (地热), và đặc biệt pin năng lượng (动力电池). TQ là nhà sản xuất và xuất khẩu lớn nhất thế giới về tất cả các danh mục này. Đây là ngành có tốc độ tăng trưởng nhanh nhất trong xuất khẩu TQ giai đoạn 2020-2025.",
        "example": {
          "zh": "中国的新能源行业发展非常快，特别是太阳能和电动车领域，已经领先全球。",
          "vi": "Ngành năng lượng mới TQ phát triển rất nhanh, đặc biệt lĩnh vực năng lượng mặt trời và xe điện, đã dẫn đầu toàn cầu."
        }
      },
      {
        "num": 2,
        "hanzi": "太阳能板",
        "pinyin": "tàiyáng néng bǎn",
        "vi": "tấm pin năng lượng mặt trời (solar panel)",
        "explanation": "Thiết bị chuyển đổi ánh sáng mặt trời thành điện năng. Hai loại phổ biến: Mono (单晶硅 — hiệu suất cao hơn, đắt hơn) và Poly (多晶硅 — rẻ hơn, hiệu suất thấp hơn một chút). Ngoài ra còn có PERC, TOPCon, HJT (các công nghệ thế hệ mới hiệu suất cao hơn). TQ chiếm 80%+ sản xuất toàn cầu.",
        "example": {
          "zh": "我们生产的太阳能板采用TOPCon技术，转换效率达到24%，在市场上属于高端产品。",
          "vi": "Tấm pin mặt trời chúng tôi sản xuất dùng công nghệ TOPCon, hiệu suất chuyển đổi đạt 24%, thuộc hàng cao cấp trên thị trường."
        }
      },
      {
        "num": 3,
        "hanzi": "光伏",
        "pinyin": "guāngfú",
        "vi": "quang điện (photovoltaic - PV)",
        "explanation": "Công nghệ chuyển đổi ánh sáng thành điện. 光伏系统 = hệ thống năng lượng mặt trời hoàn chỉnh. 光伏组件 = module (tấm pin). 光伏电站 = nhà máy điện mặt trời. Khi nghe 光伏, biết người ta đang nói về solar energy.",
        "example": {
          "zh": "这个光伏项目装机容量50MW，年发电量约7000万千瓦时。",
          "vi": "Dự án quang điện này công suất lắp đặt 50MW, sản lượng điện hàng năm khoảng 70 triệu kWh."
        }
      },
      {
        "num": 4,
        "hanzi": "逆变器",
        "pinyin": "nìbiàn qì",
        "vi": "biến tần (inverter)",
        "explanation": "Thiết bị chuyển đổi điện DC (từ pin mặt trời hoặc ắc quy) sang AC để dùng trong nhà hoặc nối lưới. Là thành phần quan trọng và đắt tiền trong hệ thống năng lượng mặt trời. TQ có hai nhà sản xuất inverter hàng đầu thế giới: Huawei và Sungrow (阳光电源).",
        "example": {
          "zh": "这套家用太阳能系统需要一台5kW的并网逆变器，可以和电网双向输电。",
          "vi": "Bộ hệ thống năng lượng mặt trời gia dụng này cần một biến tần nối lưới 5kW, có thể truyền điện hai chiều với lưới điện."
        }
      },
      {
        "num": 5,
        "hanzi": "储能系统",
        "pinyin": "chǔ néng xìtǒng",
        "vi": "hệ thống lưu trữ năng lượng (ESS)",
        "explanation": "Energy Storage System — hệ thống pin lưu trữ điện để dùng khi không có mặt trời hoặc khi điện lưới mất. Gồm: pin lithium (pack), BMS (hệ thống quản lý pin), PCS (power conversion system). Xu hướng cực nóng toàn cầu 2023–2025 do nhu cầu về energy security và grid stabilization.",
        "example": {
          "zh": "这套储能系统容量是100kWh，采用磷酸铁锂电池，循环寿命超过6000次，适合工商业应用。",
          "vi": "Hệ thống lưu trữ năng lượng này dung lượng 100kWh, dùng pin LFP, tuổi thọ vòng lặp hơn 6000 lần, phù hợp ứng dụng thương mại và công nghiệp."
        }
      },
      {
        "num": 6,
        "hanzi": "电网",
        "pinyin": "diànwǎng",
        "vi": "lưới điện (power grid)",
        "explanation": "Hệ thống truyền tải và phân phối điện năng. 并网 (grid-connected) = kết nối với lưới điện quốc gia. 离网 (off-grid) = độc lập không nối lưới. 虚拟电厂 (virtual power plant) = tập hợp nhiều nguồn phân tán. Dự án năng lượng tái tạo thường liên quan đến quy định kết nối lưới của từng quốc gia.",
        "example": {
          "zh": "我们的储能系统支持并网和离网两种模式，根据实际需求切换。",
          "vi": "Hệ thống lưu trữ của chúng tôi hỗ trợ cả hai chế độ nối lưới và độc lập, chuyển đổi theo nhu cầu thực tế."
        }
      },
      {
        "num": 7,
        "hanzi": "碳中和",
        "pinyin": "tàn zhōnghé",
        "vi": "trung hòa carbon (carbon neutrality)",
        "explanation": "Mục tiêu cân bằng giữa lượng CO₂ phát thải và lượng CO₂ được hấp thụ hoặc bù đắp. TQ cam kết carbon neutral vào 2060. EU và Mỹ sớm hơn. Đây là động lực chính đằng sau bùng nổ năng lượng tái tạo toàn cầu. Khi đàm phán năng lượng xanh, 碳中和 là từ khóa chiến lược quan trọng.",
        "example": {
          "zh": "这个项目帮助我们实现碳中和目标，减少每年5000吨的碳排放。",
          "vi": "Dự án này giúp chúng tôi đạt mục tiêu trung hòa carbon, giảm 5000 tấn phát thải carbon mỗi năm."
        }
      },
      {
        "num": 8,
        "hanzi": "转换效率",
        "pinyin": "zhuǎnhuàn xiàolǜ",
        "vi": "hiệu suất chuyển đổi",
        "explanation": "Tỷ lệ phần trăm năng lượng ánh sáng/gió được chuyển thành điện năng. Với pin mặt trời: công nghệ mono thông thường 20–22%, PERC 21–23%, TOPCon 22–25%, HJT 24–26%. Hiệu suất cao hơn = cần diện tích lắp đặt nhỏ hơn để tạo cùng lượng điện.",
        "example": {
          "zh": "我们的HJT组件转换效率达到25.5%，是目前量产组件中效率最高的，特别适合屋顶安装面积有限的项目。",
          "vi": "Module HJT của chúng tôi hiệu suất chuyển đổi đạt 25,5%, hiệu suất cao nhất trong sản phẩm đại trà hiện tại, đặc biệt phù hợp dự án lắp mái nhà có diện tích hạn chế."
        }
      },
      {
        "num": 9,
        "hanzi": "风力发电",
        "pinyin": "fēnglì fādiàn",
        "vi": "điện gió (wind power)",
        "explanation": "Phát điện từ năng lượng gió qua tuabin gió. 陆上风电 (onshore wind) vs 海上风电 (offshore wind — đắt hơn nhưng gió mạnh và ổn định hơn). TQ lắp đặt hơn 100 GW wind power mỗi năm. Tuabin gió TQ (Goldwind, Mingyang) đang cạnh tranh mạnh với Vestas, Siemens Gamesa. Giải thích tiếp: Với người làm thu mua và phiên dịch, bạn sẽ gặp 风力发电 trong ngữ cảnh dự án đầu tư quy mô lớn.",
        "example": {
          "zh": "这个沿海风电场装机容量是500MW，年发电量相当于为50万户家庭提供用电。",
          "vi": "Trang trại gió ven biển này công suất lắp đặt 500MW, sản lượng điện hàng năm tương đương cấp điện cho 500.000 hộ gia đình."
        }
      },
      {
        "num": 10,
        "hanzi": "绿色认证",
        "pinyin": "lǜsè rènzhèng",
        "vi": "chứng nhận xanh (green certification)",
        "explanation": "Các chứng nhận xác minh sản phẩm/dự án thân thiện môi trường. Quan trọng nhất: IEC 61215 và IEC 61730 cho solar panels (bắt buộc cho hầu hết thị trường), UL 1703 cho thị trường Mỹ, MCS cho Anh. Ngoài ra: REC (Renewable Energy Certificate) xác nhận điện từ nguồn tái tạo.",
        "example": {
          "zh": "我们的太阳能板通过了IEC 61215、IEC 61730和UL 1703认证，可以进入美国、欧洲和全球主要市场。",
          "vi": "Tấm pin mặt trời của chúng tôi đã qua chứng nhận IEC 61215, IEC 61730 và UL 1703, có thể vào thị trường Mỹ, Châu Âu và các thị trường lớn toàn cầu."
        }
      }
    ],
    "dialogue": {
      "context": "Phái đoàn VN đang tham quan và đàm phán với nhà sản xuất solar panel TQ về dự án lắp đặt tại VN.",
      "characters": [
        {
          "name": "销售总监李总 (Lǐ zǒng)",
          "role": "Giám đốc kinh doanh nhà sản xuất solar"
        },
        {
          "name": "Anh Tuấn",
          "role": "Đại diện công ty năng lượng VN"
        }
      ],
      "lines": [
        {
          "speaker": "Anh Tuấn",
          "zh": "李总，我们这次来主要是想了解贵公司的太阳能组件和储能系统，我们在越南有一个50MW的分布式光伏项目，需要采购组件和配套设备。",
          "vi": "Giám đốc Lý, lần này chúng tôi đến chủ yếu muốn tìm hiểu về module solar và hệ thống lưu trữ của quý công ty, chúng tôi có dự án quang điện phân tán 50MW tại VN, cần mua module và thiết bị đi kèm."
        },
        {
          "speaker": "李总",
          "zh": "非常好，50MW是个大项目，我们很有兴趣。请问您对组件有什么具体要求？是屋顶还是地面项目？",
          "vi": "Rất tốt, 50MW là dự án lớn, chúng tôi rất quan tâm. Anh có yêu cầu cụ thể gì về module? Dự án mái nhà hay mặt đất?"
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "是商业屋顶项目，面积有限制，所以希望用高效率的组件，减少占用面积。另外越南的气候特点是高温高湿，这点也需要考虑。",
          "vi": "Dự án mái thương mại, diện tích có hạn nên muốn dùng module hiệu suất cao để giảm diện tích chiếm dụng. Ngoài ra khí hậu VN đặc trưng là nóng ẩm, điểm này cũng cần xem xét."
        },
        {
          "speaker": "李总",
          "zh": "对于高温高湿的气候，我们推荐我们的TOPCon双面组件，转换效率23.5%，而且有优秀的高温性能，功率温度系数是-0.30%/°C，比普通组件低很多，在越南气候下发电量会更好。",
          "vi": "Với khí hậu nóng ẩm, chúng tôi khuyến nghị module TOPCon hai mặt của chúng tôi, hiệu suất 23,5%, đồng thời có đặc tính nhiệt độ cao xuất sắc, hệ số nhiệt độ công suất là -0,30%/°C, thấp hơn nhiều so với module thông thường, trong điều kiện khí hậu VN sản lượng điện sẽ tốt hơn."
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "-0.30%/°C的温度系数确实不错。这款组件通过了哪些认证？能在越南合规使用吗？",
          "vi": "Hệ số nhiệt độ -0,30%/°C đúng là tốt. Module này qua những chứng nhận nào? Có thể sử dụng hợp quy tại VN không?"
        },
        {
          "speaker": "李总",
          "zh": "通过了IEC 61215、IEC 61730国际认证，另外我们专门为越南市场做了防盐雾测试，符合越南海岸线附近项目的要求。我们在越南已经有30多个项目的交付经验，熟悉当地的监管要求。",
          "vi": "Đã qua chứng nhận quốc tế IEC 61215, IEC 61730, ngoài ra chúng tôi đặc biệt làm kiểm tra chống muối cho thị trường VN, đáp ứng yêu cầu dự án gần bờ biển VN. Chúng tôi đã có kinh nghiệm giao hàng hơn 30 dự án tại VN, quen thuộc với yêu cầu quản lý địa phương."
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "很好，有本地经验很重要。储能方面，项目需要配套4小时的储能，您们有合适的方案吗？",
          "vi": "Tốt, có kinh nghiệm địa phương rất quan trọng. Về lưu trữ, dự án cần lưu trữ đi kèm 4 giờ, các anh có phương án phù hợp không?"
        },
        {
          "speaker": "李总",
          "zh": "我们有配套的磷酸铁锂储能系统，50MW光伏项目建议配200MWh储能，循环寿命6000次以上，10年容量保持率80%以上。这个系统可以实现峰谷调节，提高项目的经济收益。",
          "vi": "Chúng tôi có hệ thống lưu trữ LFP đi kèm, dự án quang điện 50MW khuyến nghị đi kèm 200MWh lưu trữ, tuổi thọ vòng lặp trên 6000 lần, dung lượng sau 10 năm duy trì trên 80%. Hệ thống này có thể thực hiện điều tiết giờ cao/thấp điểm, nâng cao hiệu quả kinh tế dự án."
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "价格方面，组件和储能系统打包报价是多少？",
          "vi": "Về giá cả, báo giá trọn gói module và hệ thống lưu trữ là bao nhiêu?"
        },
        {
          "speaker": "李总",
          "zh": "组件方面，TOPCon双面组件FOB上海港的价格是每瓦0.18美元，50MW就是900万美元。储能系统200MWh的完整系统（含BMS和PCS）价格是每千瓦时100美元，也就是2000万美元。如果两个系统打包，我们可以在总价上给5%的优惠。",
          "vi": "Về module, giá module TOPCon hai mặt FOB cảng Thượng Hải là 0,18 USD/W, 50MW tức là 9 triệu USD. Hệ thống lưu trữ 200MWh trọn gói (bao gồm BMS và PCS) giá 100 USD/kWh, tức là 20 triệu USD. Nếu đóng gói hai hệ thống, chúng tôi có thể giảm 5% tổng giá."
        },
        {
          "speaker": "Anh Tuấn",
          "zh": "我们会认真评估这个方案，能否提供技术文件和项目参考案例，特别是在东南亚气候条件下的项目？",
          "vi": "Chúng tôi sẽ đánh giá nghiêm túc phương án này, có thể cung cấp tài liệu kỹ thuật và dự án tham khảo không, đặc biệt là dự án trong điều kiện khí hậu Đông Nam Á?"
        },
        {
          "speaker": "李总",
          "zh": "当然，我们明天发给您完整的技术手册、认证文件、以及越南、泰国和印尼的三个参考项目案例，包括实际发电数据和客户反馈。",
          "vi": "Tất nhiên, ngày mai chúng tôi gửi cho anh đầy đủ tài liệu kỹ thuật, chứng nhận, và 3 dự án tham khảo ở VN, Thái Lan và Indonesia, bao gồm dữ liệu phát điện thực tế và phản hồi của khách hàng."
        }
      ]
    },
    "notes": [
      {
        "title": "Thị trường solar VN: đang bùng nổ",
        "body": "VN là một trong những thị trường solar tăng trưởng nhanh nhất Đông Nam Á. Giá điện FIT (Feed-in Tariff) đã hết hạn nhưng thị trường self-consumption vẫn rất mạnh. Dự án tự dùng thương mại và công nghiệp (C&I solar) là phân khúc hot nhất."
      },
      {
        "title": "TOPCon vs PERC vs HJT: hiểu xu hướng công nghệ",
        "body": "2024-2025: TOPCon đang chiếm thị phần lớn nhất, PERC dần bị thay thế, HJT đang tăng trưởng (hiệu suất cao nhất nhưng đắt hơn). Khi tư vấn dự án, biết xu hướng công nghệ giúp tư vấn khách hàng đưa ra quyết định mua tốt hơn."
      },
      {
        "title": "Đơn vị đo trong năng lượng mặt trời",
        "body": "kWp = kilowatt-peak (công suất đỉnh). MW = megawatt (1000 kW). MWh = megawatt-hour (sản lượng điện). 1 MWp solar thường tạo ra 1200–1600 MWh điện/năm tùy vị trí địa lý. Giá module thường tính theo USD/Wp (giá mỗi watt công suất đỉnh)."
      },
      {
        "title": "Hệ số nhiệt độ: quan trọng cho VN",
        "body": "Ở VN, nhiệt độ module ngoài trời thường đạt 60–70°C. Module với hệ số nhiệt -0.30%/°C mất ít công suất hơn module -0.45%/°C ở cùng nhiệt độ. Với khí hậu nhiệt đới, đây là thông số quan trọng cần so sánh khi chọn module."
      }
    ],
    "exercises": {
      "abcd": [
        {
          "num": 1,
          "q": "Công nghệ solar panel nào có hiệu suất cao nhất trong sản xuất đại trà hiện tại?",
          "options": {
            "A": "Poly (多晶硅)",
            "B": "PERC Mono",
            "C": "TOPCon hoặc HJT",
            "D": "Amorphous thin film"
          }
        },
        {
          "num": 2,
          "q": "Hệ số nhiệt độ -0.30%/°C tốt hơn -0.45%/°C vì?",
          "options": {
            "A": "Số nhỏ hơn luôn tốt hơn",
            "B": "Mất ít công suất hơn khi nhiệt độ tăng cao",
            "C": "Rẻ hơn",
            "D": "Không có sự khác biệt"
          }
        },
        {
          "num": 3,
          "q": "LFP pin (磷酸铁锂) được dùng trong hệ thống lưu trữ năng lượng vì lý do gì?",
          "options": {
            "A": "Rẻ nhất tuyệt đối",
            "B": "An toàn nhất, tuổi thọ vòng lặp cao (>6000 lần), ổn định nhiệt",
            "C": "Năng lượng mật độ cao nhất",
            "D": "Nhẹ nhất"
          }
        },
        {
          "num": 4,
          "q": "Đơn vị USD/Wp trong solar có nghĩa là gì?",
          "options": {
            "A": "Giá mỗi tấm solar",
            "B": "Giá mỗi watt công suất đỉnh của module",
            "C": "Giá mỗi kWh điện tạo ra",
            "D": "Giá lắp đặt mỗi m²"
          }
        },
        {
          "num": 5,
          "q": "Hệ thống 50MW solar nên đi kèm bao nhiêu MWh lưu trữ để đạt 4 giờ lưu trữ?",
          "options": {
            "A": "50 MWh",
            "B": "100 MWh",
            "C": "200 MWh",
            "D": "400 MWh"
          }
        },
        {
          "num": 6,
          "q": "IEC 61215 là chứng nhận cho loại thiết bị nào?",
          "options": {
            "A": "Biến tần solar",
            "B": "Tấm pin mặt trời (solar module)",
            "C": "Hệ thống lưu trữ",
            "D": "Cáp điện"
          }
        },
        {
          "num": 7,
          "q": "光伏 trong tiếng Trung có nghĩa là gì?",
          "options": {
            "A": "Điện gió",
            "B": "Quang điện / photovoltaic (solar)",
            "C": "Thủy điện",
            "D": "Địa nhiệt"
          }
        },
        {
          "num": 8,
          "q": "碳中和 là mục tiêu của nhiều quốc gia, có nghĩa là gì?",
          "options": {
            "A": "Không dùng carbon trong sản xuất",
            "B": "Cân bằng giữa lượng CO₂ phát thải và hấp thụ/bù đắp",
            "C": "Chỉ dùng năng lượng hạt nhân",
            "D": "Cấm tất cả nhiên liệu hóa thạch"
          }
        }
      ],
      "tf": [
        {
          "num": 9,
          "q": "TQ chiếm hơn 80% sản xuất solar panel toàn cầu."
        },
        {
          "num": 10,
          "q": "Hệ số nhiệt độ quan trọng hơn ở khí hậu nhiệt đới như VN so với khí hậu ôn đới Bắc Âu."
        },
        {
          "num": 11,
          "q": "Hệ thống lưu trữ LFP 200MWh với tuổi thọ 6000 vòng lặp tương đương khoảng 16 năm sử dụng (1 chu kỳ/ngày)."
        },
        {
          "num": 12,
          "q": "Module solar PERC là công nghệ mới nhất và tốt nhất hiện tại."
        },
        {
          "num": 13,
          "q": "Solar panel cần chứng nhận IEC 61215 và IEC 61730 để vào hầu hết thị trường quốc tế."
        },
        {
          "num": 14,
          "q": "1 MWp solar điển hình tạo ra khoảng 10 MWh điện mỗi năm."
        }
      ],
      "fillblank": {
        "wordbank": [
          "太阳能板",
          "光伏",
          "逆变器",
          "储能系统",
          "转换效率",
          "碳中和"
        ],
        "items": [
          {
            "num": 15,
            "q": "这个50MW的____项目采用高效____，____达到23.5%，非常适合屋顶有限面积的商业项目。"
          },
          {
            "num": 16,
            "q": "____是将直流电转换为交流电的关键设备，质量直接影响整个系统的发电效率。"
          },
          {
            "num": 17,
            "q": "配套200MWh的____，可以实现峰谷调节，提高项目的经济效益。"
          },
          {
            "num": 18,
            "q": "我们的目标是2050年实现____，这推动了整个可再生能源行业的快速发展。"
          }
        ]
      },
      "zh2vi": [
        {
          "num": 19,
          "q": "这款TOPCon双面组件转换效率23.5%，功率温度系数-0.30%/°C，在高温气候下表现优异。"
        },
        {
          "num": 20,
          "q": "50MW光伏项目配套200MWh磷酸铁锂储能系统，可以实现4小时储能，适合越南的工商业用电需求。"
        },
        {
          "num": 21,
          "q": "我们的太阳能组件通过了IEC 61215、IEC 61730国际认证，同时做了防盐雾测试，适合越南沿海地区项目。"
        },
        {
          "num": 22,
          "q": "组件FOB上海港价格0.18美元/瓦，储能系统100美元/千瓦时，打包采购可以优惠5%。"
        },
        {
          "num": 23,
          "q": "我们在越南已经有30多个交付项目，积累了丰富的本地经验，了解当地的监管要求和施工条件。"
        }
      ],
      "vi2zh": [
        {
          "num": 24,
          "q": "Dự án của chúng tôi là 50MW lắp mái thương mại tại VN, cần module hiệu suất cao vì diện tích hạn chế."
        },
        {
          "num": 25,
          "q": "Khí hậu VN nóng ẩm, hệ số nhiệt độ của module quan trọng, anh có thể cho biết thông số này không?"
        },
        {
          "num": 26,
          "q": "Module đã có chứng nhận IEC 61215 và IEC 61730 chưa? Đây là yêu cầu bắt buộc cho dự án của chúng tôi."
        },
        {
          "num": 27,
          "q": "Chúng tôi cần hệ thống lưu trữ 4 giờ đi kèm với dự án 50MW, phương án phù hợp là gì?"
        },
        {
          "num": 28,
          "q": "Giá module FOB cảng Thượng Hải là bao nhiêu USD/Wp? Bao gồm chi phí vận chuyển đến VN không?"
        },
        {
          "num": 29,
          "q": "Anh có thể cung cấp dự án tham khảo ở Đông Nam Á với điều kiện khí hậu tương tự VN không?"
        },
        {
          "num": 30,
          "q": "Mục tiêu của dự án là giúp công ty đạt mục tiêu trung hòa carbon và giảm chi phí điện dài hạn."
        }
      ]
    },
    "answers": {
      "abcd": {
        "1": "C",
        "2": "B",
        "3": "B",
        "4": "B",
        "5": "C",
        "6": "B",
        "7": "B",
        "8": "B"
      },
      "tf": {
        "9": true,
        "10": true,
        "11": true,
        "12": false,
        "13": true,
        "14": false
      },
      "fillblank": {
        "15": [
          "光伏",
          "太阳能板",
          "转换效率"
        ],
        "16": "逆变器",
        "17": "储能系统",
        "18": "碳中和"
      },
      "zh2vi": {
        "19": "Module TOPCon hai mặt này hiệu suất 23,5%, hệ số nhiệt độ công suất -0,30%/°C, hiệu năng xuất sắc trong khí hậu nhiệt độ cao.",
        "20": "Dự án quang điện 50MW đi kèm hệ thống lưu trữ LFP 200MWh, có thể đạt 4 giờ lưu trữ, phù hợp nhu cầu điện thương mại và công nghiệp VN.",
        "21": "Module mặt trời của chúng tôi đã qua chứng nhận quốc tế IEC 61215, IEC 61730, đồng thời đã thực hiện kiểm tra chống muối, phù hợp dự án khu vực ven biển VN.",
        "22": "Giá module FOB cảng Thượng Hải 0,18 USD/W, hệ thống lưu trữ 100 USD/kWh, mua đóng gói được giảm 5%.",
        "23": "Chúng tôi đã có hơn 30 dự án giao hàng tại VN, tích lũy kinh nghiệm địa phương phong phú, hiểu yêu cầu quản lý và điều kiện thi công địa phương."
      },
      "vi2zh": {
        "24": "我们的项目是在越南安装50MW商业屋顶，因为面积有限，需要高效率组件。",
        "25": "越南气候炎热潮湿，组件的温度系数很重要，您能提供这个参数吗？",
        "26": "组件已经有IEC 61215和IEC 61730认证吗？这是我们项目的强制要求。",
        "27": "我们需要与50MW项目配套的4小时储能系统，合适的方案是什么？",
        "28": "组件FOB上海港的价格是多少美元/瓦？包含到越南的运费吗？",
        "29": "您能提供东南亚类似越南气候条件下的参考项目吗？",
        "30": "这个项目的目标是帮助公司实现碳中和目标，同时降低长期电费成本。"
      }
    }
  }
];
