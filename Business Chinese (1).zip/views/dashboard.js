/* Dashboard view — the front door */
(function () {
  const { el, render, lessonsStats, vocabStats, avgScore, todayLessonNum, dueVocab, isInFuture, lessonState } = XQ;

  function lessonStatusLabel(num) {
    const ls = XQ.state.lessons[num];
    if (!ls || !ls.startedAt) return { label: 'chưa động đến', kind: 'pending' };
    if (ls.completed) return { label: 'xong rồi', kind: 'done' };
    const tabs = ls.tabsDone || {};
    const doneCount = ['vocab', 'dialogue', 'notes', 'exercises'].filter(t => tabs[t]).length;
    return { label: `đang dở (${doneCount}/4)`, kind: 'partial' };
  }

  function continueLessonNum() {
    // Find the latest in-progress lesson; if none, return today's
    const lastId = XQ.state.stats.lastLessonId;
    if (lastId) {
      const ls = XQ.state.lessons[lastId];
      if (ls && !ls.completed) return lastId;
    }
    // First lesson not yet completed
    for (const c of CURRICULUM) {
      const ls = XQ.state.lessons[c.num];
      if (!ls || !ls.completed) return c.num;
    }
    return CURRICULUM.length;
  }

  function dashboard() {
    const todayNum = todayLessonNum();
    const continueNum = continueLessonNum();
    const todayLesson = CURRICULUM.find(c => c.num === todayNum) || CURRICULUM[0];
    const continueLesson = CURRICULUM.find(c => c.num === continueNum) || CURRICULUM[0];
    const due = dueVocab();
    const vs = vocabStats();
    const ls = lessonsStats();
    const avg = avgScore();
    const todayStatus = lessonStatusLabel(continueNum);

    // ====== HERO ======
    const hero = el('section', { class: 'dash-hero' },
      el('div', { class: 'dash-hero-meta' },
        el('span', { class: 'eyebrow' }, `Ngày thứ ${todayNum} / 32`),
        el('span', { class: 'eyebrow muted' }, '·'),
        el('span', { class: 'eyebrow muted' }, currentPhaseLabel(todayNum)),
        el('span', { class: 'spacer' }),
        el('span', { class: 'hand-note' }, todayTaunt(todayNum, ls.completed))
      ),
      el('h1', { class: 'dash-headline' },
        'Một tháng — học thuộc cả đống này.'
      ),
      el('p', { class: 'dash-subhead' },
        'Chẳng lẽ ', el('em', null, 'mày'), ' lại không làm được à?'
      )
    );

    // ====== ACTION CARDS — Học tiếp + Ôn tập ======
    const actions = el('section', { class: 'dash-actions' },
      // CONTINUE
      el('article', { class: `action-card action-card-primary phase-${continueLesson.phase}`,
                     onclick: () => XQ.navTo('/lesson/' + continueLesson.num) },
        el('div', { class: 'action-card-tag' },
          el('span', { class: 'eyebrow', style:{color:'#FAF4E0', opacity:'.8'} },
            `Bài ${pad(continueLesson.num)} · ${continueLesson.date} · Giai đoạn ${continueLesson.phase}`),
          el('span', { class: 'action-status ' + todayStatus.kind }, todayStatus.label)
        ),
        el('div', { class: 'action-card-title' }, continueLesson.title),
        el('div', { class: 'action-card-cta' },
          el('span', null, continueNum === todayNum ? 'Học hôm nay' : (todayStatus.kind === 'partial' ? 'Học tiếp chỗ đang dở' : 'Bắt đầu')),
          el('span', { class: 'arrow' }, '→')
        )
      ),
      // REVIEW
      el('article', { class: 'action-card action-card-review',
                     onclick: () => XQ.navTo('/review') },
        el('div', { class: 'action-card-tag' },
          el('span', { class: 'eyebrow' }, 'Ôn tập'),
          due.length > 0
            ? el('span', { class: 'action-status due' }, due.length + ' từ tới hạn')
            : el('span', { class: 'action-status' }, 'không gấp')
        ),
        el('div', { class: 'action-card-title' },
          due.length === 0 ? 'Tự nguyện ôn cho chắc' : 'Trả nợ từ vựng & câu cũ'
        ),
        el('div', { class: 'action-card-cta' },
          el('span', null, due.length === 0 ? 'Trộn ngẫu nhiên đã học' : `Quẹt ${Math.min(due.length, 20)} thẻ`),
          el('span', { class: 'arrow' }, '→')
        )
      )
    );

    // ====== STATS ROW ======
    const stats = el('section', { class: 'dash-stats' },
      statCard('Từ vựng đã thuộc',
        `${vs.mastered}`, `/ ${vs.total}`,
        vs.total ? Math.round(100 * vs.mastered / vs.total) : 0,
        `${vs.learned} đã gặp · ${vs.mastered} thuộc kỹ`),
      statCard('Bài đã học xong',
        `${ls.completed}`, `/ ${ls.total}`,
        Math.round(100 * ls.completed / ls.total),
        `${ls.started - ls.completed} bài đang dở`),
      statCard('Hiệu suất bài tập',
        avg == null ? '—' : Math.round(avg * 100), avg == null ? '' : '%',
        avg == null ? 0 : Math.round(avg * 100),
        avg == null ? 'chưa làm bài nào, lười vừa thôi' : grade(avg))
    );

    // ====== ROADMAP MINI ======
    const roadmap = el('section', { class: 'dash-roadmap' },
      el('div', { class: 'roadmap-head' },
        el('h3', null, 'Lộ trình 32 ngày'),
        el('a', { href: '#/roadmap', class: 'soft', style:{fontSize:'13px'} }, 'Xem chi tiết →')
      ),
      el('div', { class: 'roadmap-strip' }, ...CURRICULUM.map(c => roadmapDot(c, todayNum, continueNum)))
    );

    render(el('div', null, hero, actions, stats, roadmap));
  }

  function pad(n) { return String(n).padStart(2, '0'); }

  function currentPhaseLabel(num) {
    const c = CURRICULUM.find(x => x.num === num);
    if (!c) return '';
    const p = PHASES.find(x => x.id === c.phase);
    return p ? `Giai đoạn ${p.id} — ${p.name}` : '';
  }

  function todayTaunt(todayN, completed) {
    const taunts = [
      'Ngồi xuống học đi.',
      'Đừng có lăn tăn nữa.',
      'Lại mở app ra cho có nhỉ?',
      'Cố thêm chút nữa.',
      'Học chứ đừng scroll.',
      'Đi làm phiên dịch chứ đùa à.',
      'Còn không học giờ thì khi nào?'
    ];
    // Pick deterministically by day
    return taunts[todayN % taunts.length];
  }

  function grade(avg) {
    if (avg >= 0.9) return 'tốt, giữ phong độ';
    if (avg >= 0.75) return 'ổn, nhưng đừng tự mãn';
    if (avg >= 0.6) return 'tàm tạm, cần ôn thêm';
    return 'cần làm lại';
  }

  function statCard(label, big, suffix, pct, sub) {
    return el('div', { class: 'stat-card' },
      el('div', { class: 'stat-label' }, label),
      el('div', { class: 'stat-big' },
        el('span', { class: 'stat-num' }, big),
        suffix ? el('span', { class: 'stat-suf' }, suffix) : null
      ),
      el('div', { class: 'stat-bar' },
        el('div', { class: 'stat-bar-fill', style:{width: pct + '%'} })
      ),
      el('div', { class: 'stat-sub' }, sub)
    );
  }

  function roadmapDot(c, todayN, continueN) {
    const ls = XQ.state.lessons[c.num];
    const completed = ls && ls.completed;
    const started = ls && ls.startedAt && !completed;
    const isToday = c.num === todayN;
    const isCurrent = c.num === continueN;
    let cls = `dot phase-${c.phase}`;
    if (completed) cls += ' dot-done';
    else if (started) cls += ' dot-started';
    if (isToday) cls += ' dot-today';
    if (isCurrent) cls += ' dot-current';
    return el('a', { href: '#/lesson/' + c.num, class: cls,
                     title: `Bài ${c.num} — ${c.title} (${c.date})` },
      el('span', { class: 'dot-num' }, c.num)
    );
  }

  XQ.views.dashboard = dashboard;
})();
