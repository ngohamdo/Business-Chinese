/* Exam (lesson 32) — stub */
(function () {
  const { el, render } = XQ;
  XQ.views.exam = function () {
    render(el('div', { class: 'panel' }, el('h2', null, 'Thực chiến (đang build)')));
  };
})();
