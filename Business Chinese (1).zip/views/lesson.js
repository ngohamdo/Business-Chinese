/* ============================================================
   Lesson view — 4 tabs (vocab, dialogue, notes, exercises)
   ============================================================ */
(function () {
  const { el, render, navTo, lessonState, saveState } = XQ;

  const TABS = [
    { key: 'vocab',     zh: '词汇', vi: 'Từ vựng' },
    { key: 'dialogue',  zh: '会话', vi: 'Hội thoại' },
    { key: 'notes',     zh: '笔记', vi: 'Ghi chú' },
    { key: 'exercises', zh: '练习', vi: 'Bài tập' },
  ];

  function lesson(num, tab) {
    const c = CURRICULUM.find(x => x.num === num);
    const L = LESSONS.find(x => x.num === num);

    if (!c) {
      render(notFound('Bài này không tồn tại trong lộ trình.'));
      return;
    }

    // Mark "started" + last-visited
    const ls = lessonState(num);
    if (!ls.startedAt) ls.startedAt = Date.now();
    XQ.state.stats.lastLessonId = num;
    XQ.state.stats.lastTab = tab;
    saveState();

    // No content yet for that lesson?
    if (!L) {
      render(placeholderLesson(c));
      return;
    }

    // Header + tabs
    const root = el('div', { class: 'lesson' });

    root.appendChild(lessonHeader(c, L));
    root.appendChild(tabBar(c, L, tab));

    const content = el('div', { class: 'lesson-content' });
    root.appendChild(content);

    // Render the selected tab
    const tabRenderers = {
      vocab:     () => renderVocabTab(L, content),
      dialogue:  () => renderDialogueTab(L, content),
      notes:     () => renderNotesTab(L, content),
      exercises: () => renderExercisesTab(L, content),
    };
    (tabRenderers[tab] || tabRenderers.vocab)();

    // Bottom nav: prev / next
    root.appendChild(lessonFootNav(c));

    render(root);
  }

  // ====== Header ======
  function lessonHeader(c, L) {
    const ls = lessonState(c.num);
    const phase = PHASES.find(p => p.id === c.phase);
    return el('header', { class: `lesson-header phase-${c.phase}` },
      el('div', { class: 'lesson-header-top' },
        el('a', { href: '#/', class: 'soft lesson-back' }, '← bàn học'),
        el('span', { class: 'eyebrow' }, `Bài ${String(c.num).padStart(2,'0')} / 32`),
        el('span', { class: 'eyebrow muted' }, '·'),
        el('span', { class: 'eyebrow muted' }, `Ngày ${c.date}`),
        el('span', { class: 'eyebrow muted' }, '·'),
        el('span', { class: 'eyebrow' }, phase ? `Giai đoạn ${phase.id} — ${phase.name}` : `Giai đoạn ${c.phase}`),
        el('span', { class: 'spacer' }),
        ls.completed
          ? el('span', { class: 'action-status done' }, '✓ xong rồi')
          : el('span', { class: 'action-status partial hidden' }, '')
      ),
      el('h1', { class: 'lesson-title' }, c.title)
    );
  }

  // ====== Tab bar ======
  function tabBar(c, L, currentTab) {
    const ls = lessonState(c.num);
    const counts = {
      vocab: L.vocab.length,
      dialogue: L.dialogue.lines.length,
      notes: L.notes.length,
      exercises: L.exercises.abcd.length + L.exercises.tf.length + L.exercises.fillblank.items.length + L.exercises.zh2vi.length + L.exercises.vi2zh.length
    };
    return el('nav', { class: 'lesson-tabs' },
      ...TABS.map(t => {
        const done = ls.tabsDone && ls.tabsDone[t.key];
        return el('a', {
          href: `#/lesson/${c.num}/${t.key}`,
          class: 'lesson-tab' + (currentTab === t.key ? ' active' : '') + (done ? ' done' : '')
        },
          el('span', { class: 'lt-zh hanzi' }, t.zh),
          el('span', { class: 'lt-vi' }, t.vi),
          counts[t.key] ? el('span', { class: 'lt-count' }, counts[t.key]) : null,
          done ? el('span', { class: 'lt-check', title: 'đã xong' }, '✓') : null
        );
      })
    );
  }

  function markTabDone(L, tabKey) {
    const ls = lessonState(L.num);
    if (!ls.tabsDone) ls.tabsDone = {};
    ls.tabsDone[tabKey] = true;
    // Auto-complete lesson if all 4 tabs done
    if (TABS.every(t => ls.tabsDone[t.key])) ls.completed = true;
    saveState();
  }

  // ====== Footer nav ======
  function lessonFootNav(c) {
    const prev = CURRICULUM.find(x => x.num === c.num - 1);
    const next = CURRICULUM.find(x => x.num === c.num + 1);
    return el('div', { class: 'lesson-footnav' },
      prev
        ? el('a', { href: '#/lesson/' + prev.num, class: 'foot-link' },
            el('span', { class: 'foot-arrow' }, '←'),
            el('div', null,
              el('div', { class: 'eyebrow' }, `Bài ${prev.num}`),
              el('div', null, prev.title)
            )
          )
        : el('div', null),
      next
        ? el('a', { href: '#/lesson/' + next.num, class: 'foot-link foot-right' },
            el('div', null,
              el('div', { class: 'eyebrow' }, `Bài ${next.num}`),
              el('div', null, next.title)
            ),
            el('span', { class: 'foot-arrow' }, '→')
          )
        : el('div', null)
    );
  }

  function notFound(msg) {
    return el('div', { class: 'panel' },
      el('a', { href: '#/', class: 'soft' }, '← bàn học'),
      el('h2', { style:{marginTop:'12px'} }, 'Không tìm thấy'),
      el('p', { class: 'soft' }, msg)
    );
  }

  function placeholderLesson(c) {
    const phase = PHASES.find(p => p.id === c.phase);
    return el('div', { class: `lesson phase-${c.phase}` },
      lessonHeader(c, { vocab: [], dialogue: { lines: [] }, notes: [], exercises: { abcd:[], tf:[], fillblank:{items:[]}, zh2vi:[], vi2zh:[] } }),
      el('div', { class: 'panel', style:{marginTop:'24px', textAlign:'center', padding:'60px 30px'} },
        el('div', { class: 'hand-note', style:{fontSize:'48px', marginBottom:'16px'} }, 'Chưa tới giờ'),
        el('p', { class: 'soft', style:{fontSize:'16px', maxWidth:'42ch', margin:'0 auto'} },
          `Bài này nằm trong ${phase ? phase.name : 'giai đoạn ' + c.phase} — nội dung sẽ được mở khoá vào ngày ${c.date}. Lo học mấy bài trước cho xong đã.`
        ),
        el('div', { style:{marginTop:'28px'} },
          el('a', { href: '#/', class: 'btn btn-primary' }, '← Về bàn học')
        )
      ),
      lessonFootNav(c)
    );
  }

  /* ============================================================
     TAB 1: VOCAB — Flashcard with Leitner SRS
     ============================================================ */
  function renderVocabTab(L, container) {
    if (L.vocab.length === 0) {
      container.appendChild(reviewOnlyNotice(L));
      return;
    }
    // Mode selector: flashcard vs list
    const wrap = el('div', { class: 'vocab-wrap' });
    container.appendChild(wrap);

    const ls = lessonState(L.num);
    const mode = ls.vocabMode || 'flash';

    const modeBar = el('div', { class: 'mode-bar' },
      el('button', { class: 'mode-btn' + (mode === 'flash' ? ' active' : ''),
                     onclick: () => { ls.vocabMode = 'flash'; saveState(); renderVocabTab(L, container); } },
        'Flashcard'),
      el('button', { class: 'mode-btn' + (mode === 'list' ? ' active' : ''),
                     onclick: () => { ls.vocabMode = 'list'; saveState(); renderVocabTab(L, container); } },
        'Danh sách'),
      el('span', { class: 'spacer' }),
      el('span', { class: 'soft', style:{fontSize:'13px'} }, `${L.vocab.length} từ`)
    );

    container.innerHTML = '';
    container.appendChild(modeBar);

    if (mode === 'flash') renderFlashcardMode(L, container);
    else renderVocabListMode(L, container);
  }

  function renderFlashcardMode(L, container) {
    const ls = lessonState(L.num);
    // Build session queue: prioritize words not yet seen (box 0/undefined), then due, then sorted by box
    const ed = XQ.epochDay();
    let queue = L.vocab.map((w, i) => {
      const s = ls.vocab[i] || { box: -1, due: 0 };
      return { idx: i, word: w, state: s };
    });
    // All new words + due words
    queue.sort((a, b) => {
      const ad = a.state.box < 0 ? 0 : (a.state.due <= ed ? 1 : 2);
      const bd = b.state.box < 0 ? 0 : (b.state.due <= ed ? 1 : 2);
      if (ad !== bd) return ad - bd;
      return a.idx - b.idx;
    });
    // If everything is "later" still show them this session (a single lesson study session shows all)
    const session = {
      queue,
      total: queue.length,
      idx: 0,
      flipped: false,
      finished: false,
      stats: { again: 0, good: 0, easy: 0 }
    };

    const stage = el('div', { class: 'flash-stage' });
    container.appendChild(stage);

    function render() {
      stage.innerHTML = '';
      if (session.finished || session.idx >= session.queue.length) {
        // Done screen
        markTabDone(L, 'vocab');
        const dist = session.stats;
        stage.appendChild(el('div', { class: 'flash-done paper-card' },
          el('div', { class: 'eyebrow' }, 'Xong session'),
          el('h2', { style:{margin:'10px 0 18px'} }, donePraise(dist)),
          el('div', { class: 'flash-done-stats' },
            el('div', null, el('div', { class: 'stat-num', style:{color:'var(--bad)'} }, dist.again),
              el('div', { class: 'stat-label' }, 'Lại từ đầu')),
            el('div', null, el('div', { class: 'stat-num', style:{color:'var(--gold)'} }, dist.good),
              el('div', { class: 'stat-label' }, 'Tạm được')),
            el('div', null, el('div', { class: 'stat-num', style:{color:'var(--good)'} }, dist.easy),
              el('div', { class: 'stat-label' }, 'Dễ')),
          ),
          el('div', { style:{marginTop:'24px', display:'flex', gap:'10px', justifyContent:'center'} },
            el('button', { class: 'btn', onclick: () => { session.idx = 0; session.flipped = false; session.finished = false; session.stats = { again:0,good:0,easy:0 }; render(); } },
              'Quẹt lại từ đầu'),
            el('a', { href: `#/lesson/${L.num}/dialogue`, class: 'btn btn-primary' },
              'Sang hội thoại →')
          )
        ));
        return;
      }

      const item = session.queue[session.idx];
      const w = item.word;
      const wordKey = `${L.num}-${item.idx}`;
      const stateInfo = ls.vocab[item.idx];
      const boxLabel = stateInfo && stateInfo.box >= 0 ? `Box ${stateInfo.box + 1}/5` : 'Mới';

      // Progress + counter
      const head = el('div', { class: 'flash-head' },
        el('div', { class: 'flash-counter' },
          el('span', { class: 'flash-counter-now' }, session.idx + 1),
          el('span', { class: 'soft' }, ` / ${session.total}`)
        ),
        el('div', { class: 'flash-progress' },
          el('div', { class: 'flash-progress-fill', style:{width: (100*(session.idx)/session.total) + '%'} })
        ),
        el('div', { class: 'chip' }, boxLabel)
      );

      // Card
      const card = el('div', { class: 'flashcard' + (session.flipped ? ' flipped' : ''),
                               onclick: () => { if (!session.flipped) { session.flipped = true; render(); } } },
        el('div', { class: 'flashcard-inner' },
          // FRONT
          el('div', { class: 'flashcard-face flashcard-front' },
            el('div', { class: 'flash-eyebrow' }, w.num + '. ' + (session.flipped ? '' : 'Đọc + dịch nghĩa')),
            el('div', { class: 'flash-hanzi hanzi' }, w.hanzi),
            el('div', { class: 'flash-pinyin-hint reveal',
                        onclick: (e) => { e.stopPropagation(); e.currentTarget.classList.toggle('revealed'); } },
              el('span', { class: 'soft', style:{fontSize:'13px'} }, 'Pinyin: '),
              el('span', { class: 'pinyin reveal-content' }, w.pinyin)
            ),
            el('div', { class: 'flash-tap-hint' }, 'tap để lật mặt sau')
          ),
          // BACK
          el('div', { class: 'flashcard-face flashcard-back' },
            el('div', { class: 'flash-eyebrow' }, w.num + '. Mặt sau'),
            el('div', { class: 'flash-hanzi-small hanzi' }, w.hanzi),
            el('div', { class: 'pinyin', style:{fontSize:'18px', textAlign:'center', margin:'4px 0 14px'} }, w.pinyin),
            el('div', { class: 'flash-vi' }, w.vi),
            el('div', { class: 'flash-explanation' }, w.explanation),
            w.example && w.example.zh ? el('div', { class: 'flash-example' },
              el('div', { class: 'flash-example-zh hanzi' }, w.example.zh),
              w.example.vi ? el('div', { class: 'flash-example-vi soft' }, w.example.vi) : null
            ) : null
          )
        )
      );

      // Quality buttons (only on back)
      const quality = el('div', { class: 'flash-quality' + (session.flipped ? '' : ' invisible') },
        qBtn('又错了', 'Lại từ đầu', 'q-again', () => answer('again')),
        qBtn('还行', 'Tạm được', 'q-good',  () => answer('good')),
        qBtn('简单', 'Dễ',       'q-easy',  () => answer('easy'))
      );

      const skip = el('div', { class: 'flash-skip' },
        el('button', { class: 'btn-ghost soft', style:{fontSize:'13px'},
                       onclick: () => { session.idx++; session.flipped = false; render(); } },
          'Bỏ qua →'),
        el('span', { class: 'spacer' }),
        session.flipped
          ? el('button', { class: 'btn-ghost soft', style:{fontSize:'13px'},
                          onclick: () => { session.flipped = false; render(); } },
              '← lật lại')
          : null
      );

      stage.appendChild(head);
      stage.appendChild(card);
      stage.appendChild(quality);
      stage.appendChild(skip);

      function answer(q) {
        XQ.srsReviewWord(wordKey, q);
        session.stats[q]++;
        if (q === 'again') {
          // re-insert later in this session
          const item = session.queue[session.idx];
          session.queue.splice(session.idx + 3, 0, item);
        }
        session.idx++;
        session.flipped = false;
        render();
      }
    }

    function donePraise(d) {
      if (d.again === 0) return 'Ngon đấy. Không quên nổi từ nào.';
      if (d.again <= 2) return 'Tàm tạm. Vài hôm nữa ôn lại là chắc.';
      if (d.again >= d.good + d.easy) return 'Yếu đấy. Tự thấy chứ nhỉ — mở lại làm lượt nữa.';
      return 'Có cố. Mai ôn tiếp đi.';
    }

    render();
  }

  function qBtn(zh, vi, cls, onclick) {
    return el('button', { class: `qbtn ${cls}`, onclick },
      el('div', { class: 'qbtn-zh hanzi' }, zh),
      el('div', { class: 'qbtn-vi' }, vi)
    );
  }

  function renderVocabListMode(L, container) {
    const ls = lessonState(L.num);
    const list = el('div', { class: 'vocab-list' });
    L.vocab.forEach((w, i) => {
      const s = ls.vocab[i];
      const boxLabel = s && s.box >= 0
        ? (s.box >= 3 ? '✓ thuộc' : `box ${s.box + 1}`)
        : '— mới';
      list.appendChild(el('div', { class: 'vocab-row' },
        el('div', { class: 'vocab-num' }, w.num),
        el('div', { class: 'vocab-zh hanzi' }, w.hanzi),
        el('div', { class: 'vocab-py pinyin reveal',
                    onclick: (e) => e.currentTarget.classList.toggle('revealed') },
          el('span', { class: 'reveal-content' }, w.pinyin)),
        el('div', { class: 'vocab-vi' }, w.vi),
        el('div', { class: 'vocab-state' }, boxLabel)
      ));
      // Explanation + example, collapsible
      const detail = el('details', { class: 'vocab-detail' },
        el('summary', null, 'Giải thích + ví dụ'),
        el('div', { class: 'vocab-explanation' }, w.explanation),
        w.example && w.example.zh ? el('div', { class: 'vocab-example' },
          el('span', { class: 'hanzi' }, w.example.zh),
          w.example.vi ? el('span', { class: 'soft', style:{marginLeft:'8px'} }, '— ' + w.example.vi) : null
        ) : null
      );
      list.appendChild(detail);
    });
    container.appendChild(list);

    // Mark vocab done if user reviewed list
    container.appendChild(el('div', { style:{marginTop:'24px', textAlign:'center'} },
      el('button', { class: 'btn btn-primary',
                     onclick: () => { markTabDone(L, 'vocab'); XQ.navTo(`/lesson/${L.num}/dialogue`); } },
        'Học xong từ → Sang hội thoại →')
    ));
  }

  function reviewOnlyNotice(L) {
    return el('div', { class: 'panel center', style:{padding:'40px'} },
      el('div', { class: 'hand-note', style:{fontSize:'36px', marginBottom:'12px'} }, 'Không có từ mới'),
      el('p', { class: 'soft' }, 'Bài này là bài tổng hợp — không có từ vựng mới, chỉ tái sử dụng các từ đã học. Xem thẳng vào hội thoại nhé.'),
      el('div', { style:{marginTop:'16px'} },
        el('a', { href: `#/lesson/${L.num}/dialogue`, class: 'btn btn-primary' },
          'Sang hội thoại →')
      )
    );
  }

  /* ============================================================
     TAB 2: DIALOGUE
     ============================================================ */
  function renderDialogueTab(L, container) {
    const D = L.dialogue;
    const root = el('div', { class: 'dialogue-wrap' });

    // Context + characters
    if (D.context || D.characters.length) {
      const ctx = el('div', { class: 'dialogue-context paper-card' },
        D.context
          ? el('div', null,
              el('span', { class: 'eyebrow', style:{marginRight:'6px'} }, 'Bối cảnh:'),
              el('span', null, D.context))
          : null,
        D.characters.length
          ? el('div', { class: 'dialogue-chars' },
              ...D.characters.map(ch =>
                el('div', { class: 'dialogue-char' },
                  el('span', { class: 'hanzi dialogue-char-name' }, ch.name),
                  el('span', { class: 'soft' }, ' — ' + ch.role))))
          : null
      );
      root.appendChild(ctx);
    }

    // Toggle: show/hide all VN
    let revealAll = false;
    const toolbar = el('div', { class: 'dialogue-toolbar' },
      el('span', { class: 'eyebrow' }, `${D.lines.length} lượt thoại`),
      el('span', { class: 'spacer' }),
      el('button', { class: 'btn btn-sm',
                     onclick: () => {
                       revealAll = !revealAll;
                       document.querySelectorAll('.dialogue-vi').forEach(e => {
                         e.classList.toggle('reveal-revealed', revealAll);
                       });
                     } },
        'Hiện/ẩn tất cả bản dịch')
    );
    root.appendChild(toolbar);

    // Color speakers consistently
    const speakerColors = {};
    let colorIdx = 0;
    const colors = ['var(--red)', 'var(--gold)', 'var(--good)', 'var(--ink-soft)'];
    function colorFor(s) {
      if (!speakerColors[s]) speakerColors[s] = colors[colorIdx++ % colors.length];
      return speakerColors[s];
    }

    const turns = el('div', { class: 'dialogue-turns' });
    D.lines.forEach((line, i) => {
      const color = colorFor(line.speaker);
      const turn = el('div', { class: 'dialogue-turn' },
        el('div', { class: 'dialogue-speaker hanzi', style:{color} }, line.speaker),
        el('div', { class: 'dialogue-body' },
          el('div', { class: 'dialogue-zh hanzi' }, line.zh),
          el('div', { class: 'dialogue-vi reveal',
                      onclick: (e) => e.currentTarget.classList.toggle('reveal-revealed') },
            el('span', { class: 'soft', style:{fontSize:'12px', textTransform:'uppercase', letterSpacing:'0.1em', marginRight:'6px'} }, 'VN:'),
            el('span', { class: 'reveal-content' }, line.vi))
        )
      );
      turns.appendChild(turn);
    });
    root.appendChild(turns);

    // Bottom: mark as done
    root.appendChild(el('div', { style:{marginTop:'28px', textAlign:'center'} },
      el('button', { class: 'btn btn-primary',
                     onclick: () => { markTabDone(L, 'dialogue'); XQ.navTo(`/lesson/${L.num}/notes`); } },
        'Đọc xong hội thoại → Sang ghi chú →')
    ));

    container.appendChild(root);
  }

  /* ============================================================
     TAB 3: NOTES
     ============================================================ */
  function renderNotesTab(L, container) {
    const root = el('div', { class: 'notes-wrap' });
    if (L.notes.length === 0) {
      root.appendChild(el('p', { class: 'soft' }, 'Bài này không có ghi chú thực tế.'));
    } else {
      L.notes.forEach((n, i) => {
        root.appendChild(el('article', { class: 'note-card paper-card' },
          el('div', { class: 'eyebrow' }, `Ghi chú ${i + 1}`),
          el('h3', { class: 'note-title' }, n.title),
          // Body — convert ZH bracketed terms to highlighted spans
          el('div', { class: 'note-body', html: highlightChinese(n.body) })
        ));
      });
    }
    root.appendChild(el('div', { style:{marginTop:'28px', textAlign:'center'} },
      el('button', { class: 'btn btn-primary',
                     onclick: () => { markTabDone(L, 'notes'); XQ.navTo(`/lesson/${L.num}/exercises`); } },
        'Đọc xong → Sang bài tập →')
    ));
    container.appendChild(root);
  }

  function highlightChinese(text) {
    // Escape HTML and wrap any consecutive CJK chars in styled spans
    const escaped = text
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return escaped.replace(/[\u4e00-\u9fff]+/g, m => `<span class="hanzi note-zh">${m}</span>`);
  }

  /* ============================================================
     TAB 4: EXERCISES
     ============================================================ */
  function renderExercisesTab(L, container) {
    const root = el('div', { class: 'ex-wrap' });

    // Build a unified ordered question list, shuffled by user's session seed
    const ls = lessonState(L.num);
    if (!ls.exerciseSeed) { ls.exerciseSeed = Math.floor(Math.random() * 1e9); saveState(); }
    const all = buildExerciseQuestions(L);

    // Shuffle deterministically by seed
    const shuffled = seededShuffle(all, ls.exerciseSeed);

    // Form state — stored in ls.exerciseAnswers (qNum -> answer)
    if (!ls.exerciseAnswers) ls.exerciseAnswers = {};
    if (typeof ls.exerciseSubmitted === 'undefined') ls.exerciseSubmitted = false;

    // Top bar
    root.appendChild(el('div', { class: 'ex-head' },
      el('div', { class: 'eyebrow' }, `Bài tập củng cố · ${all.length} câu`),
      el('span', { class: 'spacer' }),
      ls.exerciseSubmitted
        ? el('span', { class: 'chip chip-good' }, `Đã làm: ${Math.round(100 * (ls.score?.correct||0)/(ls.score?.total||1))}%`)
        : null,
      el('button', { class: 'btn btn-sm', onclick: () => {
        ls.exerciseAnswers = {};
        ls.exerciseSubmitted = false;
        ls.score = null;
        ls.exerciseSeed = Math.floor(Math.random() * 1e9);
        saveState();
        renderExercisesTab(L, (container.innerHTML = '', container));
      } }, 'Làm lại từ đầu')
    ));

    const list = el('div', { class: 'ex-list' });
    shuffled.forEach((q, i) => {
      list.appendChild(renderExQuestion(L, q, i, ls));
    });
    root.appendChild(list);

    // Submit / score
    const footer = el('div', { class: 'ex-footer' });
    if (ls.exerciseSubmitted) {
      footer.appendChild(el('div', { class: 'ex-score paper-card' },
        el('div', { class: 'eyebrow' }, 'Kết quả'),
        el('h2', { style:{margin:'8px 0', fontSize:'34px'} },
          `${ls.score.correct} / ${ls.score.total}`,
          el('span', { class: 'soft', style:{fontSize:'18px', marginLeft:'8px'} },
            ` — ${Math.round(100 * ls.score.correct / ls.score.total)}%`)
        ),
        el('p', { class: 'soft' }, scoreVerdict(ls.score.correct / ls.score.total)),
        el('div', { style:{marginTop:'16px', display:'flex', gap:'10px', justifyContent:'center'} },
          el('button', { class: 'btn', onclick: () => {
            ls.exerciseAnswers = {};
            ls.exerciseSubmitted = false;
            ls.score = null;
            ls.exerciseSeed = Math.floor(Math.random() * 1e9);
            saveState();
            renderExercisesTab(L, (container.innerHTML = '', container));
          } }, 'Làm lại'),
          CURRICULUM.find(c => c.num === L.num + 1)
            ? el('a', { href: `#/lesson/${L.num + 1}`, class: 'btn btn-primary' },
                'Sang bài tiếp →')
            : el('a', { href: '#/', class: 'btn btn-primary' }, 'Về bàn học →')
        )
      ));
    } else {
      footer.appendChild(el('div', { style:{marginTop:'30px', textAlign:'center'} },
        el('button', { class: 'btn btn-primary btn-lg', onclick: () => submit() }, 'Nộp bài →'),
        el('p', { class: 'soft', style:{marginTop:'10px', fontSize:'13px'} },
          'Các câu dịch sẽ tự đối chiếu đáp án — đánh giá tự thân.')
      ));
    }
    root.appendChild(footer);

    container.appendChild(root);

    function submit() {
      // Grade auto types: abcd, tf, fillblank
      let correct = 0, total = 0;
      for (const q of all) {
        if (q.type === 'abcd' || q.type === 'tf' || q.type === 'fill') {
          total++;
          const user = ls.exerciseAnswers[q.id];
          if (isCorrect(q, user)) correct++;
        }
      }
      ls.score = { correct, total, when: Date.now() };
      ls.exerciseSubmitted = true;
      markTabDone(L, 'exercises');
      saveState();
      renderExercisesTab(L, (container.innerHTML = '', container));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  function scoreVerdict(ratio) {
    if (ratio >= 0.95) return 'Tốt. Đừng nghỉ ngơi, sang bài tiếp đi.';
    if (ratio >= 0.8)  return 'Ổn. Xem lại mấy câu sai cho nhớ.';
    if (ratio >= 0.6)  return 'Tàm tạm. Đọc lại từ vựng + hội thoại rồi quay lại làm.';
    return 'Yếu. Học lại cả bài rồi mới qua bài tiếp được.';
  }

  function buildExerciseQuestions(L) {
    const ex = L.exercises, ans = L.answers;
    const out = [];
    ex.abcd.forEach(q => out.push({
      id: 'abcd-' + q.num, type: 'abcd', num: q.num,
      q: q.q, options: q.options, answer: ans.abcd[q.num]
    }));
    ex.tf.forEach(q => out.push({
      id: 'tf-' + q.num, type: 'tf', num: q.num,
      q: q.q, answer: ans.tf[q.num]
    }));
    ex.fillblank.items.forEach(q => out.push({
      id: 'fill-' + q.num, type: 'fill', num: q.num,
      q: q.q, wordbank: ex.fillblank.wordbank, answer: ans.fillblank[q.num]
    }));
    ex.zh2vi.forEach(q => out.push({
      id: 'zh2vi-' + q.num, type: 'zh2vi', num: q.num,
      q: q.q, answer: ans.zh2vi[q.num]
    }));
    ex.vi2zh.forEach(q => out.push({
      id: 'vi2zh-' + q.num, type: 'vi2zh', num: q.num,
      q: q.q, answer: ans.vi2zh[q.num]
    }));
    return out;
  }

  function isCorrect(q, user) {
    if (user == null) return false;
    if (q.type === 'abcd') return user === q.answer;
    if (q.type === 'tf') return user === !!q.answer;
    if (q.type === 'fill') {
      const u = XQ.normalizeStr(user);
      if (Array.isArray(q.answer)) {
        // multi-blank: user must include all answers separated by space/comma
        return q.answer.every(a => u.includes(XQ.normalizeStr(a)));
      }
      return u === XQ.normalizeStr(q.answer);
    }
    return false;
  }

  function renderExQuestion(L, q, idxInSession, ls) {
    const submitted = ls.exerciseSubmitted;
    const user = ls.exerciseAnswers[q.id];
    const correct = submitted ? isCorrect(q, user) : null;

    const typeLabel = {
      abcd: 'Trắc nghiệm',
      tf: 'Đúng / Sai',
      fill: 'Điền từ',
      zh2vi: 'Dịch Trung → Việt',
      vi2zh: 'Dịch Việt → Trung'
    }[q.type];

    const wrap = el('article', { class: 'ex-q' + (submitted ? (correct == null ? ' ex-q-self' : correct ? ' ex-q-right' : ' ex-q-wrong') : '') },
      el('div', { class: 'ex-q-head' },
        el('span', { class: 'eyebrow' }, `Câu ${idxInSession + 1} · ${typeLabel}`),
        submitted
          ? (correct == null
              ? el('span', { class: 'chip', style:{fontSize:'10px'} }, 'Tự chấm')
              : correct
                ? el('span', { class: 'chip chip-good', style:{fontSize:'10px'} }, '✓ Đúng')
                : el('span', { class: 'chip', style:{background:'rgba(178,58,42,.15)', color:'var(--bad)', borderColor:'rgba(178,58,42,.3)', fontSize:'10px'} }, '✗ Sai'))
          : null
      ),
      el('div', { class: q.type === 'zh2vi' ? 'ex-q-text hanzi' : 'ex-q-text' }, q.q)
    );

    if (q.type === 'abcd') {
      const opts = el('div', { class: 'ex-options' });
      ['A','B','C','D'].forEach(letter => {
        if (!q.options[letter]) return;
        const isSelected = user === letter;
        const isAnswer = submitted && q.answer === letter;
        const cls = 'ex-opt' + (isSelected ? ' selected' : '') +
                    (submitted && isAnswer ? ' answer' : '') +
                    (submitted && isSelected && !isAnswer ? ' wrong' : '');
        opts.appendChild(el('label', { class: cls },
          el('input', {
            type: 'radio',
            name: q.id,
            value: letter,
            checked: isSelected ? true : false,
            disabled: submitted,
            onchange: () => { ls.exerciseAnswers[q.id] = letter; saveState(); }
          }),
          el('span', { class: 'ex-opt-letter' }, letter),
          el('span', { class: 'ex-opt-text' }, q.options[letter])
        ));
      });
      wrap.appendChild(opts);
    }
    else if (q.type === 'tf') {
      const opts = el('div', { class: 'ex-options ex-options-tf' });
      [['true', 'Đúng', true], ['false', 'Sai', false]].forEach(([v, label, val]) => {
        const isSelected = user === val;
        const isAnswer = submitted && q.answer === val;
        const cls = 'ex-opt ex-opt-tf' + (isSelected ? ' selected' : '') +
                    (submitted && isAnswer ? ' answer' : '') +
                    (submitted && isSelected && !isAnswer ? ' wrong' : '');
        opts.appendChild(el('label', { class: cls },
          el('input', {
            type: 'radio',
            name: q.id,
            value: v,
            checked: isSelected ? true : false,
            disabled: submitted,
            onchange: () => { ls.exerciseAnswers[q.id] = val; saveState(); }
          }),
          el('span', { class: 'ex-opt-text' }, label)
        ));
      });
      wrap.appendChild(opts);
    }
    else if (q.type === 'fill') {
      const wb = el('div', { class: 'ex-wordbank' },
        el('span', { class: 'soft', style:{fontSize:'12px', marginRight:'6px'} }, 'Từ:'),
        ...q.wordbank.map(w => el('span', { class: 'wordbank-chip hanzi',
          onclick: () => {
            if (submitted) return;
            const cur = ls.exerciseAnswers[q.id] || '';
            ls.exerciseAnswers[q.id] = cur ? cur + ' ' + w : w;
            saveState();
            input.value = ls.exerciseAnswers[q.id];
          }}, w))
      );
      const input = el('input', {
        type: 'text', class: 'ex-input',
        placeholder: 'Nhập đáp án bằng chữ Hán...',
        value: user || '',
        disabled: submitted,
        oninput: (e) => { ls.exerciseAnswers[q.id] = e.target.value; saveState(); }
      });
      wrap.appendChild(wb);
      wrap.appendChild(input);
      if (submitted && !correct) {
        wrap.appendChild(el('div', { class: 'ex-correct' },
          el('span', { class: 'eyebrow' }, 'Đáp án:'), ' ',
          el('span', { class: 'hanzi' }, Array.isArray(q.answer) ? q.answer.join(' / ') : q.answer)
        ));
      }
    }
    else if (q.type === 'zh2vi' || q.type === 'vi2zh') {
      const textarea = el('textarea', {
        class: 'ex-textarea' + (q.type === 'vi2zh' ? ' hanzi' : ''),
        placeholder: q.type === 'zh2vi' ? 'Dịch sang tiếng Việt...' : 'Dịch sang tiếng Trung...',
        rows: 2,
        disabled: submitted,
        oninput: (e) => { ls.exerciseAnswers[q.id] = e.target.value; saveState(); }
      });
      textarea.value = user || '';
      wrap.appendChild(textarea);
      if (submitted) {
        wrap.appendChild(el('details', { class: 'ex-self-check', open: true },
          el('summary', null, 'Xem đáp án gợi ý'),
          el('div', { class: q.type === 'vi2zh' ? 'hanzi ex-answer-text' : 'ex-answer-text' }, q.answer || '(chưa có đáp án)')
        ));
      }
    }

    return wrap;
  }

  // Deterministic shuffle using simple LCG with a seed
  function seededShuffle(arr, seed) {
    const a = arr.slice();
    let s = seed >>> 0;
    function rnd() { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(rnd() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  XQ.views.lesson = lesson;
})();
