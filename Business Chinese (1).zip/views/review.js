/* ============================================================
   Review view — SRS due flashcards + mixed old exercises
   ============================================================ */
(function () {
  const { el, render, dueVocab, saveState, srsReviewWord, shuffle } = XQ;

  function review() {
    const due = dueVocab();
    const learnedLessons = LESSONS.filter(L => {
      const ls = XQ.state.lessons[L.num];
      return ls && Object.keys(ls.vocab || {}).length > 0;
    });

    const header = el('section', { class: 'roadmap-hero' },
      el('span', { class: 'eyebrow' }, 'Ôn tập'),
      el('h1', { class: 'dash-headline', style:{maxWidth:'24ch', margin:'10px 0 0'} },
        due.length === 0 && learnedLessons.length === 0
          ? 'Chưa có gì để ôn — học vài bài đã.'
          : 'Trả nợ trí nhớ.'),
      el('p', { class: 'soft', style:{maxWidth:'60ch', fontSize:'15px', marginTop:'12px'} },
        due.length > 0
          ? `${due.length} từ vựng tới hạn — quẹt qua một lượt rồi mới được nghỉ.`
          : learnedLessons.length > 0
            ? 'Không có từ tới hạn. Muốn ôn cho chắc thì tự rút ngẫu nhiên.'
            : 'Mở Bài 1 lên học đi đã.'
      )
    );

    const modeBar = el('div', { class: 'review-modebar' },
      modeBtn('Từ vựng SRS', () => runVocabReview(due, learnedLessons), true),
      modeBtn('Câu hỏi cũ', () => runExerciseReview(learnedLessons), false)
    );

    const stage = el('div', { id: 'review-stage' });

    render(el('div', null, header, modeBar, stage));

    // Default mode
    if (learnedLessons.length === 0) {
      stage.appendChild(emptyState());
    } else {
      runVocabReview(due, learnedLessons);
    }
  }

  function modeBtn(label, fn, active) {
    return el('button', {
      class: 'mode-btn' + (active ? ' active' : ''),
      onclick: (e) => {
        document.querySelectorAll('.review-modebar .mode-btn').forEach(b => b.classList.remove('active'));
        e.currentTarget.classList.add('active');
        fn();
      }
    }, label);
  }

  function emptyState() {
    return el('div', { class: 'panel center', style:{padding:'40px'} },
      el('p', { class: 'soft' }, 'Quay về bàn học → Bắt đầu bài 1.'),
      el('div', { style:{marginTop:'14px'} },
        el('a', { href: '#/lesson/1', class: 'btn btn-primary' }, 'Mở Bài 1')
      )
    );
  }

  /* ====== Vocab review ====== */
  function runVocabReview(due, learnedLessons) {
    const stage = document.getElementById('review-stage');
    stage.innerHTML = '';

    let queue;
    if (due.length > 0) {
      queue = shuffle(due);
    } else if (learnedLessons.length > 0) {
      // Take 15 random vocab from learned lessons
      const pool = [];
      for (const L of learnedLessons) {
        const ls = XQ.state.lessons[L.num];
        for (const [idx, v] of Object.entries(ls.vocab || {})) {
          if (idx >= L.vocab.length) continue;
          pool.push({ lessonId: L.num, idx: +idx, word: L.vocab[+idx], v });
        }
      }
      queue = shuffle(pool).slice(0, 15);
    } else {
      stage.appendChild(emptyState());
      return;
    }

    if (queue.length === 0) {
      stage.appendChild(emptyState());
      return;
    }

    runFlashcardSession(stage, queue, 'review');
  }

  function runFlashcardSession(stage, queue, sessionType) {
    const session = {
      queue: queue.slice(),
      total: queue.length,
      idx: 0,
      flipped: false,
      finished: false,
      stats: { again: 0, good: 0, easy: 0 }
    };

    function draw() {
      stage.innerHTML = '';
      if (session.finished || session.idx >= session.queue.length) {
        const d = session.stats;
        stage.appendChild(el('div', { class: 'flash-done paper-card' },
          el('div', { class: 'eyebrow' }, 'Xong session ôn'),
          el('h2', { style:{margin:'10px 0 16px'} }, donePraise(d)),
          el('div', { class: 'flash-done-stats' },
            el('div', null, el('div', { class: 'stat-num', style:{color:'var(--bad)'} }, d.again),
              el('div', { class: 'stat-label' }, 'Lại từ đầu')),
            el('div', null, el('div', { class: 'stat-num', style:{color:'var(--gold)'} }, d.good),
              el('div', { class: 'stat-label' }, 'Tạm được')),
            el('div', null, el('div', { class: 'stat-num', style:{color:'var(--good)'} }, d.easy),
              el('div', { class: 'stat-label' }, 'Dễ'))
          ),
          el('div', { style:{marginTop:'24px', display:'flex', gap:'10px', justifyContent:'center'} },
            el('a', { href: '#/', class: 'btn' }, 'Về bàn học'),
            el('button', { class: 'btn btn-primary',
                          onclick: () => XQ.views.review() },
              'Ôn lượt nữa')
          )
        ));
        return;
      }
      const item = session.queue[session.idx];
      const w = item.word;
      const wordKey = `${item.lessonId}-${item.idx}`;
      const L = LESSONS.find(x => x.num === item.lessonId);

      const head = el('div', { class: 'flash-head' },
        el('div', { class: 'flash-counter' },
          el('span', { class: 'flash-counter-now' }, session.idx + 1),
          el('span', { class: 'soft' }, ` / ${session.total}`)
        ),
        el('div', { class: 'flash-progress' },
          el('div', { class: 'flash-progress-fill', style:{width: (100*session.idx/session.total) + '%'} })
        ),
        el('a', { class: 'chip', href: `#/lesson/${item.lessonId}`,
                  title: L ? L.title : '' }, `Bài ${item.lessonId}`)
      );

      const card = el('div', { class: 'flashcard' + (session.flipped ? ' flipped' : ''),
                               onclick: () => { if (!session.flipped) { session.flipped = true; draw(); } } },
        el('div', { class: 'flashcard-inner' },
          el('div', { class: 'flashcard-face flashcard-front' },
            el('div', { class: 'flash-eyebrow' }, session.flipped ? '' : 'Đọc + dịch nghĩa'),
            el('div', { class: 'flash-hanzi hanzi' }, w.hanzi),
            el('div', { class: 'flash-pinyin-hint reveal',
                        onclick: (e) => { e.stopPropagation(); e.currentTarget.classList.toggle('revealed'); } },
              el('span', { class: 'soft', style:{fontSize:'13px'} }, 'Pinyin: '),
              el('span', { class: 'pinyin reveal-content' }, w.pinyin)
            ),
            el('div', { class: 'flash-tap-hint' }, 'tap để lật mặt sau')
          ),
          el('div', { class: 'flashcard-face flashcard-back' },
            el('div', { class: 'flash-eyebrow' }, `Bài ${item.lessonId} · ${L ? L.title : ''}`),
            el('div', { class: 'flash-hanzi-small hanzi' }, w.hanzi),
            el('div', { class: 'pinyin', style:{fontSize:'18px', textAlign:'center', margin:'4px 0 14px'} }, w.pinyin),
            el('div', { class: 'flash-vi' }, w.vi),
            el('div', { class: 'flash-explanation' }, w.explanation),
            w.example && w.example.zh ? el('div', { class: 'flash-example' },
              el('div', { class: 'flash-example-zh hanzi' }, w.example.zh),
              w.example.vi ? el('div', { class: 'flash-example-vi soft' }, w.example.vi) : null
            ) : null
          )
        )
      );

      const quality = el('div', { class: 'flash-quality' + (session.flipped ? '' : ' invisible') },
        qBtn('又错了', 'Lại từ đầu', 'q-again', () => answer('again')),
        qBtn('还行', 'Tạm được', 'q-good',  () => answer('good')),
        qBtn('简单', 'Dễ',       'q-easy',  () => answer('easy'))
      );

      const skip = el('div', { class: 'flash-skip' },
        el('button', { class: 'btn-ghost soft', style:{fontSize:'13px'},
                       onclick: () => { session.idx++; session.flipped = false; draw(); } },
          'Bỏ qua →'),
        el('span', { class: 'spacer' }),
        session.flipped
          ? el('button', { class: 'btn-ghost soft', style:{fontSize:'13px'},
                          onclick: () => { session.flipped = false; draw(); } },
              '← lật lại')
          : null
      );

      stage.appendChild(head);
      stage.appendChild(el('div', { class: 'flash-stage' }, card, quality, skip));

      function answer(q) {
        srsReviewWord(wordKey, q);
        session.stats[q]++;
        if (q === 'again') {
          const item = session.queue[session.idx];
          session.queue.splice(session.idx + 3, 0, item);
        }
        session.idx++;
        session.flipped = false;
        draw();
      }
    }

    draw();
  }

  function donePraise(d) {
    if (d.again === 0) return 'Trí nhớ ổn ra phết.';
    if (d.again <= 2) return 'Vài chỗ lung lay. Mai làm lại.';
    return 'Chưa thuộc đâu — đừng tự lừa mình.';
  }

  function qBtn(zh, vi, cls, onclick) {
    return el('button', { class: `qbtn ${cls}`, onclick },
      el('div', { class: 'qbtn-zh hanzi' }, zh),
      el('div', { class: 'qbtn-vi' }, vi)
    );
  }

  /* ====== Exercise review ====== */
  function runExerciseReview(learnedLessons) {
    const stage = document.getElementById('review-stage');
    stage.innerHTML = '';

    if (learnedLessons.length === 0) {
      stage.appendChild(emptyState());
      return;
    }

    // Pull random ABCD + TF questions (auto-gradable only) from learned lessons
    const pool = [];
    for (const L of learnedLessons) {
      const ls = XQ.state.lessons[L.num];
      if (!ls) continue;
      const ans = L.answers;
      L.exercises.abcd.forEach(q => pool.push({
        type: 'abcd', lessonId: L.num, num: q.num,
        q: q.q, options: q.options, answer: ans.abcd[q.num]
      }));
      L.exercises.tf.forEach(q => pool.push({
        type: 'tf', lessonId: L.num, num: q.num,
        q: q.q, answer: ans.tf[q.num]
      }));
      L.exercises.fillblank.items.forEach(q => pool.push({
        type: 'fill', lessonId: L.num, num: q.num,
        q: q.q, wordbank: L.exercises.fillblank.wordbank, answer: ans.fillblank[q.num]
      }));
    }

    if (pool.length === 0) {
      stage.appendChild(emptyState());
      return;
    }

    const N = Math.min(15, pool.length);
    const questions = shuffle(pool).slice(0, N);
    const session = {
      questions,
      idx: 0,
      answers: {},
      submitted: false,
      correct: 0
    };

    function draw() {
      stage.innerHTML = '';
      if (session.submitted) {
        // Results
        const score = session.correct;
        stage.appendChild(el('div', { class: 'flash-done paper-card', style:{padding:'40px'} },
          el('div', { class: 'eyebrow' }, 'Kết quả ôn'),
          el('h2', { style:{margin:'10px 0 18px', fontSize:'40px'} },
            `${score} / ${session.questions.length}`,
            el('span', { class: 'soft', style:{fontSize:'20px', marginLeft:'8px'} },
              ` — ${Math.round(100 * score / session.questions.length)}%`)
          ),
          el('p', { class: 'soft' }, scoreVerdict(score / session.questions.length)),
          el('div', { style:{marginTop:'20px', display:'flex', gap:'10px', justifyContent:'center', flexWrap:'wrap'} },
            el('button', { class: 'btn', onclick: () => XQ.views.review() }, 'Ôn lượt nữa'),
            el('a', { href: '#/', class: 'btn btn-primary' }, 'Về bàn học')
          )
        ));
        return;
      }

      // Single question view
      const q = session.questions[session.idx];
      stage.appendChild(el('div', { class: 'flash-head' },
        el('div', { class: 'flash-counter' },
          el('span', { class: 'flash-counter-now' }, session.idx + 1),
          el('span', { class: 'soft' }, ` / ${session.questions.length}`)
        ),
        el('div', { class: 'flash-progress' },
          el('div', { class: 'flash-progress-fill',
            style:{width: (100*session.idx/session.questions.length) + '%'} })
        ),
        el('a', { class: 'chip', href: `#/lesson/${q.lessonId}` }, `Bài ${q.lessonId}`)
      ));

      const qWrap = el('article', { class: 'ex-q', style:{marginBottom:'14px'} },
        el('div', { class: 'eyebrow', style:{marginBottom:'8px'} },
          typeLabel(q.type)),
        el('div', { class: 'ex-q-text' + (q.type === 'fill' ? ' hanzi' : '') }, q.q)
      );

      if (q.type === 'abcd') {
        const opts = el('div', { class: 'ex-options' });
        ['A','B','C','D'].forEach(letter => {
          if (!q.options[letter]) return;
          opts.appendChild(el('label', { class: 'ex-opt' + (session.answers[session.idx] === letter ? ' selected' : '') },
            el('input', { type: 'radio', name: 'rq' + session.idx, value: letter,
                          checked: session.answers[session.idx] === letter ? true : false,
                          onchange: () => { session.answers[session.idx] = letter; draw(); } }),
            el('span', { class: 'ex-opt-letter' }, letter),
            el('span', { class: 'ex-opt-text' }, q.options[letter])
          ));
        });
        qWrap.appendChild(opts);
      } else if (q.type === 'tf') {
        const opts = el('div', { class: 'ex-options ex-options-tf' });
        [['Đúng', true], ['Sai', false]].forEach(([label, val]) => {
          opts.appendChild(el('label', { class: 'ex-opt ex-opt-tf' + (session.answers[session.idx] === val ? ' selected' : '') },
            el('input', { type: 'radio', name: 'rq' + session.idx, value: String(val),
                          checked: session.answers[session.idx] === val ? true : false,
                          onchange: () => { session.answers[session.idx] = val; draw(); } }),
            el('span', { class: 'ex-opt-text' }, label)
          ));
        });
        qWrap.appendChild(opts);
      } else if (q.type === 'fill') {
        const wb = el('div', { class: 'ex-wordbank' },
          el('span', { class: 'soft', style:{fontSize:'12px', marginRight:'6px'} }, 'Từ:'),
          ...q.wordbank.map(w => el('span', { class: 'wordbank-chip hanzi',
            onclick: () => {
              const cur = session.answers[session.idx] || '';
              session.answers[session.idx] = cur ? cur + ' ' + w : w;
              input.value = session.answers[session.idx];
            }}, w))
        );
        const input = el('input', {
          type: 'text', class: 'ex-input',
          placeholder: 'Nhập đáp án bằng chữ Hán...',
          value: session.answers[session.idx] || '',
          oninput: (e) => { session.answers[session.idx] = e.target.value; }
        });
        qWrap.appendChild(wb);
        qWrap.appendChild(input);
      }
      stage.appendChild(qWrap);

      // Nav buttons
      const nav = el('div', { style:{display:'flex', gap:'10px', marginTop:'16px'} },
        session.idx > 0
          ? el('button', { class: 'btn', onclick: () => { session.idx--; draw(); } }, '← câu trước')
          : el('div', null),
        el('span', { class: 'spacer' }),
        session.idx < session.questions.length - 1
          ? el('button', { class: 'btn btn-primary', onclick: () => { session.idx++; draw(); } },
              'câu tiếp →')
          : el('button', { class: 'btn btn-primary', onclick: () => grade() },
              'Nộp bài →')
      );
      stage.appendChild(nav);
    }

    function grade() {
      let correct = 0;
      session.questions.forEach((q, i) => {
        const u = session.answers[i];
        if (u == null) return;
        if (q.type === 'abcd' && u === q.answer) correct++;
        else if (q.type === 'tf' && u === !!q.answer) correct++;
        else if (q.type === 'fill') {
          const norm = XQ.normalizeStr(u);
          if (Array.isArray(q.answer)) {
            if (q.answer.every(a => norm.includes(XQ.normalizeStr(a)))) correct++;
          } else if (norm === XQ.normalizeStr(q.answer)) correct++;
        }
      });
      session.correct = correct;
      session.submitted = true;
      draw();
    }

    draw();
  }

  function typeLabel(t) {
    return { abcd: 'Trắc nghiệm', tf: 'Đúng / Sai', fill: 'Điền từ' }[t] || '';
  }

  function scoreVerdict(r) {
    if (r >= 0.9) return 'Ổn lắm. Giờ về làm bài mới.';
    if (r >= 0.7) return 'Đỡ rồi. Vài chỗ vẫn lung lay.';
    return 'Học lại bài cũ trước khi tiếp đi.';
  }

  XQ.views.review = review;
})();
