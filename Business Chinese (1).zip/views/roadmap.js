/* ============================================================
   Roadmap view — visual 32-day timeline grouped by phase
   ============================================================ */
(function () {
  const { el, render, todayLessonNum } = XQ;

  function roadmap() {
    const todayN = todayLessonNum();

    const header = el('section', { class: 'roadmap-hero' },
      el('span', { class: 'eyebrow' }, 'Lộ trình · 32 ngày'),
      el('h1', { class: 'dash-headline', style:{maxWidth:'24ch', margin:'10px 0 0'} },
        'Từ chào hỏi đến đàm phán FDI — đúng một tháng.'),
      el('p', { class: 'soft', style:{maxWidth:'60ch', fontSize:'15px', marginTop:'12px'} },
        'Mỗi ngày một bài. 12 bài nền tảng dùng được mọi ngành, rồi 4 ngành chuyên: nội thất / mỹ phẩm / thời trang, điện tử, năng lượng xanh. Bài cuối là kiểm tra thực chiến.')
    );

    const phaseBlocks = el('section', { class: 'roadmap-phases' });
    PHASES.forEach(p => {
      const lessons = CURRICULUM.filter(c => c.phase === p.id);
      const completed = lessons.filter(c => XQ.state.lessons[c.num]?.completed).length;
      const isActive = lessons.some(c => c.num === todayN);
      phaseBlocks.appendChild(
        el('section', { class: `roadmap-phase phase-${p.id}` + (isActive ? ' is-active' : '') },
          el('div', { class: 'roadmap-phase-head' },
            el('div', null,
              el('span', { class: 'eyebrow' }, `Giai đoạn ${p.id}`),
              el('h2', { class: 'roadmap-phase-name' }, p.name)
            ),
            el('div', { class: 'roadmap-phase-meta' },
              el('div', { class: 'hanzi', style:{fontSize:'22px', color:'var(--phase)', textAlign:'right'} }, p.zh),
              el('div', { class: 'soft', style:{fontSize:'13px'} }, `${p.range} · ${completed}/${lessons.length} xong`)
            )
          ),
          el('div', { class: 'roadmap-lessons' },
            ...lessons.map(c => roadmapLessonCard(c, todayN))
          )
        )
      );
    });

    render(el('div', null, header, phaseBlocks));
  }

  function roadmapLessonCard(c, todayN) {
    const ls = XQ.state.lessons[c.num];
    const L = LESSONS.find(x => x.num === c.num);
    const completed = ls && ls.completed;
    const started = ls && ls.startedAt && !completed;
    const inFuture = c.num > todayN;
    const isToday = c.num === todayN;
    const hasContent = !!L;

    let statusLabel = '';
    let statusKind = '';
    if (completed) { statusLabel = '✓ xong'; statusKind = 'done'; }
    else if (started) { statusLabel = 'đang dở'; statusKind = 'partial'; }
    else if (isToday) { statusLabel = 'hôm nay'; statusKind = 'today'; }
    else if (!hasContent) { statusLabel = 'sắp tới'; statusKind = 'future'; }
    else if (inFuture) { statusLabel = 'chưa tới ngày'; statusKind = 'future'; }
    else { statusLabel = 'chưa làm'; statusKind = ''; }

    return el('a', { href: `#/lesson/${c.num}`, class: `roadmap-lesson rl-${statusKind}` },
      el('div', { class: 'rl-num hanzi' }, String(c.num).padStart(2, '0')),
      el('div', { class: 'rl-body' },
        el('div', { class: 'rl-meta' },
          el('span', { class: 'rl-date' }, c.date),
          el('span', { class: 'rl-dot-sep' }, '·'),
          el('span', { class: `rl-status rl-status-${statusKind}` }, statusLabel)
        ),
        el('div', { class: 'rl-title' }, c.title),
        hasContent
          ? el('div', { class: 'rl-stats' },
              L.vocab.length ? `${L.vocab.length} từ` : 'tổng hợp',
              ' · ',
              `${L.dialogue.lines.length} câu thoại`,
              ' · ',
              '30 bài tập'
            )
          : el('div', { class: 'rl-stats soft' }, 'nội dung sắp được mở khoá')
      )
    );
  }

  XQ.views.roadmap = roadmap;
})();
