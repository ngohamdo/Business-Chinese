// tweaks.jsx
// 牛逼清恒 — Tweaks for the cozy modern theme.
// Three expressive controls that reshape the feel:
//   • Mood       — full palette + dark mode
//   • Personality — radii + shadow shapes
//   • Ambience   — background atmosphere

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "mood": "cozy",
  "personality": "soft",
  "ambience": "glow"
}/*EDITMODE-END*/;

function applyTweaks(t) {
  const root = document.documentElement;
  root.dataset.mood = t.mood;
  root.dataset.personality = t.personality;
  root.dataset.ambience = t.ambience;
}

// Mood swatches — first color is the bg, second the accent, third the ink
const MOOD_SWATCHES = {
  cozy:   ['#F5EFE3', '#E25A1F', '#15110D'],
  citrus: ['#FFF6E6', '#FF6A1A', '#1F1612'],
  sage:   ['#F0F3EC', '#4A8F6A', '#1A211C'],
  mocha:  ['#1F1915', '#FF9248', '#F5EFE3'],
};

function MoodSwatch({ mood, active, onClick }) {
  const [bg, accent, ink] = MOOD_SWATCHES[mood];
  return (
    <button
      type="button"
      onClick={onClick}
      title={mood}
      style={{
        flex: 1,
        height: 56,
        border: active ? '2px solid var(--tw-accent, #15110D)' : '1px solid rgba(0,0,0,.08)',
        borderRadius: 14,
        background: bg,
        cursor: 'pointer',
        padding: 0,
        position: 'relative',
        overflow: 'hidden',
        outline: 'none',
        transition: 'transform .12s, border-color .12s',
        transform: active ? 'scale(1)' : 'scale(.98)',
      }}
    >
      <div style={{
        position: 'absolute', inset: 6,
        borderRadius: 10,
        background: `linear-gradient(135deg, ${bg} 0%, ${bg} 50%, ${accent} 50%, ${accent} 100%)`,
      }} />
      <div style={{
        position: 'absolute', bottom: 6, left: 6,
        fontSize: 9, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase',
        color: ink, fontFamily: 'Space Grotesk, system-ui, sans-serif',
        padding: '1px 5px', background: 'rgba(255,255,255,.65)',
        borderRadius: 4,
      }}>{mood}</div>
    </button>
  );
}

function MoodPicker({ value, onChange }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{
        fontSize: 11, fontWeight: 600,
        letterSpacing: '0.06em', textTransform: 'uppercase',
        color: 'var(--tw-muted, #888)',
      }}>Mood</div>
      <div style={{ display: 'flex', gap: 8 }}>
        {Object.keys(MOOD_SWATCHES).map(m => (
          <MoodSwatch key={m} mood={m} active={value === m} onClick={() => onChange(m)} />
        ))}
      </div>
    </div>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  React.useEffect(() => applyTweaks(t), [t]);

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Reshape the vibe" />
      <MoodPicker value={t.mood} onChange={(v) => setTweak('mood', v)} />

      <TweakRadio
        label="Personality"
        value={t.personality}
        options={['soft', 'crisp', 'pillowy']}
        onChange={(v) => setTweak('personality', v)}
      />

      <TweakRadio
        label="Ambience"
        value={t.ambience}
        options={['glow', 'calm', 'paper', 'aurora']}
        onChange={(v) => setTweak('ambience', v)}
      />
    </TweaksPanel>
  );
}

// Apply tweaks on initial load (before edit mode is activated) so the saved
// preferences take effect immediately.
(function bootstrapTweaks() {
  try {
    const saved = JSON.parse(localStorage.getItem('tweaks') || 'null');
    applyTweaks({ ...TWEAK_DEFAULTS, ...(saved || {}) });
  } catch (e) {
    applyTweaks(TWEAK_DEFAULTS);
  }
})();

const mountEl = document.getElementById('tweaks-root');
if (mountEl) {
  ReactDOM.createRoot(mountEl).render(<App />);
}
